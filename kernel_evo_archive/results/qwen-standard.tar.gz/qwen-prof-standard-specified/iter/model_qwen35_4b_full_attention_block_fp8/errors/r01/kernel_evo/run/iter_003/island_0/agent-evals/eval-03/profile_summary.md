# B300 device profile of your last candidate

- device: NVIDIA B300 SXM6 AC, 148 SMs, 232448 B opt-in shared memory/block
- GPU busy: 3065.620 ms total; kernels 3065.582 ms over 680 launches of 53 distinct names
- memcpy: 0.036 ms over 17 calls; memset: 0.002 ms over 2 calls

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_mlp_gateup_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgme… | 1160.950 | 55 | 37.9 |
| kernel_cutlass_qkv_proj_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 857.139 | 55 | 28.0 |
| kernel_cutlass_mlp_down_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 600.691 | 55 | 19.6 |
| kernel_cutlass_out_proj_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 339.608 | 55 | 11.1 |
| kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 98.637 | 55 | 3.2 |
| kernel_cutlass_q_rope_norm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo25… | 2.700 | 55 | 0.1 |
| kernel_cutlass_rms_norm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo25601… | 2.547 | 55 | 0.1 |
| kernel_cutlass_mlp_norm_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo25601_tensorptrf8… | 1.714 | 55 | 0.1 |
| kernel_cutlass_k_rope_norm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo25… | 0.754 | 55 | 0.0 |
| kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 0.167 | 19 | 0.0 |
