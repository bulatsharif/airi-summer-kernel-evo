import cutlass
import cutlass.cute as cute


# ---------------------------------------------------------------------------
# Qwen3.5-4B dimensions (task contract)
# ---------------------------------------------------------------------------
TOKENS = 128
HIDDEN_SIZE = 2560
NUM_HEADS = 16
NUM_KV_HEADS = 4
HEAD_DIM = 256
ROTARY_DIM = 64
HALF = 32
INTERMEDIATE_SIZE = 9216
EPSILON = 1.0e-6
ATTN_SCALE = 1.0 / 16.0

Q_GATE_SIZE = 2 * NUM_HEADS * HEAD_DIM     # 8192
KV_SIZE = NUM_KV_HEADS * HEAD_DIM          # 1024
QUERY_SIZE = NUM_HEADS * HEAD_DIM          # 4096

BLOCK_T = 128

# ---------------------------------------------------------------------------
# Fixed requantization scales (starter.py convention)
# ---------------------------------------------------------------------------
NORM_SCALE = 1.0 / 64.0
QKV_SCALE = 1.0 / 64.0
CONTEXT_SCALE = 1.0 / 64.0
MLP_PROJECTION_SCALE = 1.0 / 64.0
MLP_ACTIVATION_SCALE = 1.0 / 32.0
WEIGHT_H_SCALE = HIDDEN_SIZE ** -0.5 / 448.0
WEIGHT_CONTEXT_SCALE = QUERY_SIZE ** -0.5 / 448.0
WEIGHT_MLP_SCALE = INTERMEDIATE_SIZE ** -0.5 / 448.0
FP8_DTYPE = cutlass.Float8E4M3FN


# ---------------------------------------------------------------------------
# 1. Pre-norm: n = rms_norm(src, weight); reused for pre-norm and post-norm.
#    Requires a block-wide reduction over the full row (HIDDEN_SIZE cols).
# ---------------------------------------------------------------------------
@cute.kernel
def rms_norm_kernel(
    src: cute.Tensor,
    weight: cute.Tensor,
    output: cute.Tensor,
):
    tid, _, _ = cute.arch.thread_idx()
    bx, _, _ = cute.arch.block_idx()

    acc = cutlass.Float32(0.0)
    for j in cutlass.range(HIDDEN_SIZE):
        v = src[bx, j].to(cutlass.Float32)
        acc += v * v
    mean = acc / cutlass.Float32(float(HIDDEN_SIZE))
    inv = cute.rsqrt(mean + cutlass.Float32(EPSILON))

    for chunk in cutlass.range(HIDDEN_SIZE // BLOCK_T):
        i = chunk * BLOCK_T + tid
        w = weight[i].to(cutlass.Float32)
        n = src[bx, i].to(cutlass.Float32) * inv * (cutlass.Float32(1.0) + w)
        output[bx, i] = FP8_DTYPE(n / cutlass.Float32(NORM_SCALE))


# ---------------------------------------------------------------------------
# 2. Q/gate, K, V projections: y = n1 @ W
# ---------------------------------------------------------------------------
@cute.kernel
def qkv_proj_kernel(
    n1: cute.Tensor,
    q_gate_weight: cute.Tensor,
    k_weight: cute.Tensor,
    v_weight: cute.Tensor,
    q_gate_workspace: cute.Tensor,
    k_workspace: cute.Tensor,
    v_workspace: cute.Tensor,
):
    tid, _, _ = cute.arch.thread_idx()
    bx, _, _ = cute.arch.block_idx()

    for chunk in cutlass.range(Q_GATE_SIZE // BLOCK_T):
        n = chunk * BLOCK_T + tid
        acc = cutlass.Float32(0.0)
        for k in cutlass.range(HIDDEN_SIZE):
            a = n1[bx, k].to(cutlass.Float32) * cutlass.Float32(NORM_SCALE)
            w = q_gate_weight[n, k].to(cutlass.Float32) * cutlass.Float32(WEIGHT_H_SCALE)
            acc += a * w
        q_gate_workspace[bx, n] = FP8_DTYPE(acc / cutlass.Float32(QKV_SCALE))

    for chunk in cutlass.range(KV_SIZE // BLOCK_T):
        n = chunk * BLOCK_T + tid
        acc = cutlass.Float32(0.0)
        for k in cutlass.range(HIDDEN_SIZE):
            a = n1[bx, k].to(cutlass.Float32) * cutlass.Float32(NORM_SCALE)
            w = k_weight[n, k].to(cutlass.Float32) * cutlass.Float32(WEIGHT_H_SCALE)
            acc += a * w
        k_workspace[bx, n] = FP8_DTYPE(acc / cutlass.Float32(QKV_SCALE))

    for chunk in cutlass.range(KV_SIZE // BLOCK_T):
        n = chunk * BLOCK_T + tid
        acc = cutlass.Float32(0.0)
        for k in cutlass.range(HIDDEN_SIZE):
            a = n1[bx, k].to(cutlass.Float32) * cutlass.Float32(NORM_SCALE)
            w = v_weight[n, k].to(cutlass.Float32) * cutlass.Float32(WEIGHT_H_SCALE)
            acc += a * w
        v_workspace[bx, n] = FP8_DTYPE(acc / cutlass.Float32(QKV_SCALE))


# ---------------------------------------------------------------------------
# 3. Q head-norm + RoPE.
# ---------------------------------------------------------------------------
@cute.kernel
def q_rope_norm_kernel(
    q_gate_workspace: cute.Tensor,
    q_norm_weight: cute.Tensor,
    cos: cute.Tensor,
    sin: cute.Tensor,
    query_workspace: cute.Tensor,
):
    tid, _, _ = cute.arch.thread_idx()
    bx, _, _ = cute.arch.block_idx()
    t = bx // NUM_HEADS
    h = bx % NUM_HEADS
    base = h * (2 * HEAD_DIM)

    acc = cutlass.Float32(0.0)
    for d in cutlass.range(HEAD_DIM):
        qv = q_gate_workspace[t, base + d].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE)
        acc += qv * qv
    mean = acc / cutlass.Float32(float(HEAD_DIM))
    inv = cute.rsqrt(mean + cutlass.Float32(EPSILON))

    d = tid
    qself = q_gate_workspace[t, base + d].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE)
    wself = q_norm_weight[d].to(cutlass.Float32)
    qself = qself * inv * (cutlass.Float32(1.0) + wself)

    qr = qself
    if d < HALF:
        qpair = q_gate_workspace[t, base + d + HALF].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE)
        wpair = q_norm_weight[d + HALF].to(cutlass.Float32)
        qpair = qpair * inv * (cutlass.Float32(1.0) + wpair)
        c = cos[t, d].to(cutlass.Float32)
        s = sin[t, d].to(cutlass.Float32)
        qr = qself * c - qpair * s
    else:
        if d < ROTARY_DIM:
            qpair = q_gate_workspace[t, base + d - HALF].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE)
            wpair = q_norm_weight[d - HALF].to(cutlass.Float32)
            qpair = qpair * inv * (cutlass.Float32(1.0) + wpair)
            c = cos[t, d].to(cutlass.Float32)
            s = sin[t, d].to(cutlass.Float32)
            qr = qself * c + qpair * s

    query_workspace[t, h * HEAD_DIM + d] = FP8_DTYPE(qr / cutlass.Float32(QKV_SCALE))


# ---------------------------------------------------------------------------
# 4. K head-norm + RoPE (shared KV heads).
# ---------------------------------------------------------------------------
@cute.kernel
def k_rope_norm_kernel(
    k_workspace: cute.Tensor,
    k_norm_weight: cute.Tensor,
    cos: cute.Tensor,
    sin: cute.Tensor,
    key_workspace: cute.Tensor,
):
    tid, _, _ = cute.arch.thread_idx()
    bx, _, _ = cute.arch.block_idx()
    t = bx // NUM_KV_HEADS
    h = bx % NUM_KV_HEADS
    base = h * HEAD_DIM

    acc = cutlass.Float32(0.0)
    for d in cutlass.range(HEAD_DIM):
        kv = k_workspace[t, base + d].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE)
        acc += kv * kv
    mean = acc / cutlass.Float32(float(HEAD_DIM))
    inv = cute.rsqrt(mean + cutlass.Float32(EPSILON))

    d = tid
    kself = k_workspace[t, base + d].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE)
    wself = k_norm_weight[d].to(cutlass.Float32)
    kself = kself * inv * (cutlass.Float32(1.0) + wself)

    kr = kself
    if d < HALF:
        kpair = k_workspace[t, base + d + HALF].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE)
        wpair = k_norm_weight[d + HALF].to(cutlass.Float32)
        kpair = kpair * inv * (cutlass.Float32(1.0) + wpair)
        c = cos[t, d].to(cutlass.Float32)
        s = sin[t, d].to(cutlass.Float32)
        kr = kself * c - kpair * s
    else:
        if d < ROTARY_DIM:
            kpair = k_workspace[t, base + d - HALF].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE)
            wpair = k_norm_weight[d - HALF].to(cutlass.Float32)
            kpair = kpair * inv * (cutlass.Float32(1.0) + wpair)
            c = cos[t, d].to(cutlass.Float32)
            s = sin[t, d].to(cutlass.Float32)
            kr = kself * c + kpair * s

    key_workspace[t, base + d] = FP8_DTYPE(kr / cutlass.Float32(QKV_SCALE))


# ---------------------------------------------------------------------------
# 5. Causal GQA softmax attention + gating.
# ---------------------------------------------------------------------------
@cute.kernel
def attention_kernel(
    query_workspace: cute.Tensor,
    key_workspace: cute.Tensor,
    v_workspace: cute.Tensor,
    q_gate_workspace: cute.Tensor,
    score_workspace: cute.Tensor,
    probability_workspace: cute.Tensor,
    context_workspace: cute.Tensor,
):
    bx, _, _ = cute.arch.block_idx()
    t = bx // NUM_HEADS
    h = bx % NUM_HEADS
    kvh = h // NUM_KV_HEADS
    qbase = h * (2 * HEAD_DIM)
    kvbase = kvh * HEAD_DIM

    for kk in range(t + 1):
        acc = cutlass.Float32(0.0)
        for d in cutlass.range(HEAD_DIM):
            q = query_workspace[t, h * HEAD_DIM + d].to(cutlass.Float32)
            k = key_workspace[kk, kvbase + d].to(cutlass.Float32)
            acc += q * k
        score_workspace[bx, kk] = acc * cutlass.Float32(ATTN_SCALE)

    mval = score_workspace[bx, 0]
    for kk in range(t + 1):
        s = score_workspace[bx, kk]
        if s > mval:
            mval = s
    esum = cutlass.Float32(0.0)
    for kk in range(t + 1):
        e = cute.exp(score_workspace[bx, kk] - mval)
        probability_workspace[bx, kk] = e
        esum += e
    einv = cutlass.Float32(1.0) / esum
    for kk in range(t + 1):
        probability_workspace[bx, kk] = probability_workspace[bx, kk] * einv

    for d in cutlass.range(HEAD_DIM):
        ctx = cutlass.Float32(0.0)
        for kk in range(t + 1):
            p = probability_workspace[bx, kk].to(cutlass.Float32)
            v = v_workspace[kk, kvbase + d].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE)
            ctx += p * v
        gate = q_gate_workspace[t, qbase + HEAD_DIM + d].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE)
        sg = cutlass.Float32(1.0) / (cutlass.Float32(1.0) + cute.exp(-gate))
        gated = ctx * sg
        context_workspace[t, h * HEAD_DIM + d] = FP8_DTYPE(gated / cutlass.Float32(CONTEXT_SCALE))


# ---------------------------------------------------------------------------
# 6. Output projection + first residual.
# ---------------------------------------------------------------------------
@cute.kernel
def out_proj_kernel(
    context_workspace: cute.Tensor,
    out_weight: cute.Tensor,
    hidden: cute.Tensor,
    residual_workspace: cute.Tensor,
):
    tid, _, _ = cute.arch.thread_idx()
    bx, _, _ = cute.arch.block_idx()
    for chunk in cutlass.range(HIDDEN_SIZE // BLOCK_T):
        n = chunk * BLOCK_T + tid
        acc = cutlass.Float32(0.0)
        for k in cutlass.range(QUERY_SIZE):
            a = context_workspace[bx, k].to(cutlass.Float32) * cutlass.Float32(CONTEXT_SCALE)
            w = out_weight[n, k].to(cutlass.Float32) * cutlass.Float32(WEIGHT_CONTEXT_SCALE)
            acc += a * w
        res = hidden[bx, n].to(cutlass.Float32) + acc
        residual_workspace[bx, n] = res


# ---------------------------------------------------------------------------
# 7. MLP: gate & up projections, SwiGLU product, down projection.
# ---------------------------------------------------------------------------
@cute.kernel
def mlp_kernel(
    n2: cute.Tensor,
    gate_weight: cute.Tensor,
    up_weight: cute.Tensor,
    down_weight: cute.Tensor,
    gate_workspace: cute.Tensor,
    up_workspace: cute.Tensor,
    mlp_workspace: cute.Tensor,
    residual_workspace: cute.Tensor,
    output: cute.Tensor,
):
    tid, _, _ = cute.arch.thread_idx()
    bx, _, _ = cute.arch.block_idx()

    for chunk in cutlass.range(INTERMEDIATE_SIZE // BLOCK_T):
        n = chunk * BLOCK_T + tid
        acc = cutlass.Float32(0.0)
        for k in cutlass.range(HIDDEN_SIZE):
            a = n2[bx, k].to(cutlass.Float32) * cutlass.Float32(NORM_SCALE)
            w = gate_weight[n, k].to(cutlass.Float32) * cutlass.Float32(WEIGHT_H_SCALE)
            acc += a * w
        sil = acc / (cutlass.Float32(1.0) + cute.exp(-acc))
        gate_workspace[bx, n] = FP8_DTYPE(sil / cutlass.Float32(MLP_ACTIVATION_SCALE))

    for chunk in cutlass.range(INTERMEDIATE_SIZE // BLOCK_T):
        n = chunk * BLOCK_T + tid
        acc = cutlass.Float32(0.0)
        for k in cutlass.range(HIDDEN_SIZE):
            a = n2[bx, k].to(cutlass.Float32) * cutlass.Float32(NORM_SCALE)
            w = up_weight[n, k].to(cutlass.Float32) * cutlass.Float32(WEIGHT_H_SCALE)
            acc += a * w
        up_workspace[bx, n] = FP8_DTYPE(acc / cutlass.Float32(MLP_PROJECTION_SCALE))

    for chunk in cutlass.range(INTERMEDIATE_SIZE // BLOCK_T):
        n = chunk * BLOCK_T + tid
        g = gate_workspace[bx, n].to(cutlass.Float32) * cutlass.Float32(MLP_ACTIVATION_SCALE)
        u = up_workspace[bx, n].to(cutlass.Float32) * cutlass.Float32(MLP_PROJECTION_SCALE)
        mlp_workspace[bx, n] = FP8_DTYPE((g * u) / cutlass.Float32(MLP_ACTIVATION_SCALE))

    cute.arch.sync_threads()

    for chunk in cutlass.range(HIDDEN_SIZE // BLOCK_T):
        m = chunk * BLOCK_T + tid
        acc = cutlass.Float32(0.0)
        for n in cutlass.range(INTERMEDIATE_SIZE):
            a = mlp_workspace[bx, n].to(cutlass.Float32) * cutlass.Float32(MLP_ACTIVATION_SCALE)
            w = down_weight[m, n].to(cutlass.Float32) * cutlass.Float32(WEIGHT_MLP_SCALE)
            acc += a * w
        res = residual_workspace[bx, m].to(cutlass.Float32)
        output[bx, m] = res + acc


# ---------------------------------------------------------------------------
# Entry point.
# ---------------------------------------------------------------------------
@cute.jit
def qwen35_full_attention_block(
    hidden: cute.Tensor,
    input_norm_weight: cute.Tensor,
    q_norm_weight: cute.Tensor,
    k_norm_weight: cute.Tensor,
    q_gate_weight: cute.Tensor,
    k_weight: cute.Tensor,
    v_weight: cute.Tensor,
    out_weight: cute.Tensor,
    post_norm_weight: cute.Tensor,
    gate_weight: cute.Tensor,
    up_weight: cute.Tensor,
    down_weight: cute.Tensor,
    cos: cute.Tensor,
    sin: cute.Tensor,
    norm1_workspace: cute.Tensor,
    q_gate_workspace: cute.Tensor,
    k_workspace: cute.Tensor,
    v_workspace: cute.Tensor,
    query_workspace: cute.Tensor,
    key_workspace: cute.Tensor,
    score_workspace: cute.Tensor,
    probability_workspace: cute.Tensor,
    context_workspace: cute.Tensor,
    residual_workspace: cute.Tensor,
    norm2_workspace: cute.Tensor,
    gate_workspace: cute.Tensor,
    up_workspace: cute.Tensor,
    mlp_workspace: cute.Tensor,
    output: cute.Tensor,
):
    rms_norm_kernel(hidden, input_norm_weight, norm1_workspace).launch(
        grid=(TOKENS, 1, 1), block=(BLOCK_T, 1, 1)
    )
    qkv_proj_kernel(
        norm1_workspace, q_gate_weight, k_weight, v_weight,
        q_gate_workspace, k_workspace, v_workspace,
    ).launch(grid=(TOKENS, 1, 1), block=(BLOCK_T, 1, 1))
    q_rope_norm_kernel(
        q_gate_workspace, q_norm_weight, cos, sin, query_workspace,
    ).launch(grid=(TOKENS * NUM_HEADS, 1, 1), block=(HEAD_DIM, 1, 1))
    k_rope_norm_kernel(
        k_workspace, k_norm_weight, cos, sin, key_workspace,
    ).launch(grid=(TOKENS * NUM_KV_HEADS, 1, 1), block=(HEAD_DIM, 1, 1))
    attention_kernel(
        query_workspace, key_workspace, v_workspace, q_gate_workspace,
        score_workspace, probability_workspace, context_workspace,
    ).launch(grid=(TOKENS * NUM_HEADS, 1, 1), block=(1, 1, 1))
    out_proj_kernel(
        context_workspace, out_weight, hidden, residual_workspace,
    ).launch(grid=(TOKENS, 1, 1), block=(BLOCK_T, 1, 1))
    rms_norm_kernel(
        residual_workspace, post_norm_weight, norm2_workspace,
    ).launch(grid=(TOKENS, 1, 1), block=(BLOCK_T, 1, 1))
    mlp_kernel(
        norm2_workspace, gate_weight, up_weight, down_weight,
        gate_workspace, up_workspace, mlp_workspace,
        residual_workspace, output,
    ).launch(grid=(TOKENS, 1, 1), block=(BLOCK_T, 1, 1))


class ModelNew:
    forward = staticmethod(qwen35_full_attention_block)
