# B300 device profile of your last candidate

- device: NVIDIA B300 SXM6 AC, 148 SMs, 232448 B opt-in shared memory/block
- GPU busy: 15391.772 ms total; kernels 15391.735 ms over 570 launches of 51 distinct names
- memcpy: 0.033 ms over 17 calls; memset: 0.003 ms over 2 calls

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 11768.404 | 55 | 76.5 |
| kernel_cutlass_mlp_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo25601_tensorptrf8E4M3F… | 2419.878 | 55 | 15.7 |
| kernel_cutlass_qkv_proj_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 857.016 | 55 | 5.6 |
| kernel_cutlass_out_proj_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 339.598 | 55 | 2.2 |
| kernel_cutlass_q_rope_norm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo25… | 2.702 | 55 | 0.0 |
| kernel_cutlass_rms_norm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo25601… | 2.542 | 55 | 0.0 |
| kernel_cutlass_k_rope_norm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo25… | 0.754 | 55 | 0.0 |
| kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 0.168 | 19 | 0.0 |
| void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 0.166 | 32 | 0.0 |
| void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 0.163 | 8 | 0.0 |
