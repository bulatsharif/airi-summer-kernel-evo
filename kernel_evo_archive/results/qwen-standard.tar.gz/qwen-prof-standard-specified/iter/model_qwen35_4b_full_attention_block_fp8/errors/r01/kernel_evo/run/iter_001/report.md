# KernelEvo iteration 1

Run: `run`  
Barrier status: **evaluated**  
Valid: 0 · Promoted: 0

| Island | Result | Progress | Runtime | Speedup | Promoted | Idea |
|---:|---|---:|---:|---:|:---:|---|
| 0 | failed: RuntimeError: validation failed: max_abs=0.395972; exit_code=1; success pattern… | — | — | 0.000x | no | Implement the task's CuTe DSL FP8 kernel so it compiles and produces numerically correct output on… |

Global best: `seed` at **1.000x** speedup.
