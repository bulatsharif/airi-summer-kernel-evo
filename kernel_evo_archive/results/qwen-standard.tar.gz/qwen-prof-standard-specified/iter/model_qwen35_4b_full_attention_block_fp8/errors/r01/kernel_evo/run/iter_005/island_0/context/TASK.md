# KernelEvo island authoring task

- role: `kernel-author`
- run: `run`
- backend: `cute`
- iteration: `5`
- island: `0`

## Editable file

- `/Users/bulatsaripov/Desktop/Summer2026/AIRI-Summer-2026/Project/arm-worktrees-prof9/qwen-prof-standard-specified/results/qwen-prof-standard-specified/iter/model_qwen35_4b_full_attention_block_fp8/errors/r01/kernel_evo/run/iter_005/island_0/candidate/submission.py`

## Readable files

- `/Users/bulatsaripov/Desktop/Summer2026/AIRI-Summer-2026/Project/arm-worktrees-prof9/qwen-prof-standard-specified/results/qwen-prof-standard-specified/iter/model_qwen35_4b_full_attention_block_fp8/errors/r01/kernel_evo/run/iter_005/island_0/baseline/submission.py`
- `/Users/bulatsaripov/Desktop/Summer2026/AIRI-Summer-2026/Project/arm-worktrees-prof9/qwen-prof-standard-specified/results/qwen-prof-standard-specified/iter/model_qwen35_4b_full_attention_block_fp8/errors/r01/kernel_evo/run/iter_005/island_0/context/IDEA.md`
- `/Users/bulatsaripov/Desktop/Summer2026/AIRI-Summer-2026/Project/arm-worktrees-prof9/qwen-prof-standard-specified/results/qwen-prof-standard-specified/iter/model_qwen35_4b_full_attention_block_fp8/errors/r01/kernel_evo/run/iter_005/island_0/context/FEEDBACK.md`
- `/Users/bulatsaripov/Desktop/Summer2026/AIRI-Summer-2026/Project/arm-worktrees-prof9/qwen-prof-standard-specified/results/qwen-prof-standard-specified/iter/model_qwen35_4b_full_attention_block_fp8/errors/r01/kernel_evo/run/iter_005/island_0/context/RULES.md`
- `/Users/bulatsaripov/Desktop/Summer2026/AIRI-Summer-2026/Project/arm-worktrees-prof9/qwen-prof-standard-specified/results/qwen-prof-standard-specified/iter/model_qwen35_4b_full_attention_block_fp8/errors/r01/kernel_evo/run/iter_005/island_0/tests/summary.md`

The task statement and this run's documentation were given to you in full at the start of this session — work from what is already in front of you. Nothing else is listed here and nothing else is available to open.
- `/Users/bulatsaripov/Desktop/Summer2026/AIRI-Summer-2026/Project/arm-worktrees-prof9/qwen-prof-standard-specified/results/qwen-prof-standard-specified/iter/model_qwen35_4b_full_attention_block_fp8/errors/r01/kernel_evo/run/iter_005/island_0/context/PREVIOUS_ATTEMPT.py`

## Contract

Implement exactly one candidate optimization in the editable file. Preserve the interface.
Do not edit tests, baseline, state, context, or another island. Do not run the full benchmark.
Optimize active device work without adding a CUDA-graph wrapper solely for the benchmark. An existing or internally used CUDA graph is allowed, but is neither required nor rewarded; fitness counts kernel and memcpy duration.
Read `PARENT_PROFILE.md` before choosing the change. The seed hypothesis is not exhaustive:
you may implement a different bounded optimization when the compact per-operation breakdown
supports it, while preserving any explicit capability/codegen contract.
Run the backend lint named in RULES.md before submission.

Return only the candidate path and a short structured rationale to the coordinator:

```json
{
  "candidate_path": "/Users/bulatsaripov/Desktop/Summer2026/AIRI-Summer-2026/Project/arm-worktrees-prof9/qwen-prof-standard-specified/results/qwen-prof-standard-specified/iter/model_qwen35_4b_full_attention_block_fp8/errors/r01/kernel_evo/run/iter_005/island_0/candidate/submission.py",
  "idea_summary": "what changed",
  "expected_perf_mechanism": "why it should be faster",
  "risk": "main correctness/performance risk",
  "needs_evaluation": true
}
```
