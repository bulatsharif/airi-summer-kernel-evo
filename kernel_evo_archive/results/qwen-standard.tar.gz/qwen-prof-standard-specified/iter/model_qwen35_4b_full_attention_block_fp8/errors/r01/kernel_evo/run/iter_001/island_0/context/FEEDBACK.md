# Compressed feedback

- Selected parent `seed` has no usable profile; do not assume its bottleneck.
