# Seed hypothesis implement-cute-fp8-kernel

Implement the task's CuTe DSL FP8 kernel so it compiles and produces numerically correct output on B300.

This is a starting hypothesis/capability contract, not a closed idea list. Use the compact parent profile to refine or replace its optimization mechanism.
