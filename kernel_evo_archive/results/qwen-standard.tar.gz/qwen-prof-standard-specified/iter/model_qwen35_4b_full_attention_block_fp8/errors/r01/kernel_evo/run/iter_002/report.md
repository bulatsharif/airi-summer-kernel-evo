# KernelEvo iteration 2

Run: `run`  
Barrier status: **evaluated**  
Valid: 1 · Promoted: 0

| Island | Result | Progress | Runtime | Speedup | Promoted | Idea |
|---:|---|---:|---:|---:|:---:|---|
| 0 | valid | — | 279856.018 µs | 0.178x | no | Implement the task's CuTe DSL FP8 kernel so it compiles and produces numerically correct output on… |

Global best: `seed` at **1.000x** speedup.

## Compact profile objectives

- Island 0 (b300_trace): inner device — µs, — kernels, — memcpys; eager layer — µs, dispatch gaps — µs; graph no, replay — µs.

Compact profile review required for island(s): 0. Use `kernel-evo iter review-profiles`, then `kernel-evo island review-submit`.
