import cutlass
import cutlass.cute as cute


TOKENS = 128
HIDDEN_SIZE = 2560
NUM_HEADS = 16
NUM_KV_HEADS = 4
HEAD_DIM = 256
ROTARY_DIM = 64
INTERMEDIATE_SIZE = 9216
Q_GATE_SIZE = 8192
KV_SIZE = 1024
QUERY_SIZE = 4096
THREADS = 128
EPSILON = 1.0e-6

INPUT_SCALE = 1.0 / 448.0
NORM_SCALE = 1.0 / 64.0
QKV_SCALE = 1.0 / 64.0
CONTEXT_SCALE = 1.0 / 64.0
MLP_PROJECTION_SCALE = 1.0 / 64.0
MLP_ACTIVATION_SCALE = 1.0 / 32.0
WEIGHT_H_SCALE = HIDDEN_SIZE ** -0.5 / 448.0
WEIGHT_CONTEXT_SCALE = QUERY_SIZE ** -0.5 / 448.0
WEIGHT_MLP_SCALE = INTERMEDIATE_SIZE ** -0.5 / 448.0


@cute.jit
def warp_sum(value):
    value += cute.arch.shuffle_sync_bfly(value, 16)
    value += cute.arch.shuffle_sync_bfly(value, 8)
    value += cute.arch.shuffle_sync_bfly(value, 4)
    value += cute.arch.shuffle_sync_bfly(value, 2)
    value += cute.arch.shuffle_sync_bfly(value, 1)
    return value


@cute.kernel
def input_rms_norm_kernel(
    hidden: cute.Tensor, weight: cute.Tensor, output: cute.Tensor
):
    lane, _, _ = cute.arch.thread_idx()
    row, _, _ = cute.arch.block_idx()
    squared = cutlass.Float32(0.0)
    for iteration in cutlass.range(HIDDEN_SIZE // 32):
        column = iteration * 32 + lane
        value = hidden[row, column].to(cutlass.Float32) * INPUT_SCALE
        squared += value * value
    inverse_rms = cute.rsqrt(warp_sum(squared) / HIDDEN_SIZE + EPSILON)
    for iteration in cutlass.range(HIDDEN_SIZE // 32):
        column = iteration * 32 + lane
        value = hidden[row, column].to(cutlass.Float32) * INPUT_SCALE
        output[row, column] = (
            (
            value * inverse_rms * (1.0 + weight[column].to(cutlass.Float32))
        ) / NORM_SCALE
        ).to(cutlass.Float8E4M3FN)


@cute.kernel
def attention_input_projection_kernel(
    hidden: cute.Tensor, weight: cute.Tensor, output: cute.Tensor
):
    thread, _, _ = cute.arch.thread_idx()
    block, _, _ = cute.arch.block_idx()
    output_size = cute.size(output, mode=[1])
    linear = block * THREADS + thread
    if linear < TOKENS * output_size:
        row = linear // output_size
        column = linear % output_size
        accumulator = cutlass.Float32(0.0)
        for k in cutlass.range(HIDDEN_SIZE):
            accumulator += (
                hidden[row, k].to(cutlass.Float32)
                * weight[column, k].to(cutlass.Float32)
            )
        output[row, column] = (
            (
            accumulator * NORM_SCALE * WEIGHT_H_SCALE / QKV_SCALE
        )
        ).to(cutlass.Float8E4M3FN)


@cute.kernel
def query_norm_rope_kernel(
    q_gate: cute.Tensor,
    weight: cute.Tensor,
    cos: cute.Tensor,
    sin: cute.Tensor,
    output: cute.Tensor,
):
    lane, _, _ = cute.arch.thread_idx()
    block, _, _ = cute.arch.block_idx()
    row = block // NUM_HEADS
    head = block % NUM_HEADS
    start = head * 2 * HEAD_DIM
    squared = cutlass.Float32(0.0)
    for iteration in cutlass.range(HEAD_DIM // 32):
        column = iteration * 32 + lane
        value = q_gate[row, start + column].to(cutlass.Float32) * QKV_SCALE
        squared += value * value
    inverse_rms = cute.rsqrt(warp_sum(squared) / HEAD_DIM + EPSILON)
    for iteration in cutlass.range(HEAD_DIM // 32):
        column = iteration * 32 + lane
        value = q_gate[row, start + column].to(cutlass.Float32) * QKV_SCALE
        value *= inverse_rms * (1.0 + weight[column].to(cutlass.Float32))
        if column < ROTARY_DIM:
            half = ROTARY_DIM // 2
            paired = column - half
            if column < half:
                paired = column + half
            rotated = q_gate[row, start + paired].to(cutlass.Float32) * QKV_SCALE
            rotated *= inverse_rms * (1.0 + weight[paired].to(cutlass.Float32))
            if column < half:
                rotated = -rotated
            value = (
                value * cos[row, column].to(cutlass.Float32)
                + rotated * sin[row, column].to(cutlass.Float32)
            )
        output[row, head * HEAD_DIM + column] = (
            value / QKV_SCALE
        ).to(cutlass.Float8E4M3FN)


@cute.kernel
def key_norm_rope_kernel(
    key: cute.Tensor,
    weight: cute.Tensor,
    cos: cute.Tensor,
    sin: cute.Tensor,
    output: cute.Tensor,
):
    lane, _, _ = cute.arch.thread_idx()
    block, _, _ = cute.arch.block_idx()
    row = block // NUM_KV_HEADS
    head = block % NUM_KV_HEADS
    start = head * HEAD_DIM
    squared = cutlass.Float32(0.0)
    for iteration in cutlass.range(HEAD_DIM // 32):
        column = iteration * 32 + lane
        value = key[row, start + column].to(cutlass.Float32) * QKV_SCALE
        squared += value * value
    inverse_rms = cute.rsqrt(warp_sum(squared) / HEAD_DIM + EPSILON)
    for iteration in cutlass.range(HEAD_DIM // 32):
        column = iteration * 32 + lane
        value = key[row, start + column].to(cutlass.Float32) * QKV_SCALE
        value *= inverse_rms * (1.0 + weight[column].to(cutlass.Float32))
        if column < ROTARY_DIM:
            half = ROTARY_DIM // 2
            paired = column - half
            if column < half:
                paired = column + half
            rotated = key[row, start + paired].to(cutlass.Float32) * QKV_SCALE
            rotated *= inverse_rms * (1.0 + weight[paired].to(cutlass.Float32))
            if column < half:
                rotated = -rotated
            value = (
                value * cos[row, column].to(cutlass.Float32)
                + rotated * sin[row, column].to(cutlass.Float32)
            )
        output[row, start + column] = (
            value / QKV_SCALE
        ).to(cutlass.Float8E4M3FN)


@cute.kernel
def attention_score_kernel(
    query: cute.Tensor, key: cute.Tensor, scores: cute.Tensor
):
    thread, _, _ = cute.arch.thread_idx()
    block, _, _ = cute.arch.block_idx()
    linear = block * THREADS + thread
    if linear < NUM_HEADS * TOKENS * TOKENS:
        key_token = linear % TOKENS
        row = linear // TOKENS
        query_token = row % TOKENS
        head = row // TOKENS
        if key_token <= query_token:
            accumulator = cutlass.Float32(0.0)
            query_start = head * HEAD_DIM
            key_start = (head // 4) * HEAD_DIM
            for column in cutlass.range(HEAD_DIM):
                accumulator += (
                    query[query_token, query_start + column].to(cutlass.Float32)
                    * key[key_token, key_start + column].to(cutlass.Float32)
                )
            scores[row, key_token] = accumulator * QKV_SCALE * QKV_SCALE / 16.0
        else:
            scores[row, key_token] = -cutlass.Float32(1.0e30)


@cute.kernel
def softmax_kernel(scores: cute.Tensor, probabilities: cute.Tensor):
    row, _, _ = cute.arch.block_idx()
    maximum = scores[row, 0].to(cutlass.Float32)
    for column in cutlass.range(TOKENS):
        value = scores[row, column].to(cutlass.Float32)
        if value > maximum:
            maximum = value
    denominator = cutlass.Float32(0.0)
    for column in cutlass.range(TOKENS):
        denominator += cute.exp(scores[row, column].to(cutlass.Float32) - maximum)
    for column in cutlass.range(TOKENS):
        probabilities[row, column] = cute.exp(
            scores[row, column].to(cutlass.Float32) - maximum
        ) / denominator


@cute.kernel
def gated_context_kernel(
    q_gate: cute.Tensor,
    value: cute.Tensor,
    probabilities: cute.Tensor,
    context: cute.Tensor,
):
    thread, _, _ = cute.arch.thread_idx()
    block, _, _ = cute.arch.block_idx()
    linear = block * THREADS + thread
    if linear < TOKENS * QUERY_SIZE:
        query_token = linear // QUERY_SIZE
        column = linear % QUERY_SIZE
        head = column // HEAD_DIM
        head_column = column % HEAD_DIM
        accumulator = cutlass.Float32(0.0)
        for key_token in cutlass.range(TOKENS):
            accumulator += (
                probabilities[head * TOKENS + query_token, key_token].to(
                    cutlass.Float32
                )
                * value[
                    key_token, (head // 4) * HEAD_DIM + head_column
                ].to(cutlass.Float32)
            )
        gate_column = head * 2 * HEAD_DIM + HEAD_DIM + head_column
        gate = q_gate[query_token, gate_column].to(cutlass.Float32) * QKV_SCALE
        sigmoid = 1.0 / (1.0 + cute.exp(-gate))
        context[query_token, column] = (
            (
            accumulator * QKV_SCALE * sigmoid / CONTEXT_SCALE
        )
        ).to(cutlass.Float8E4M3FN)


@cute.kernel
def attention_output_kernel(
    hidden: cute.Tensor,
    context: cute.Tensor,
    weight: cute.Tensor,
    residual: cute.Tensor,
):
    thread, _, _ = cute.arch.thread_idx()
    block, _, _ = cute.arch.block_idx()
    linear = block * THREADS + thread
    if linear < TOKENS * HIDDEN_SIZE:
        row = linear // HIDDEN_SIZE
        column = linear % HIDDEN_SIZE
        accumulator = cutlass.Float32(0.0)
        for k in cutlass.range(QUERY_SIZE):
            accumulator += (
                context[row, k].to(cutlass.Float32)
                * weight[column, k].to(cutlass.Float32)
            )
        residual[row, column] = (
            hidden[row, column].to(cutlass.Float32) * INPUT_SCALE
            + accumulator * CONTEXT_SCALE * WEIGHT_CONTEXT_SCALE
        )


@cute.kernel
def residual_rms_norm_kernel(
    hidden: cute.Tensor, weight: cute.Tensor, output: cute.Tensor
):
    lane, _, _ = cute.arch.thread_idx()
    row, _, _ = cute.arch.block_idx()
    squared = cutlass.Float32(0.0)
    for iteration in cutlass.range(HIDDEN_SIZE // 32):
        column = iteration * 32 + lane
        value = hidden[row, column].to(cutlass.Float32)
        squared += value * value
    inverse_rms = cute.rsqrt(warp_sum(squared) / HIDDEN_SIZE + EPSILON)
    for iteration in cutlass.range(HIDDEN_SIZE // 32):
        column = iteration * 32 + lane
        value = hidden[row, column].to(cutlass.Float32)
        output[row, column] = (
            (
            value * inverse_rms * (1.0 + weight[column].to(cutlass.Float32))
        ) / NORM_SCALE
        ).to(cutlass.Float8E4M3FN)


@cute.kernel
def mlp_input_projection_kernel(
    hidden: cute.Tensor, weight: cute.Tensor, output: cute.Tensor
):
    thread, _, _ = cute.arch.thread_idx()
    block, _, _ = cute.arch.block_idx()
    linear = block * THREADS + thread
    if linear < TOKENS * INTERMEDIATE_SIZE:
        row = linear // INTERMEDIATE_SIZE
        column = linear % INTERMEDIATE_SIZE
        accumulator = cutlass.Float32(0.0)
        for k in cutlass.range(HIDDEN_SIZE):
            accumulator += (
                hidden[row, k].to(cutlass.Float32)
                * weight[column, k].to(cutlass.Float32)
            )
        output[row, column] = (
            (
            accumulator
            * NORM_SCALE
            * WEIGHT_H_SCALE
            / MLP_PROJECTION_SCALE
        )
        ).to(cutlass.Float8E4M3FN)


@cute.kernel
def swiglu_kernel(
    gate: cute.Tensor, up: cute.Tensor, output: cute.Tensor
):
    thread, _, _ = cute.arch.thread_idx()
    block, _, _ = cute.arch.block_idx()
    linear = block * THREADS + thread
    if linear < TOKENS * INTERMEDIATE_SIZE:
        row = linear // INTERMEDIATE_SIZE
        column = linear % INTERMEDIATE_SIZE
        gate_value = gate[row, column].to(cutlass.Float32) * MLP_PROJECTION_SCALE
        up_value = up[row, column].to(cutlass.Float32) * MLP_PROJECTION_SCALE
        silu = gate_value / (1.0 + cute.exp(-gate_value))
        output[row, column] = (
            silu * up_value / MLP_ACTIVATION_SCALE
        ).to(cutlass.Float8E4M3FN)


@cute.kernel
def down_projection_kernel(
    residual: cute.Tensor,
    hidden: cute.Tensor,
    weight: cute.Tensor,
    output: cute.Tensor,
):
    thread, _, _ = cute.arch.thread_idx()
    block, _, _ = cute.arch.block_idx()
    linear = block * THREADS + thread
    if linear < TOKENS * HIDDEN_SIZE:
        row = linear // HIDDEN_SIZE
        column = linear % HIDDEN_SIZE
        accumulator = cutlass.Float32(0.0)
        for k in cutlass.range(INTERMEDIATE_SIZE):
            accumulator += (
                hidden[row, k].to(cutlass.Float32)
                * weight[column, k].to(cutlass.Float32)
            )
        output[row, column] = (
            residual[row, column].to(cutlass.Float32)
            + accumulator * MLP_ACTIVATION_SCALE * WEIGHT_MLP_SCALE
        )


@cute.jit
def qwen35_full_attention_block(
    hidden: cute.Tensor,
    input_norm_weight: cute.Tensor,
    q_norm_weight: cute.Tensor,
    k_norm_weight: cute.Tensor,
    q_gate_weight: cute.Tensor,
    k_weight: cute.Tensor,
    v_weight: cute.Tensor,
    out_weight: cute.Tensor,
    post_norm_weight: cute.Tensor,
    gate_weight: cute.Tensor,
    up_weight: cute.Tensor,
    down_weight: cute.Tensor,
    cos: cute.Tensor,
    sin: cute.Tensor,
    norm1_workspace: cute.Tensor,
    q_gate_workspace: cute.Tensor,
    k_workspace: cute.Tensor,
    v_workspace: cute.Tensor,
    query_workspace: cute.Tensor,
    key_workspace: cute.Tensor,
    score_workspace: cute.Tensor,
    probability_workspace: cute.Tensor,
    context_workspace: cute.Tensor,
    residual_workspace: cute.Tensor,
    norm2_workspace: cute.Tensor,
    gate_workspace: cute.Tensor,
    up_workspace: cute.Tensor,
    mlp_workspace: cute.Tensor,
    output: cute.Tensor,
):
    input_rms_norm_kernel(hidden, input_norm_weight, norm1_workspace).launch(
        grid=(TOKENS, 1, 1), block=(32, 1, 1)
    )
    for weight, workspace, size in (
        (q_gate_weight, q_gate_workspace, Q_GATE_SIZE),
        (k_weight, k_workspace, KV_SIZE),
        (v_weight, v_workspace, KV_SIZE),
    ):
        attention_input_projection_kernel(
            norm1_workspace, weight, workspace
        ).launch(
            grid=((TOKENS * size + THREADS - 1) // THREADS, 1, 1),
            block=(THREADS, 1, 1),
        )
    query_norm_rope_kernel(
        q_gate_workspace, q_norm_weight, cos, sin, query_workspace
    ).launch(grid=(TOKENS * NUM_HEADS, 1, 1), block=(32, 1, 1))
    key_norm_rope_kernel(
        k_workspace, k_norm_weight, cos, sin, key_workspace
    ).launch(grid=(TOKENS * NUM_KV_HEADS, 1, 1), block=(32, 1, 1))
    attention_score_kernel(
        query_workspace, key_workspace, score_workspace
    ).launch(
        grid=((NUM_HEADS * TOKENS * TOKENS + THREADS - 1) // THREADS, 1, 1),
        block=(THREADS, 1, 1),
    )
    softmax_kernel(score_workspace, probability_workspace).launch(
        grid=(NUM_HEADS * TOKENS, 1, 1), block=(1, 1, 1)
    )
    gated_context_kernel(
        q_gate_workspace, v_workspace, probability_workspace, context_workspace
    ).launch(
        grid=((TOKENS * QUERY_SIZE + THREADS - 1) // THREADS, 1, 1),
        block=(THREADS, 1, 1),
    )
    attention_output_kernel(
        hidden, context_workspace, out_weight, residual_workspace
    ).launch(
        grid=((TOKENS * HIDDEN_SIZE + THREADS - 1) // THREADS, 1, 1),
        block=(THREADS, 1, 1),
    )
    residual_rms_norm_kernel(
        residual_workspace, post_norm_weight, norm2_workspace
    ).launch(grid=(TOKENS, 1, 1), block=(32, 1, 1))
    for weight, workspace in (
        (gate_weight, gate_workspace),
        (up_weight, up_workspace),
    ):
        mlp_input_projection_kernel(norm2_workspace, weight, workspace).launch(
            grid=((TOKENS * INTERMEDIATE_SIZE + THREADS - 1) // THREADS, 1, 1),
            block=(THREADS, 1, 1),
        )
    swiglu_kernel(gate_workspace, up_workspace, mlp_workspace).launch(
        grid=((TOKENS * INTERMEDIATE_SIZE + THREADS - 1) // THREADS, 1, 1),
        block=(THREADS, 1, 1),
    )
    down_projection_kernel(
        residual_workspace, mlp_workspace, down_weight, output
    ).launch(
        grid=((TOKENS * HIDDEN_SIZE + THREADS - 1) // THREADS, 1, 1),
        block=(THREADS, 1, 1),
    )


class ModelNew:
    forward = staticmethod(qwen35_full_attention_block)

# === CUTE_HARNESS_EVALUATOR_V1 ===
_CUTE_HARNESS_SEED = 0
_CUTE_HARNESS_WARMUP = 5
_CUTE_HARNESS_REPEATS = 50

import torch as _cute_harness_torch
import torch.nn.functional as _cute_harness_functional

import cutlass as _cute_harness_cutlass
import cutlass.cute as _cute_harness_cute
from cutlass.cute.runtime import from_dlpack as _cute_harness_from_dlpack
from cutlass.utils import create_cute_tensor_for_fp8 as _cute_harness_create_fp8


_CUTE_HARNESS_TOKENS = 128
_CUTE_HARNESS_HIDDEN = 2560
_CUTE_HARNESS_HEADS = 16
_CUTE_HARNESS_KV_HEADS = 4
_CUTE_HARNESS_HEAD_DIM = 256
_CUTE_HARNESS_ROTARY = 64
_CUTE_HARNESS_INTERMEDIATE = 9216
_CUTE_HARNESS_Q_GATE = 8192
_CUTE_HARNESS_KV = 1024
_CUTE_HARNESS_QUERY = 4096
_CUTE_HARNESS_EPSILON = 1.0e-6
_CUTE_HARNESS_INPUT_SCALE = 1.0 / 448.0
_CUTE_HARNESS_NORM_SCALE = 1.0 / 64.0
_CUTE_HARNESS_QKV_SCALE = 1.0 / 64.0
_CUTE_HARNESS_CONTEXT_SCALE = 1.0 / 64.0
_CUTE_HARNESS_MLP_PROJECTION_SCALE = 1.0 / 64.0
_CUTE_HARNESS_MLP_ACTIVATION_SCALE = 1.0 / 32.0
_CUTE_HARNESS_WEIGHT_H_BOUND = _CUTE_HARNESS_HIDDEN ** -0.5
_CUTE_HARNESS_WEIGHT_CONTEXT_BOUND = _CUTE_HARNESS_QUERY ** -0.5
_CUTE_HARNESS_WEIGHT_MLP_BOUND = _CUTE_HARNESS_INTERMEDIATE ** -0.5
_CUTE_HARNESS_WEIGHT_H_SCALE = _CUTE_HARNESS_WEIGHT_H_BOUND / 448.0
_CUTE_HARNESS_WEIGHT_CONTEXT_SCALE = (
    _CUTE_HARNESS_WEIGHT_CONTEXT_BOUND / 448.0
)
_CUTE_HARNESS_WEIGHT_MLP_SCALE = _CUTE_HARNESS_WEIGHT_MLP_BOUND / 448.0
_CUTE_HARNESS_FP8_DTYPE = _cute_harness_cutlass.Float8E4M3FN


def _cute_harness_fp8_tensor(source, scale):
    storage = _cute_harness_torch.empty(
        source.shape, device="cuda", dtype=_cute_harness_torch.uint8
    )
    tensor = _cute_harness_create_fp8(
        storage, _CUTE_HARNESS_FP8_DTYPE, 1, source / scale
    )
    return storage, tensor


def _cute_harness_empty_fp8(shape):
    return _cute_harness_fp8_tensor(
        _cute_harness_torch.zeros(shape, device="cuda"), 1.0
    )


def _cute_harness_scaled_linear(activation, weight, activation_scale, weight_scale):
    scale_a = _cute_harness_torch.tensor(activation_scale, device="cuda")
    scale_b = _cute_harness_torch.tensor(weight_scale, device="cuda")
    return _cute_harness_torch._scaled_mm(
        activation,
        weight.t(),
        scale_a=scale_a,
        scale_b=scale_b,
        out_dtype=_cute_harness_torch.float32,
    )


def _cute_harness_rms_norm(hidden, weight):
    inverse_rms = _cute_harness_torch.rsqrt(
        hidden.square().mean(dim=-1, keepdim=True) + _CUTE_HARNESS_EPSILON
    )
    return hidden * inverse_rms * (1.0 + weight)


def _cute_harness_apply_rope(hidden, cos, sin):
    rotary = hidden[..., :_CUTE_HARNESS_ROTARY]
    half = _CUTE_HARNESS_ROTARY // 2
    rotated = _cute_harness_torch.cat(
        (-rotary[..., half:], rotary[..., :half]), dim=-1
    )
    embedded = rotary * cos[:, None, :] + rotated * sin[:, None, :]
    return _cute_harness_torch.cat(
        (embedded, hidden[..., _CUTE_HARNESS_ROTARY:]), dim=-1
    )


def main():
    if not _cute_harness_torch.cuda.is_available():
        raise RuntimeError("A Blackwell CUDA device is required")

    _cute_harness_torch.manual_seed(_CUTE_HARNESS_SEED)
    hidden_source = _cute_harness_torch.empty(
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_HIDDEN), device="cuda"
    ).uniform_(-1.0, 1.0)
    input_norm_weight = 0.02 * _cute_harness_torch.randn(
        (_CUTE_HARNESS_HIDDEN,), device="cuda"
    )
    post_norm_weight = 0.02 * _cute_harness_torch.randn(
        (_CUTE_HARNESS_HIDDEN,), device="cuda"
    )
    q_norm_weight = 0.02 * _cute_harness_torch.randn(
        (_CUTE_HARNESS_HEAD_DIM,), device="cuda"
    )
    k_norm_weight = 0.02 * _cute_harness_torch.randn(
        (_CUTE_HARNESS_HEAD_DIM,), device="cuda"
    )

    positions = _cute_harness_torch.arange(
        _CUTE_HARNESS_TOKENS, device="cuda", dtype=_cute_harness_torch.float32
    )
    rotary_indices = _cute_harness_torch.arange(
        0,
        _CUTE_HARNESS_ROTARY,
        2,
        device="cuda",
        dtype=_cute_harness_torch.float32,
    )
    inverse_frequency = 1.0 / (
        10_000_000.0 ** (rotary_indices / _CUTE_HARNESS_ROTARY)
    )
    frequencies = positions[:, None] * inverse_frequency[None, :]
    embeddings = _cute_harness_torch.cat((frequencies, frequencies), dim=-1)
    cos_storage = embeddings.cos()
    sin_storage = embeddings.sin()

    weight_specs = (
        ("q_gate", _CUTE_HARNESS_Q_GATE, _CUTE_HARNESS_HIDDEN,
         _CUTE_HARNESS_WEIGHT_H_BOUND, _CUTE_HARNESS_WEIGHT_H_SCALE),
        ("k", _CUTE_HARNESS_KV, _CUTE_HARNESS_HIDDEN,
         _CUTE_HARNESS_WEIGHT_H_BOUND, _CUTE_HARNESS_WEIGHT_H_SCALE),
        ("v", _CUTE_HARNESS_KV, _CUTE_HARNESS_HIDDEN,
         _CUTE_HARNESS_WEIGHT_H_BOUND, _CUTE_HARNESS_WEIGHT_H_SCALE),
        ("out", _CUTE_HARNESS_HIDDEN, _CUTE_HARNESS_QUERY,
         _CUTE_HARNESS_WEIGHT_CONTEXT_BOUND, _CUTE_HARNESS_WEIGHT_CONTEXT_SCALE),
        ("gate", _CUTE_HARNESS_INTERMEDIATE, _CUTE_HARNESS_HIDDEN,
         _CUTE_HARNESS_WEIGHT_H_BOUND, _CUTE_HARNESS_WEIGHT_H_SCALE),
        ("up", _CUTE_HARNESS_INTERMEDIATE, _CUTE_HARNESS_HIDDEN,
         _CUTE_HARNESS_WEIGHT_H_BOUND, _CUTE_HARNESS_WEIGHT_H_SCALE),
        ("down", _CUTE_HARNESS_HIDDEN, _CUTE_HARNESS_INTERMEDIATE,
         _CUTE_HARNESS_WEIGHT_MLP_BOUND, _CUTE_HARNESS_WEIGHT_MLP_SCALE),
    )
    weight_storages = {}
    weight_tensors = {}
    for name, rows, columns, bound, scale in weight_specs:
        source = _cute_harness_torch.empty(
            (rows, columns), device="cuda"
        ).uniform_(-bound, bound)
        storage, tensor = _cute_harness_fp8_tensor(source, scale)
        weight_storages[name] = storage
        weight_tensors[name] = tensor

    hidden_storage, hidden = _cute_harness_fp8_tensor(
        hidden_source, _CUTE_HARNESS_INPUT_SCALE
    )
    fp8_workspace_shapes = (
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_HIDDEN),
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_Q_GATE),
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_KV),
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_KV),
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_QUERY),
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_KV),
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_QUERY),
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_HIDDEN),
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_INTERMEDIATE),
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_INTERMEDIATE),
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_INTERMEDIATE),
    )
    fp8_workspaces = [_cute_harness_empty_fp8(shape) for shape in fp8_workspace_shapes]
    (
        norm1_pair,
        q_gate_pair,
        k_pair,
        v_pair,
        query_pair,
        key_pair,
        context_pair,
        norm2_pair,
        gate_pair,
        up_pair,
        mlp_pair,
    ) = fp8_workspaces

    score_storage = _cute_harness_torch.empty(
        (_CUTE_HARNESS_HEADS * _CUTE_HARNESS_TOKENS, _CUTE_HARNESS_TOKENS),
        device="cuda",
    )
    probability_storage = _cute_harness_torch.empty_like(score_storage)
    residual_storage = _cute_harness_torch.empty(
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_HIDDEN), device="cuda"
    )
    output_storage = _cute_harness_torch.empty_like(residual_storage)
    dynamic = lambda tensor: _cute_harness_from_dlpack(tensor).mark_layout_dynamic(
        leading_dim=1
    )
    arguments = (
        hidden,
        _cute_harness_from_dlpack(input_norm_weight),
        _cute_harness_from_dlpack(q_norm_weight),
        _cute_harness_from_dlpack(k_norm_weight),
        weight_tensors["q_gate"],
        weight_tensors["k"],
        weight_tensors["v"],
        weight_tensors["out"],
        _cute_harness_from_dlpack(post_norm_weight),
        weight_tensors["gate"],
        weight_tensors["up"],
        weight_tensors["down"],
        dynamic(cos_storage),
        dynamic(sin_storage),
        *(pair[1] for pair in fp8_workspaces[:6]),
        dynamic(score_storage),
        dynamic(probability_storage),
        context_pair[1],
        dynamic(residual_storage),
        *(pair[1] for pair in fp8_workspaces[7:]),
        dynamic(output_storage),
    )
    compiled = _cute_harness_cute.compile(qwen35_full_attention_block, *arguments)
    for _ in range(_CUTE_HARNESS_WARMUP):
        compiled(*arguments)
    _cute_harness_torch.cuda.synchronize()

    timings_ms = []
    for _ in range(_CUTE_HARNESS_REPEATS):
        start = _cute_harness_torch.cuda.Event(enable_timing=True)
        end = _cute_harness_torch.cuda.Event(enable_timing=True)
        start.record()
        compiled(*arguments)
        end.record()
        end.synchronize()
        timings_ms.append(start.elapsed_time(end))
    kernel_time_ms = sorted(timings_ms)[len(timings_ms) // 2]

    fp8 = _cute_harness_torch.float8_e4m3fn
    hidden_fp8 = hidden_storage.view(fp8)
    weights_fp8 = {name: storage.view(fp8) for name, storage in weight_storages.items()}
    hidden_dequantized = hidden_fp8.float() * _CUTE_HARNESS_INPUT_SCALE
    norm1 = _cute_harness_rms_norm(hidden_dequantized, input_norm_weight)
    norm1_fp8 = (norm1 / _CUTE_HARNESS_NORM_SCALE).to(fp8)
    q_gate = _cute_harness_scaled_linear(
        norm1_fp8, weights_fp8["q_gate"], _CUTE_HARNESS_NORM_SCALE,
        _CUTE_HARNESS_WEIGHT_H_SCALE,
    )
    k = _cute_harness_scaled_linear(
        norm1_fp8, weights_fp8["k"], _CUTE_HARNESS_NORM_SCALE,
        _CUTE_HARNESS_WEIGHT_H_SCALE,
    )
    v = _cute_harness_scaled_linear(
        norm1_fp8, weights_fp8["v"], _CUTE_HARNESS_NORM_SCALE,
        _CUTE_HARNESS_WEIGHT_H_SCALE,
    )
    q_gate_fp8 = (q_gate / _CUTE_HARNESS_QKV_SCALE).to(fp8)
    k_fp8 = (k / _CUTE_HARNESS_QKV_SCALE).to(fp8)
    v_fp8 = (v / _CUTE_HARNESS_QKV_SCALE).to(fp8)
    q_gate_heads = (q_gate_fp8.float() * _CUTE_HARNESS_QKV_SCALE).reshape(
        _CUTE_HARNESS_TOKENS, _CUTE_HARNESS_HEADS, 2, _CUTE_HARNESS_HEAD_DIM
    )
    query = _cute_harness_rms_norm(q_gate_heads[:, :, 0], q_norm_weight)
    gate = q_gate_heads[:, :, 1]
    key = _cute_harness_rms_norm(
        (k_fp8.float() * _CUTE_HARNESS_QKV_SCALE).reshape(
            _CUTE_HARNESS_TOKENS, _CUTE_HARNESS_KV_HEADS, _CUTE_HARNESS_HEAD_DIM
        ),
        k_norm_weight,
    )
    query = _cute_harness_apply_rope(query, cos_storage, sin_storage)
    key = _cute_harness_apply_rope(key, cos_storage, sin_storage)
    query_fp8 = (query / _CUTE_HARNESS_QKV_SCALE).to(fp8)
    key_fp8 = (key / _CUTE_HARNESS_QKV_SCALE).to(fp8)
    query = query_fp8.float() * _CUTE_HARNESS_QKV_SCALE
    key = key_fp8.float() * _CUTE_HARNESS_QKV_SCALE
    key = key.repeat_interleave(
        _CUTE_HARNESS_HEADS // _CUTE_HARNESS_KV_HEADS, dim=1
    )
    value = (v_fp8.float() * _CUTE_HARNESS_QKV_SCALE).reshape(
        _CUTE_HARNESS_TOKENS, _CUTE_HARNESS_KV_HEADS, _CUTE_HARNESS_HEAD_DIM
    ).repeat_interleave(_CUTE_HARNESS_HEADS // _CUTE_HARNESS_KV_HEADS, dim=1)
    scores = _cute_harness_torch.einsum("thd,shd->hts", query, key) / 16.0
    causal_mask = _cute_harness_torch.triu(
        _cute_harness_torch.ones(
            (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_TOKENS),
            device="cuda",
            dtype=_cute_harness_torch.bool,
        ),
        diagonal=1,
    )
    probabilities = scores.masked_fill(causal_mask, -float("inf")).softmax(dim=-1)
    context = _cute_harness_torch.einsum(
        "hts,shd->thd", probabilities, value
    ) * _cute_harness_torch.sigmoid(gate)
    context_fp8 = (context.reshape(
        _CUTE_HARNESS_TOKENS, _CUTE_HARNESS_QUERY
    ) / _CUTE_HARNESS_CONTEXT_SCALE).to(fp8)
    residual = hidden_dequantized + _cute_harness_scaled_linear(
        context_fp8, weights_fp8["out"], _CUTE_HARNESS_CONTEXT_SCALE,
        _CUTE_HARNESS_WEIGHT_CONTEXT_SCALE,
    )
    norm2 = _cute_harness_rms_norm(residual, post_norm_weight)
    norm2_fp8 = (norm2 / _CUTE_HARNESS_NORM_SCALE).to(fp8)
    gate_mlp = _cute_harness_scaled_linear(
        norm2_fp8, weights_fp8["gate"], _CUTE_HARNESS_NORM_SCALE,
        _CUTE_HARNESS_WEIGHT_H_SCALE,
    )
    up_mlp = _cute_harness_scaled_linear(
        norm2_fp8, weights_fp8["up"], _CUTE_HARNESS_NORM_SCALE,
        _CUTE_HARNESS_WEIGHT_H_SCALE,
    )
    gate_fp8 = (gate_mlp / _CUTE_HARNESS_MLP_PROJECTION_SCALE).to(fp8)
    up_fp8 = (up_mlp / _CUTE_HARNESS_MLP_PROJECTION_SCALE).to(fp8)
    activation = _cute_harness_functional.silu(
        gate_fp8.float() * _CUTE_HARNESS_MLP_PROJECTION_SCALE
    ) * (up_fp8.float() * _CUTE_HARNESS_MLP_PROJECTION_SCALE)
    activation_fp8 = (activation / _CUTE_HARNESS_MLP_ACTIVATION_SCALE).to(fp8)
    reference = residual + _cute_harness_scaled_linear(
        activation_fp8, weights_fp8["down"], _CUTE_HARNESS_MLP_ACTIVATION_SCALE,
        _CUTE_HARNESS_WEIGHT_MLP_SCALE,
    )

    max_abs = (output_storage - reference).abs().max().item()
    if not _cute_harness_torch.isfinite(output_storage).all().item() or max_abs > 0.08:
        raise RuntimeError(f"validation failed: max_abs={max_abs:.6f}")
    print(
        "task=model_qwen35_4b_full_attention_block_fp8 "
        f"max_abs={max_abs:.6f} kernel_time_ms={kernel_time_ms:.6f} PASS"
    )
    _cute_harness_torch.cuda.synchronize()


main()
