# B300 device profile of your last candidate

- device: NVIDIA B300 SXM6 AC, 148 SMs, 232448 B opt-in shared memory/block
- GPU busy: 4043.794 ms total; kernels 4043.759 ms over 790 launches of 55 distinct names
- memcpy: 0.032 ms over 17 calls; memset: 0.003 ms over 2 calls

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_mlp_down_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 1334.163 | 55 | 33.0 |
| kernel_cutlass_mlp_gateup_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgme… | 1241.694 | 55 | 30.7 |
| kernel_cutlass_qkv_q_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmemalig… | 637.384 | 55 | 15.8 |
| kernel_cutlass_out_proj_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 547.058 | 55 | 13.5 |
| kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 98.806 | 55 | 2.4 |
| kernel_cutlass_qkv_kv_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmemali… | 87.664 | 55 | 2.2 |
| kernel_cutlass_qkv_kv_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmemali… | 87.579 | 55 | 2.2 |
| kernel_cutlass_q_rope_norm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo25… | 2.866 | 55 | 0.1 |
| kernel_cutlass_rms_norm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo25601… | 2.542 | 55 | 0.1 |
| kernel_cutlass_mlp_norm_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo25601_tensorptrf8… | 2.307 | 55 | 0.1 |
