# B300 device profile of your last candidate

- device: NVIDIA B300 SXM6 AC, 148 SMs, 232448 B opt-in shared memory/block
- GPU busy: 2743.366 ms total; kernels 2743.333 ms over 1010 launches of 59 distinct names
- memcpy: 0.032 ms over 17 calls; memset: 0.001 ms over 2 calls

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_down_projection_kernel_tensorptrf32gmemoi641_tensorptrf8E4M3FNgmemalign1… | 613.440 | 55 | 22.4 |
| kernel_cutlass_mlp_input_projection_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf… | 591.565 | 55 | 21.6 |
| kernel_cutlass_mlp_input_projection_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf… | 591.553 | 55 | 21.6 |
| kernel_cutlass_attention_input_projection_kernel_tensorptrf8E4M3FNgmemalign16oi641_tens… | 525.939 | 55 | 19.2 |
| kernel_cutlass_attention_output_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M… | 269.664 | 55 | 9.8 |
| kernel_cutlass_attention_input_projection_kernel_tensorptrf8E4M3FNgmemalign16oi641_tens… | 66.398 | 55 | 2.4 |
| kernel_cutlass_attention_input_projection_kernel_tensorptrf8E4M3FNgmemalign16oi641_tens… | 66.393 | 55 | 2.4 |
| kernel_cutlass_attention_score_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3… | 10.214 | 55 | 0.4 |
| kernel_cutlass_input_rms_norm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmem… | 1.725 | 55 | 0.1 |
| kernel_cutlass_softmax_kernel_tensorptrf32gmemoi641_tensorptrf32gmemoi641_7 | 1.621 | 55 | 0.1 |
