KernelEvo owns correctness and performance evaluation. The author must preserve the baseline interface and must not run the full benchmark.
