# CuTe B300 authoring rules

- Preserve `ModelNew.forward` and the task JIT entrypoint.
- Keep candidate code CuTe-only: no `main()`, PyTorch calls, inputs, oracle, timing, or PASS output.
- Read the listed `errors` documentation bundle before editing.
- Run `kernel-evo cute task-check model_gpt2_small_transformer_block_fp8 <candidate>` before submission.
- Do not run the remote benchmark; KernelEvo owns evaluation and promotion.
