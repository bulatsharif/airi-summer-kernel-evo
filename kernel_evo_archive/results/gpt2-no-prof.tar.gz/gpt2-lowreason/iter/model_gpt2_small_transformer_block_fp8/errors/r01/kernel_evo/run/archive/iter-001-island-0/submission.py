import cutlass
import cutlass.cute as cute


TOKENS = 128
HIDDEN_SIZE = 768
NUM_HEADS = 12
HEAD_DIM = 64
MLP_SIZE = 3072
QKV_SIZE = 3 * HIDDEN_SIZE
THREADS = 128
EPSILON = 1.0e-5

INPUT_SCALE = 1.0 / 448.0
NORM_SCALE = 1.0 / 64.0
QKV_SCALE = 1.0 / 64.0
CONTEXT_SCALE = 1.0 / 64.0
MLP_SCALE = 1.0 / 64.0
WEIGHT_H_SCALE = HIDDEN_SIZE ** -0.5 / 448.0
WEIGHT_MLP_SCALE = MLP_SIZE ** -0.5 / 448.0
FP8_DTYPE = cutlass.Float8E4M3FN

# Derived launch geometry.
GEMM_BLOCK = 256
QKV_OUT = TOKENS * QKV_SIZE
H_OUT = TOKENS * HIDDEN_SIZE
MLP_OUT = TOKENS * MLP_SIZE
ATTN_TOTAL = NUM_HEADS * TOKENS

SQRT_2_OVER_PI = 0.7978845608028654
GELU_C = 0.044715


@cute.jit
def gelu_new(x):
    # GPT-2 approximate GELU: 0.5 * x * (1 + tanh(sqrt(2/pi) * (x + 0.044715 * x^3)))
    x3 = x * x * x
    inner = cutlass.Float32(SQRT_2_OVER_PI) * (x + cutlass.Float32(GELU_C) * x3)
    t = cute.tanh(inner)
    return cutlass.Float32(0.5) * x * (cutlass.Float32(1.0) + t)


@cute.kernel
def layer_norm_fp8_kernel(
    hidden: cute.Tensor,
    weight: cute.Tensor,
    bias: cute.Tensor,
    output: cute.Tensor,
):
    token, _, _ = cute.arch.thread_idx()

    mean = cutlass.Float32(0.0)
    for h in cutlass.range(HIDDEN_SIZE):
        mean = mean + hidden[token, h].to(cutlass.Float32) * cutlass.Float32(INPUT_SCALE)
    mean = mean / cutlass.Float32(HIDDEN_SIZE)

    var = cutlass.Float32(0.0)
    for h in cutlass.range(HIDDEN_SIZE):
        d = hidden[token, h].to(cutlass.Float32) * cutlass.Float32(INPUT_SCALE) - mean
        var = var + d * d
    var = var / cutlass.Float32(HIDDEN_SIZE)
    rstd = cute.rsqrt(var + cutlass.Float32(EPSILON))

    for h in cutlass.range(HIDDEN_SIZE):
        val = (hidden[token, h].to(cutlass.Float32) * cutlass.Float32(INPUT_SCALE) - mean) * rstd
        n1 = val * weight[h].to(cutlass.Float32) + bias[h].to(cutlass.Float32)
        output[token, h] = FP8_DTYPE(n1 * cutlass.Float32(1.0 / NORM_SCALE))


@cute.kernel
def qkv_projection_kernel(
    hidden: cute.Tensor,
    weight: cute.Tensor,
    bias: cute.Tensor,
    output: cute.Tensor,
):
    flat, _, _ = cute.arch.thread_idx()
    blk, _, _ = cute.arch.block_idx()
    bdim, _, _ = cute.arch.block_dim()
    tid = blk * bdim + flat

    token = tid // QKV_SIZE
    out_idx = tid % QKV_SIZE

    acc = cutlass.Float32(0.0)
    for k in cutlass.range(HIDDEN_SIZE):
        acc = acc + hidden[token, k].to(cutlass.Float32) * weight[out_idx, k].to(cutlass.Float32)

    real = acc * cutlass.Float32(NORM_SCALE * WEIGHT_H_SCALE) + bias[out_idx].to(cutlass.Float32)
    output[token, out_idx] = FP8_DTYPE(real * cutlass.Float32(1.0 / QKV_SCALE))


@cute.kernel
def attention_score_kernel(qkv: cute.Tensor, scores: cute.Tensor):
    flat, _, _ = cute.arch.thread_idx()
    blk, _, _ = cute.arch.block_idx()
    bdim, _, _ = cute.arch.block_dim()
    tid = blk * bdim + flat

    if tid < ATTN_TOTAL:
        head = tid // TOKENS
        t1 = tid % TOKENS
        q_base = head * HEAD_DIM
        k_base = HIDDEN_SIZE + head * HEAD_DIM
        for t2 in cutlass.range(TOKENS):
            acc = cutlass.Float32(0.0)
            for d in cutlass.range(HEAD_DIM):
                acc = acc + qkv[t1, q_base + d].to(cutlass.Float32) * qkv[t2, k_base + d].to(cutlass.Float32)
            score = acc * cutlass.Float32(QKV_SCALE * QKV_SCALE) / cutlass.Float32(8.0)
            scores_f[(head * TOKENS + t1) * TOKENS + t2] = score


@cute.kernel
def causal_softmax_kernel(
    scores: cute.Tensor,
    probabilities: cute.Tensor,
):
    flat, _, _ = cute.arch.thread_idx()
    blk, _, _ = cute.arch.block_idx()
    bdim, _, _ = cute.arch.block_dim()
    tid = blk * bdim + flat

    if tid < ATTN_TOTAL:
        head = tid // TOKENS
        t1 = tid % TOKENS

        # Causal keys are t2 in [0, t1]. Use runtime loop bounds instead of an
        # inner statement-if (which would create an scf.if region inside the loop).
        m = cutlass.Float32(-1.0e30)
        for t2 in cutlass.range(t1 + 1):
            s = scores_f[(head * TOKENS + t1) * TOKENS + t2].to(cutlass.Float32)
            m = s if s > m else m

        esum = cutlass.Float32(0.0)
        for t2 in cutlass.range(t1 + 1):
            s = scores_f[(head * TOKENS + t1) * TOKENS + t2].to(cutlass.Float32)
            esum = esum + cute.exp(s - m)
        inv = cutlass.Float32(1.0) / esum

        for t2 in cutlass.range(t1 + 1):
            s = scores_f[(head * TOKENS + t1) * TOKENS + t2].to(cutlass.Float32)
            probabilities[head, t1, t2] = cute.exp(s - m) * inv

        for t2 in cutlass.range(t1 + 1, TOKENS):
            probabilities[head, t1, t2] = cutlass.Float32(0.0)


@cute.kernel
def attention_context_kernel(
    qkv: cute.Tensor,
    probabilities: cute.Tensor,
    context: cute.Tensor,
):
    flat, _, _ = cute.arch.thread_idx()
    blk, _, _ = cute.arch.block_idx()
    bdim, _, _ = cute.arch.block_dim()
    tid = blk * bdim + flat

    if tid < ATTN_TOTAL:
        head = tid // TOKENS
        t1 = tid % TOKENS
        v_base = 2 * HIDDEN_SIZE + head * HEAD_DIM
        hbase = head * HEAD_DIM
        for d in cutlass.range(HEAD_DIM):
            acc = cutlass.Float32(0.0)
            for t2 in cutlass.range(TOKENS):
                acc = acc + probabilities[head, t1, t2].to(cutlass.Float32) * qkv[t2, v_base + d].to(cutlass.Float32)
            ctx = acc * cutlass.Float32(QKV_SCALE / CONTEXT_SCALE)
            context[t1, hbase + d] = FP8_DTYPE(ctx)


@cute.kernel
def attention_projection_kernel(
    hidden: cute.Tensor,
    context: cute.Tensor,
    weight: cute.Tensor,
    bias: cute.Tensor,
    residual: cute.Tensor,
):
    flat, _, _ = cute.arch.thread_idx()
    blk, _, _ = cute.arch.block_idx()
    bdim, _, _ = cute.arch.block_dim()
    tid = blk * bdim + flat

    token = tid // HIDDEN_SIZE
    out_idx = tid % HIDDEN_SIZE

    acc = cutlass.Float32(0.0)
    for k in cutlass.range(HIDDEN_SIZE):
        acc = acc + context[token, k].to(cutlass.Float32) * weight[out_idx, k].to(cutlass.Float32)

    linear = acc * cutlass.Float32(CONTEXT_SCALE * WEIGHT_H_SCALE) + bias[out_idx].to(cutlass.Float32)
    hidden_real = hidden[token, out_idx].to(cutlass.Float32) * cutlass.Float32(INPUT_SCALE)
    residual[token, out_idx] = hidden_real + linear


@cute.kernel
def layer_norm_fp32_kernel(
    hidden: cute.Tensor,
    weight: cute.Tensor,
    bias: cute.Tensor,
    output: cute.Tensor,
):
    token, _, _ = cute.arch.thread_idx()

    mean = cutlass.Float32(0.0)
    for h in cutlass.range(HIDDEN_SIZE):
        mean = mean + hidden[token, h].to(cutlass.Float32)
    mean = mean / cutlass.Float32(HIDDEN_SIZE)

    var = cutlass.Float32(0.0)
    for h in cutlass.range(HIDDEN_SIZE):
        d = hidden[token, h].to(cutlass.Float32) - mean
        var = var + d * d
    var = var / cutlass.Float32(HIDDEN_SIZE)
    rstd = cute.rsqrt(var + cutlass.Float32(EPSILON))

    for h in cutlass.range(HIDDEN_SIZE):
        val = (hidden[token, h].to(cutlass.Float32) - mean) * rstd
        n2 = val * weight[h].to(cutlass.Float32) + bias[h].to(cutlass.Float32)
        output[token, h] = FP8_DTYPE(n2 * cutlass.Float32(1.0 / NORM_SCALE))


@cute.kernel
def mlp_fc_gelu_kernel(
    hidden: cute.Tensor,
    weight: cute.Tensor,
    bias: cute.Tensor,
    output: cute.Tensor,
):
    flat, _, _ = cute.arch.thread_idx()
    blk, _, _ = cute.arch.block_idx()
    bdim, _, _ = cute.arch.block_dim()
    tid = blk * bdim + flat

    token = tid // MLP_SIZE
    out_idx = tid % MLP_SIZE

    acc = cutlass.Float32(0.0)
    for k in cutlass.range(HIDDEN_SIZE):
        acc = acc + hidden[token, k].to(cutlass.Float32) * weight[out_idx, k].to(cutlass.Float32)

    fc = acc * cutlass.Float32(NORM_SCALE * WEIGHT_MLP_SCALE) + bias[out_idx].to(cutlass.Float32)
    g = gelu_new(fc)
    output[token, out_idx] = FP8_DTYPE(g * cutlass.Float32(1.0 / MLP_SCALE))


@cute.kernel
def mlp_projection_kernel(
    residual: cute.Tensor,
    hidden: cute.Tensor,
    weight: cute.Tensor,
    bias: cute.Tensor,
    output: cute.Tensor,
):
    flat, _, _ = cute.arch.thread_idx()
    blk, _, _ = cute.arch.block_idx()
    bdim, _, _ = cute.arch.block_dim()
    tid = blk * bdim + flat

    token = tid // HIDDEN_SIZE
    out_idx = tid % HIDDEN_SIZE

    acc = cutlass.Float32(0.0)
    for k in cutlass.range(MLP_SIZE):
        acc = acc + hidden[token, k].to(cutlass.Float32) * weight[out_idx, k].to(cutlass.Float32)

    mlp = acc * cutlass.Float32(MLP_SCALE * WEIGHT_MLP_SCALE) + bias[out_idx].to(cutlass.Float32)
    output[token, out_idx] = residual[token, out_idx].to(cutlass.Float32) + mlp


@cute.jit
def gpt2_transformer_block(
    hidden: cute.Tensor,
    ln1_weight: cute.Tensor,
    ln1_bias: cute.Tensor,
    qkv_weight: cute.Tensor,
    qkv_bias: cute.Tensor,
    out_weight: cute.Tensor,
    out_bias: cute.Tensor,
    ln2_weight: cute.Tensor,
    ln2_bias: cute.Tensor,
    fc_weight: cute.Tensor,
    fc_bias: cute.Tensor,
    proj_weight: cute.Tensor,
    proj_bias: cute.Tensor,
    norm1_workspace: cute.Tensor,
    qkv_workspace: cute.Tensor,
    score_workspace: cute.Tensor,
    probability_workspace: cute.Tensor,
    context_workspace: cute.Tensor,
    residual_workspace: cute.Tensor,
    norm2_workspace: cute.Tensor,
    mlp_workspace: cute.Tensor,
    output: cute.Tensor,
):
    # 1. n1 = layer_norm(hidden, ln1_weight, ln1_bias) -> FP8 norm1_workspace
    layer_norm_fp8_kernel(hidden, ln1_weight, ln1_bias, norm1_workspace).launch(
        grid=(1, 1, 1),
        block=(TOKENS, 1, 1),
    )
    # 2. qkv = linear_fp8(n1, qkv_weight, qkv_bias) -> FP8 qkv_workspace
    qkv_projection_kernel(norm1_workspace, qkv_weight, qkv_bias, qkv_workspace).launch(
        grid=(QKV_OUT // GEMM_BLOCK, 1, 1),
        block=(GEMM_BLOCK, 1, 1),
    )
    # 3. scores = q @ k.T / sqrt(64)
    attention_score_kernel(qkv_workspace, score_workspace).launch(
        grid=(ATTN_TOTAL // GEMM_BLOCK, 1, 1),
        block=(GEMM_BLOCK, 1, 1),
    )
    # 4. probabilities = causal_softmax(scores)
    causal_softmax_kernel(score_workspace, probability_workspace).launch(
        grid=(ATTN_TOTAL // GEMM_BLOCK, 1, 1),
        block=(GEMM_BLOCK, 1, 1),
    )
    # 5. context = probabilities @ v -> FP8 context_workspace
    attention_context_kernel(qkv_workspace, probability_workspace, context_workspace).launch(
        grid=(ATTN_TOTAL // GEMM_BLOCK, 1, 1),
        block=(GEMM_BLOCK, 1, 1),
    )
    # 6. residual = hidden + linear_fp8(context, out_weight, out_bias) -> FP32
    attention_projection_kernel(hidden, context_workspace, out_weight, out_bias, residual_workspace).launch(
        grid=(H_OUT // GEMM_BLOCK, 1, 1),
        block=(GEMM_BLOCK, 1, 1),
    )
    # 7. n2 = layer_norm(residual, ln2_weight, ln2_bias) -> FP8 norm2_workspace
    layer_norm_fp32_kernel(residual_workspace, ln2_weight, ln2_bias, norm2_workspace).launch(
        grid=(1, 1, 1),
        block=(TOKENS, 1, 1),
    )
    # 8. mlp = linear_fp8(gelu_new(linear_fp8(n2, fc_weight, fc_bias)), proj_weight, proj_bias)
    mlp_fc_gelu_kernel(norm2_workspace, fc_weight, fc_bias, mlp_workspace).launch(
        grid=(MLP_OUT // GEMM_BLOCK, 1, 1),
        block=(GEMM_BLOCK, 1, 1),
    )
    mlp_projection_kernel(residual_workspace, mlp_workspace, proj_weight, proj_bias, output).launch(
        grid=(H_OUT // GEMM_BLOCK, 1, 1),
        block=(GEMM_BLOCK, 1, 1),
    )


class ModelNew:
    forward = staticmethod(gpt2_transformer_block)
