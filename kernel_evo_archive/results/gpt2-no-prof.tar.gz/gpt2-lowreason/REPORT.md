# CuTe documentation ablation

## Main results

### Iter

| Tier | Runs | Pass rate | Speed up (best raw) | Input tokens | Output tokens |
| --- | ---: | ---: | ---: | ---: | ---: |
| Error hints | 1 | 4/6 (66.7%) | 6.9034× | 6,832,060 | 61,553 |

Pass rate is over primary author calls; responses that do not produce a candidate count as failures. Best raw speedup is reference time divided by candidate time for the fastest passing mutation; it is not a stability-confirmed result.
Token columns are provider-reported totals across all runs, including repair calls.

## Stability across independent runs

| Approach | Tier | Runs | Pass rate/run (mean ± SD) | Solved runs | Best raw speedup/run (mean ± SD) |
| --- | --- | ---: | ---: | ---: | ---: |
| iter | Error hints | 1 | 66.7% ± 0.0% | 1/1 | 6.9034× ± 0.0000× |

## Cost

| Approach | Tier | Static docs¹ | Requests/attempt | Repair calls | Cap hits | Input/attempt | Cached/attempt | Output/attempt | Total/attempt |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| iter | errors | 33594 | 1.00 | 0 | 0 | 1138677 | 1067307 | 10259 | 1148936 |

¹ Static context is a cl100k estimate; provider usage columns are authoritative.

## Frequent failure

| Approach | Tier | Invalid attempts | No candidate | Missing jitted entry point | No remote result |
| --- | --- | ---: | ---: | ---: | ---: |
| iter | errors | 2 | 0 | 0 | 0 |

## Change from bare

| Approach | Tier | Pass change | Speedup ratio | Output change | Total change |
| --- | --- | ---: | ---: | ---: | ---: |

## By task

| Approach | Tier | Task | Attempts | Pass | Best | Geomean speedup¹ | Output/attempt |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: |
| iter | errors | model_gpt2_small_transformer_block_fp8 | 6 | 66.7% | 6.9034x | 6.903x | 10259 |

Runs included: 1.
