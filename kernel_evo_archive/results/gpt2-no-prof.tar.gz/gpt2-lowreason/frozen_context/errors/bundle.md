# File: TASK.md

# Task: complete GPT-2 Small transformer block, CuTe FP8

Implement one complete inference-time GPT-2 Small decoder block in CuTe DSL.
The timed entrypoint must perform all of the following, in order:

```text
n1       = layer_norm(hidden, ln1_weight, ln1_bias)
q, k, v  = split(linear_fp8(n1, qkv_weight, qkv_bias))
context  = causal_softmax(q @ k.T / sqrt(64)) @ v
residual = hidden + linear_fp8(context, out_weight, out_bias)
n2       = layer_norm(residual, ln2_weight, ln2_bias)
mlp      = linear_fp8(gelu_new(linear_fp8(n2, fc_weight, fc_bias)),
                      proj_weight, proj_bias)
output   = residual + mlp
```

This is the whole `transformer.h[0]` block: both LayerNorms, causal multi-head
attention, all four dense projections, GELU, and both residual connections.
Dropout and KV caching are intentionally absent.

## Fixed GPT-2 Small shape

```text
tokens = 128       hidden = 768       heads = 12
head_dim = 64      mlp = 3072         qkv = 2304
```

Batch size is one, so the token dimension is also the sequence dimension.
All dimensions are exact multiples of common tensor-core tiles; no tail path
is required.

## Precision contract

- Hidden state and all four weight matrices are physically FP8 E4M3FN.
- LayerNorm output, packed QKV, attention context, and GELU output are
  requantized to FP8 using the fixed scales in `starter.py`.
- Dense accumulation, LayerNorm statistics, attention scores/softmax,
  biases, residuals, and final output are FP32.
- The reference applies the same intermediate FP8 rounding. Do not silently
  keep an intermediate in FP32 across a declared FP8 boundary.
- Weights use `[N,K]` packed layout and must not be transposed in candidate
  storage.

## Candidate ABI

Preserve the `gpt2_transformer_block` signature in `starter.py`. The supplied
workspace tensors are owned by the evaluator and may be used, overwritten, or
ignored, but the output must be written by launched CuTe GPU kernels.

The private baseline is a deliberately simple scalar CuTe implementation.
Optimization is the point of the task: tensor-core `cute.gemm`, fused
epilogues, fewer materialized workspaces, and fused attention are all allowed
without changing the ABI or numerical contract.

Do not define `main()`, call PyTorch, allocate test inputs, or print a PASS
marker. The harness owns compilation, validation, and whole-block timing.

```text
python3 -m cute_harness check model_gpt2_small_transformer_block_fp8 submission.py
python3 -m cute_harness run model_gpt2_small_transformer_block_fp8 submission.py
```


# File: 01-core-api-scope.md

# Tier II: local CuTe DSL foundations

Tier II is the first documentation arm. Tier I is deliberately bare and
contains only the task statement.

This tier contains the local CuTe DSL execution model, public namespaces,
function signatures, parameter roles, value types, layout operations, copies,
MMA calls, launches, Blackwell execution, asynchronous pipelines, TMEM,
low-precision numerics, and validation methodology. It does not contain:

- complete kernel implementations;
- recommended tiles, stages, block sizes, or cluster shapes;
- a failure atlas or repair advice.

Higher tiers add those categories cumulatively. The task statement remains the
only authority for the requested operation, tensors, formats, shapes, scales,
entry point, and validation contract.

## Version and evidence boundary

The API descriptions are curated from NVIDIA CUTLASS CuTe DSL 4.6.1
documentation and neutral probes against the study worker. Public documented
spelling is used throughout. Where a function is release-sensitive, the text
states the object and parameter contract without inventing convenience
wrappers.

There are four distinct compatibility levels:

1. a Python symbol exists;
2. a decorated function traces;
3. generated IR and device code compile;
4. a launch with concrete layouts, address spaces, and resources succeeds.

An API signature establishes only the first level. The task's own compiler and
evaluation feedback establish the later levels.

## Namespace map

| Namespace | Contents |
| --- | --- |
| `cutlass` | scalar DSL types, `Constexpr`, compile-time helpers, DSL loop helpers |
| `cutlass.cute` | decorators, layouts, tensors, copy/MMA abstractions, layout algebra |
| `cutlass.cute.arch` | device indices, barriers, synchronization, SMEM/TMEM allocation |
| `cutlass.cute.runtime` | DLPack conversion, raw pointer construction, runtime adapters |
| `cutlass.cute.nvgpu` | NVIDIA GPU instruction and copy families |
| `cutlass.pipeline` | cooperative groups, barriers, and asynchronous pipelines |
| `cutlass.utils` | allocators and layout/operation construction utilities |
| `cutlass.utils.blackwell_helpers` | release-specific Blackwell construction helpers |

Import the namespace that owns an abstraction. Do not infer that an equally
plausible spelling exists under another namespace.

## Reading order

Start with the language, type, layout, copy/MMA, and control-flow API chapters.
Then read the architecture, TMA, pipeline, TMEM, numerical, correctness, and
performance chapters as the candidate requires.

All files in this directory are part of Tier II and are copied into the
agent's isolated workspace. No internet or repository lookup is required.


# File: 02-language-compilation-and-launch.md

# CuTe DSL language, compilation, and launch API

CuTe DSL is a compiled Python subset. Decorated Python functions are
preprocessed and traced into an intermediate representation, lowered toward
PTX and device code, then loaded and launched. Python remains the
metaprogramming language; DSL values represent generated runtime computation.

## The three compilation stages

1. **AST preprocessing.** The compiler rewrites supported loops, branches, and
   decorated function boundaries into structured regions.
2. **Tracing and partial evaluation.** Python executes with proxy arguments.
   Tensor operations emit IR; Python-static values are evaluated immediately.
3. **Lowering and execution.** The IR is optimized, lowered to target code,
   assembled, loaded, and launched.

This explains why a single function can contain both ordinary Python objects
and runtime DSL values. It also explains why an untaken Python branch may
vanish when preprocessing is disabled.

## Standard imports

```python
import cutlass
import cutlass.cute as cute
from cutlass.cute.runtime import from_dlpack, make_ptr
```

Architecture-specific modules are documented in Tier II. A candidate should
use only imports already permitted by its harness policy.

## `@cute.jit`

`@cute.jit` declares a compiled host function or an inline compiled helper.

Decorator form:

```text
@cute.jit
@cute.jit(preprocess=True)
@cute.jit(preprocess=False)
```

| Parameter | Type/default | Meaning |
| --- | --- | --- |
| `preprocess` | `bool`, true | Rewrite supported Python control flow before tracing |

Use the installed `preprocess` spelling.

Call behavior:

- Python may call a `@cute.jit` function.
- A `@cute.jit` or `@cute.kernel` function may call a `@cute.jit` helper; the
  helper is inlined at compile time.
- Static arguments specialize generated code.
- Runtime arguments become parameters of the generated function.
- A top-level JIT call may use `no_cache=True` to force recompilation. Normal
  authoring should leave caching enabled.

## `@cute.kernel`

`@cute.kernel` declares a GPU kernel. It cannot be called directly from
ordinary Python and cannot invoke another `@cute.kernel`.

Decorator form:

```text
@cute.kernel
@cute.kernel(preprocess=True)
@cute.kernel(preprocess=False)
```

| Parameter | Type/default | Meaning |
| --- | --- | --- |
| `preprocess` | `bool`, true | Preserve supported dynamic loops and branches as structured IR |

A JIT function first binds all declared kernel arguments:

```python
bound_kernel = device_kernel(argument_0, argument_1)
```

The resulting bound object is launched:

```python
bound_kernel.launch(grid=grid, block=block)
```

Binding and launching are separate. Calling `device_kernel.launch(...)`
without binding declared arguments does not satisfy the kernel signature.

## Kernel launch parameters

```text
bound_kernel.launch(
    *,
    grid,
    block,
    cluster=None,
    smem=None,
    stream=None,
    fallback_cluster=None,
    max_number_threads=(0, 0, 0),
    min_blocks_per_mp=0,
    use_pdl=False,
    cooperative=False,
    smem_merge_branch_allocs=False,
    preferred_smem_carveout=None,
)
```

The exact bound method may expose a subset of these options. Supply only
options required by the design.

| Parameter | Meaning |
| --- | --- |
| `grid` | Three-dimensional number of CTAs to launch |
| `block` | Three-dimensional thread count for each CTA |
| `cluster` | Preferred three-dimensional CTA-cluster shape |
| `smem` | Dynamic shared-memory bytes; `None` permits allocator-based calculation |
| `stream` | CUDA stream on which the kernel is launched |
| `fallback_cluster` | Minimum cluster shape when the preferred shape cannot be scheduled |
| `max_number_threads` | Maximum thread dimensions emitted as a launch bound |
| `min_blocks_per_mp` | Minimum resident blocks per multiprocessor hint |
| `use_pdl` | Enable programmatic dependent launch |
| `cooperative` | Request a cooperative launch |
| `smem_merge_branch_allocs` | Permit mutually exclusive branches to reuse shared storage |
| `preferred_smem_carveout` | Shared-memory versus L1 carveout preference |

`grid`, `block`, and cluster shapes are plain three-element tuples or lists.
Their values belong to the implementation, so this documentation does not
provide defaults.

## Calling convention matrix

| Caller | Callee | Allowed | Result |
| --- | --- | --- | --- |
| Python | `@cute.jit` | yes | JIT compilation or cache lookup, then execution |
| Python | `@cute.kernel` | no | kernel must be launched through JIT code |
| `@cute.jit` | `@cute.jit` | yes | compile-time inline call |
| `@cute.jit` | Python helper | yes | helper executes while tracing |
| `@cute.jit` | `@cute.kernel` | yes | bind, then launch |
| `@cute.kernel` | `@cute.jit` | yes | compile-time inline helper |
| `@cute.kernel` | Python helper | yes | helper executes while tracing |
| `@cute.kernel` | `@cute.kernel` | no | dynamic parallelism is not this calling model |

## Arguments and specialization

Common annotation classes are:

```text
cutlass.Constexpr     compile-time Python value
cutlass.Int32         runtime signed integer
cutlass.Int64         runtime signed integer
cutlass.Float32       runtime floating-point scalar
cute.Tensor           typed tensor view
cute.Pointer          typed pointer
```

Use `Constexpr` for facts that construct types, layouts, instruction atoms, or
unrolled structure. Use runtime scalar annotations for coordinates, dynamic
dimensions, and values that may vary without recompilation.

The JIT cache key depends on the compiled function and the static/type
specialization of its arguments. Converting a genuinely dynamic dimension to a
Python integer may create one compiled specialization per observed value.

## Candidate and harness boundary

When the surrounding harness owns compilation and evaluation:

- preserve the required JIT entry point and its signature;
- keep device work in CuTe DSL;
- do not add input generation, an oracle, timing, or a `main()` function;
- do not call `cute.compile` inside the candidate;
- let the harness bind external framework objects to the candidate entry point.

These are interface rules, not an algorithm. The task statement specifies the
actual arguments and semantics.


# File: 03-types-pointers-and-runtime.md

# Types, pointers, tensors, and runtime conversion

CuTe types describe both values and compile-time structure. A correct program
must distinguish Python-static values, runtime scalar proxies, layouts,
pointers, and tensors.

## Scalar type families

Representative public scalar types live under `cutlass`:

| Family | Representative types |
| --- | --- |
| Boolean | `Boolean` |
| Signed integer | `Int8`, `Int16`, `Int32`, `Int64` |
| Unsigned integer | `Uint8`, `Uint16`, `Uint32`, `Uint64` |
| Binary floating point | `Float16`, `BFloat16`, `TFloat32`, `Float32`, `Float64` |
| FP8 | `Float8E4M3FN`, `Float8E5M2` |
| Narrow types | release-supported FP6/FP4 types |
| Compile-time value | `Constexpr` |

A scalar type object acts as a conversion constructor:

```python
runtime_i = cutlass.Int32(value)
runtime_x = cutlass.Float32(value)
```

The conversion becomes generated code when `value` is a runtime proxy and is
folded when both type and value are static. Use the public type constructor;
there is no general requirement for a `cute.cast` or `cute.convert` helper.

## Static and runtime integers

Python `int` is a static metaprogramming value. CuTe integer proxies carry a
runtime IR value and may also carry divisibility information used by layout
algebra.

Runtime integers support arithmetic such as addition, subtraction,
multiplication, floor division, and remainder. Divisibility constraints
propagate through compatible arithmetic. They cannot be used wherever the
Python interpreter itself requires an integer, for example:

- indexing a Python tuple or list;
- selecting a Python class;
- setting a static array length;
- iterating `cutlass.range_constexpr`;
- changing the rank or nesting of a static layout.

Use `cute.is_static(value)` to distinguish a static value and
`cute.get_divisibility(value)` to query known integer divisibility when
available.

## `cute.Pointer`

A pointer combines an element type, address space, alignment, and address.

Important properties:

| Property | Meaning |
| --- | --- |
| `dtype` | pointed-to scalar type |
| `memspace` | global, shared, register, tensor, or generic address space |
| `alignment` / `max_alignment` | known byte alignment |

Common operations:

```text
pointer + element_offset
pointer - element_offset
pointer.align(minimum_byte_alignment)
pointer.toint()
```

Pointer offsets count elements of the pointer's dtype, not bytes. Alignment is
an assumption and a contract; declaring stronger alignment does not realign the
underlying allocation.

## `make_ptr`

```text
cutlass.cute.runtime.make_ptr(
    dtype,
    value,
    mem_space=cute.AddressSpace.generic,
    assumed_align=None,
) -> cute.Pointer
```

| Parameter | Meaning |
| --- | --- |
| `dtype` | scalar type of each pointed-to element |
| `value` | integer address or compatible pointer object |
| `mem_space` | address-space annotation |
| `assumed_align` | assumed byte alignment |

Use `nullptr(dtype, mem_space=..., assumed_align=...)` only when a null pointer
is part of a compilation or optional-argument contract.

## `cute.Tensor`

A tensor is an engine, usually a pointer, composed with a layout:

```text
tensor(coordinate) = engine[layout(coordinate)]
```

Core properties include:

| Property | Meaning |
| --- | --- |
| `element_type` | scalar element type |
| `layout` | coordinate-to-address mapping |
| `shape` | logical extents |
| `stride` | logical strides |
| `memspace` | storage address space |
| `iterator` | underlying engine |

Tensor indexing may use a scalar coordinate, a coordinate tuple, or a tuple
containing `None` to retain modes. The legality of a load or store also depends
on element type, address space, alignment, and whether the coordinate is in
bounds.

## Constructing a tensor from a pointer

```text
cute.make_tensor(pointer, layout) -> cute.Tensor
```

`pointer` and `layout` must describe the same allocation. The layout's codomain
must fit in the backing storage. A layout alone has no storage and cannot be
loaded, stored, copied, or partitioned as a tensor.

## DLPack conversion

```text
cutlass.cute.runtime.from_dlpack(
    tensor_dlpack,
    assumed_align=None,
    use_32bit_stride=False,
    *,
    enable_tvm_ffi=False,
    force_tf32=False,
) -> cute.Tensor
```

| Parameter | Meaning |
| --- | --- |
| `tensor_dlpack` | object implementing the DLPack producer protocol |
| `assumed_align` | byte alignment promised by the caller; defaults to element size |
| `use_32bit_stride` | use 32-bit dynamic strides when the addressable span permits it |
| `enable_tvm_ffi` | produce a TVM-FFI-compatible runtime argument |
| `force_tf32` | represent Float32 storage through a TF32 compute type where supported |

Conversion is a zero-copy view. The original storage owner must remain alive,
and producer and consumer must obey compatible stream ordering.

## Dynamic runtime tensor layouts

Runtime DLPack tensors initially carry concrete shape and stride metadata.
Methods can replace selected facts by dynamic constraints:

```text
tensor.mark_layout_dynamic(leading_dim=None) -> tensor
tensor.mark_compact_shape_dynamic(
    mode,
    stride_order=None,
    divisibility=1,
) -> tensor
```

`mark_layout_dynamic` keeps the identified leading dimension at stride one and
makes other supported layout facts dynamic. If `leading_dim` is omitted, the
method attempts to infer a unique stride-one dimension. The current API is
limited to flat layouts.

`mark_compact_shape_dynamic` marks one compact shape mode dynamic and
propagates the constraint into strides.

| Parameter | Meaning |
| --- | --- |
| `mode` | shape mode to make dynamic |
| `stride_order` | outermost-to-innermost mode ordering |
| `divisibility` | promised divisibility of the runtime extent |

Omitting `stride_order` is valid only when the compact ordering is
unambiguous.

## Shared storage structures

`@cute.struct` defines compile-time shared-storage records:

```text
cute.struct.MemRange[dtype, count]
cute.struct.Align[field_type, byte_alignment]
```

`MemRange` describes a typed fixed-size range. Its data object provides
`data_ptr()` and `get_tensor(layout, swizzle=None, dtype=None)`.
`Align` assigns explicit alignment to a scalar, range, or nested struct.

The resulting struct class provides static size and alignment information.
Allocation belongs to an allocator such as `cutlass.utils.SmemAllocator`; the
struct decorator itself is not an allocator.

## Memory-space discipline

| Space | Typical owner and lifetime |
| --- | --- |
| Global memory | application-visible allocation, survives the kernel |
| Shared memory | one CTA or cluster, allocated for a launch |
| Register memory | one thread's generated values |
| Tensor memory | Blackwell tensor-core storage with explicit protocol |
| Generic | pointer whose concrete space is not encoded strongly |

An equal dtype and shape do not make pointers from different address spaces
interchangeable. Copy and MMA operations constrain the source and destination
spaces they accept.

## Elementwise math intrinsics

Reciprocal square root is a `cute` intrinsic rather than a Python or NumPy call:

```text
cute.rsqrt(x)
```

Use it where a normalization needs `1 / sqrt(...)`; computing it as `x ** -0.5`
inside a kernel is not equivalent and may not lower.


# File: 04-layout-tensor-and-algebra-api.md

# Layout, tensor-view, and algebra API

A CuTe layout maps a logical coordinate to a linear coordinate. It is not a
memory allocation. A tensor combines that mapping with an engine such as a
pointer.

## Shape, stride, and rank

For flat shape `(d0, d1)` and stride `(s0, s1)`:

```text
offset(i0, i1) = i0 * s0 + i1 * s1
```

Shapes and strides may be hierarchical tuples. Hierarchy carries semantic
structure such as tile, thread, value, pipeline-stage, or instruction modes.
Two layouts with equal flattened extents can still express different
ownership.

## `make_layout`

```text
cute.make_layout(shape, *, stride=None) -> Layout
```

| Parameter | Meaning |
| --- | --- |
| `shape` | integer or nested integer tuple describing logical extents |
| `stride` | optional integer or nested tuple describing coordinate weights |

When `stride` is omitted, CuTe constructs a compact layout following its
left-major convention. State stride explicitly whenever physical order is part
of the external tensor contract.

Layout properties:

```text
layout.shape
layout.stride
layout.max_alignment
```

## Tensor construction and indexing

```text
cute.make_tensor(engine, layout) -> Tensor
```

The engine is commonly a pointer or fragment storage. The layout codomain
addresses the engine.

```python
value = tensor[coordinate]
tensor[coordinate] = value
subview = tensor[(None, fixed_coordinate)]
```

`None` retains a mode instead of selecting one coordinate from it. The returned
object may be a scalar value or another tensor view depending on the retained
modes.

## Extent and structure queries

| API | Result |
| --- | --- |
| `cute.rank(object)` | number of top-level modes |
| `cute.depth(object)` | hierarchy nesting depth |
| `cute.size(object, mode=None)` | logical element count, optionally for selected modes |
| `cute.cosize(layout)` | minimum codomain span addressed by a layout |
| `cute.size_in_bytes(dtype, layout)` | byte storage needed for a typed layout |
| `cute.is_static(object)` | whether structure is known at compile time |
| `cute.is_congruent(a, b)` | exact structural congruence |
| `cute.is_weakly_congruent(a, b)` | weaker compatible structure test |
| `cute.pretty_str(object)` | readable static representation |

`size` and `cosize` answer different questions. A strided or swizzled layout
can address a larger codomain than its logical number of elements.

## Coordinate conversion

```text
cute.crd2idx(coordinate, layout) -> index
cute.idx2crd(index, shape) -> coordinate
```

`crd2idx` applies the layout mapping. `idx2crd` reconstructs a coordinate under
the supplied shape/layout convention. These functions reason about logical
coordinates; they do not validate that a resulting pointer access lies within
an allocation.

## Slicing and selecting modes

```text
cute.slice_(object, coordinate) -> sliced object
cute.select(object, mode) -> selected modes
cute.front(object) -> first leaf or mode
cute.get_leaves(object) -> flattened leaves
cute.group_modes(object, begin, end=None) -> regrouped object
cute.append(object, value, up_to_rank=None) -> extended object
cute.prepend(object, value, up_to_rank=None) -> extended object
```

The same structural operation may accept a shape, stride, layout, coordinate,
or tensor. The result preserves the kind of the input where the API defines
that transformation.

`group_modes` changes hierarchy but not storage. Regroup only when the consumer
expects the resulting mode structure.

## Layout transformations

Representative public operations:

| API | Purpose |
| --- | --- |
| `cute.coalesce(layout, target_profile=None)` | combine compatible adjacent modes |
| `cute.composition(outer, inner)` | compose coordinate mappings |
| `cute.complement(layout, codomain)` | construct uncovered codomain mapping |
| `cute.logical_divide(object, tiler)` | divide into tile and rest modes |
| `cute.zipped_divide(object, tiler)` | divide and group tile/rest modes |
| `cute.tiled_divide(object, tiler)` | divide by a hierarchical tiler |
| `cute.logical_product(a, b)` | build a logical product layout |
| `cute.blocked_product(a, b)` | build a blocked product |
| `cute.raked_product(a, b)` | build a raked product |

These operations transform coordinate structure. They do not copy data.
Composition order matters: `composition(a, b)` applies the inner mapping and
then the outer mapping.

## Tiling

```text
cute.local_tile(
    tensor,
    tiler,
    coordinate,
    proj=None,
) -> Tensor
```

| Parameter | Meaning |
| --- | --- |
| `tensor` | source tensor view |
| `tiler` | tile shape or hierarchical tiler |
| `coordinate` | coordinate selecting a tile in the quotient modes |
| `proj` | optional mode projection |

The result is a view. It does not allocate or transfer storage.

```text
cute.local_partition(
    target,
    tiler,
    index,
    proj=1,
) -> Tensor
```

`local_partition` assigns a tiler's partition selected by `index`. It is a
general layout operation; it is not interchangeable with copy- or MMA-specific
partition methods.

## Layout comparison questions

Before passing a layout or tensor to another API, establish:

1. rank and hierarchy;
2. logical shape;
3. stride-one mode;
4. codomain span;
5. element type and memory space;
6. static versus runtime modes;
7. ownership expected by the consumer.

Matching only the printed shape is insufficient.

## Swizzles

`cute.make_swizzle(b, m, s)` constructs a bitwise address permutation. `b` is
the number of swizzle bits, `m` is the number of unchanged low bits, and `s`
is the shift distance used by the XOR mapping.

Swizzles are normally composed with an existing layout. They change address
mapping, not logical shape. The three parameters must follow from the memory
operation and bank-layout contract; they are not general tuning knobs.

## Static and dynamic layouts

A static layout contains Python-known extents and strides and participates in
specialization. A dynamic layout contains runtime integer leaves with known
constraints. Rank and tuple nesting remain static even when selected extents
are dynamic.

Dynamic layout values can participate in generated arithmetic but cannot
change Python structure during execution. Preserve static hierarchy and make
only genuinely variable leaves dynamic.

## Deriving an operand's major mode

The major mode is read from the tensor, not chosen from a constant:

```text
utils.LayoutEnum.from_tensor(tensor).mma_major_mode()
```

There is no `LayoutEnum.RowMajor` and no `LayoutEnum.MMA_MAJOR_A`, and a layout
object has no `leading_dim` attribute.

## Integer arithmetic and composed layouts

Ceiling division lives on `cute`, not on `cutlass`:

```text
cute.ceil_div(value, divisor)
```

It accepts a tuple as well as a scalar, which is how a launch grid is derived
from a shape and a tile shape. `cutlass.ceil_div` does not exist; reaching for
it is a common carry-over from the C++ interface.

A layout produced by composing a swizzle with an underlying layout has its own
type, and appears in annotations where a shared-memory layout is passed:

```text
cute.ComposedLayout
```


# File: 05-copy-mma-memory-and-sync-api.md

# Copy, MMA, memory, and synchronization API

CuTe expresses data movement and matrix operations through atoms and tiled
operations. An atom describes one hardware or logical operation. A tiled
operation composes atoms with participant and value layouts.

## Copy object model

```text
CopyOp -> CopyAtom -> TiledCopy -> ThrCopy -> tensor partitions
```

- `CopyOp` identifies an instruction or logical copy operation.
- `CopyAtom` combines that operation with an element/value layout.
- `TiledCopy` maps the copy across a thread layout.
- `ThrCopy` is the slice owned by one participant.

Representative constructors:

```text
cute.make_copy_atom(copy_operation, copy_internal_type, **operation_parameters)
cute.make_tiled_copy(copy_atom, thread_value_layout, tiler)
cute.make_tiled_copy_tv(copy_atom, thread_layout, value_layout)
```

| Parameter | Meaning |
| --- | --- |
| `copy_operation` | instruction or logical copy operation |
| `copy_internal_type` | scalar type used to express the atom's source/destination layouts |
| operation parameters | operation-specific options such as `num_bits_per_copy` for a universal copy |
| `thread_value_layout` | combined participant/value mapping |
| `tiler` | logical tile covered by the tiled copy |
| `thread_layout` | mapping from participant coordinate to participant ID |
| `value_layout` | values owned by each participant |

## Copy partitioning

```text
tiled_copy.get_slice(thread_index) -> ThrCopy
thread_copy.partition_S(source_tensor) -> Tensor
thread_copy.partition_D(destination_tensor) -> Tensor
```

`partition_S` and `partition_D` are methods on the participant slice. The
source and destination must be tensors, not layouts. Their per-participant
value counts and ordering must match the copy atom.

## Issuing a copy

```text
cute.copy(
    atom_or_tiled_copy,
    source,
    destination,
    *,
    pred=None,
    unroll_factor=None,
    **operation_parameters,
) -> None
```

| Parameter | Meaning |
| --- | --- |
| `atom_or_tiled_copy` | copy operation defining transfer semantics |
| `source` | compatible source tensor or partition |
| `destination` | compatible destination tensor or partition |
| `pred` | optional predicate tensor/value for guarded transfers |
| `unroll_factor` | optional generated-loop unroll control |
| operation parameters | instruction-specific barriers, masks, or cache controls |

`cute.autovec_copy(source, destination)` requests a compiler-selected vectorized
copy when the source/destination layout and alignment permit one. It does not
replace an instruction-specific asynchronous protocol.

## Register fragments

```text
cute.make_rmem_tensor(layout_or_shape, dtype) -> Tensor
cute.make_rmem_tensor_like(source, dtype=None) -> Tensor
cute.full(shape, fill_value, dtype) -> TensorSSA
cute.full_like(source, fill_value, dtype=None) -> TensorSSA
```

`make_rmem_tensor` creates thread-local fragment storage. `full` creates an SSA
tensor value and requires shape, fill value, and dtype. A tensor SSA value and
a pointer-backed `cute.Tensor` are different object kinds.

## MMA object model

```text
MmaOp -> MmaAtom -> TiledMma -> ThrMma -> operand/accumulator partitions
```

- `MmaOp` identifies an instruction family and its operand contract.
- `MmaAtom` wraps the instruction with layouts.
- `TiledMma` maps it over an instruction or CTA tile.
- `ThrMma` is the participant-specific slice.

Representative construction:

```text
cute.make_tiled_mma(
    mma_operation_or_atom,
    atom_layout_mnk=(1, 1, 1),
    permutation_mnk=None,
) -> TiledMma
```

The first argument may be an MMA operation or an already constructed atom.
The `atom_layout_mnk` maps atoms over logical M/N/K modes.
`permutation_mnk` optionally changes the operand/accumulator mode order.

Common `TiledMma` surface:

```text
tiled_mma.get_slice(participant_index) -> ThrMma
tiled_mma.get_tile_size(mode_index) -> shape
tiled_mma.partition_shape_A(shape_mk)
tiled_mma.partition_shape_B(shape_nk)
tiled_mma.partition_shape_C(shape_mn)
tiled_mma.make_fragment_A(tensor_or_partition)
tiled_mma.make_fragment_B(tensor_or_partition)
tiled_mma.make_fragment_C(tensor_or_partition)
tiled_mma.shape_mnk
tiled_mma.size
```

Common `ThrMma` surface:

```text
thread_mma.partition_A(tensor_mk) -> Tensor
thread_mma.partition_B(tensor_nk) -> Tensor
thread_mma.partition_C(tensor_mn) -> Tensor
```

The operand suffix expresses the logical role. It is not a generic source or
destination marker.

## Issuing an MMA

```text
cute.gemm(atom, destination, operand_a, operand_b, source_accumulator) -> None
```

The five roles are:

1. MMA atom or tiled MMA;
2. destination accumulator;
3. A fragment;
4. B fragment;
5. prior/source accumulator.

The selected instruction determines whether the destination aliases the source
accumulator, whether the operation overwrites or accumulates, and where the
fragments reside.

## Shared-memory allocation

High-level allocator:

```text
cutlass.utils.SmemAllocator.allocate_tensor(
    element_type,
    layout,
    byte_alignment=1,
    swizzle=None,
) -> Tensor
```

| Parameter | Meaning |
| --- | --- |
| `element_type` | scalar type stored in shared memory |
| `layout` | exact shared-memory layout |
| `byte_alignment` | required start alignment |
| `swizzle` | optional address swizzle when not already composed into layout |

Low-level path:

```text
cute.arch.alloc_smem(dtype, count, alignment) -> Pointer
cute.make_tensor(pointer, layout) -> Tensor
```

`count` is an element count; derive it from the exact layout codomain. The
pointer, layout, and declared alignment must agree.

## Device index functions

All dimensional index functions return three values and take no axis argument:

```text
cute.arch.thread_idx() -> (x, y, z)
cute.arch.block_dim() -> (x, y, z)
cute.arch.block_idx() -> (x, y, z)
cute.arch.grid_dim() -> (x, y, z)
cute.arch.cluster_idx() -> (x, y, z)
cute.arch.cluster_dim() -> (x, y, z)
```

Additional scalar queries:

```text
cute.arch.lane_idx()
cute.arch.warp_idx()
cute.arch.physical_warp_id()
cute.arch.block_idx_in_cluster()
cute.arch.dynamic_smem_size()
```

## Synchronization functions

| API | Scope and role |
| --- | --- |
| `cute.arch.sync_warp(mask=None)` | synchronize participating warp lanes |
| `cute.arch.sync_threads()` | synchronize threads in a CTA |
| `cute.arch.barrier(barrier_id, number_of_threads)` | named CTA barrier |
| `cute.arch.barrier_arrive(barrier_id, number_of_threads)` | split-phase arrival |
| `cute.arch.elect_one()` | context selecting one lane in each warp |
| `cute.arch.make_warp_uniform(value)` | assert/hint that an integer is warp-uniform |

Barrier IDs, participant counts, and scope are semantic parameters, not
arbitrary constants. Every required participant must execute compatible
barrier control flow.

Transaction-barrier and Blackwell-specific functions are described in Tier II.

## TMA atom and pipeline constructors

```text
cute.nvgpu.make_tiled_tma_atom_A(...)
cute.nvgpu.make_tiled_tma_atom_B(...)

pipeline.PipelineTmaUmma.create(...)
pipeline.PipelineUmmaAsync.create(...)
pipeline.CooperativeGroup(...)
pipeline.Agent.Thread
pipeline.NamedBarrier
```

## Cross-lane exchange

A warp-level butterfly shuffle exchanges a value between lanes at a given
offset:

```text
cute.arch.shuffle_sync_bfly(value, offset=<int>)
```

It returns the partner lane's value; combining the returned value with the local
one, over a descending sequence of offsets, is the standard way to reduce across
a warp without shared memory. The offsets and the combining operation are yours
to choose for the reduction you need.


# File: 06-control-flow-assumptions-and-output.md

# Control flow, assumptions, and diagnostic output

CuTe's default AST preprocessor converts supported Python control flow into
structured IR. Whether a condition or bound is Python-static or DSL-runtime
determines where it executes.

## Loop forms

| Form | Evaluation | Parameters |
| --- | --- | --- |
| `cutlass.range_constexpr(...)` | Python compile time, fully unrolled | static start/stop/step |
| `range(...)` | generated runtime loop under preprocessing | runtime-compatible start/stop/step |
| `cutlass.range(...)` | generated runtime loop | start/stop/step plus compiler controls |

`cutlass.range` may accept controls such as:

| Parameter | Meaning |
| --- | --- |
| `unroll` | requested unroll factor or policy |
| `unroll_full` | request complete unrolling when legal |
| `prefetch_stages` | request compiler software pipelining |

Software-pipelining controls alter generated scheduling; they do not create
hardware transaction barriers or repair a manually staged asynchronous
pipeline.

`range_constexpr` requires every bound to be known to Python during tracing.
Use it when each iteration constructs static code or types. Use a runtime range
when the trip count is a DSL value.

## Branches

```text
if cutlass.const_expr(static_predicate):
    ...  # Python compile-time branch

if runtime_predicate:
    ...  # structured runtime branch
```

`cutlass.const_expr(value)` requires a compile-time value. It removes untaken
code from the specialization. An ordinary `if` over a DSL Boolean emits both
structured regions.

The same distinction applies to `while`: a `const_expr` condition executes
during tracing; a DSL condition emits runtime control flow.

## Dynamic-region restrictions

Inside generated dynamic loops and branches:

- `break`, `continue`, early `return`, and exception raising are unsupported;
- a value first created inside a region is not automatically available after
  the region;
- a variable cannot change its Python/DSL type across branches or iterations;
- Python container shape and tuple nesting cannot change at runtime;
- a runtime proxy cannot drive reflection, imports, generators, or dynamic
  dispatch.

Keep Python metaprogramming outside dynamic regions. Express runtime selection
with values and compatible tensor operations rather than changing object
structure.

## Compile-time assumptions

```text
cute.assume(value, divby=None) -> value
```

`divby` is a positive Python integer stating that a runtime integer is
divisible by that value. The function returns the constrained value. The
assumption must be true for every launch; it is not a runtime check. This
release does not expose lower- or upper-bound keywords on `cute.assume`.

Use explicit task validation or predication when a condition is not guaranteed.
False assumptions may enable invalid addressing or code generation.

## Static inspection

Python output runs during tracing:

```python
print(layout)
print(tensor.shape, tensor.stride)
print(cute.pretty_str(fragment))
```

It can inspect static object kinds, layouts, shapes, strides, and
specialization choices. A runtime scalar prints as a proxy representation
rather than its device value.

## Device output

```text
cute.printf(format_or_value, *values)
```

Supported styles include:

```python
cute.printf(value)
cute.printf("index={}, value={}", index, value)
cute.printf("value=%.3f", value)
```

Device printing affects timing and can produce large output. Guard it to a
small participant subset and remove it before performance measurement.

## Compilation and runtime stages

Classify a failure by its earliest stage:

1. Python parse/import;
2. decorator argument binding;
3. AST preprocessing;
4. tracing and object/type construction;
5. IR verification/lowering;
6. PTX assembly;
7. kernel launch and resources;
8. asynchronous execution or memory access;
9. numerical validation;
10. performance measurement.

An error reported during a later synchronization can originate from an earlier
asynchronous launch. The earliest deterministic diagnostic is normally the
most useful evidence.

## API-use discipline

- Treat free functions, object methods, layouts, tensors, atoms, and
  participant slices as different kinds.
- Preserve the exact namespace and argument roles documented locally.
- Do not translate a CUDA C++, Triton, or framework idiom by guessing a CuTe
  spelling.
- Do not build further logic on an unverified return object.
- Compilation validates syntax and types; a real launch validates resources,
  address spaces, and synchronization.


# File: 07-layout-reasoning.md

# Reasoning about layouts, tensors, and ownership

The core API chapter lists layout functions. This chapter explains how to
reason with them.

## Four views of every tensor

Record four distinct descriptions:

1. **Mathematical view:** the modes used by the operation.
2. **Physical view:** the order and strides in memory.
3. **Tiled view:** the region assigned to one CTA or cluster.
4. **Participant view:** the values owned by a thread, warp, or instruction.

A layout error often comes from silently replacing one view with another.
Equal element counts do not imply equal coordinate meaning.

## Shape and stride are a mapping

For coordinate `(i, j)` under shape `(m, n)` and stride `(s_m, s_n)`:

```text
linear_coordinate = i * s_m + j * s_n
```

The stride-one mode is physically contiguous. Names such as row-major and
column-major are shorthand; the actual shape/stride pair is authoritative.

For hierarchical shapes:

```text
((tile_mode, within_tile_mode), other_mode)
```

the matching stride hierarchy explains how each nested coordinate contributes
to the address. Preserve hierarchy while another object uses it to identify
instruction, stage, thread, or value modes.

## Logical size, codomain size, and allocation

Three quantities answer different questions:

- `cute.size(layout)` counts logical coordinates.
- `cute.cosize(layout)` describes the required linear codomain span.
- `cute.size_in_bytes(dtype, layout)` describes typed storage bytes.

A strided layout may have `cosize > size`. A composed or swizzled layout may
also address a nontrivial codomain. Allocation must cover the codomain, not just
the logical count.

## Static versus dynamic structure

Static facts:

- rank and tuple hierarchy;
- element and address-space types;
- instruction atoms;
- most thread/value mappings;
- specialization choices.

Potentially dynamic facts:

- problem extents;
- coordinates;
- selected strides;
- loop trip counts;
- predicates.

Making everything static produces many specializations. Making structure
dynamic prevents Python from constructing types and layouts. The useful middle
ground keeps hierarchy and divisibility static while representing only varying
extent leaves as runtime values.

## Tiling versus partitioning

Tiling answers:

```text
Which region of the whole tensor belongs to this CTA or work item?
```

Partitioning answers:

```text
Which values in that region belong to this participant or hardware atom?
```

Typical object flow:

```text
whole tensor
  -> CTA tile through local_tile
  -> operation-specific partition through ThrCopy or ThrMma
  -> fragment compatible with an instruction
```

Do not substitute a manually reshaped tensor for an operation-specific
partition merely because its shape is similar. The operation object may encode
address-space, ownership, and vectorization constraints that are invisible in
the printed extent.

## Copy congruence

For a tiled copy, verify:

1. the participant slice came from the same `TiledCopy`;
2. `partition_S` receives the source tensor;
3. `partition_D` receives the destination tensor;
4. per-participant value counts agree;
5. vector modes map to physically compatible strides;
6. all active participants have valid coordinates;
7. predicates cover every possibly invalid source and destination coordinate.

A predicated synchronous copy and a transaction-counted asynchronous copy have
different tail requirements. Do not promise bytes for accesses that a
predicate suppresses.

## MMA congruence

An MMA connects:

- logical M/N/K modes;
- the tiled instruction shape;
- A, B, and accumulator layouts;
- participant ownership;
- operand memory spaces and formats.

The A partition consumes an M/K view, B consumes an N/K view under the chosen
physical convention, and C/D consume an M/N view. The operation's partition
methods establish the exact mapping.

The physical B tensor may expose N/K even when the mathematical notation writes
K/N. That representation is a layout decision, not an implicit transpose.
Always derive the oracle and indexing from the declared physical view.

## Shared-memory layouts and swizzles

A shared-memory layout must satisfy all of:

- storage fits;
- pointer alignment is sufficient;
- the producer copy can write it;
- the consumer copy or MMA can read it;
- stage modes do not overlap;
- bank mapping is legal and useful.

Swizzling changes address bits to alter bank access. Reusing a swizzle with a
different element width, tile, or consumer can invalidate the mapping. Prefer a
layout constructed for the selected operation instead of treating swizzle
parameters as independent tuning values.

## Tensor memory is a separate address space

Blackwell tensor memory is not register memory or shared memory. A TMEM tensor
requires:

- a TMEM allocation;
- a compatible TMEM layout;
- an instruction that writes it;
- completion before reads;
- a matching TMEM-to-register copy;
- release after the final consumer.

A fragment initially carrying only layout metadata is not usable storage until
it is bound to an allocated pointer in the correct address space.

## Bounds and tails

For each logical mode, state whether the implementation:

- requires exact divisibility;
- pads a physical allocation;
- predicates a compatible load/store;
- uses a separate tail path.

Predicating a write does not make an out-of-bounds read safe. Predicating a TMA
transaction may also require changing transaction bytes and pipeline
participation. Derive safety at every memory boundary.

## Coordinate audit

For a small hypothetical coordinate:

1. expand the whole-tensor layout;
2. calculate the selected CTA tile coordinate;
3. identify retained and selected modes;
4. expand the participant partition;
5. compute the physical address;
6. check bounds and alignment;
7. confirm the consumer interprets the modes identically.

This audit is more reliable than changing index arithmetic based only on an
output pattern.


# File: 08-blackwell-architecture.md

# Blackwell execution architecture

Blackwell kernels combine several independently scheduled engines. Performance
comes from overlap, but correctness comes from explicit ownership and
synchronization among those engines.

## Execution hierarchy

```text
grid
  -> optional clusters of CTAs
    -> CTA / thread block
      -> warps
        -> lanes
```

- A lane is one thread within a warp.
- A warp executes in SIMT fashion.
- A CTA shares shared memory and CTA barriers.
- A cluster permits limited cross-CTA coordination and distributed shared
  memory.
- A grid contains all CTAs launched for the kernel.

Collectives require the documented participant set. A branch that excludes one
required lane, warp, or CTA can deadlock even when excluded participants do no
arithmetic.

## Memory hierarchy

| Space | Scope | Typical role |
| --- | --- | --- |
| Global memory | device/application | input and output tensors |
| Shared memory | CTA or cluster | staged tiles and barriers |
| Registers | thread | scalar work and register fragments |
| Tensor memory | CTA group on Blackwell | `tcgen05` accumulators and related fragments |

Address space is part of type compatibility. A layout suitable for one space
does not make a pointer from another space legal.

## Independent engines

A high-throughput Blackwell dataflow may involve:

- TMA for multidimensional global/shared transfers;
- ordinary or asynchronous copy instructions;
- `tcgen05` tensor-core MMA;
- TMEM copy instructions;
- CUDA cores for scalar/vector epilogues;
- barriers that communicate completion.

These engines can run asynchronously relative to issuing threads and to each
other. Program order alone is not a completion guarantee.

## Conceptual dense dataflow

```text
global operands
  -> TMA or copy
  -> staged shared-memory operands
  -> tensor-core MMA
  -> tensor-memory accumulator
  -> register fragment
  -> conversion or epilogue
  -> global output
```

This is a vocabulary map, not a required implementation. Elementwise and
reduction kernels may use only global memory, registers, and shared memory.
Choose engines from the operation contract.

## Warp specialization

Warp-specialized kernels give different roles to different warps, such as:

- producer role: issue data movement;
- compute role: issue tensor-core operations;
- consumer role: load accumulators and store results.

Role assignment must agree with:

- the block thread count;
- cooperative-group participant counts;
- named barriers;
- pipeline producer/consumer groups;
- TMEM allocation ownership;
- cluster participation.

The role structure is a design invariant. It is not safe to change the block
size independently.

## CTA clusters

A cluster provides:

- a cluster coordinate and shape;
- cross-CTA synchronization;
- distributed shared-memory addressing;
- TMA multicast opportunities;
- instruction modes that cooperate across CTAs.

Cluster shape affects the grid mapping: grid dimensions count CTAs, while a
work tile may be owned by a cluster. Every dimension must divide or cover the
intended launch space under the chosen scheduling policy.

Multicast requires a mask derived from cluster coordinates and an identical
receiver protocol. Sending data to a CTA that does not wait or omitting a CTA
that does wait breaks completion.

## One-CTA and multi-CTA tensor-core work

Blackwell tensor-core instructions may be issued by one CTA or a cooperating
CTA group. Changing that mode affects:

- legal instruction shapes;
- cluster constraints;
- operand sharing;
- TMEM allocation and ownership;
- synchronization;
- which participants store output.

It is not merely a boolean performance option.

## Resource coupling

The following values form one resource equation:

```text
operand tile
pipeline stages
shared-memory layouts
barrier storage
tensor-memory columns
register fragments
threads and roles
cluster shape
```

Increasing a tile or stage count can raise reuse and overlap while also
increasing shared memory, TMEM, registers, and live barriers. A configuration
can trace correctly but fail launch-resource validation.

## Target checks

The study device is a B300-class Blackwell target. Exact compute capability,
CUDA toolchain, and CUTLASS build decide instruction availability. Distinguish:

1. architecture family supports a concept;
2. the installed package exposes an API;
3. the selected operation supports the concrete dtypes/layouts;
4. generated code targets the device;
5. launch resources fit.

Do not infer native tensor-core execution from an FP8 storage type alone.

## Ownership table

For each asynchronous object, write:

| Question | Required answer |
| --- | --- |
| Who initializes it? | one lane, warp, CTA, or cluster |
| Who issues work? | exact producer participant set |
| Who observes completion? | exact consumer participant set |
| What storage does it protect? | tensor/layout/stage |
| What event marks completion? | byte arrival, commit, wait, or barrier phase |
| When is it reused or released? | after all consumers finish |

This table makes architectural protocols explicit without selecting any
task-specific implementation.


# File: 09-tma-and-transaction-barriers.md

# TMA and transaction-barrier foundations

The Tensor Memory Accelerator performs multidimensional transfers between
global and shared memory. A legal TMA transfer is a contract among a descriptor,
tensor layouts, a shared-memory tile, participants, and a transaction barrier.

## TMA operation families

Representative copy-operation objects under
`cutlass.cute.nvgpu.cpasync` include:

```text
CopyBulkTensorTileG2SOp
CopyBulkTensorTileG2SMulticastOp
CopyBulkTensorTileS2GOp
CopyReduceBulkTensorTileS2GOp
```

The operation selects direction and semantics. It is passed to a TMA atom
factory; it is not itself a tensor or descriptor.

## Generic TMA atom factory

```text
cpasync.make_tiled_tma_atom(
    op,
    gmem_tensor,
    smem_layout,
    cta_tiler,
    num_multicast=1,
    *,
    internal_type=None,
) -> TmaInfo
```

| Parameter | Meaning |
| --- | --- |
| `op` | TMA copy operation |
| `gmem_tensor` | global tensor and physical layout |
| `smem_layout` | destination/source shared-memory layout, possibly staged |
| `cta_tiler` | CTA-level tile definition |
| `num_multicast` | number of multicast recipients |
| `internal_type` | optional descriptor element type when storage type is unsupported directly |

The returned TMA tensor maps logical global coordinates to descriptor
coordinates. It is not ordinary data storage.

## MMA-aware A/B factories

```text
cute.nvgpu.make_tiled_tma_atom_A(
    op,
    gmem_tensor,
    smem_layout,
    mma_tiler_mnk,
    tiled_mma,
    cluster_shape_vmnk=None,
    *,
    internal_type=None,
) -> TmaInfo

cute.nvgpu.make_tiled_tma_atom_B(
    op,
    gmem_tensor,
    smem_layout,
    mma_tiler_mnk,
    tiled_mma,
    cluster_shape_vmnk=None,
    *,
    internal_type=None,
) -> TmaInfo
```

The specialized factories account for the M/K or N/K projection expected by
the tiled MMA and for multicast across the complementary cluster mode.

`TmaInfo` exposes:

```text
.atom
.smem_layout
.tma_tensor
```

Treat it as an object with named fields, not as an assumed tuple.
Two-item unpacking into `(atom, tma_tensor)` remains supported for backward
compatibility; `smem_layout` is available through the named property.

## TMA partitioning

```text
cpasync.tma_partition(
    atom,
    cta_coord,
    cta_layout,
    smem_tensor,
    gmem_tensor,
) -> (smem_partition, gmem_partition)
```

| Parameter | Meaning |
| --- | --- |
| `atom` | TMA copy atom |
| `cta_coord` | current coordinate in the CTA layout |
| `cta_layout` | participating CTA/cluster layout |
| `smem_tensor` | shared-memory tensor compatible with the atom |
| `gmem_tensor` | TMA coordinate tensor or compatible global view |

Partitioning preserves descriptor semantics. An equal-shape manual view is not
necessarily an equivalent replacement.

## Issuing TMA through `cute.copy`

The TMA atom and partitions are passed to `cute.copy`. Instruction-specific
keyword arguments may include:

| Parameter | Role |
| --- | --- |
| `tma_bar_ptr` | transaction-barrier pointer associated with the destination stage |
| `mcast_mask` | cluster recipient mask for multicast loads |

The selected copy operation defines which arguments are legal. TMA issue is
asynchronous; completion is represented by the associated transaction barrier.

## Transaction bytes

A transaction barrier tracks both thread arrivals and asynchronous byte
arrivals. The expected byte count must equal the transfers associated with that
barrier phase.

Derive bytes from:

```text
element type
exact tile layout
number of operand/scale transfers
multicast protocol
predicated or omitted transfers
```

Do not count logical elements when the physical transfer uses a different
internal type or packed representation.

## Barrier API

```text
cute.arch.mbarrier_init(mbar_ptr, arrival_count)
cute.arch.mbarrier_init_fence()
cute.arch.mbarrier_expect_tx(
    mbar_ptr,
    transaction_bytes,
    peer_cta_rank_in_cluster=None,
)
cute.arch.mbarrier_arrive_and_expect_tx(
    mbar_ptr,
    transaction_bytes,
    peer_cta_rank_in_cluster=None,
    relaxed=False,
    scope=CTA,
)
cute.arch.mbarrier_arrive(
    mbar_ptr,
    peer_cta_rank_in_cluster=None,
    arrive_count=1,
)
cute.arch.mbarrier_wait(mbar_ptr, phase)
cute.arch.mbarrier_try_wait(mbar_ptr, phase)
```

| Argument | Meaning |
| --- | --- |
| `mbar_ptr` | pointer to barrier storage in shared memory |
| `arrival_count` / `arrive_count` | initialized phase count / decrement performed by one arrive |
| `transaction_bytes` | asynchronous bytes required for completion |
| `peer_cta_rank_in_cluster` | optional remote CTA whose barrier is addressed |
| `phase` | parity/phase expected by the waiter |

The try/test operations return DSL Booleans suitable for generated control
flow.

## Election rules

Barrier initialization and expected-byte registration are single-thread state
operations. Use `cute.arch.elect_one()` around such operations when the
documented call requires one issuing lane.

The TMA copy operation already performs its own issue election. Wrapping the
TMA `cute.copy` itself in another election can change participant behavior and
cause deadlock.

After barrier initialization:

1. publish initialized barrier state with the required init fence;
2. synchronize the participating CTA or cluster as required;
3. issue transfers against that barrier;
4. perform required explicit arrivals;
5. wait for the matching phase before consuming data.

This ordering is architectural. It does not specify a task's tensors or tile
sizes.

## Multicast masks

```text
cpasync.create_tma_multicast_mask(
    cta_layout_vmnk,
    cta_coord_vmnk,
    mcast_mode,
) -> Int16
```

The mask is derived from the cluster layout, current CTA coordinate, and the
logical mode shared across recipients. Every selected receiver must follow the
same stage and barrier protocol.

## Descriptor utilities

```text
cpasync.prefetch_descriptor(tma_atom)
cpasync.copy_tensormap(tma_atom, tensormap_ptr)
cpasync.update_tma_descriptor(tma_atom, gmem_tensor, descriptor_ptr)
cpasync.fence_tma_desc_acquire(descriptor_ptr)
cpasync.cp_fence_tma_desc_release(global_descriptor_ptr, shared_descriptor_ptr)
cpasync.fence_tma_desc_release()
```

Descriptor update changes the encoded base address, shape, and strides while
preserving other descriptor fields. Acquire/release fences order descriptor
visibility. These utilities are needed only when descriptors are managed
dynamically; ordinary static descriptors do not require manual updates.


# File: 10-pipelines-and-ownership.md

# Asynchronous pipelines and ownership

A pipeline is a ring of storage stages plus synchronization state. The stage
index identifies a storage slot; the phase distinguishes successive uses of
that slot.

## Pipeline vocabulary

Conceptual producer:

```text
wait until a stage is reusable
issue asynchronous work associated with the stage
publish or commit completion responsibility
advance to the next stage
```

Conceptual consumer:

```text
wait until a stage is complete
consume its data
release the stage for reuse
advance to the next stage
```

These are roles, not universal method names. Different pipeline classes model
different completion engines.

## Pipeline namespace

Pipeline classes live under:

```python
import cutlass.pipeline as pipeline
```

Core participant types:

```text
pipeline.Agent.Thread
pipeline.Agent.Warp
pipeline.Agent.ThreadBlock
pipeline.Agent.ThreadBlockCluster
pipeline.CooperativeGroup(agent, size=1)
```

`CooperativeGroup` receives an `Agent` enum first and an optional participant
count. An integer alone is not an agent kind.

## TMA-to-UMMA pipeline

```text
pipeline.PipelineTmaUmma.create(
    *,
    num_stages,
    producer_group,
    consumer_group,
    tx_count,
    barrier_storage=None,
    cta_layout_vmnk=None,
    mcast_mode_mn=(1, 1),
    enable_multicast_signaling=False,
    defer_sync=False,
    name="",
) -> pipeline
```

| Parameter | Meaning |
| --- | --- |
| `num_stages` | ring length |
| `producer_group` | participants issuing TMA work |
| `consumer_group` | participants consuming staged operands |
| `tx_count` | expected asynchronous bytes per stage |
| `barrier_storage` | optional shared-memory backing; omitted storage uses the reserved allocator |
| `cta_layout_vmnk` | optional cluster participant layout |
| `mcast_mode_mn` | multicast modes for operand sharing |
| `enable_multicast_signaling` | enable consumer signaling across multicast recipients |
| `defer_sync` | postpone factory-owned initial synchronization |
| `name` | optional profiling/debug label |

This class couples TMA byte arrival to readiness for UMMA consumption. A
producer does not add an unrelated commit if transaction completion already
publishes the stage.

## UMMA asynchronous pipeline

```text
pipeline.PipelineUmmaAsync.create(
    *,
    num_stages,
    producer_group,
    consumer_group,
    barrier_storage=None,
    cta_layout_vmnk=None,
    defer_sync=False,
    name="",
) -> pipeline
```

This class coordinates asynchronous tensor-core output with its consumer.
Completion is based on the UMMA commit/wait protocol rather than TMA byte
arrival.

## Participant interface

On the study worker, a created pipeline can expose paired participants:

```text
producer, consumer = created_pipeline.make_participants()
```

Participant lifecycle:

```text
producer.acquire_and_advance() -> producer token
consumer.wait_and_advance() -> consumer token
producer_token.commit()
consumer_token.release()
```

Token fields are pipeline-specific. A TMA producer token commonly provides the
barrier associated with the acquired stage. Do not call a method merely because
its name appears on another pipeline or on the internal pipeline object.

Lower-level pipeline state APIs may expose:

```text
pipeline.make_pipeline_state(role, stages)
state.advance()
state.clone()
pipeline_object.producer_acquire(state, try_acquire_token=None)
pipeline_object.producer_get_barrier(state)
pipeline_object.producer_commit(state)
pipeline_object.producer_tail(state)
pipeline_object.consumer_wait(state, try_wait_token=None)
pipeline_object.consumer_get_barrier(state)
pipeline_object.consumer_release(state)
```

Use one coherent interface style. Do not combine participant tokens from one
style with manually advanced state from another.

## Named barriers

```text
pipeline.NamedBarrier(
    barrier_id,
    num_threads,
)
```

A named barrier coordinates a fixed CTA participant count. Hardware IDs are
in `[0, 15]`; ID 0 is also used by CTA synchronization. Barrier ID and count
must not collide with other protocols in the same kernel.

```text
pipeline.sync(barrier_id=...)
```

is a pipeline-namespace synchronization helper when available. Its signature
is not interchangeable with `cute.arch.barrier`.

## Deriving stage count

More stages can hide latency but increase:

- operand shared memory;
- barrier storage;
- live descriptors and state;
- register pressure;
- prologue and drain work.

Stage count follows from a resource and latency model. It is not supplied here
because no single value is correct across operations or shapes.

## Prologue, steady state, and drain

Any multistage loop has three logical regions:

1. **Prologue:** fill enough stages before the first consumer use.
2. **Steady state:** issue future work while consuming completed work.
3. **Drain:** finish outstanding consumers and release or tail the pipeline.

Count events for a finite number of work items:

```text
producer acquisitions == stages actually written
consumer waits == stages actually consumed
consumer releases == reusable stages returned
```

If an acquired stage is never published, or a consumed stage is never
released, later reuse can stall.

## Phase discipline

A circular slot is reused, so waiting on only its numeric stage index is
ambiguous. Pipeline state carries phase/parity. Every acquire, wait, release,
and advance must refer to the same logical generation of the slot.

Copying a stage index while dropping phase state can read stale completion from
a prior ring traversal.

## Warp and CTA participation

For each pipeline:

- define producer and consumer warps;
- derive cooperative-group sizes from those roles;
- initialize barrier storage exactly once;
- ensure all required participants reach initialization synchronization;
- ensure role branches remain compatible with named/CTA/cluster barriers;
- release stages even when a participant has no arithmetic work.

Predicates over data coordinates must not accidentally predicate required
pipeline state transitions.

## Persistent scheduling

Persistent kernels reuse CTAs across multiple work tiles. Before a CTA moves to
another tile, all stages belonging to the prior tile must be drained or
reinitialized according to the pipeline contract. Work-tile scheduling and
pipeline lifetime are coupled.

## Resource ledger

Maintain a local ledger:

| Resource | Formula source |
| --- | --- |
| staged operand bytes | exact typed SMEM layout × stage count |
| barrier bytes | pipeline factory/storage type |
| transaction bytes | physical transfers per stage |
| producer participants | role assignment |
| consumer participants | role assignment |
| prologue iterations | pipeline and work count |
| drain operations | outstanding stages/tokens |

The ledger is general; its values must be derived from the current
implementation.


# File: 11-tcgen05-tmem-and-epilogues.md

# `tcgen05`, tensor memory, and epilogues

Blackwell `tcgen05` is an instruction family for tensor-core operations and
tensor-memory transfers. Its operand types, layouts, tile shapes, and CTA-group
mode are coupled.

## Namespace and operation families

```python
import cutlass.utils as utils
import cutlass.utils.blackwell_helpers as blackwell_helpers
from cutlass.cute.nvgpu import tcgen05
```

The namespace includes:

- dense narrow-precision MMA operations;
- block-scaled MMA operations;
- TMEM load/store/copy operations;
- commit and wait operations;
- CTA-group and field enums.

Use a construction helper or documented operation class. Do not encode an
instruction descriptor from remembered PTX fields.

## Tiled MMA construction inputs

A Blackwell tiled MMA construction needs:

| Input | Meaning |
| --- | --- |
| A element type | physical scalar type of operand A |
| A major mode | stride/layout interpretation for A |
| B element type or compatible family | physical scalar type of operand B |
| B major mode | stride/layout interpretation for B |
| accumulator type | type accumulated by the instruction |
| CTA group | one-CTA or cooperating-CTA instruction mode |
| MMA tiler M/N | instruction-level output tiler |
| CTA/MMA tiler | operation-level M/N/K tiling |

These facts determine legal operand fragments. They are not independent
keywords to guess.

The recommended Blackwell helper form for a dense trivial tiled MMA has seven
required positional roles:

```text
blackwell_helpers.make_trivial_tiled_mma(
    a_dtype,
    b_dtype,
    a_major,
    b_major,
    accumulator_dtype,
    cta_group,
    mma_tiler_mn,
)
```

An optional eighth positional argument selects the source kind for A and
defaults to shared memory. A deprecated overload accepts one shared A/B dtype;
use separate dtypes for new code. The helper derives remaining instruction
details from types and major modes. No concrete atom shape is prescribed here.

## Operand major modes

`cutlass.utils.LayoutEnum.from_tensor(tensor).mma_major_mode()` derives the
major mode from a tensor's physical layout. A and B may use different modes.

The mode describes how the instruction sees contiguous structure. It is not
the same as a mathematical transpose flag and must remain consistent with TMA
and shared-memory layouts.

## Shared-memory operand layouts

Blackwell helpers provide operation-compatible staged layouts:

```text
blackwell_helpers.make_smem_layout_a(
    tiled_mma,
    mma_tiler_mnk,
    a_dtype,
    num_stages,
    *,
    is_k_major=None,
)

blackwell_helpers.make_smem_layout_b(
    tiled_mma,
    mma_tiler_mnk,
    b_dtype,
    num_stages,
    *,
    is_k_major=None,
)
```

The result includes a stage mode. Allocate from the complete returned layout;
do not append a second stage mode manually.

## TMEM allocation model

Tensor memory is allocated in columns through `cutlass.utils.TmemAllocator`.
The constructor binds shared-memory address storage to a named barrier:

```text
utils.TmemAllocator(
    alloc_result_dst_smem_ptr=None,
    *,
    barrier_for_retrieve,
    allocator_warp_id=0,
    is_two_cta=False,
    num_allocated_columns=0,
    two_cta_tmem_dealloc_mbar_ptr=None,
    arch="sm_100",
    initialize_mbarrier=True,
)
```

`arch` selects the allocator instruction target. `initialize_mbarrier` controls
automatic setup of the optional two-CTA deallocation barrier.

Representative methods:

```text
allocator.reserve(number_of_columns) -> buffer pool
allocator.allocate(number_of_columns)
allocator.wait_for_alloc()
allocator.retrieve_ptr(dtype=...) -> TMEM Pointer
buffer_pool.allocate_tensor(layout, dtype) -> Tensor
allocator.relinquish_alloc_permit()
allocator.free(tmem_ptr, num_columns=0)
```

Exact allocation/free ownership depends on the selected allocator style and
CTA group. Use one coherent style.

TMEM allocation generally has:

1. one designated participant reserves or allocates;
2. required participants wait for allocation visibility;
3. fragments are rebound to the allocated TMEM pointer;
4. MMA writes TMEM;
5. consumers wait before reading;
6. the epilogue finishes;
7. the owner releases TMEM.

Releasing before all consumers finish is a use-after-release even if the
Python object remains in scope.

## Accumulator fragments

The tiled MMA supplies a compatible C/D partition shape and fragment layout:

```text
thread_mma.partition_C(output_tile)
tiled_mma.partition_shape_C(output_shape)
tiled_mma.make_fragment_C(partition_or_shape)
```

An accumulator fragment may initially describe layout without usable backing
storage. Binding that layout to an allocated TMEM pointer creates the actual
TMEM tensor.

Do not initialize a TMEM fragment with a generic register `.fill()` unless its
type and address space explicitly support that operation.

## MMA accumulation semantics

For a reduction over K tiles:

```text
first contribution: initialize or overwrite the accumulator
later contributions: accumulate into the existing value
```

The chosen operation exposes this distinction through an accumulator/source
field, an operation variant, or an instruction parameter. Applying accumulate
mode to uninitialized TMEM reads undefined prior state. Reinitializing every K
iteration drops earlier contributions.

## Commit and completion

`tcgen05` work is asynchronous. Issuing MMA does not make TMEM immediately
readable. The design must connect:

- instruction issue;
- commit of the correct group;
- completion barrier or pipeline token;
- consumer wait;
- TMEM load.

Some commit operations must be issued by one elected lane. All relevant
participants must observe compatible control flow around the wait.

## TMEM-to-register copies

A TMEM load operation is combined with a copy atom/tiled copy whose value
layout matches the accumulator fragment:

```text
tcgen05.make_tmem_copy(load_operation, accumulator_tensor)
tiled_copy.get_slice(participant)
partition source TMEM
partition destination register fragment
cute.copy(...)
```

The load operation width and repetition must cover the fragment owned by each
participant. Changing the accumulator tile changes this relationship.

## Epilogue choices

Simple direct epilogue:

```text
TMEM -> register fragment -> conversion/arithmetic -> predicated GMEM store
```

Staged epilogue:

```text
TMEM -> register fragment -> shared-memory layout -> asynchronous GMEM store
```

The staged path can improve transfer efficiency but introduces:

- extra SMEM;
- copy partitioning;
- CTA synchronization;
- optional store-pipeline state;
- more tail constraints.

Select it based on a measured bottleneck and a compatible output contract.

## Epilogue helper families

The installed Blackwell utilities include helper families for:

```text
make_smem_layout_epi
get_tmem_load_op
get_smem_store_op
epilog_tmem_copy_and_partition
epilog_smem_copy_and_partition
epilog_gmem_copy_and_partition
```

These helpers construct layouts and partitions. Their concrete arguments
depend on the tiled MMA, output type/layout, and chosen subtile structure.
Their existence does not prescribe an epilogue design.

## Completion boundary

Before releasing TMEM or returning from the kernel, prove:

1. all MMA contributions were committed;
2. the accumulator consumer waited for completion;
3. every promised output element was loaded and stored;
4. shared-memory stores, if any, completed;
5. all participants reached required barriers;
6. no later instruction refers to released TMEM.

## Exact member names

These are the names the installed Python DSL exposes. They do not mirror the
CUTLASS C++ spellings, and the difference is usually one of case convention
rather than a missing feature.

```text
tcgen05.CtaGroup.ONE          CTA group selector for a single-CTA MMA
tcgen05.Field.ACCUMULATE      the accumulate field set on a tiled MMA
tcgen05.Repetition.x64        repetition selector
tcgen05.make_tmem_copy(...)   TMEM copy construction
```

`CTA_GROUP`, `CTA_Group`, and `CtaGroup.CTA_SINGLE` do not exist.

Helpers for Blackwell tiled-MMA and shared-memory layout construction live in
`cutlass.utils.blackwell_helpers`:

```text
sm100_utils.make_trivial_tiled_mma(...)
sm100_utils.make_smem_layout_a(...)
sm100_utils.make_smem_layout_b(...)
```

## TMEM load operations

Loading an accumulator out of tensor memory uses a load-op object parameterized
by a repetition count:

```text
tcgen05.Ld32x32bOp(tcgen05.Repetition.x64)
```

The op is passed to `tcgen05.make_tmem_copy(...)` to build the copy that moves
accumulator fragments from TMEM into registers for the epilogue.


# File: 12-low-precision-numerics.md

# FP8, FP4, scaling, and numerical contracts

Low-precision storage is not a complete numerical specification. A kernel also
needs the format, scale direction, scale granularity, accumulation type,
intermediate conversions, output type, and exceptional-value behavior.

## Floating-point fields

A binary floating-point format encodes:

```text
sign | exponent | significand/fraction
```

More exponent bits increase dynamic range. More fraction bits improve local
precision. Fewer total bits increase rounding and saturation pressure.

## FP8 formats

| Format | Exponent bits | Fraction bits | Main tradeoff |
| --- | ---: | ---: | --- |
| E4M3 | 4 | 3 | greater precision, smaller range |
| E5M2 | 5 | 2 | greater range, lower precision |

Common CuTe type names:

```text
cutlass.Float8E4M3FN
cutlass.Float8E5M2
```

The `FN` suffix denotes a finite-value-oriented E4M3 encoding. E4M3 and E5M2
are different byte interpretations and cannot be exchanged by changing only a
type annotation.

NVIDIA E4M3FN has maximum finite magnitude 448. E5M2 provides a much larger
range at lower precision. Always follow the dtype in the task/runtime tensor
rather than choosing by habit.

## Quantization and dequantization

One common convention:

```text
q = round_and_clamp(real / scale)
real_approx = q * scale
```

An inverse-scale convention:

```text
q = round_and_clamp(real * inverse_scale)
real_approx = q / inverse_scale
```

The variable name alone does not establish direction. Write the actual
equation before implementing arithmetic.

For independently dequantized operands:

```text
A_real ~= A_low * scale_A
B_real ~= B_low * scale_B
A_real @ B_real ~= (A_low @ B_low) * scale_A * scale_B
```

This identity does not determine where scaling is applied. An instruction,
accumulator path, or epilogue may incorporate it. Apply each logical scale
exactly once.

## Scale granularity

Common scale ownership:

- one value per tensor;
- one value per row, column, or channel;
- one value per fixed-size block;
- hierarchical block and tensor scales.

Scale layout is part of the tensor contract. Each data coordinate must select
the scale owned by the same logical group. A wrong mode can produce smooth,
plausible output while systematically scaling the wrong rows or blocks.

## Dense FP8

Dense FP8 tensor-core MMA consumes FP8 operands directly. External scaling may
have been used to create those operands, but scale tensors are not instruction
operands unless the operation explicitly includes them.

Storage dtype, multiply behavior, accumulator dtype, and output dtype remain
separate:

```text
FP8 storage -> narrow multiply -> usually wider accumulation -> output conversion
```

Do not dequantize both full operands to FP32 inside a candidate and call the
result an FP8 tensor-core implementation.

## Block-scaled FP8 and MX formats

Block-scaled instructions consume operand blocks and corresponding scale
factors. A common MXFP8 family uses:

- E4M3 or E5M2 operand values;
- E8M0-like power-of-two scale representation;
- scale ownership over a fixed K-axis block;
- FP32 accumulation.

Logical scale coordinates and physical scale storage are distinct. Instruction
utilities may pack or swizzle scale layouts for GMEM, SMEM, and TMEM.

Adding an arbitrary scale tensor to dense FP8 does not create an MXFP8
contract. Use a block-scaled instruction only when the declared scale type,
granularity, and physical layout match it.

## FP4 and packed storage

E2M1 FP4 uses one sign bit, two exponent bits, and one fraction bit. Its finite
magnitudes are:

```text
0, 0.5, 1, 1.5, 2, 3, 4, 6
```

Two logical FP4 values occupy one byte. A packed-storage contract must specify:

- which nibble holds the first logical element;
- bit interpretation and sign;
- logical element count versus byte count;
- scale ownership;
- padding for an odd logical count.

Scalar dereference of a sub-byte typed tensor is not generally supported in the
4.6.1 DSL path. Elementwise packed work may require typed byte loads and
explicit nibble extraction. Vectorized copy or tensor-core paths can retain a
packed narrow type when their operation supports it.

Plain packed E2M1 is not automatically NVFP4. NVFP4 additionally defines scale
types, block granularity, layouts, and a compatible block-scaled instruction.

## Accumulation

Reduction error depends on:

- accumulator precision;
- reduction length;
- summation order;
- cancellation;
- fast-accumulation modes;
- frequency of conversion or rescaling.

FP32 accumulation often reduces error, but the task contract is authoritative.
Fast accumulation can change both speed and numerical behavior and must be
validated as an optimization.

Initialize the accumulator exactly once per logical output. Distinguish the
first reduction contribution from later accumulation.

## Conversion and nonlinear arithmetic

Apply reductions and nonlinear operations in the declared compute type. Convert
to the output type at the declared boundary.

Public scalar type constructors perform conversion:

```python
converted = cutlass.Float32(value)
```

Simple selection can use generated comparisons:

```python
result = positive_value if predicate else negative_value
```

Whether Python conditional syntax lowers to elementwise selection depends on
the value type and preprocessed region. Preserve type compatibility across
both branches.

## Rounding, saturation, and non-finite values

Specify:

- rounding mode where observable;
- saturation or overflow behavior;
- treatment of NaN and infinity;
- output conversion point.

Do not silently clamp an intermediate unless the mathematical contract says
so. Do not let an output cast hide overflow produced earlier.

## Four error budgets

Separate:

1. input quantization error;
2. kernel arithmetic/accumulation error;
3. scale placement/indexing error;
4. output conversion error.

When the evaluator supplies already-quantized inputs, kernel correctness is
normally measured against a reference derived from those stored values and
their scales. Comparing only with original high-precision pre-quantized values
mixes two different error sources.

## Numerical invariants

General invariants:

- zeros obey the operation's zero behavior;
- signs and monotonicity are preserved where mathematically required;
- changing one scale affects only its owned group;
- scaling does not depend on tile or stage count;
- every output is initialized and written;
- unexpected NaN or infinity fails validation;
- repeated execution is deterministic within the operation's guarantees.

These invariants diagnose numerical contracts without supplying a task
algorithm.


# File: 13-correctness-and-performance-method.md

# Correctness and performance method

Kernel development is a sequence of separate gates. Passing an earlier gate
does not imply passing a later one.

## Development gates

1. Candidate policy and public interface.
2. Python parsing and imports.
3. JIT argument binding.
4. tracing and API object construction.
5. IR/PTX compilation.
6. legal launch and resource configuration.
7. memory and synchronization safety.
8. numerical validation.
9. repeatability.
10. performance measurement.

Optimize only after gate eight passes for every required case.

## Write the contract before the implementation

Record:

```text
mathematical equation
logical tensor modes
physical shapes and strides
storage, compute, accumulator, and output dtypes
scale direction, granularity, and layout
alignment and divisibility guarantees
tail behavior
entry point and output ownership
```

These facts come from the task, not from the documentation tier.

## Correctness oracle principles

An independent oracle should:

- use the actual stored low-precision inputs;
- decode physical layouts and packed formats correctly;
- apply scale direction and granularity exactly;
- reproduce accumulator and epilogue semantics;
- convert to the requested output type at the same logical boundary.

The candidate must not contain or weaken the harness-owned oracle.

## Structured validation cases

Useful generic patterns:

- zeros and exactly representable small values;
- positive/negative signs;
- identity or one-hot structure;
- row/column ramps;
- alternating signs and cancellation;
- distinct scale values per group;
- multiple reduction tiles;
- multiple output tiles;
- supported boundary cases.

Each pattern isolates a class of mistakes. It does not determine an
operation's implementation.

## Output coverage and safety

Initialize the output with a sentinel when the evaluator supports it. Verify
that every promised element is written and no guard region changes.

For every access, reason about:

- coordinate bounds;
- physical stride;
- allocation span;
- alignment;
- address space;
- asynchronous completion;
- lifetime.

An unspecified launch failure is not a numerical mismatch and should not be
handled by changing tolerance.

## Error metrics

Combined absolute and relative comparison handles both near-zero and large
values:

```text
abs_error = abs(output - reference)
relative_error = abs_error / max(abs(reference), relative_floor)
pass if abs_error <= atol + rtol * abs(reference)
```

Tolerance follows from the declared numerical contract. Never loosen it only
because one candidate fails.

Also inspect:

- maximum and mean absolute error;
- guarded relative error;
- location and pattern of the worst errors;
- count of non-finite values;
- repeat-to-repeat variation.

## Measurement boundary

Kernel-only timing excludes:

- compilation and cache misses;
- tensor allocation;
- input generation;
- reference computation;
- descriptor construction owned outside the launch;
- profiling startup;
- device printing.

Warm up the exact executor, inputs, specialization, and stream used for timing.
Synchronize through a valid event or stream boundary.

## Latency and throughput

Report a robust statistic such as median latency over bounded repetitions.
Minimum latency can reveal the best uncontended run but should not replace the
distribution.

For a matrix product with batch count `L`:

```text
work = 2 * M * N * K * L floating-point operations
throughput = work / seconds
```

Use an operation-specific work definition for non-GEMM kernels. State the
definition rather than comparing unlike metrics.

## Native-path evidence

Low-precision storage alone does not prove low-precision tensor-core execution.
Evidence can come from:

- the selected documented instruction object;
- generated PTX/SASS instruction family;
- profiler counters consistent with the intended engine.

The measured interval must execute candidate CuTe code, not a framework
fallback.

## Resource-aware optimization

Potential dimensions:

- tile and vector width;
- block/warp role structure;
- shared-memory staging;
- pipeline depth;
- cluster cooperation;
- epilogue path;
- persistent scheduling;
- specialization.

Change one family at a time. Revalidate correctness and resources after every
change. A larger tile or deeper pipeline can reduce memory latency while also
reducing occupancy or exceeding resource limits.

## Comparing candidates

Keep:

- exact candidate hash/configuration;
- correctness status;
- median and dispersion;
- resource observations;
- instruction-path evidence;
- compiler/runtime diagnostics.

Treat differences within evaluator noise as ties. Retain a known-correct
candidate while exploring.


# File: 01-language-and-launch-patterns.md

# Language, control-flow, and launch patterns

Tier III adds code fragments. Every uppercase name is deliberately undefined.
Fragments demonstrate one API boundary at a time and do not form a complete
task kernel.

## Decorated kernel and JIT boundary

```python
@cute.kernel
def device_operation(
    source: cute.Tensor,
    destination: cute.Tensor,
    logical_count: cutlass.Int32,
):
    # Device implementation is intentionally omitted.
    ...


@cute.jit
def entrypoint(
    source: cute.Tensor,
    destination: cute.Tensor,
    logical_count: cutlass.Int32,
):
    device_operation(source, destination, logical_count).launch(
        grid=(GRID_X, GRID_Y, 1),
        block=(BLOCK_X, 1, 1),
    )
```

The kernel arguments are bound before `.launch`. `GRID_X`, `GRID_Y`, and
`BLOCK_X` must be derived from the operation and resource model.

## Coordinate extraction

```python
thread_x, thread_y, thread_z = cute.arch.thread_idx()
block_x, block_y, block_z = cute.arch.block_idx()
block_size_x, block_size_y, block_size_z = cute.arch.block_dim()
grid_size_x, grid_size_y, grid_size_z = cute.arch.grid_dim()
```

The functions return tuples. A one-dimensional linear coordinate can be
expressed as:

```python
linear_thread = block_x * block_size_x + thread_x
```

This expression says nothing about which tensor mode the coordinate owns.

## Runtime predicate

```python
coordinate = COMPUTE_LOGICAL_COORDINATE()
if coordinate < runtime_extent:
    USE_VALID_COORDINATE(coordinate)
```

The branch is generated runtime control flow because the predicate contains
DSL values. Every object used in both regions must keep a compatible type.

## Compile-time specialization

```python
@cute.jit
def specialized_helper(
    runtime_value: cutlass.Int32,
    feature_enabled: cutlass.Constexpr,
):
    if cutlass.const_expr(feature_enabled):
        APPLY_OPTIONAL_STATIC_FEATURE(runtime_value)
    else:
        APPLY_BASE_FEATURE(runtime_value)
```

Each `feature_enabled` value creates a specialization. The uppercase calls
represent compatible generated operations.

## Static and dynamic loops

```python
@cute.jit
def loop_forms(
    runtime_count: cutlass.Int32,
    static_count: cutlass.Constexpr,
):
    for static_index in cutlass.range_constexpr(static_count):
        BUILD_STATIC_OBJECT(static_index)

    for runtime_index in cutlass.range(runtime_count):
        PROCESS_RUNTIME_ITEM(runtime_index)
```

The static loop creates code during tracing. The runtime loop emits an IR loop.
Do not pass `runtime_count` to `range_constexpr`.

## Runtime loop with compiler controls

```python
for runtime_index in cutlass.range(
    runtime_count,
    unroll=UNROLL_POLICY,
):
    PROCESS_RUNTIME_ITEM(runtime_index)
```

`UNROLL_POLICY` is a compile-time choice. It is deliberately not assigned a
value.

## Static and runtime debugging

```python
print("static layout:", layout)
print("static shape:", tensor.shape)

if thread_x == 0 and block_x == 0:
    cute.printf("runtime coordinate={}, value={}", coordinate, value)
```

Python `print` runs while compiling. `cute.printf` runs on the device. Remove
device printing before timing.

## Alignment and divisibility assumptions

```python
runtime_extent = cute.assume(runtime_extent, divby=REQUIRED_DIVISIBILITY)
```

This is a compiler assumption, not a check. Only use divisibility guaranteed
by the external contract or preceding control flow.

## Optional cluster launch

```python
bound = device_operation(arguments...)
bound.launch(
    grid=(GRID_X, GRID_Y, GRID_Z),
    block=(BLOCK_X, BLOCK_Y, BLOCK_Z),
    cluster=(CLUSTER_X, CLUSTER_Y, CLUSTER_Z),
    smem=SHARED_MEMORY_BYTES,
    stream=stream,
)
```

Cluster, dynamic shared memory, and stream are independent launch parameters
but must agree with kernel allocation and synchronization. No values shown here
are defaults.

## Candidate interface preservation

```python
class ModelNew:
    forward = staticmethod(entrypoint)
```

This compatibility alias does not compile or launch the kernel by itself. The
harness calls the named JIT entry point and owns external inputs and
evaluation.


# File: 02-layout-and-tensor-patterns.md

# Layout and tensor-view patterns

These fragments illustrate coordinate mappings and view operations. The small
extents are neutral teaching values, not launch or kernel recommendations.

## Flat physical layouts

```python
left_major = cute.make_layout((4, 8))
right_major = cute.make_layout((4, 8), stride=(8, 1))

print(left_major.shape, left_major.stride)
print(right_major.shape, right_major.stride)
```

The layouts have equal logical shape and different address mappings.

## Coordinate-to-index check

```python
layout = cute.make_layout((4, 8), stride=(8, 1))
coordinate = (2, 3)
linear = cute.crd2idx(coordinate, layout)
```

For this static example, `linear` is the sum of each coordinate multiplied by
its stride. Use such checks to verify coordinate order before adding tiling.

## Hierarchical layout

```python
hierarchical = cute.make_layout(
    ((OUTER_MODE, INNER_MODE), OTHER_MODE),
    stride=((OUTER_STRIDE, INNER_STRIDE), OTHER_STRIDE),
)
```

Every uppercase leaf must be derived from a storage contract. Hierarchy is
preserved in `.shape` and `.stride`.

## Pointer plus layout

```python
typed_pointer = make_ptr(
    ELEMENT_TYPE,
    raw_address,
    cute.AddressSpace.gmem,
    assumed_align=ASSUMED_ALIGNMENT,
)
tensor = cute.make_tensor(typed_pointer, physical_layout)
```

`ASSUMED_ALIGNMENT` promises an existing property of the allocation. It does
not change the address.

## Runtime framework view

```python
runtime_tensor = from_dlpack(
    framework_tensor,
    assumed_align=ASSUMED_ALIGNMENT,
    use_32bit_stride=USE_32BIT_STRIDE,
)
```

The conversion is zero-copy. Keep `framework_tensor` alive through completion.

## Dynamic compact mode

```python
runtime_tensor = runtime_tensor.mark_compact_shape_dynamic(
    mode=DYNAMIC_MODE,
    stride_order=PHYSICAL_STRIDE_ORDER,
    divisibility=EXTENT_DIVISIBILITY,
)
```

The mode, ordering, and divisibility are part of the specialization contract.

## Local tile

```python
cta_tile = cute.local_tile(
    whole_tensor,
    (TILE_MODE_0, TILE_MODE_1),
    (tile_coordinate_0, tile_coordinate_1),
)
```

The result is a view of the same storage. The tile coordinate lives in quotient
modes created by division.

## Retaining and selecting modes

```python
all_first_mode_at_second_coordinate = tensor[(None, second_coordinate)]
selected_modes = cute.select(tensor, SELECTED_MODE_PROFILE)
grouped = cute.group_modes(tensor, BEGIN_MODE, END_MODE)
```

`None` retains a mode. `select` chooses modes. `group_modes` changes hierarchy.
None of these operations copies data.

## Logical versus codomain storage

```python
logical_elements = cute.size(layout)
storage_elements = cute.cosize(layout)
storage_bytes = cute.size_in_bytes(ELEMENT_TYPE, layout)
```

Allocate according to `storage_bytes` or the exact allocator contract, not
only `logical_elements`.

## Shared-memory tensor

```python
smem_allocator = utils.SmemAllocator()
smem_tensor = smem_allocator.allocate_tensor(
    ELEMENT_TYPE,
    SHARED_LAYOUT,
    byte_alignment=BYTE_ALIGNMENT,
)
```

The layout, element type, and byte alignment are a coupled contract. This
fragment does not construct `SHARED_LAYOUT`.

## Low-level shared-memory path

```python
element_count = cute.cosize(SHARED_LAYOUT)
smem_pointer = cute.arch.alloc_smem(
    ELEMENT_TYPE,
    element_count,
    alignment=BYTE_ALIGNMENT,
)
smem_tensor = cute.make_tensor(smem_pointer, SHARED_LAYOUT)
```

Use either a compatible allocator or the low-level pointer path; do not
allocate twice for one tensor.

## Participant ownership table

Before indexing a view, record:

```text
whole tensor modes:
CTA tile modes:
participant modes:
retained modes after slicing:
physical stride-one mode:
valid coordinate predicate:
```

This table is intentionally blank because its contents are task- and
implementation-specific.


# File: 03-copy-and-partition-patterns.md

# Copy and partition patterns

These fragments show the boundaries among copy operations, tiled copies,
participant slices, and tensors. The operation, layouts, widths, and
participants remain unspecified.

## Synchronous tiled copy

```python
copy_atom = cute.make_copy_atom(
    COPY_OPERATION,
    ELEMENT_TYPE,
    num_bits_per_copy=COPY_WIDTH_BITS,
)
tiled_copy = cute.make_tiled_copy_tv(
    copy_atom,
    THREAD_LAYOUT,
    VALUE_LAYOUT,
)

participant_copy = tiled_copy.get_slice(participant_index)
source_partition = participant_copy.partition_S(source_tensor)
destination_partition = participant_copy.partition_D(destination_tensor)

cute.copy(copy_atom, source_partition, destination_partition)
```

The fragment does not define the operation or layouts. The source and
destination partitions must have congruent per-participant values.

## Predicated copy

```python
predicate = BUILD_PREDICATE_FROM_LOGICAL_COORDINATES()
cute.copy(
    copy_atom,
    source_partition,
    destination_partition,
    pred=predicate,
)
```

The predicate layout must correspond to the copy's value layout. A scalar
predicate may guard an entire participant transfer; a tensor predicate can
guard individual values when supported.

## Compiler-selected vector copy

```python
cute.autovec_copy(source_fragment, destination_fragment)
```

Use this only when both fragments expose compatible contiguous structure and
alignment. The compiler chooses a legal vectorization; the call does not add
asynchronous completion.

## Generic TMA atom

```python
tma_atom, tma_coordinate_tensor = cpasync.make_tiled_tma_atom(
    TMA_OPERATION,
    global_tensor,
    SHARED_LAYOUT,
    CTA_TILER,
    num_multicast=MULTICAST_COUNT,
)
```

The operation, shared layout, CTA tiler, and multicast count must describe one
physical transfer. This fragment does not issue it.

## TMA partition

```python
smem_partition, gmem_partition = cpasync.tma_partition(
    tma_atom,
    cta_coordinate,
    CTA_LAYOUT,
    shared_tensor,
    tma_coordinate_tensor,
)
```

The output partitions are associated with the descriptor. Do not replace them
with equal-shape manual tensors.

## Transaction-barrier setup

```python
with cute.arch.elect_one():
    cute.arch.mbarrier_init(barrier_pointer, ARRIVAL_COUNT)
    cute.arch.mbarrier_expect_tx(barrier_pointer, TRANSACTION_BYTES)

cute.arch.mbarrier_init_fence()
cute.arch.sync_threads()
```

`ARRIVAL_COUNT` and `TRANSACTION_BYTES` follow from participants and physical
transfers. No values are supplied.

## TMA issue

```python
cute.copy(
    tma_atom,
    gmem_partition,
    smem_partition,
    tma_bar_ptr=barrier_pointer,
    mcast_mask=MULTICAST_MASK,
)
```

Do not wrap this call in `elect_one`; the TMA operation handles its issue
election. Omit `mcast_mask` for a non-multicast operation.

## Completion wait

```python
with cute.arch.elect_one():
    cute.arch.mbarrier_arrive(barrier_pointer)

cute.arch.mbarrier_wait(barrier_pointer, phase)
```

This illustrates separate thread arrival and byte completion. A pipeline may
encapsulate these transitions instead of exposing raw barrier calls.

## Multicast mask

```python
mask = cpasync.create_tma_multicast_mask(
    CTA_LAYOUT_VMNK,
    cta_coordinate_vmnk,
    MULTICAST_MODE,
)
```

The cluster layout and current coordinate define recipients. `MULTICAST_MODE`
identifies the shared logical mode, not a bit number chosen independently.

## Copy audit

For each fragment, fill in:

```text
source address space:
destination address space:
element/internal type:
source layout:
destination layout:
participants:
bytes or values per participant:
boundary predicate:
completion event:
lifetime after completion:
```

The blank audit prevents a syntax pattern from becoming a task recipe.


# File: 04-pipeline-and-tmem-patterns.md

# Pipeline and tensor-memory patterns

These fragments demonstrate object lifecycles. They omit the operation,
resource values, role predicates, iteration space, and tensor layouts.

## Cooperative groups

```python
producer_group = pipeline.CooperativeGroup(
    pipeline.Agent.Thread,
    PRODUCER_PARTICIPANTS,
)
consumer_group = pipeline.CooperativeGroup(
    pipeline.Agent.Thread,
    CONSUMER_PARTICIPANTS,
)
```

The counts must equal the actual participating threads. A group with the wrong
agent enum or count can construct an invalid pipeline.

## TMA/UMMA pipeline factory

```python
created_pipeline = pipeline.PipelineTmaUmma.create(
    num_stages=NUMBER_OF_STAGES,
    producer_group=producer_group,
    consumer_group=consumer_group,
    tx_count=TRANSACTION_BYTES_PER_STAGE,
    barrier_storage=BARRIER_STORAGE_POINTER,
    cta_layout_vmnk=CTA_LAYOUT_VMNK,
    mcast_mode_mn=MULTICAST_MODES,
)

producer, consumer = created_pipeline.make_participants()
```

Every uppercase value belongs to the resource and ownership model.

## TMA participant lifecycle

```python
producer_token = producer.acquire_and_advance()

ISSUE_TMA_WORK(
    stage_barrier=producer_token.barrier,
    work_coordinate=work_coordinate,
)

consumer_token = consumer.wait_and_advance()
CONSUME_COMPLETED_STAGE(consumer_token)
consumer_token.release()
```

TMA byte arrival publishes producer completion. This fragment intentionally
does not call a generic producer commit.

## UMMA accumulator pipeline

```python
created_accumulator_pipeline = pipeline.PipelineUmmaAsync.create(
    num_stages=ACCUMULATOR_STAGES,
    producer_group=mma_group,
    consumer_group=epilogue_group,
    barrier_storage=ACCUMULATOR_BARRIER_STORAGE,
    cta_layout_vmnk=CTA_LAYOUT_VMNK,
)

mma_producer, epilogue_consumer = (
    created_accumulator_pipeline.make_participants()
)
```

The accumulator stage count and groups are distinct from the operand pipeline.

## UMMA participant lifecycle

```python
empty_accumulator = mma_producer.acquire_and_advance()
ISSUE_ALL_MMA_CONTRIBUTIONS(empty_accumulator)
empty_accumulator.commit()

full_accumulator = epilogue_consumer.wait_and_advance()
READ_AND_STORE_ACCUMULATOR(full_accumulator)
full_accumulator.release()
```

Commit belongs to the UMMA producer token in this interface. The uppercase
operations hide task-specific MMA and output work.

## Pipeline loop skeleton

```python
for work_index in cutlass.range(runtime_work_count):
    producer_token = producer.acquire_and_advance()
    ISSUE_ASYNCHRONOUS_STAGE(work_index, producer_token)

    consumer_token = consumer.wait_and_advance()
    CONSUME_STAGE(work_index, consumer_token)
    consumer_token.release()
```

This does not show a correct prologue or drain for any particular ring. Derive
those regions from work count and pipeline semantics.

## Named synchronization

```python
role_barrier = pipeline.NamedBarrier(
    barrier_id=BARRIER_ID,
    num_threads=PARTICIPATING_THREADS,
)

pipeline.sync(barrier_id=BARRIER_ID)
```

The exact call surface depends on whether the named barrier object or namespace
helper is used. Do not mix IDs or participant counts with another protocol.

## TMEM allocation

```python
tmem_allocation_barrier = pipeline.NamedBarrier(
    barrier_id=TMEM_BARRIER_ID,
    num_threads=TMEM_BARRIER_PARTICIPANTS,
)
tmem_allocator = utils.TmemAllocator(
    TMEM_BASE_ADDRESS_STORAGE,
    barrier_for_retrieve=tmem_allocation_barrier,
    allocator_warp_id=ALLOCATOR_WARP_ID,
    is_two_cta=USES_TWO_CTAS,
)
tmem_allocator.allocate(TMEM_COLUMNS)
tmem_allocator.wait_for_alloc()
tmem_pointer = tmem_allocator.retrieve_ptr(dtype=ACCUMULATOR_TYPE)
```

`TMEM_COLUMNS` follows from the accumulator and epilogue fragment layouts. The
fragment leaves every resource value undefined and does not show release.

## Binding a fragment layout to TMEM

```python
accumulator_metadata = tiled_mma.make_fragment_C(
    tiled_mma.partition_shape_C(OUTPUT_TILE_SHAPE)
)
accumulator = cute.make_tensor(
    tmem_pointer,
    accumulator_metadata.layout,
)
```

The metadata layout must be compatible with the allocated TMEM region. This
fragment does not establish the correct output tile shape.

## TMEM-to-register copy

```python
tmem_copy = tcgen05.make_tmem_copy(
    TMEM_LOAD_OPERATION,
    accumulator,
)
participant_copy = tmem_copy.get_slice(participant_index)

tmem_partition = participant_copy.partition_S(accumulator)
register_fragment = cute.make_rmem_tensor_like(
    participant_copy.partition_D(DESTINATION_VIEW),
    dtype=COMPUTE_TYPE,
)
register_partition = participant_copy.partition_D(register_fragment)

cute.copy(tmem_copy, tmem_partition, register_partition)
```

The load operation, destination view, and participant mapping must be selected
together.

## Lifetime audit

```text
barrier storage initialized by:
operand stage acquired by:
TMA issued by:
stage consumed by:
stage released by:
TMEM allocated by:
MMA committed by:
TMEM read after:
TMEM released after:
```

No line can be filled from syntax alone.


# File: 05-mma-epilogue-and-numerical-patterns.md

# MMA, epilogue, and low-precision patterns

These fragments illustrate roles and arithmetic boundaries. They do not
construct an instruction, choose a tile, or implement a complete reduction.

## Derive operand major modes

```python
a_major = utils.LayoutEnum.from_tensor(a_tensor).mma_major_mode()
b_major = utils.LayoutEnum.from_tensor(b_tensor).mma_major_mode()
```

Major mode follows the physical tensor layout. It is not selected from the
mathematical notation alone.

## Construct a dense Blackwell tiled MMA

```python
tiled_mma = sm100_utils.make_trivial_tiled_mma(
    A_ELEMENT_TYPE,
    B_ELEMENT_TYPE,
    a_major,
    b_major,
    ACCUMULATOR_TYPE,
    CTA_GROUP,
    MMA_TILER_MN,
)
```

The seven positional arguments show the installed roles. Every uppercase
value must be derived from the operation and architecture contract.

## Participant MMA partitions

```python
participant_mma = tiled_mma.get_slice(participant_index)

a_partition = participant_mma.partition_A(a_tile_mk)
b_partition = participant_mma.partition_B(b_tile_nk)
c_partition = participant_mma.partition_C(c_tile_mn)
```

A, B, and C consume different logical mode pairs. The tile views must already
use the physical convention expected by the tiled MMA.

## Fragment construction

```python
a_fragment = tiled_mma.make_fragment_A(shared_a_partition)
b_fragment = tiled_mma.make_fragment_B(shared_b_partition)
accumulator_fragment = tiled_mma.make_fragment_C(c_partition)
```

The A/B fragment constructors consume compatible shared-memory tensors. The C
fragment may require TMEM binding before it can hold accumulator values.

## Five-role MMA call

```python
cute.gemm(
    tiled_mma,
    destination_accumulator,
    a_fragment,
    b_fragment,
    source_accumulator,
)
```

This fragment omits initialization versus accumulation fields, async commit,
and completion. Those belong to the selected operation.

## First and later reduction contributions

```python
for reduction_index in cutlass.range(runtime_reduction_tiles):
    is_first = reduction_index == 0
    CONFIGURE_ACCUMULATION_MODE(is_first)
    ISSUE_MMA_FOR_REDUCTION_TILE(reduction_index)
```

`CONFIGURE_ACCUMULATION_MODE` is conceptual. It is not a CuTe API name.

## Scalar conversion

```python
compute_value = cutlass.Float32(input_value)
output_value = OUTPUT_TYPE(compute_value)
```

The public scalar type constructor performs conversion. The output type and
conversion point come from the numerical contract.

## Piecewise arithmetic

```python
if runtime_value > cutlass.Float32(0.0):
    transformed = POSITIVE_BRANCH(runtime_value)
else:
    transformed = NEGATIVE_BRANCH(runtime_value)
```

Both branches must produce compatible DSL types. The uppercase functions
represent operation-specific arithmetic.

## Dequantization equation

```python
stored = LOAD_LOW_PRECISION_VALUE(logical_coordinate)
scale_coordinate = MAP_DATA_TO_SCALE_COORDINATE(logical_coordinate)
scale = LOAD_SCALE(scale_coordinate)
real_approximation = cutlass.Float32(stored) * cutlass.Float32(scale)
```

The mapping and multiplication direction are placeholders. A task may specify
inverse scale or instruction-owned scaling instead.

## Packed nibble extraction

```python
packed_byte = LOAD_PACKED_BYTE(byte_coordinate)
low_nibble = packed_byte & cutlass.Uint8(0x0F)
high_nibble = (packed_byte >> cutlass.Uint8(4)) & cutlass.Uint8(0x0F)
```

This demonstrates packed storage only. Decoding sign/exponent/fraction and
mapping nibble order remain part of the format contract.

## Predicated output fragment

```python
logical_coordinate = MAP_FRAGMENT_VALUE_TO_OUTPUT(participant, value_index)
if OUTPUT_COORDINATE_IS_VALID(logical_coordinate):
    output_tensor[logical_coordinate] = OUTPUT_TYPE(register_fragment[value_index])
```

The participant mapping and predicate are intentionally unspecified.

## Adaptation sequence

When adapting any code fragment:

1. identify every uppercase placeholder;
2. derive it from the task or Tier II contracts;
3. preserve object kind and address space;
4. compile after one subsystem becomes concrete;
5. validate before adding another subsystem.

Combining every fragment on this page does not produce a complete kernel.


# File: 06-complete-worked-kernels.md

# Complete worked kernels

The fragments in the other files show one boundary at a time. These two are
whole programs, included so the shape of a finished kernel is visible end to end.

Neither is a task solution. The first computes an elementwise epilogue and never
constructs an MMA. The second targets Hopper sm_90a; this Blackwell device
rejects it at the architecture gate, so it can be read for structure but neither
run nor reused here.

## A complete Blackwell FP8 elementwise kernel

Verified on B300: `max_abs_error=0.0`, `device_time_ms=0.044`. It shows the whole
path from decorated kernel to launch, FP8 converted into FP32 for arithmetic, and
a fused epilogue -- with no MMA anywhere. `main()` and its torch validation are
omitted: the harness owns those and a candidate must not define them.

```python
"""Numerically verified neutral scale + bias + ReLU epilogue.

This standalone documentation example uses two rows and does not implement the
Level 2 GEMM. Benchmark candidates must not copy main() or torch validation.
"""

import torch

import cutlass
import cutlass.cute as cute
from cutlass.cute.runtime import from_dlpack
from cutlass.utils import create_cute_tensor_for_fp8


ROWS = 2
COLS = 1024
THREADS = 128
SCALE = 0.125
FP8_DTYPE = cutlass.Float8E4M3FN


@cute.kernel
def scale_bias_relu_kernel(
    input_tensor: cute.Tensor,
    bias: cute.Tensor,
    output: cute.Tensor,
):
    thread_idx, _, _ = cute.arch.thread_idx()
    row_idx, _, _ = cute.arch.block_idx()
    for iteration in cutlass.range(COLS // THREADS):
        column = iteration * THREADS + thread_idx
        value = input_tensor[row_idx, column].to(cutlass.Float32) * SCALE
        value = value + bias[column].to(cutlass.Float32)
        output[row_idx, column] = value * (value > 0.0)


@cute.jit
def scale_bias_relu(
    input_tensor: cute.Tensor,
    bias: cute.Tensor,
    output: cute.Tensor,
):
    scale_bias_relu_kernel(input_tensor, bias, output).launch(
        grid=(ROWS, 1, 1),
        block=(THREADS, 1, 1),
    )
```

Note `create_cute_tensor_for_fp8` for building the FP8 view, the `.to(cutlass.Float32)`
before arithmetic, and the branchless ReLU written as a multiply by a predicate.

## The mainloop of a complete Hopper GEMM

Excerpted from a 1,648-line NVIDIA CUTLASS example for `sm_90a`. Blackwell refuses
it -- `OpError: expects arch to be sm_90a, but got sm_103a` -- so the Blackwell MMA
path is a different one and this cannot be copied into a candidate. What transfers
is the shape of a pipelined mainloop: wait for a buffer, issue the MMA across
K-blocks, set the accumulate flag after the first, commit, advance.

```python
# Wait for the A/B buffer to be ready
mainloop_pipeline.consumer_wait(mainloop_consumer_read_state, peek_ab_full_status)

cute.nvgpu.warpgroup.fence()
for k_block_idx in cutlass.range(num_k_blocks, unroll_full=True):
    k_block_coord = (None, None, k_block_idx, mainloop_consumer_read_state.index)
    tCrA_1phase = tCrA[k_block_coord]
    tCrB_1phase = tCrB[k_block_coord]

    cute.gemm(
        tiled_mma,
        accumulators,
        tCrA_1phase,
        tCrB_1phase,
        accumulators,
    )
    tiled_mma.set(cute.nvgpu.warpgroup.Field.ACCUMULATE, True)

cute.nvgpu.warpgroup.commit_group()
mainloop_consumer_read_state.advance()
```

Three things generalize. The accumulator is both a source and a destination of
`cute.gemm`. The accumulate field is set *after* the first K-block, so the first
iteration overwrites and later ones add. And the K loop runs inside a buffer a
pipeline hands over, rather than being a bare loop over global memory.

The Blackwell equivalent uses a different namespace and a different accumulate
field; the API sections of the documentation name both.


# File: 07-complete-fp8-gemm.md

# A complete Blackwell FP8 GEMM

The other files show boundaries and two whole kernels that do not use the MMA
path. This one does: a single-tile FP8 GEMM that compiles and runs on this
device, verified at `max_abs_error=0.0` and `device_time_ms=0.061`.

It computes `A[128,64] @ B[128,64].T -> C[128,128]` with E4M3FN inputs and FP32
accumulation. It is a building block, not an answer: it carries no task shape, no
task scale factors, and no epilogue. A benchmark task runs far larger shapes,
applies its own dequantization, and fuses its own elementwise stage -- all of
which you still have to work out and none of which appears below.

`main()` and its torch validation are cut, because the harness supplies those and
a candidate must not define them.

```python
"""Numerically verified neutral B300 FP8 GEMM bridge.

Computes A[128,64] @ B[128,64].T -> C[128,128] with E4M3FN inputs and
Float32 accumulation/output. This is documentation, not a benchmark candidate:
candidate submissions must not copy main(), torch validation, or the direct
main() call because the harness supplies those parts.

Shared-B300 evidence from 2026-07-27:
  max_abs_error=0.0
  device_time_ms=0.13721599999791942
  profile_id=1bf96cbb-9f27-4888-9539-95ff03883227
"""

import torch

import cutlass
import cutlass.cute as cute
import cutlass.pipeline as pipeline
import cutlass.utils as utils
import cutlass.utils.blackwell_helpers as sm100_utils
from cutlass.cute.nvgpu import cpasync, tcgen05
from cutlass.cute.runtime import from_dlpack
from cutlass.utils import create_cute_tensor_for_fp8


FP8_DTYPE = cutlass.Float8E4M3FN
ACC_DTYPE = cutlass.Float32
MMA_TILER_MNK = MMA_TILE_SHAPE      # choose: (M_tile, N_tile, K_tile)
THREADS_PER_CTA = THREADS_PER_BLOCK  # choose to match the tiled MMA
AB_STAGES = AB_PIPELINE_DEPTH        # choose: how many A/B buffers overlap
ACC_STAGES = ACC_PIPELINE_DEPTH      # choose: accumulator pipeline depth


@cute.struct
class SharedStorage:
    ab_mbar_ptr: cute.struct.MemRange[cutlass.Int64, AB_STAGES * 2]
    acc_mbar_ptr: cute.struct.MemRange[cutlass.Int64, ACC_STAGES * 2]
    tmem_holding_buf: cutlass.Int32


@cute.kernel
def fp8_mma_one_tile_kernel(
    tiled_mma: cute.TiledMma,
    tma_atom_a: cute.CopyAtom,
    tma_tensor_a: cute.Tensor,
    tma_atom_b: cute.CopyAtom,
    tma_tensor_b: cute.Tensor,
    output: cute.Tensor,
    smem_layout_a: cute.ComposedLayout,
    smem_layout_b: cute.ComposedLayout,
):
    thread_idx, _, _ = cute.arch.thread_idx()
    warp_idx = cute.arch.make_warp_uniform(cute.arch.warp_idx())

    smem = utils.SmemAllocator()
    storage = smem.allocate(SharedStorage)
    smem_a = smem.allocate_tensor(
        element_type=FP8_DTYPE,
        layout=smem_layout_a.outer,
        byte_alignment=128,
        swizzle=smem_layout_a.inner,
    )
    smem_b = smem.allocate_tensor(
        element_type=FP8_DTYPE,
        layout=smem_layout_b.outer,
        byte_alignment=128,
        swizzle=smem_layout_b.inner,
    )

    tmem_barrier = pipeline.NamedBarrier(
        barrier_id=1,
        num_threads=THREADS_PER_CTA,
    )
    tmem = utils.TmemAllocator(
        storage.tmem_holding_buf.ptr,
        barrier_for_retrieve=tmem_barrier,
    )
    tmem.allocate(512)

    if warp_idx == 0:
        cpasync.prefetch_descriptor(tma_atom_a)
        cpasync.prefetch_descriptor(tma_atom_b)

    one_stage_a = cute.select(smem_layout_a, mode=[0, 1, 2])
    one_stage_b = cute.select(smem_layout_b, mode=[0, 1, 2])
    transaction_bytes = cute.size_in_bytes(
        FP8_DTYPE, one_stage_a
    ) + cute.size_in_bytes(FP8_DTYPE, one_stage_b)
    ab_producer, ab_consumer = pipeline.PipelineTmaUmma.create(
        num_stages=AB_STAGES,
        producer_group=pipeline.CooperativeGroup(pipeline.Agent.Thread),
        consumer_group=pipeline.CooperativeGroup(pipeline.Agent.Thread),
        tx_count=transaction_bytes,
        barrier_storage=storage.ab_mbar_ptr.data_ptr(),
    ).make_participants()
    acc_producer, acc_consumer = pipeline.PipelineUmmaAsync.create(
        num_stages=ACC_STAGES,
        producer_group=pipeline.CooperativeGroup(pipeline.Agent.Thread),
        consumer_group=pipeline.CooperativeGroup(
            pipeline.Agent.Thread,
            THREADS_PER_CTA,
        ),
        barrier_storage=storage.acc_mbar_ptr.data_ptr(),
    ).make_participants()

    global_a = cute.local_tile(
        tma_tensor_a,
        MMA_TILER_MNK,
        (0, None, None),
        proj=(1, None, 1),
    )
    global_b = cute.local_tile(
        tma_tensor_b,
        MMA_TILER_MNK,
        (None, 0, None),
        proj=(None, 1, 1),
    )
    global_c = cute.local_tile(
        output,
        MMA_TILER_MNK,
        (0, 0, None),
        proj=(1, 1, None),
    )

    thr_mma = tiled_mma.get_slice(0)
    mma_global_a = thr_mma.partition_A(global_a)
    mma_global_b = thr_mma.partition_B(global_b)
    mma_global_c = thr_mma.partition_C(global_c)
    mma_smem_a = tiled_mma.make_fragment_A(smem_a)
    mma_smem_b = tiled_mma.make_fragment_B(smem_b)
    acc_shape = tiled_mma.partition_shape_C(MMA_TILER_MNK[:2])
    tmem_acc = tiled_mma.make_fragment_C(acc_shape)

    tma_smem_a, tma_global_a = cpasync.tma_partition(
        tma_atom_a,
        0,
        cute.make_layout(1),
        cute.group_modes(smem_a, 0, 3),
        cute.group_modes(mma_global_a, 0, 3),
    )
    tma_smem_b, tma_global_b = cpasync.tma_partition(
        tma_atom_b,
        0,
        cute.make_layout(1),
        cute.group_modes(smem_b, 0, 3),
        cute.group_modes(mma_global_b, 0, 3),
    )

    tmem.wait_for_alloc()
    tmem_ptr = tmem.retrieve_ptr(ACC_DTYPE)
    tmem_acc = cute.make_tensor(tmem_ptr, tmem_acc.layout)

    subtile_count = 2
    epilogue_tiler = (
        (
            cute.size(tmem_acc, mode=[0, 0]),
            cute.size(tmem_acc, mode=[0, 1]) // subtile_count,
        ),
    )
    tmem_acc_epilogue = cute.zipped_divide(tmem_acc, epilogue_tiler)
    global_c_epilogue = cute.zipped_divide(mma_global_c, epilogue_tiler)
    tmem_atom = cute.make_copy_atom(
        tcgen05.Ld32x32bOp(tcgen05.Repetition.x64),
        ACC_DTYPE,
    )
    tmem_tiled_copy = tcgen05.make_tmem_copy(
        tmem_atom,
        tmem_acc_epilogue[None, 0],
    )
    tmem_thread_copy = tmem_tiled_copy.get_slice(thread_idx)
    tmem_source = tmem_thread_copy.partition_S(tmem_acc_epilogue)
    global_destination = tmem_thread_copy.partition_D(global_c_epilogue)
    register_acc = cute.make_rmem_tensor(
        global_destination[None, None, 0].shape,
        ACC_DTYPE,
    )

    if warp_idx == 0:
        acc_empty = acc_producer.acquire_and_advance()
        num_k_tiles = cute.size(global_a, mode=[2])
        for _ in cutlass.range(num_k_tiles, prefetch_stages=AB_STAGES - 2):
            ab_empty = ab_producer.acquire_and_advance()
            cute.copy(
                tma_atom_a,
                tma_global_a[(None, ab_empty.count)],
                tma_smem_a[(None, ab_empty.index)],
                tma_bar_ptr=ab_empty.barrier,
            )
            cute.copy(
                tma_atom_b,
                tma_global_b[(None, ab_empty.count)],
                tma_smem_b[(None, ab_empty.index)],
                tma_bar_ptr=ab_empty.barrier,
            )
            ab_full = ab_consumer.wait_and_advance()
            num_k_blocks = cute.size(mma_smem_a, mode=[2])
            for k_block in cutlass.range_constexpr(num_k_blocks):
                coord = (None, None, k_block, ab_full.index)
                cute.gemm(
                    tiled_mma,
                    tmem_acc,
                    mma_smem_a[coord],
                    mma_smem_b[coord],
                    tmem_acc,
                )
                tiled_mma.set(tcgen05.Field.ACCUMULATE, True)
            ab_full.release()
        acc_empty.commit()

    tmem.relinquish_alloc_permit()
    acc_full = acc_consumer.wait_and_advance()
    for tile_idx in cutlass.range(cute.size(tmem_source, mode=[2])):
        cute.copy(
            tmem_tiled_copy,
            tmem_source[None, None, tile_idx],
            register_acc,
        )
        cute.autovec_copy(
            register_acc,
            global_destination[None, None, tile_idx],
        )
    acc_full.release()

    pipeline.sync(barrier_id=1)
    tmem.free(tmem_ptr)


@cute.jit
def fp8_mma_one_tile(a: cute.Tensor, b: cute.Tensor, output: cute.Tensor):
    a_major = utils.LayoutEnum.from_tensor(a).mma_major_mode()
    b_major = utils.LayoutEnum.from_tensor(b).mma_major_mode()
    tiled_mma = sm100_utils.make_trivial_tiled_mma(
        a.element_type,
        a_major,
        b_major,
        ACC_DTYPE,
        tcgen05.CtaGroup.ONE,
        MMA_TILER_MNK[:2],
    )
    smem_layout_a = sm100_utils.make_smem_layout_a(
        tiled_mma,
        MMA_TILER_MNK,
        a.element_type,
        AB_STAGES,
    )
    smem_layout_b = sm100_utils.make_smem_layout_b(
        tiled_mma,
        MMA_TILER_MNK,
        b.element_type,
        AB_STAGES,
    )
    tma_a = cute.nvgpu.make_tiled_tma_atom_A(
        sm100_utils.CopyBulkTensorTileG2SOp(),
        a,
        cute.select(smem_layout_a, mode=[0, 1, 2]),
        MMA_TILER_MNK,
        tiled_mma,
    )
    tma_b = cute.nvgpu.make_tiled_tma_atom_B(
        sm100_utils.CopyBulkTensorTileG2SOp(),
        b,
        cute.select(smem_layout_b, mode=[0, 1, 2]),
        MMA_TILER_MNK,
        tiled_mma,
    )
    fp8_mma_one_tile_kernel(
        tiled_mma,
        tma_a.atom,
        tma_a.tma_tensor,
        tma_b.atom,
        tma_b.tma_tensor,
        output,
        smem_layout_a,
        smem_layout_b,
    ).launch(
        grid=(1, 1, 1),
        block=(THREADS_PER_CTA, 1, 1),
    )
```

## What to take from it

The order of construction: derive the operand major modes from the tensors, build
the tiled MMA, build the shared-memory layouts from that MMA, then build the TMA
atoms from those layouts. Each step consumes the previous one, so the sequence is
not interchangeable.

The accumulator lives in tensor memory. It is allocated, its pointer retrieved,
used as both the source and the destination of `cute.gemm`, copied out through a
TMEM copy atom, and freed. The accumulate field is set after the first K-block so
the first iteration writes and the rest add.

The pipeline is what makes the K loop safe: a producer acquires a stage, issues
the TMA copies against that stage's barrier, and a consumer waits on it before the
MMA reads shared memory.

What is deliberately absent: the four tuning constants are left as named choices
rather than values, because the verified reference for a task in this catalog uses
exactly the numbers this example was written with. The scaling a task specifies is
not applied here, and there is no epilogue at all.


# File: 01-diagnostic-workflow.md

# Diagnostic workflow and observed failure classes

Tier IV adds diagnostic guidance derived from 200 pre-study AIRI and KernelEvo
error records. The records contained 65 normalized signatures. They are grouped
here by mechanism, without task paths, shapes, candidate code, or solution
choices.

## Observed high-frequency classes

| Normalized class | Records | Interpretation |
| --- | ---: | --- |
| CUDA invalid value | 46 | launch, resource, descriptor, or configuration rejected |
| required JIT entry point missing | 29 | public interface or decorator was changed |
| numerical validation families | 30+ | output ran but did not meet the fixed oracle |
| unspecified launch failure | 12 | asynchronous device failure surfaced later |
| operation creation failure | 7 | incompatible type/layout/instruction combination |
| IR verification failure | 4 | illegal compiler IR or unsupported lowering combination |
| repeated API hallucinations | many | plausible symbol used in wrong namespace or release |

Frequency helps prioritize diagnosis; it does not prove the cause of a new
failure.

## Always start with the earliest deterministic error

Compiler and runtime output often contains cascades. Use this order:

1. public candidate policy and entry point;
2. first Python/import/attribute error;
3. first argument-binding/type error;
4. first IR or operation-creation error;
5. launch configuration;
6. asynchronous timeout or memory failure;
7. numerical validation;
8. performance.

Do not optimize or restructure code while an earlier gate fails.

## Minimal diagnostic record

For each attempt, retain:

```text
candidate change:
earliest failing stage:
exact first diagnostic:
object type at failing call:
expected parameter roles:
actual parameter roles:
one hypothesis:
one next change:
result after that change:
```

This prevents repeated, unrelated edits.

## Failure localization

| Stage | Evidence |
| --- | --- |
| Parse/import | Python exception before tracing |
| Binding | signature/decorator complaint naming the entry point |
| Tracing | Python type, missing attribute, proxy/static error |
| Lowering | operation creation, IR verification, PTX assembly |
| Launch | invalid value or resource/configuration diagnostic |
| Execution | timeout, illegal access, unspecified launch failure |
| Validation | finite output differs from reference |
| Timing | correct output but unstable or slow measurement |

An error at a synchronization call may belong to the preceding asynchronous
launch. Insert a diagnostic synchronization only to localize; remove it from
the final measured path.

## Reduction strategy

Reduce the failing region without replacing the design:

- keep the public interface unchanged;
- retain one use of the suspect API;
- remove downstream consumers;
- use one legal work item or stage when the protocol permits;
- preserve address spaces and object kinds;
- compile or launch again.

Reduction is for identifying the first invalid boundary. It is not permission
to replace a task with a framework operation.

## Change discipline

After one concrete error:

1. classify it;
2. inspect the local API signature and actual object kinds;
3. change only the first mismatch;
4. rerun the same check;
5. keep the change only if the error advances or disappears.

If an identical candidate produces the same deterministic failure, resubmitting
it adds no information.

## Do not hide failures

Never:

- catch a compiler or launch failure and report success;
- weaken the harness comparison;
- skip required cases;
- leave output uninitialized;
- substitute a framework implementation;
- increase timeout without explaining a tiny-case hang;
- claim performance for an invalid output.


# File: 02-api-binding-and-tracing-errors.md

# API, binding, and tracing errors

## Required entry point is not JIT-decorated

Symptoms:

```text
Function ... is not decorated with jit decorator
required entry point must remain @cute.jit
```

Inspect:

- exact function name from the task;
- `@cute.jit` remains immediately attached;
- signature and argument order are preserved;
- `ModelNew.forward` points to that function;
- no later definition shadows it.

Fix the interface before inspecting kernel internals.

## Failed to bind arguments

Symptoms name a decorated function and expected signature.

Compare:

| Expected | Actual |
| --- | --- |
| positional argument count | bound arguments |
| keyword names | supplied keywords |
| `Constexpr` versus runtime | argument objects |
| pointer/tensor annotation | runtime adapter result |
| kernel binding | all declared kernel arguments |

Do not remove an argument merely to silence binding when the harness contract
requires it.

## Unknown attribute or namespace

Common observed hallucinations:

| Invented or misplaced spelling | Local API fact |
| --- | --- |
| `blackwell_helpers.SmemAllocator` | allocator lives under `cutlass.utils` |
| `cute.arch.num_threads` | use `block_dim()` and derive the needed count |
| `TiledMma.get_slice_in_stage` | public slice method is `get_slice` |
| `cute.convert`, `cute.cast` | use public scalar type constructors |
| `cute.maximum`, `cute.fmax` | express compatible scalar comparisons/selection |
| `cute.constexpr` | compile-time helpers live under `cutlass` |
| `cute.pipeline` | import `cutlass.pipeline` |
| tensor `.partition_D` | partition method belongs to a ThrCopy/ThrMma object |
| `utils.SharedStorage` | define a `@cute.struct` storage type explicitly |

Do not blindly accept a compiler's similarly named suggestion. Verify that its
parameter and return-object roles match the call site.

## TMA namespace confusion

There are two related surfaces:

```text
cpasync.make_tiled_tma_atom          generic factory
cute.nvgpu.make_tiled_tma_atom_A/B  MMA-aware operand factories
```

The specialized A/B factories do not live under `cpasync`; the generic factory
does. Their construction roles and tiling transformations differ. Choose from
the required abstraction, not from name similarity.

## Static value used as a runtime object

Symptoms:

- Python `int` unexpectedly has `.value`;
- branch or operation expects a DSL scalar;
- a static tuple is treated like an IR aggregate.

Identify where the value is created. Use a DSL scalar constructor only when
generated arithmetic is required. Do not wrap every constant blindly; Python
needs static values to construct layouts and types.

## Runtime proxy used as a Python integer

Symptoms:

```text
ArithValue object cannot be interpreted as an integer
runtime value cannot index tuple/list
range_constexpr requires constexpr
```

Trace the value's first use in Python structure:

- tuple/list index;
- static loop bound;
- shape rank;
- class/type selection;
- Python allocation length.

Keep structure static or move the operation into generated runtime control
flow. Casting one runtime integer type to another does not make it Python
static.

## Dynamic control-flow rejection

Symptoms:

```text
early exit is not allowed
continue not properly in loop
value unavailable outside dynamic region
branch changes variable type
```

Repair principles:

- replace early exit with a predicate carried through the remaining body;
- initialize compatible values before the region;
- keep both branches' result types equal;
- avoid mutation of Python containers in runtime regions.

Do not convert a runtime condition to `const_expr` unless it is truly static.

## Wrong object kind

Frequent confusions:

```text
Layout versus Tensor
Pointer versus Tensor
TensorSSA versus pointer-backed Tensor
TmaInfo versus tuple
TiledCopy versus ThrCopy
TiledMma versus ThrMma
pipeline object versus participant/token
```

At the failure, write:

```text
expected kind:
actual type:
constructor that produced it:
method that should own the next operation:
```

Repair the first wrong constructor or method owner.

## DLPack direction confusion

`from_dlpack` consumes a framework object implementing the producer protocol
and returns a CuTe runtime tensor. The returned internal `_Tensor` is not
necessarily a framework DLPack producer. Do not try to reconvert it through
`.__dlpack__()` unless the API explicitly supports that direction.

## Symbol does not exist on the module you reached for

Symptoms:

```text
AttributeError: module 'cutlass' has no attribute ...
AttributeError: module 'cutlass.cute' has no attribute ...
AttributeError: module 'cutlass.cute.nvgpu.tcgen05' has no attribute ...
```

This is the most frequent failure in this DSL, and it is almost never a missing
import: the module imported cleanly and the attribute simply is not part of the
Python API. It usually arrives by analogy — a helper that exists in CUTLASS C++,
or a name that would be natural in another framework, recalled from memory
rather than read.

Inspect:

- whether the packet's documentation names this construct at all;
- whether the operation belongs on the module you used, on the tiled MMA
  object, or on a helper namespace;
- whether you invented a convenience wrapper for arithmetic the task does not
  need — dimensions that divide evenly need no rounding helper, plain integer
  division suffices.

Prefer a spelling the documentation shows over one you remember. A second guess
from the same memory is rarely better than the first.

## Callable used as a subscript, or called with the wrong arity

Symptoms:

```text
TypeError: 'function' object is not subscriptable
TypeError: ... missing N required positional arguments
```

The symbol was found, so this is progress from the previous class: the remaining
error is shape of the call, not its existence. The first form indexes something
that must be called; the second supplies too few operands to an operation whose
signature is fixed.

Inspect:

- brackets where parentheses belong, and the reverse;
- every operand the operation requires, in order, including accumulator and
  destination arguments that are easy to omit;
- whether a factory must be constructed before the object it returns is used.

The documentation shows the full call form. Copy its argument order rather than
inferring one.

## Attribute errors on a module or enum

Symptoms:

```text
AttributeError: module 'cutlass.cute.nvgpu.tcgen05' has no attribute ...
AttributeError: type object 'LayoutEnum' has no attribute ...
```

Almost always a name carried over from CUTLASS C++ rather than an absent
feature, and almost always a case convention. Cycling through capitalisations
costs one evaluation per guess and rarely converges; the API sections of the
documentation list the exact members, so look the name up instead of varying it.

## Errors this device has actually produced

Every line below is a verbatim diagnostic from a real run on this hardware,
with the number of times it occurred. They are reproduced exactly, not
paraphrased, so a message can be matched against this list character for
character when it appears.

```text
[31x] Error Code: MmaF8F6F4Op error
[13x] cutlass.base_dsl.common.DSLOperationBuildError:
[11x] RuntimeError: validation failed: full_abs=8.928038, sample_abs=2.592082
[9x] AttributeError: type object 'LayoutEnum' has no attribute 'RowMajor'
[8x] TypeError: copy() missing 1 required positional argument: 'dst'
[5x] AttributeError: type object 'OperandMajorMode' has no attribute 'RowMajor'
[5x] AttributeError: module 'cutlass.cute' has no attribute 'launch'
[4x] AttributeError: module 'cutlass.cute' has no attribute 'make_smem_tensor'. Did you mean: 'make_rmem_tensor'?
[3x] AttributeError: module 'cutlass.cute' has no attribute 'LayoutEnum'
[3x] TypeError: gemm() missing 1 required positional argument: 'c'
[3x] TypeError: 'function' object is not subscriptable
[3x] AttributeError: 'function' object has no attribute 'launch'
[2x] AttributeError: type object 'LayoutEnum' has no attribute 'kRowMajor'
[2x] ValueError: tensor<ptr<f32, tmem, align<1>> o ((128,128),1,1):((65536,1),0,0)> doesn't support load and store
[2x] AttributeError: type object 'OperandMajorMode' has no attribute 'kRowMajor'
[2x] AttributeError: 'NoneType' object has no attribute 'shape'
[2x] TypeError: make_tensor() got an unexpected keyword argument 'dtype'
[2x] AttributeError: module 'cutlass.cute' has no attribute 'shared_array'
[2x] AttributeError: module 'cutlass.cute.nvgpu.tcgen05' has no attribute 'CTA_GROUP_ONE'
[2x] cutlass.base_dsl.common.DSLRuntimeError: DSLRuntimeError: Failed to bind arguments to function `fp8_gemm_kernel` with signature `(matrix_a: cutlass.cute.typing.Tensor, matrix_b_nk: cutlass.cute.typing.Tensor, output: cutlass.cute.typing.Tensor)`
[2x] AttributeError: module 'cutlass.cute.nvgpu.tcgen05' has no attribute 'CTA_GROUP'
[2x] AttributeError: module 'cutlass.cute.nvgpu.tcgen05' has no attribute 'CTA_Group'. Did you mean: 'CtaGroup'?
[1x] ValueError: unable to convert (128, 128) in type <class 'tuple'> to Numeric
[1x] ValueError: Expected source and destination tensors to have the same rank, but got 2 and 3
[1x] AttributeError: type object 'OperandMajorMode' has no attribute 'ROW'
[1x] ValueError: Operation creation failed
[1x] cutlass.base_dsl.common.DSLAstPreprocessorError: DSLAstPreprocessorError: Early exit (break) is not allowed in `fp8_gemm_kernel`
[1x] AttributeError: module 'cutlass.cute' has no attribute 'fragment'
[1x] TypeError: Tensor() takes no arguments
[1x] TypeError: gemm() missing 2 required positional arguments: 'b' and 'c'
[1x] AttributeError: module 'cutlass.cute' has no attribute 'Smem'
[1x] AttributeError: type object 'OperandMajorMode' has no attribute 'ROW_MAJOR'
[1x] AttributeError: type object 'CtaGroup' has no attribute 'OneCta'
[1x] AttributeError: type object 'CtaGroup' has no attribute 'OneCTA'
```

Read the list before inventing a spelling. A name that appears here has already
been tried on this device and does not resolve; trying it again costs an
evaluation and returns the same line. Several entries are the same mistake in
different clothes -- six spellings of a major mode, four of a CTA-group member --
and the API sections carry the forms that do resolve.

Three of these are not name problems and no respelling will move them: a rank
mismatch between the two sides of a copy, a Python tuple handed to something
that wanted a layout or a numeric type, and an early `break` inside a traced
kernel. Those require changing what was built, not what it was called.

`RuntimeError: validation failed: full_abs=..., sample_abs=..., out_abs=...`
means the kernel compiled, launched and ran, and only the numbers are wrong --
the furthest any failure gets. When `out_abs` is `0.000000` the output buffer was
never written, so look for a kernel that launched but stored nothing rather than
for an arithmetic error.


# File: 03-layout-copy-and-mma-errors.md

# Layout, copy, and MMA errors

## Operation creation failed

This usually means every named Python object exists, but their combination is
illegal. Candidate dimensions:

- operand dtype;
- accumulator dtype;
- address space;
- major mode;
- atom/tile shape;
- CTA-group mode;
- operand fragment layout;
- alignment.

Reduce to construction of the failing operation. Compare each parameter role
against Tier II before adding TMA, pipeline, or epilogue logic.

## IR verification failed

IR verification is later than Python type construction. Common mechanisms:

- an operation received a value from the wrong address space;
- a region yields incompatible types;
- a layout/instruction constraint was not enforced by the Python wrapper;
- a runtime value entered a type-forming position;
- unsupported sub-byte scalar access reached lowering.

The first verifier message usually names the invalid operation or operand.
Inspect that boundary instead of rewriting the whole kernel.

## Layout versus tensor passed to partitioning

Symptoms:

- partition method rejects an object;
- generated operation expects a tensor value;
- shape prints correctly but lowering fails.

`ThrMma.partition_A/B/C` and `ThrCopy.partition_S/D` consume tensor views.
Pass the allocated or pointer-backed tensor, not its `.layout`.

## Partition method on the wrong owner

Observed mistakes include:

```text
tensor.partition_D(...)
top-level cute.partition_D(...)
TiledMma.partition_D(...)
```

Partition ownership:

```text
ThrCopy.partition_S / partition_D
ThrMma.partition_A / partition_B / partition_C
```

Obtain the participant slice from the matching tiled object first.

## Shape matches but copy is illegal

Check:

- source and destination address spaces;
- source/destination partition value layouts;
- vector direction and stride-one mode;
- element/internal types;
- base and stride alignment;
- participant count;
- predicate layout.

Manual reshaping can preserve extents while losing instruction-compatible
ownership.

## Transposed or repeated output

Pattern-based hypotheses:

| Pattern | First layout hypothesis |
| --- | --- |
| exact transpose | mathematical and physical mode conventions differ |
| repeated rows/columns | a mode was omitted or fixed incorrectly |
| periodic stripes | vector width, stride, or participant mapping mismatch |
| correct first tile only | work-tile coordinate not advanced |
| correct interior, wrong edge | boundary predicate or tail policy |

Confirm with coordinate-to-address calculations. Do not compensate with an
ad hoc output transpose until the physical contract is explicit.

## TMA partition mismatch

Symptoms:

- descriptor construction succeeds but launch fails;
- an equal-shape manual partition causes illegal instruction;
- only multicast/cluster cases fail.

Verify the TMA atom, TMA coordinate tensor, SMEM layout, CTA layout, and
coordinate all came from one construction. Preserve the descriptor-returned
tensor and use `cpasync.tma_partition`.

## Shared-memory overlap

Symptoms:

- stage-dependent corruption;
- changing stage count changes numerical pattern;
- one operand appears to overwrite another;
- launch succeeds only with smaller storage.

Check:

- full staged layout `cosize`;
- element width;
- allocator offsets and alignments;
- whether a stage mode was omitted or added twice;
- barrier storage versus operand storage;
- mutually exclusive branch allocation policy.

## Accumulator initialization error

Patterns:

- error grows with reduction length;
- only the first reduction tile contributes;
- output changes between repeated runs;
- NaN or stale values appear before epilogue arithmetic.

Confirm:

- first contribution initializes/overwrites;
- later contributions accumulate;
- TMEM is allocated before use;
- source accumulator does not read uninitialized storage;
- each logical output has one accumulator owner.

## Incomplete fragment store

Symptoms:

- periodic untouched values;
- sentinel remains in a subset;
- only one participant's output appears.

Trace:

```text
TMEM fragment
-> participant TMEM partition
-> register destination partition
-> output coordinate mapping
-> store predicate
```

Compare value counts at each boundary.


# File: 04-launch-and-resource-errors.md

# Launch and resource errors

## CUDA invalid value

This high-frequency error is broad. First separate:

1. launch geometry;
2. cluster geometry;
3. dynamic shared memory;
4. kernel attributes and occupancy hints;
5. descriptor or pointer arguments;
6. architecture/instruction availability.

Inspect the fully bound launch and generated resource requirements. Do not
change all dimensions simultaneously.

## Invalid grid or block

Verify:

- each dimension is an integer/DSL integer accepted by the launch;
- dimensions are positive where work is launched;
- tuple/list rank is at most three and canonicalizes correctly;
- block threads match warp-role assumptions;
- the grid covers the intended work space;
- cluster grouping agrees with grid dimensions.

An empty grid may appear fast while doing no work. Output validation must catch
it.

## Kernel argument binding versus launch configuration

A bound kernel object already holds declared kernel arguments. `.launch`
receives launch configuration, not the kernel tensors again.

Conversely, calling `.launch` on the undecorated function or an unbound kernel
omits required arguments.

## Shared-memory overflow

Compute:

```text
sum of every live SMEM allocation
+ staged operand bytes
+ barrier/pipeline storage
+ epilogue storage
+ alignment padding
```

If mutually exclusive branches do not opt into merged allocation, their
allocations can be counted additively.

Changing tile or stages requires recomputing all dependent layouts and launch
attributes.

## Register or occupancy pressure

Symptoms:

- compilation succeeds but launch/resources fail;
- a larger tile is slower;
- increasing stages reduces residency;
- `ptxas` reports high register use or spills.

Identify which live fragments and unrolling decisions increased state. Do not
assume shared memory is the only occupancy constraint.

## TMEM allocation/configuration failure

Check:

- requested columns follow from fragment layout;
- allocation owner and CTA group agree;
- all required participants wait for allocation;
- no previous allocation remains live;
- release occurs after final use;
- instruction and epilogue expect the same TMEM layout.

TMEM resources are distinct from shared memory and registers.

## Cluster launch failure

Verify:

- preferred and fallback cluster tuples have exactly three dimensions;
- grid can be grouped under the chosen cluster policy;
- architecture supports the requested cluster mode;
- multi-CTA instruction mode matches cluster cooperation;
- multicast masks stay within the cluster;
- cluster barriers have all required participants.

Test the same operation without cluster-specific behavior only to isolate the
cluster mechanism, not as a final substitute when the implementation depends
on it.

## Alignment errors

Alignment has two parts:

1. base pointer alignment;
2. stride/offset preservation for every selected tile.

An aligned base does not make `base + offset` aligned for a vector operation.
Derive the byte offset for each operand and stage.

`assumed_align` tells the compiler a fact; a false promise can turn a safe
scalar access into an illegal vector access.

## Unsupported architecture or instruction

An importable symbol may still lower to an instruction unavailable for the
actual target or dtype/layout combination.

Check:

- target compute capability selected by compilation;
- instruction family;
- operand types;
- CTA group;
- layout/shape constraints.

Do not install another package version inside a candidate to work around the
study environment.

## Resource-isolation sequence

When launch fails after construction:

1. record grid/block/cluster and dynamic SMEM;
2. record compiler resource output if available;
3. isolate optional cluster or epilogue attributes;
4. keep the same instruction/data contract;
5. change one resource dimension;
6. rerun a real launch.

Tracing alone cannot validate launch resources.


# File: 05-async-hang-and-memory-errors.md

# Asynchronous, hang, and memory errors

## Timeout on a small workload

A small deterministic timeout usually indicates a synchronization protocol
error, not insufficient timeout.

Audit one stage:

```text
initial phase
producer acquisition
expected bytes
asynchronous issue
explicit arrivals
consumer wait
consumer release
phase advance
```

Then compare counts across prologue, steady state, and drain.

## Producer/consumer count mismatch

Symptoms:

- hang only after ring wraparound;
- one stage count works and another does not;
- final work item never completes.

Count:

```text
acquired stages
published/committed stages
waited stages
released stages
tail/drain operations
```

Every logical stage generation must complete its lifecycle.

## Wrong transaction byte count

If expected bytes exceed issued bytes, the barrier never completes. If expected
bytes are too small, consumers can observe incomplete data.

Recompute from physical transfers, including:

- every operand;
- scale-factor transfers;
- packed/internal element width;
- multicast behavior;
- predicates and skipped transfers.

Do not modify bytes solely until a timeout disappears; validate loaded data.

## Double or missing election

Single-thread state operations need election. TMA copy issue already performs
its own election.

Potential failures:

- every lane initializes one barrier;
- no lane registers expected bytes;
- a TMA copy is nested under an extra election and does not follow the expected
  issue protocol;
- tcgen commit is issued by an incompatible participant set.

Classify each operation as single-lane, warp collective, CTA collective, or
instruction-owned election.

## Divergent collective control flow

All required participants must reach:

- CTA/warp/cluster barriers;
- pipeline initialization;
- stage waits and releases;
- TMEM allocation waits;
- instruction commits.

A data predicate may suppress arithmetic or a store, but it must not suppress a
required collective transition.

## Unspecified launch failure

This often surfaces at a later synchronization. Suspect:

- illegal address;
- invalid asynchronous instruction operand;
- use-before-completion;
- use-after-release;
- broken cluster/distributed-SMEM participation.

Insert synchronization after major asynchronous boundaries to identify the
first failing region. Remove those synchronizations after diagnosis.

## Illegal memory access

Audit:

1. logical coordinate;
2. physical stride and byte offset;
3. allocation span;
4. source/destination address space;
5. alignment;
6. boundary predicate;
7. object lifetime.

For a tiled/partitioned tensor, perform this audit after every view
transformation, not only on the whole tensor.

## Stale or partially updated output

Possible mechanisms:

- missing store for some participants;
- accumulator consumer read before completion;
- stage reused before release;
- output store completed asynchronously after lifetime ended;
- predicate excludes valid coordinates;
- grid does not cover all output tiles.

Sentinel initialization and repeated runs can distinguish missing writes from
wrong arithmetic.

## Stage-dependent numerical error

If correctness changes with stage count, prioritize:

- omitted stage mode in SMEM;
- wrong stage pointer;
- phase mismatch;
- premature reuse;
- barrier bytes shared across stages;
- prologue/drain off by one.

The mathematical operation should not depend on the number of storage stages.

## Cluster-only hang

Check:

- all CTAs in the cluster launch;
- multicast sender and receiver masks;
- remote barrier address/rank;
- cluster arrival/wait participation;
- multi-CTA instruction ownership;
- output responsibility.

Reduce cluster complexity only to identify which cross-CTA contract is broken.

## Lifetime ordering

General order:

```text
allocate
publish initialization
write asynchronously
wait for completion
read/consume
wait for consumers if necessary
release
```

Python lexical scope does not enforce device lifetime.


# File: 06-numerical-and-performance-errors.md

# Numerical and performance errors

## Classify the numerical pattern first

| Pattern | First hypotheses |
| --- | --- |
| nearly constant global ratio | scale direction or duplicate/missing scale |
| one row/column/group wrong | scale ownership or layout mode |
| edge-only error | tail predicate or output coverage |
| error grows with reduction length | accumulator initialization/precision |
| alternating or periodic error | partition/value layout |
| stale-looking regions | missing store or use-before-completion |
| NaN/Inf | overflow, uninitialized state, invalid conversion |
| nondeterministic output | race, phase error, incomplete synchronization |

Test the hypothesis with structured inputs before changing the implementation.

## Scale direction error

Write both producer and consumer equations. Determine whether the stored
metadata is a dequantization scale or reciprocal quantization multiplier.

A constant ratio across output often indicates:

- multiplying where division was required;
- applying A or B scale twice;
- omitting one operand scale;
- applying output scale at the wrong boundary.

Do not rename the variable without changing the equation.

## Scale indexing error

Use distinct, easily distinguishable scale values for each logical group in a
diagnostic case. Map:

```text
data coordinate
-> logical scale group
-> physical scale coordinate
-> loaded scale
```

If only selected groups fail, inspect mode mapping before accumulation
precision.

## Packed-format decode error

Symptoms:

- every pair of values swapped;
- signs wrong in alternating positions;
- magnitude set limited to unexpected values;
- odd final element incorrect.

Check nibble order, sign/exponent/fraction decode, byte versus logical index,
and odd-length padding separately.

## Accumulation precision error

Error that grows smoothly with reduction length can come from a narrower
accumulator or a changed summation order. Confirm accumulator type in the
actual MMA and intermediate epilogue, not only in a Python constant.

Fast-accumulation modes require a separate correctness comparison.

## Output conversion error

If the accumulator is correct but stored output is wrong:

- inspect register fragment values before conversion;
- confirm output dtype constructor;
- check saturation/rounding expectations;
- verify store partition and physical output layout;
- check epilogue arithmetic executes before conversion.

Do not mask overflow by increasing tolerance.

## Correct but unexpectedly slow

First verify measurement:

- compilation is excluded;
- allocation and reference work are excluded;
- warmup uses the same specialization;
- events and kernel use the same stream;
- synchronization is correct;
- device printing/debug flags are disabled;
- all output work is still performed.

Then verify generated instruction-path evidence.

## FP8 storage without FP8 tensor-core execution

Possible causes:

- operands converted to wider values before the core operation;
- scalar code implements the product;
- selected MMA operation does not match types/layouts;
- framework fallback performs the work.

Inspect construction and generated code. Correctness alone does not identify
the execution engine.

## Resource regression

A seemingly useful change can slow down by:

- reducing occupancy;
- increasing register spills;
- adding shared-memory traffic;
- increasing barrier count;
- extending prologue/drain;
- adding cluster coordination;
- increasing tail waste.

Compare one resource family at a time.

## Timing noise

If candidate differences are near evaluator variation:

- repeat bounded measurements;
- compare medians and dispersion;
- rerun the known-correct reference under the same conditions;
- treat overlapping noise as a tie.

Do not infer a speedup from a single minimum.

## Optimization repair loop

1. retain the correct candidate;
2. state one bottleneck hypothesis;
3. change one configuration family;
4. rerun correctness;
5. measure with the same protocol;
6. keep only reproducible improvements.

Tier IV does not recommend a tile, stage count, cluster, or epilogue. Those
choices require task-specific evidence and profiling.

## Kernel runs but the result is far outside tolerance

Symptoms:

```text
RuntimeError: validation failed: full_abs=..., sample_abs=...
```

The kernel compiled, launched, and completed: only the numbers are wrong. This
is a better position than any binding error, and the reported magnitudes tell
you which kind of mistake it is. An absolute error of the same order as the
output means a systematic fault — a missing or doubled scale factor, an
accumulator in the wrong precision, a transposed operand, or an epilogue applied
in the wrong order. An error a few multiples of the tolerance means rounding or
accumulation order, not structure.

Inspect:

- every scale the task specifies, applied exactly once and on the intended side;
- accumulation precision, which must not inherit the narrow input type;
- operand layouts and which mode is contiguous;
- the order of epilogue operations, which is fixed by the task statement.

Change one of these at a time. Re-running an unchanged kernel reproduces the
same magnitudes to the digit and tells you nothing new.
