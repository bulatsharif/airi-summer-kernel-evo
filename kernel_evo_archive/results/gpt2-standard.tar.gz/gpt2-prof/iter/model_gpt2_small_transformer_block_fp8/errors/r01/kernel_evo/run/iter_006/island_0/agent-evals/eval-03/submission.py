import cutlass
import cutlass.cute as cute


TOKENS = 128
HIDDEN_SIZE = 768
NUM_HEADS = 12
HEAD_DIM = 64
MLP_SIZE = 3072
QKV_SIZE = 3 * HIDDEN_SIZE
THREADS = 128
EPSILON = 1.0e-5
UNROLL = 8

# Output columns computed per thread in each dense projection kernel.
QKV_CPT = 2
OUT_CPT = 2
FC_CPT = 4
PROJ_CPT = 3

INPUT_SCALE = 1.0 / 448.0
NORM_SCALE = 1.0 / 64.0
QKV_SCALE = 1.0 / 64.0
CONTEXT_SCALE = 1.0 / 64.0
MLP_SCALE = 1.0 / 64.0
WEIGHT_H_SCALE = HIDDEN_SIZE ** -0.5 / 448.0
WEIGHT_MLP_SCALE = MLP_SIZE ** -0.5 / 448.0
FP8_DTYPE = cutlass.Float8E4M3FN

SQRT_HEAD_DIM = 8.0  # sqrt(64)
NEG_INF = -1.0e30
GELU_CONST = 0.7978845608028654  # sqrt(2/pi)


@cute.jit
def gelu_new(x):
    # GPT-2 "new" GELU (tanh approximation).
    return 0.5 * x * (1.0 + cute.tanh(GELU_CONST * (x + 0.044715 * x * x * x)))


# ---------------------------------------------------------------------------
# Layer norm over an FP8 input dequantized by INPUT_SCALE. Output requantized
# to FP8 with NORM_SCALE.
# ---------------------------------------------------------------------------
@cute.kernel
def layer_norm_fp8_kernel(
    hidden: cute.Tensor,
    weight: cute.Tensor,
    bias: cute.Tensor,
    output: cute.Tensor,
):
    tid, _, _ = cute.arch.thread_idx()
    row, _, _ = cute.arch.block_idx()

    smem_sum = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, THREADS, 4),
        cute.make_layout(THREADS),
    )
    smem_sumsq = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, THREADS, 4),
        cute.make_layout(THREADS),
    )
    smem_mean = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, 1, 4),
        cute.make_layout(1),
    )
    smem_rstd = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, 1, 4),
        cute.make_layout(1),
    )

    local_sum = cutlass.Float32(0.0)
    local_sumsq = cutlass.Float32(0.0)
    for i in cutlass.range(HIDDEN_SIZE // THREADS):
        col = i * THREADS + tid
        v = hidden[row, col].to(cutlass.Float32) * cutlass.Float32(INPUT_SCALE)
        local_sum = local_sum + v
        local_sumsq = local_sumsq + v * v
    smem_sum[tid] = local_sum
    smem_sumsq[tid] = local_sumsq
    cute.arch.sync_threads()

    if tid == 0:
        total_sum = cutlass.Float32(0.0)
        total_sumsq = cutlass.Float32(0.0)
        for i in cutlass.range(THREADS):
            total_sum = total_sum + smem_sum[i]
            total_sumsq = total_sumsq + smem_sumsq[i]
        mean = total_sum / cutlass.Float32(HIDDEN_SIZE)
        var = total_sumsq / cutlass.Float32(HIDDEN_SIZE) - mean * mean
        smem_mean[0] = mean
        smem_rstd[0] = cute.rsqrt(var + cutlass.Float32(EPSILON))
    cute.arch.sync_threads()

    mean = smem_mean[0]
    rstd = smem_rstd[0]
    for i in cutlass.range(HIDDEN_SIZE // THREADS):
        col = i * THREADS + tid
        v = hidden[row, col].to(cutlass.Float32) * cutlass.Float32(INPUT_SCALE)
        norm = (v - mean) * rstd
        out = norm * weight[col].to(cutlass.Float32) + bias[col].to(cutlass.Float32)
        output[row, col] = cutlass.Float8E4M3FN(out / cutlass.Float32(NORM_SCALE))


# ---------------------------------------------------------------------------
# Layer norm over an already-real FP32 input (the residual). Output requantized
# to FP8 with NORM_SCALE.
# ---------------------------------------------------------------------------
@cute.kernel
def layer_norm_fp32_kernel(
    hidden: cute.Tensor,
    weight: cute.Tensor,
    bias: cute.Tensor,
    output: cute.Tensor,
):
    tid, _, _ = cute.arch.thread_idx()
    row, _, _ = cute.arch.block_idx()

    smem_sum = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, THREADS, 4),
        cute.make_layout(THREADS),
    )
    smem_sumsq = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, THREADS, 4),
        cute.make_layout(THREADS),
    )
    smem_mean = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, 1, 4),
        cute.make_layout(1),
    )
    smem_rstd = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, 1, 4),
        cute.make_layout(1),
    )

    local_sum = cutlass.Float32(0.0)
    local_sumsq = cutlass.Float32(0.0)
    for i in cutlass.range(HIDDEN_SIZE // THREADS):
        col = i * THREADS + tid
        v = hidden[row, col].to(cutlass.Float32)
        local_sum = local_sum + v
        local_sumsq = local_sumsq + v * v
    smem_sum[tid] = local_sum
    smem_sumsq[tid] = local_sumsq
    cute.arch.sync_threads()

    if tid == 0:
        total_sum = cutlass.Float32(0.0)
        total_sumsq = cutlass.Float32(0.0)
        for i in cutlass.range(THREADS):
            total_sum = total_sum + smem_sum[i]
            total_sumsq = total_sumsq + smem_sumsq[i]
        mean = total_sum / cutlass.Float32(HIDDEN_SIZE)
        var = total_sumsq / cutlass.Float32(HIDDEN_SIZE) - mean * mean
        smem_mean[0] = mean
        smem_rstd[0] = cute.rsqrt(var + cutlass.Float32(EPSILON))
    cute.arch.sync_threads()

    mean = smem_mean[0]
    rstd = smem_rstd[0]
    for i in cutlass.range(HIDDEN_SIZE // THREADS):
        col = i * THREADS + tid
        v = hidden[row, col].to(cutlass.Float32)
        norm = (v - mean) * rstd
        out = norm * weight[col].to(cutlass.Float32) + bias[col].to(cutlass.Float32)
        output[row, col] = cutlass.Float8E4M3FN(out / cutlass.Float32(NORM_SCALE))


# ---------------------------------------------------------------------------
# Dense projections. One CTA per (output tile, token); the A-operand row is
# staged into shared memory once and reused by every thread. Each thread owns
# CPT output columns and the K-reduction is split across UNROLL independent
# accumulator chains. Reading the shared A value once per K and feeding CPT
# output columns raises instruction-level parallelism and cuts shared-memory
# traffic by CPTx.
# ---------------------------------------------------------------------------
@cute.jit
def dot_columns(a_smem: cute.Tensor, weight: cute.Tensor, n0: int, k_total: int, cpt: int):
    accs = [cutlass.Float32(0.0) for _ in cutlass.range_constexpr(cpt)]
    for b in cutlass.range(k_total // UNROLL):
        base = b * UNROLL
        for u in cutlass.range_constexpr(UNROLL):
            av = a_smem[base + u].to(cutlass.Float32)
            for j in cutlass.range_constexpr(cpt):
                accs[j] = accs[j] + av * weight[n0 + j, base + u].to(cutlass.Float32)
    return accs


@cute.kernel
def qkv_projection_kernel(
    hidden: cute.Tensor,
    weight: cute.Tensor,
    bias: cute.Tensor,
    output: cute.Tensor,
):
    tid, _, _ = cute.arch.thread_idx()
    n_tile, row, _ = cute.arch.block_idx()
    n0 = n_tile * (THREADS * QKV_CPT) + tid * QKV_CPT

    smem_h = cute.make_tensor(
        cute.arch.alloc_smem(FP8_DTYPE, HIDDEN_SIZE, 4),
        cute.make_layout(HIDDEN_SIZE),
    )
    for i in cutlass.range(HIDDEN_SIZE // THREADS):
        smem_h[i * THREADS + tid] = hidden[row, i * THREADS + tid]
    cute.arch.sync_threads()

    accs = dot_columns(smem_h, weight, n0, HIDDEN_SIZE, QKV_CPT)
    for j in cutlass.range_constexpr(QKV_CPT):
        real = accs[j] * cutlass.Float32(NORM_SCALE * WEIGHT_H_SCALE) + bias[n0 + j].to(cutlass.Float32)
        output[row, n0 + j] = cutlass.Float8E4M3FN(real / cutlass.Float32(QKV_SCALE))


@cute.kernel
def attention_fused_kernel(qkv: cute.Tensor, context: cute.Tensor):
    # One CTA per (query token, head). Thread t owns key index t for that head.
    # Causal scores, per-head softmax and the 64-dim context output are computed
    # in shared memory. THREADS == TOKENS.
    tid, _, _ = cute.arch.thread_idx()
    row, head, _ = cute.arch.block_idx()

    smem_score = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, THREADS, 4),
        cute.make_layout(THREADS),
    )
    smem_prob = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, THREADS, 4),
        cute.make_layout(THREADS),
    )
    smem_max = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, THREADS, 4),
        cute.make_layout(THREADS),
    )
    smem_sum = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, THREADS, 4),
        cute.make_layout(THREADS),
    )
    smem_mx = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, 1, 4),
        cute.make_layout(1),
    )
    smem_total = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, 1, 4),
        cute.make_layout(1),
    )

    # Stage 1: score[tid] = q[row,head,:] . k[tid,head,:] / sqrt(64), causal masked.
    hbase = head * HEAD_DIM
    q0 = cutlass.Float32(0.0)
    q1 = cutlass.Float32(0.0)
    q2 = cutlass.Float32(0.0)
    q3 = cutlass.Float32(0.0)
    q4 = cutlass.Float32(0.0)
    q5 = cutlass.Float32(0.0)
    q6 = cutlass.Float32(0.0)
    q7 = cutlass.Float32(0.0)
    for b in cutlass.range(HEAD_DIM // UNROLL):
        base = b * UNROLL
        q0 = q0 + (qkv[row, hbase + base + 0].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE)) * (qkv[tid, HIDDEN_SIZE + hbase + base + 0].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE))
        q1 = q1 + (qkv[row, hbase + base + 1].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE)) * (qkv[tid, HIDDEN_SIZE + hbase + base + 1].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE))
        q2 = q2 + (qkv[row, hbase + base + 2].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE)) * (qkv[tid, HIDDEN_SIZE + hbase + base + 2].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE))
        q3 = q3 + (qkv[row, hbase + base + 3].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE)) * (qkv[tid, HIDDEN_SIZE + hbase + base + 3].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE))
        q4 = q4 + (qkv[row, hbase + base + 4].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE)) * (qkv[tid, HIDDEN_SIZE + hbase + base + 4].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE))
        q5 = q5 + (qkv[row, hbase + base + 5].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE)) * (qkv[tid, HIDDEN_SIZE + hbase + base + 5].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE))
        q6 = q6 + (qkv[row, hbase + base + 6].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE)) * (qkv[tid, HIDDEN_SIZE + hbase + base + 6].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE))
        q7 = q7 + (qkv[row, hbase + base + 7].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE)) * (qkv[tid, HIDDEN_SIZE + hbase + base + 7].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE))
    acc = ((q0 + q1) + (q2 + q3)) + ((q4 + q5) + (q6 + q7))
    s = acc / cutlass.Float32(SQRT_HEAD_DIM)
    if tid > row:
        s = cutlass.Float32(NEG_INF)
    smem_score[tid] = s
    cute.arch.sync_threads()

    # Stage 2: softmax over the key axis.
    s = smem_score[tid]
    smem_max[tid] = s
    cute.arch.sync_threads()
    if tid == 0:
        mx = smem_max[0]
        for i in cutlass.range(1, THREADS):
            if smem_max[i] > mx:
                mx = smem_max[i]
        smem_mx[0] = mx
    cute.arch.sync_threads()
    mx = smem_mx[0]
    e = cute.exp(s - mx)
    smem_sum[tid] = e
    cute.arch.sync_threads()
    if tid == 0:
        tot = smem_sum[0]
        for i in cutlass.range(1, THREADS):
            tot = tot + smem_sum[i]
        smem_total[0] = tot
    cute.arch.sync_threads()
    tot = smem_total[0]
    smem_prob[tid] = e / tot
    cute.arch.sync_threads()

    # Stage 3: context[row, head*64+d] = sum_n prob[n] * v[n,head,d], requantized.
    if tid < HEAD_DIM:
        d = tid
        c0 = cutlass.Float32(0.0)
        c1 = cutlass.Float32(0.0)
        c2 = cutlass.Float32(0.0)
        c3 = cutlass.Float32(0.0)
        c4 = cutlass.Float32(0.0)
        c5 = cutlass.Float32(0.0)
        c6 = cutlass.Float32(0.0)
        c7 = cutlass.Float32(0.0)
        for b in cutlass.range(TOKENS // UNROLL):
            base = b * UNROLL
            c0 = c0 + smem_prob[base + 0] * (qkv[base + 0, 2 * HIDDEN_SIZE + hbase + d].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE))
            c1 = c1 + smem_prob[base + 1] * (qkv[base + 1, 2 * HIDDEN_SIZE + hbase + d].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE))
            c2 = c2 + smem_prob[base + 2] * (qkv[base + 2, 2 * HIDDEN_SIZE + hbase + d].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE))
            c3 = c3 + smem_prob[base + 3] * (qkv[base + 3, 2 * HIDDEN_SIZE + hbase + d].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE))
            c4 = c4 + smem_prob[base + 4] * (qkv[base + 4, 2 * HIDDEN_SIZE + hbase + d].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE))
            c5 = c5 + smem_prob[base + 5] * (qkv[base + 5, 2 * HIDDEN_SIZE + hbase + d].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE))
            c6 = c6 + smem_prob[base + 6] * (qkv[base + 6, 2 * HIDDEN_SIZE + hbase + d].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE))
            c7 = c7 + smem_prob[base + 7] * (qkv[base + 7, 2 * HIDDEN_SIZE + hbase + d].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE))
        cacc = ((c0 + c1) + (c2 + c3)) + ((c4 + c5) + (c6 + c7))
        context[row, hbase + d] = cutlass.Float8E4M3FN(
            cacc / cutlass.Float32(CONTEXT_SCALE)
        )


@cute.kernel
def attention_projection_kernel(
    hidden: cute.Tensor,
    context: cute.Tensor,
    weight: cute.Tensor,
    bias: cute.Tensor,
    residual: cute.Tensor,
):
    tid, _, _ = cute.arch.thread_idx()
    n_tile, row, _ = cute.arch.block_idx()
    col0 = n_tile * (THREADS * OUT_CPT) + tid * OUT_CPT

    smem_h = cute.make_tensor(
        cute.arch.alloc_smem(FP8_DTYPE, HIDDEN_SIZE, 4),
        cute.make_layout(HIDDEN_SIZE),
    )
    smem_c = cute.make_tensor(
        cute.arch.alloc_smem(FP8_DTYPE, HIDDEN_SIZE, 4),
        cute.make_layout(HIDDEN_SIZE),
    )
    for i in cutlass.range(HIDDEN_SIZE // THREADS):
        smem_h[i * THREADS + tid] = hidden[row, i * THREADS + tid]
        smem_c[i * THREADS + tid] = context[row, i * THREADS + tid]
    cute.arch.sync_threads()

    accs = dot_columns(smem_c, weight, col0, HIDDEN_SIZE, OUT_CPT)
    for j in cutlass.range_constexpr(OUT_CPT):
        col = col0 + j
        real = accs[j] * cutlass.Float32(CONTEXT_SCALE * WEIGHT_H_SCALE) + bias[col].to(cutlass.Float32)
        residual[row, col] = smem_h[col].to(cutlass.Float32) * cutlass.Float32(INPUT_SCALE) + real


@cute.kernel
def mlp_fc_gelu_kernel(
    hidden: cute.Tensor,
    weight: cute.Tensor,
    bias: cute.Tensor,
    output: cute.Tensor,
):
    tid, _, _ = cute.arch.thread_idx()
    n_tile, row, _ = cute.arch.block_idx()
    n0 = n_tile * (THREADS * FC_CPT) + tid * FC_CPT

    smem_h = cute.make_tensor(
        cute.arch.alloc_smem(FP8_DTYPE, HIDDEN_SIZE, 4),
        cute.make_layout(HIDDEN_SIZE),
    )
    for i in cutlass.range(HIDDEN_SIZE // THREADS):
        smem_h[i * THREADS + tid] = hidden[row, i * THREADS + tid]
    cute.arch.sync_threads()

    accs = dot_columns(smem_h, weight, n0, HIDDEN_SIZE, FC_CPT)
    for j in cutlass.range_constexpr(FC_CPT):
        fc_real = accs[j] * cutlass.Float32(NORM_SCALE * WEIGHT_H_SCALE) + bias[n0 + j].to(cutlass.Float32)
        g = gelu_new(fc_real)
        output[row, n0 + j] = cutlass.Float8E4M3FN(g / cutlass.Float32(MLP_SCALE))


@cute.kernel
def mlp_projection_kernel(
    residual: cute.Tensor,
    hidden: cute.Tensor,
    weight: cute.Tensor,
    bias: cute.Tensor,
    output: cute.Tensor,
):
    tid, _, _ = cute.arch.thread_idx()
    n_tile, row, _ = cute.arch.block_idx()
    col0 = n_tile * (THREADS * PROJ_CPT) + tid * PROJ_CPT

    smem_h = cute.make_tensor(
        cute.arch.alloc_smem(FP8_DTYPE, MLP_SIZE, 4),
        cute.make_layout(MLP_SIZE),
    )
    for i in cutlass.range(MLP_SIZE // THREADS):
        smem_h[i * THREADS + tid] = hidden[row, i * THREADS + tid]
    cute.arch.sync_threads()

    accs = dot_columns(smem_h, weight, col0, MLP_SIZE, PROJ_CPT)
    for j in cutlass.range_constexpr(PROJ_CPT):
        col = col0 + j
        real = accs[j] * cutlass.Float32(MLP_SCALE * WEIGHT_MLP_SCALE) + bias[col].to(cutlass.Float32)
        output[row, col] = residual[row, col].to(cutlass.Float32) + real


@cute.jit
def gpt2_transformer_block(
    hidden: cute.Tensor,
    ln1_weight: cute.Tensor,
    ln1_bias: cute.Tensor,
    qkv_weight: cute.Tensor,
    qkv_bias: cute.Tensor,
    out_weight: cute.Tensor,
    out_bias: cute.Tensor,
    ln2_weight: cute.Tensor,
    ln2_bias: cute.Tensor,
    fc_weight: cute.Tensor,
    fc_bias: cute.Tensor,
    proj_weight: cute.Tensor,
    proj_bias: cute.Tensor,
    norm1_workspace: cute.Tensor,
    qkv_workspace: cute.Tensor,
    score_workspace: cute.Tensor,
    probability_workspace: cute.Tensor,
    context_workspace: cute.Tensor,
    residual_workspace: cute.Tensor,
    norm2_workspace: cute.Tensor,
    mlp_workspace: cute.Tensor,
    output: cute.Tensor,
):
    grid = (TOKENS, 1, 1)
    block = (THREADS, 1, 1)

    layer_norm_fp8_kernel(hidden, ln1_weight, ln1_bias, norm1_workspace).launch(grid=grid, block=block)
    qkv_projection_kernel(norm1_workspace, qkv_weight, qkv_bias, qkv_workspace).launch(
        grid=(QKV_SIZE // (THREADS * QKV_CPT), TOKENS, 1), block=block
    )
    attention_fused_kernel(qkv_workspace, context_workspace).launch(
        grid=(TOKENS, NUM_HEADS, 1), block=block
    )
    attention_projection_kernel(hidden, context_workspace, out_weight, out_bias, residual_workspace).launch(
        grid=(HIDDEN_SIZE // (THREADS * OUT_CPT), TOKENS, 1), block=block
    )
    layer_norm_fp32_kernel(residual_workspace, ln2_weight, ln2_bias, norm2_workspace).launch(grid=grid, block=block)
    mlp_fc_gelu_kernel(norm2_workspace, fc_weight, fc_bias, mlp_workspace).launch(
        grid=(MLP_SIZE // (THREADS * FC_CPT), TOKENS, 1), block=block
    )
    mlp_projection_kernel(residual_workspace, mlp_workspace, proj_weight, proj_bias, output).launch(
        grid=(HIDDEN_SIZE // (THREADS * PROJ_CPT), TOKENS, 1), block=block
    )


class ModelNew:
    forward = staticmethod(gpt2_transformer_block)

# === CUTE_HARNESS_EVALUATOR_V1 ===
_CUTE_HARNESS_SEED = 0
_CUTE_HARNESS_WARMUP = 5
_CUTE_HARNESS_REPEATS = 50

import math as _cute_harness_math

import torch as _cute_harness_torch
import torch.nn.functional as _cute_harness_functional

import cutlass as _cute_harness_cutlass
import cutlass.cute as _cute_harness_cute
from cutlass.cute.runtime import from_dlpack as _cute_harness_from_dlpack
from cutlass.utils import (
    create_cute_tensor_for_fp8 as _cute_harness_create_fp8,
)


_CUTE_HARNESS_TOKENS = 128
_CUTE_HARNESS_HIDDEN = 768
_CUTE_HARNESS_HEADS = 12
_CUTE_HARNESS_HEAD_DIM = 64
_CUTE_HARNESS_MLP = 3072
_CUTE_HARNESS_QKV = 2304
_CUTE_HARNESS_EPSILON = 1.0e-5
_CUTE_HARNESS_INPUT_SCALE = 1.0 / 448.0
_CUTE_HARNESS_NORM_SCALE = 1.0 / 64.0
_CUTE_HARNESS_QKV_SCALE = 1.0 / 64.0
_CUTE_HARNESS_CONTEXT_SCALE = 1.0 / 64.0
_CUTE_HARNESS_MLP_SCALE = 1.0 / 64.0
_CUTE_HARNESS_WEIGHT_H_BOUND = _CUTE_HARNESS_HIDDEN ** -0.5
_CUTE_HARNESS_WEIGHT_MLP_BOUND = _CUTE_HARNESS_MLP ** -0.5
_CUTE_HARNESS_WEIGHT_H_SCALE = _CUTE_HARNESS_WEIGHT_H_BOUND / 448.0
_CUTE_HARNESS_WEIGHT_MLP_SCALE = _CUTE_HARNESS_WEIGHT_MLP_BOUND / 448.0
_CUTE_HARNESS_FP8_DTYPE = _cute_harness_cutlass.Float8E4M3FN


def _cute_harness_fp8_tensor(source, scale):
    storage = _cute_harness_torch.empty(
        source.shape,
        device="cuda",
        dtype=_cute_harness_torch.uint8,
    )
    tensor = _cute_harness_create_fp8(
        storage,
        _CUTE_HARNESS_FP8_DTYPE,
        1,
        source / scale,
    )
    return storage, tensor


def _cute_harness_empty_fp8(shape):
    source = _cute_harness_torch.zeros(
        shape,
        device="cuda",
        dtype=_cute_harness_torch.float32,
    )
    return _cute_harness_fp8_tensor(source, 1.0)


def _cute_harness_scaled_linear(
    activation,
    weight,
    activation_scale,
    weight_scale,
    bias,
):
    scale_a = _cute_harness_torch.tensor(
        activation_scale,
        device="cuda",
        dtype=_cute_harness_torch.float32,
    )
    scale_b = _cute_harness_torch.tensor(
        weight_scale,
        device="cuda",
        dtype=_cute_harness_torch.float32,
    )
    return _cute_harness_torch._scaled_mm(
        activation,
        weight.t(),
        scale_a=scale_a,
        scale_b=scale_b,
        out_dtype=_cute_harness_torch.float32,
    ) + bias


def main():
    if not _cute_harness_torch.cuda.is_available():
        raise RuntimeError("A Blackwell CUDA device is required")

    _cute_harness_torch.manual_seed(_CUTE_HARNESS_SEED)
    hidden_source = _cute_harness_torch.empty(
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_HIDDEN),
        device="cuda",
        dtype=_cute_harness_torch.float32,
    ).uniform_(-1.0, 1.0)
    ln1_weight = 1.0 + 0.02 * _cute_harness_torch.randn(
        (_CUTE_HARNESS_HIDDEN,), device="cuda"
    )
    ln1_bias = 0.02 * _cute_harness_torch.randn(
        (_CUTE_HARNESS_HIDDEN,), device="cuda"
    )
    ln2_weight = 1.0 + 0.02 * _cute_harness_torch.randn(
        (_CUTE_HARNESS_HIDDEN,), device="cuda"
    )
    ln2_bias = 0.02 * _cute_harness_torch.randn(
        (_CUTE_HARNESS_HIDDEN,), device="cuda"
    )
    qkv_bias = 0.02 * _cute_harness_torch.randn(
        (_CUTE_HARNESS_QKV,), device="cuda"
    )
    out_bias = 0.02 * _cute_harness_torch.randn(
        (_CUTE_HARNESS_HIDDEN,), device="cuda"
    )
    fc_bias = 0.02 * _cute_harness_torch.randn(
        (_CUTE_HARNESS_MLP,), device="cuda"
    )
    proj_bias = 0.02 * _cute_harness_torch.randn(
        (_CUTE_HARNESS_HIDDEN,), device="cuda"
    )

    qkv_weight_source = _cute_harness_torch.empty(
        (_CUTE_HARNESS_QKV, _CUTE_HARNESS_HIDDEN), device="cuda"
    ).uniform_(
        -_CUTE_HARNESS_WEIGHT_H_BOUND,
        _CUTE_HARNESS_WEIGHT_H_BOUND,
    )
    out_weight_source = _cute_harness_torch.empty(
        (_CUTE_HARNESS_HIDDEN, _CUTE_HARNESS_HIDDEN), device="cuda"
    ).uniform_(
        -_CUTE_HARNESS_WEIGHT_H_BOUND,
        _CUTE_HARNESS_WEIGHT_H_BOUND,
    )
    fc_weight_source = _cute_harness_torch.empty(
        (_CUTE_HARNESS_MLP, _CUTE_HARNESS_HIDDEN), device="cuda"
    ).uniform_(
        -_CUTE_HARNESS_WEIGHT_H_BOUND,
        _CUTE_HARNESS_WEIGHT_H_BOUND,
    )
    proj_weight_source = _cute_harness_torch.empty(
        (_CUTE_HARNESS_HIDDEN, _CUTE_HARNESS_MLP), device="cuda"
    ).uniform_(
        -_CUTE_HARNESS_WEIGHT_MLP_BOUND,
        _CUTE_HARNESS_WEIGHT_MLP_BOUND,
    )

    hidden_storage, hidden = _cute_harness_fp8_tensor(
        hidden_source, _CUTE_HARNESS_INPUT_SCALE
    )
    qkv_weight_storage, qkv_weight = _cute_harness_fp8_tensor(
        qkv_weight_source, _CUTE_HARNESS_WEIGHT_H_SCALE
    )
    out_weight_storage, out_weight = _cute_harness_fp8_tensor(
        out_weight_source, _CUTE_HARNESS_WEIGHT_H_SCALE
    )
    fc_weight_storage, fc_weight = _cute_harness_fp8_tensor(
        fc_weight_source, _CUTE_HARNESS_WEIGHT_H_SCALE
    )
    proj_weight_storage, proj_weight = _cute_harness_fp8_tensor(
        proj_weight_source, _CUTE_HARNESS_WEIGHT_MLP_SCALE
    )

    norm1_workspace_storage, norm1_workspace = _cute_harness_empty_fp8(
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_HIDDEN)
    )
    qkv_workspace_storage, qkv_workspace = _cute_harness_empty_fp8(
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_QKV)
    )
    context_workspace_storage, context_workspace = _cute_harness_empty_fp8(
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_HIDDEN)
    )
    norm2_workspace_storage, norm2_workspace = _cute_harness_empty_fp8(
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_HIDDEN)
    )
    mlp_workspace_storage, mlp_workspace = _cute_harness_empty_fp8(
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_MLP)
    )

    score_workspace_storage = _cute_harness_torch.empty(
        (_CUTE_HARNESS_HEADS * _CUTE_HARNESS_TOKENS, _CUTE_HARNESS_TOKENS),
        device="cuda",
        dtype=_cute_harness_torch.float32,
    )
    probability_workspace_storage = _cute_harness_torch.empty_like(
        score_workspace_storage
    )
    residual_workspace_storage = _cute_harness_torch.empty(
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_HIDDEN),
        device="cuda",
        dtype=_cute_harness_torch.float32,
    )
    output_storage = _cute_harness_torch.empty_like(
        residual_workspace_storage
    )
    score_workspace = _cute_harness_from_dlpack(
        score_workspace_storage
    ).mark_layout_dynamic(leading_dim=1)
    probability_workspace = _cute_harness_from_dlpack(
        probability_workspace_storage
    ).mark_layout_dynamic(leading_dim=1)
    residual_workspace = _cute_harness_from_dlpack(
        residual_workspace_storage
    ).mark_layout_dynamic(leading_dim=1)
    output = _cute_harness_from_dlpack(output_storage).mark_layout_dynamic(
        leading_dim=1
    )

    parameter_tensors = (
        _cute_harness_from_dlpack(ln1_weight),
        _cute_harness_from_dlpack(ln1_bias),
        qkv_weight,
        _cute_harness_from_dlpack(qkv_bias),
        out_weight,
        _cute_harness_from_dlpack(out_bias),
        _cute_harness_from_dlpack(ln2_weight),
        _cute_harness_from_dlpack(ln2_bias),
        fc_weight,
        _cute_harness_from_dlpack(fc_bias),
        proj_weight,
        _cute_harness_from_dlpack(proj_bias),
    )
    arguments = (
        hidden,
        *parameter_tensors,
        norm1_workspace,
        qkv_workspace,
        score_workspace,
        probability_workspace,
        context_workspace,
        residual_workspace,
        norm2_workspace,
        mlp_workspace,
        output,
    )
    compiled = _cute_harness_cute.compile(
        gpt2_transformer_block,
        *arguments,
    )
    for _ in range(_CUTE_HARNESS_WARMUP):
        compiled(*arguments)
    _cute_harness_torch.cuda.synchronize()

    timings_ms = []
    for _ in range(_CUTE_HARNESS_REPEATS):
        start = _cute_harness_torch.cuda.Event(enable_timing=True)
        end = _cute_harness_torch.cuda.Event(enable_timing=True)
        start.record()
        compiled(*arguments)
        end.record()
        end.synchronize()
        timings_ms.append(start.elapsed_time(end))
    kernel_time_ms = sorted(timings_ms)[len(timings_ms) // 2]

    hidden_fp8 = hidden_storage.view(_cute_harness_torch.float8_e4m3fn)
    qkv_weight_fp8 = qkv_weight_storage.view(
        _cute_harness_torch.float8_e4m3fn
    )
    out_weight_fp8 = out_weight_storage.view(
        _cute_harness_torch.float8_e4m3fn
    )
    fc_weight_fp8 = fc_weight_storage.view(
        _cute_harness_torch.float8_e4m3fn
    )
    proj_weight_fp8 = proj_weight_storage.view(
        _cute_harness_torch.float8_e4m3fn
    )
    hidden_dequantized = hidden_fp8.float() * _CUTE_HARNESS_INPUT_SCALE
    norm1_reference = _cute_harness_functional.layer_norm(
        hidden_dequantized,
        (_CUTE_HARNESS_HIDDEN,),
        ln1_weight,
        ln1_bias,
        _CUTE_HARNESS_EPSILON,
    )
    norm1_fp8 = (norm1_reference / _CUTE_HARNESS_NORM_SCALE).to(
        _cute_harness_torch.float8_e4m3fn
    )
    qkv_reference = _cute_harness_scaled_linear(
        norm1_fp8,
        qkv_weight_fp8,
        _CUTE_HARNESS_NORM_SCALE,
        _CUTE_HARNESS_WEIGHT_H_SCALE,
        qkv_bias,
    )
    qkv_fp8 = (qkv_reference / _CUTE_HARNESS_QKV_SCALE).to(
        _cute_harness_torch.float8_e4m3fn
    )
    qkv_dequantized = qkv_fp8.float() * _CUTE_HARNESS_QKV_SCALE
    query, key, value = qkv_dequantized.reshape(
        _CUTE_HARNESS_TOKENS,
        3,
        _CUTE_HARNESS_HEADS,
        _CUTE_HARNESS_HEAD_DIM,
    ).unbind(dim=1)
    scores = _cute_harness_torch.einsum(
        "thd,shd->hts", query, key
    ) / _cute_harness_math.sqrt(_CUTE_HARNESS_HEAD_DIM)
    causal_mask = _cute_harness_torch.triu(
        _cute_harness_torch.ones(
            (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_TOKENS),
            device="cuda",
            dtype=_cute_harness_torch.bool,
        ),
        diagonal=1,
    )
    probabilities = scores.masked_fill(causal_mask, -float("inf")).softmax(
        dim=-1
    )
    context_reference = _cute_harness_torch.einsum(
        "hts,shd->thd", probabilities, value
    ).reshape(_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_HIDDEN)
    context_fp8 = (
        context_reference / _CUTE_HARNESS_CONTEXT_SCALE
    ).to(_cute_harness_torch.float8_e4m3fn)
    residual_reference = hidden_dequantized + _cute_harness_scaled_linear(
        context_fp8,
        out_weight_fp8,
        _CUTE_HARNESS_CONTEXT_SCALE,
        _CUTE_HARNESS_WEIGHT_H_SCALE,
        out_bias,
    )
    norm2_reference = _cute_harness_functional.layer_norm(
        residual_reference,
        (_CUTE_HARNESS_HIDDEN,),
        ln2_weight,
        ln2_bias,
        _CUTE_HARNESS_EPSILON,
    )
    norm2_fp8 = (norm2_reference / _CUTE_HARNESS_NORM_SCALE).to(
        _cute_harness_torch.float8_e4m3fn
    )
    fc_reference = _cute_harness_scaled_linear(
        norm2_fp8,
        fc_weight_fp8,
        _CUTE_HARNESS_NORM_SCALE,
        _CUTE_HARNESS_WEIGHT_H_SCALE,
        fc_bias,
    )
    mlp_fp8 = (
        _cute_harness_functional.gelu(fc_reference, approximate="tanh")
        / _CUTE_HARNESS_MLP_SCALE
    ).to(_cute_harness_torch.float8_e4m3fn)
    quantized_reference = residual_reference + _cute_harness_scaled_linear(
        mlp_fp8,
        proj_weight_fp8,
        _CUTE_HARNESS_MLP_SCALE,
        _CUTE_HARNESS_WEIGHT_MLP_SCALE,
        proj_bias,
    )

    fp32_norm1 = _cute_harness_functional.layer_norm(
        hidden_source,
        (_CUTE_HARNESS_HIDDEN,),
        ln1_weight,
        ln1_bias,
        _CUTE_HARNESS_EPSILON,
    )
    fp32_qkv = fp32_norm1 @ qkv_weight_source.t() + qkv_bias
    fp32_query, fp32_key, fp32_value = fp32_qkv.reshape(
        _CUTE_HARNESS_TOKENS,
        3,
        _CUTE_HARNESS_HEADS,
        _CUTE_HARNESS_HEAD_DIM,
    ).unbind(dim=1)
    fp32_scores = _cute_harness_torch.einsum(
        "thd,shd->hts", fp32_query, fp32_key
    ) / _cute_harness_math.sqrt(_CUTE_HARNESS_HEAD_DIM)
    fp32_probabilities = fp32_scores.masked_fill(
        causal_mask, -float("inf")
    ).softmax(dim=-1)
    fp32_context = _cute_harness_torch.einsum(
        "hts,shd->thd", fp32_probabilities, fp32_value
    ).reshape(_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_HIDDEN)
    fp32_residual = (
        hidden_source + fp32_context @ out_weight_source.t() + out_bias
    )
    fp32_norm2 = _cute_harness_functional.layer_norm(
        fp32_residual,
        (_CUTE_HARNESS_HIDDEN,),
        ln2_weight,
        ln2_bias,
        _CUTE_HARNESS_EPSILON,
    )
    fp32_mlp = _cute_harness_functional.gelu(
        fp32_norm2 @ fc_weight_source.t() + fc_bias,
        approximate="tanh",
    )
    fp32_reference = (
        fp32_residual + fp32_mlp @ proj_weight_source.t() + proj_bias
    )

    quantized_max_abs = (output_storage - quantized_reference).abs().max().item()
    sample_rows = _cute_harness_torch.tensor(
        [0, 1, 31, 63, 64, 95, 127], device="cuda"
    )
    sample_columns = _cute_harness_torch.tensor(
        [0, 63, 64, 255, 511, 767], device="cuda"
    )
    sample_actual = output_storage.index_select(0, sample_rows).index_select(
        1, sample_columns
    )
    sample_reference = fp32_reference.index_select(
        0, sample_rows
    ).index_select(1, sample_columns)
    fp32_sample_max_abs = (sample_actual - sample_reference).abs().max().item()
    if (
        not _cute_harness_torch.isfinite(output_storage).all().item()
        or quantized_max_abs > 0.05
        or fp32_sample_max_abs > 0.5
    ):
        raise RuntimeError(
            f"validation failed: quantized_abs={quantized_max_abs:.6f}, "
            f"fp32_sample_abs={fp32_sample_max_abs:.6f}"
        )

    print(
        "task=model_gpt2_small_transformer_block_fp8 "
        f"quantized_max_abs={quantized_max_abs:.6f} "
        f"fp32_sample_max_abs={fp32_sample_max_abs:.6f} "
        f"kernel_time_ms={kernel_time_ms:.6f} PASS"
    )
    _cute_harness_torch.cuda.synchronize()


main()
