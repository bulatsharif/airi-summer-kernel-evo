# KernelEvo iteration 1

Run: `run`  
Barrier status: **evaluated**  
Valid: 0 · Promoted: 0

| Island | Result | Progress | Runtime | Speedup | Promoted | Idea |
|---:|---|---:|---:|---:|:---:|---|
| 0 | failed: RuntimeError: validation failed: quantized_abs=80.115250, fp32_sample_abs=50.20… | — | — | 0.000x | no | Implement the task's CuTe DSL FP8 kernel so it compiles and produces numerically correct output on… |

Global best: `seed` at **1.000x** speedup.
