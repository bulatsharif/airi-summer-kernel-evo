# B300 device profile of your last candidate

- device: NVIDIA B300 SXM6 AC, 148 SMs, 232448 B opt-in shared memory/block
- GPU busy: 201.576 ms total; kernels 201.548 ms over 503 launches of 40 distinct names
- memcpy: 0.028 ms over 15 calls; memset: 0.001 ms over 1 calls

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_mlp_projection_kernel_tensorptrf32gmemoi641_tensorptrf8E4M3FNgmemalign16… | 69.761 | 55 | 34.6 |
| kernel_cutlass_mlp_fc_gelu_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgm… | 60.504 | 55 | 30.0 |
| kernel_cutlass_qkv_projection_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3F… | 46.186 | 55 | 22.9 |
| kernel_cutlass_attention_projection_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf… | 17.575 | 55 | 8.7 |
| kernel_cutlass_attention_fused_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3… | 6.737 | 55 | 3.3 |
| kernel_cutlass_layer_norm_fp32_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo7681_tenso… | 0.186 | 55 | 0.1 |
| kernel_cutlass_layer_norm_fp8_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmem… | 0.180 | 55 | 0.1 |
| void sgemm_largek_lds64<true, false, 6, 3, 4, 5, 2, 66>(float*, float const*, float con… | 0.059 | 1 | 0.0 |
| cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 0.042 | 4 | 0.0 |
| void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 0.033 | 17 | 0.0 |
