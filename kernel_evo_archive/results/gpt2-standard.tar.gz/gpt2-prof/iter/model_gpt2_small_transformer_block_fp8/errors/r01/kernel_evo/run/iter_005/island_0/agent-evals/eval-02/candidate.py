import cutlass
import cutlass.cute as cute


TOKENS = 128
HIDDEN_SIZE = 768
NUM_HEADS = 12
HEAD_DIM = 64
MLP_SIZE = 3072
QKV_SIZE = 3 * HIDDEN_SIZE
THREADS = 128
EPSILON = 1.0e-5

INPUT_SCALE = 1.0 / 448.0
NORM_SCALE = 1.0 / 64.0
QKV_SCALE = 1.0 / 64.0
CONTEXT_SCALE = 1.0 / 64.0
MLP_SCALE = 1.0 / 64.0
WEIGHT_H_SCALE = HIDDEN_SIZE ** -0.5 / 448.0
WEIGHT_MLP_SCALE = MLP_SIZE ** -0.5 / 448.0
FP8_DTYPE = cutlass.Float8E4M3FN

SQRT_HEAD_DIM = 8.0  # sqrt(64)
NEG_INF = -1.0e30
GELU_CONST = 0.7978845608028654  # sqrt(2/pi)


@cute.jit
def gelu_new(x):
    # GPT-2 "new" GELU (tanh approximation).
    return 0.5 * x * (1.0 + cute.tanh(GELU_CONST * (x + 0.044715 * x * x * x)))


# ---------------------------------------------------------------------------
# Layer norm over an FP8 input dequantized by INPUT_SCALE. Output requantized
# to FP8 with NORM_SCALE.
# ---------------------------------------------------------------------------
@cute.kernel
def layer_norm_fp8_kernel(
    hidden: cute.Tensor,
    weight: cute.Tensor,
    bias: cute.Tensor,
    output: cute.Tensor,
):
    tid, _, _ = cute.arch.thread_idx()
    row, _, _ = cute.arch.block_idx()

    smem_sum = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, THREADS, 4),
        cute.make_layout(THREADS),
    )
    smem_sumsq = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, THREADS, 4),
        cute.make_layout(THREADS),
    )
    smem_mean = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, 1, 4),
        cute.make_layout(1),
    )
    smem_rstd = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, 1, 4),
        cute.make_layout(1),
    )

    local_sum = cutlass.Float32(0.0)
    local_sumsq = cutlass.Float32(0.0)
    for i in cutlass.range(HIDDEN_SIZE // THREADS):
        col = i * THREADS + tid
        v = hidden[row, col].to(cutlass.Float32) * cutlass.Float32(INPUT_SCALE)
        local_sum = local_sum + v
        local_sumsq = local_sumsq + v * v
    smem_sum[tid] = local_sum
    smem_sumsq[tid] = local_sumsq
    cute.arch.sync_threads()

    if tid == 0:
        total_sum = cutlass.Float32(0.0)
        total_sumsq = cutlass.Float32(0.0)
        for i in cutlass.range(THREADS):
            total_sum = total_sum + smem_sum[i]
            total_sumsq = total_sumsq + smem_sumsq[i]
        mean = total_sum / cutlass.Float32(HIDDEN_SIZE)
        var = total_sumsq / cutlass.Float32(HIDDEN_SIZE) - mean * mean
        smem_mean[0] = mean
        smem_rstd[0] = cute.rsqrt(var + cutlass.Float32(EPSILON))
    cute.arch.sync_threads()

    mean = smem_mean[0]
    rstd = smem_rstd[0]
    for i in cutlass.range(HIDDEN_SIZE // THREADS):
        col = i * THREADS + tid
        v = hidden[row, col].to(cutlass.Float32) * cutlass.Float32(INPUT_SCALE)
        norm = (v - mean) * rstd
        out = norm * weight[col].to(cutlass.Float32) + bias[col].to(cutlass.Float32)
        output[row, col] = cutlass.Float8E4M3FN(out / cutlass.Float32(NORM_SCALE))


# ---------------------------------------------------------------------------
# Layer norm over an already-real FP32 input (the residual). Output requantized
# to FP8 with NORM_SCALE.
# ---------------------------------------------------------------------------
@cute.kernel
def layer_norm_fp32_kernel(
    hidden: cute.Tensor,
    weight: cute.Tensor,
    bias: cute.Tensor,
    output: cute.Tensor,
):
    tid, _, _ = cute.arch.thread_idx()
    row, _, _ = cute.arch.block_idx()

    smem_sum = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, THREADS, 4),
        cute.make_layout(THREADS),
    )
    smem_sumsq = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, THREADS, 4),
        cute.make_layout(THREADS),
    )
    smem_mean = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, 1, 4),
        cute.make_layout(1),
    )
    smem_rstd = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, 1, 4),
        cute.make_layout(1),
    )

    local_sum = cutlass.Float32(0.0)
    local_sumsq = cutlass.Float32(0.0)
    for i in cutlass.range(HIDDEN_SIZE // THREADS):
        col = i * THREADS + tid
        v = hidden[row, col].to(cutlass.Float32)
        local_sum = local_sum + v
        local_sumsq = local_sumsq + v * v
    smem_sum[tid] = local_sum
    smem_sumsq[tid] = local_sumsq
    cute.arch.sync_threads()

    if tid == 0:
        total_sum = cutlass.Float32(0.0)
        total_sumsq = cutlass.Float32(0.0)
        for i in cutlass.range(THREADS):
            total_sum = total_sum + smem_sum[i]
            total_sumsq = total_sumsq + smem_sumsq[i]
        mean = total_sum / cutlass.Float32(HIDDEN_SIZE)
        var = total_sumsq / cutlass.Float32(HIDDEN_SIZE) - mean * mean
        smem_mean[0] = mean
        smem_rstd[0] = cute.rsqrt(var + cutlass.Float32(EPSILON))
    cute.arch.sync_threads()

    mean = smem_mean[0]
    rstd = smem_rstd[0]
    for i in cutlass.range(HIDDEN_SIZE // THREADS):
        col = i * THREADS + tid
        v = hidden[row, col].to(cutlass.Float32)
        norm = (v - mean) * rstd
        out = norm * weight[col].to(cutlass.Float32) + bias[col].to(cutlass.Float32)
        output[row, col] = cutlass.Float8E4M3FN(out / cutlass.Float32(NORM_SCALE))


# ---------------------------------------------------------------------------
# Dense projections. One CTA per (output tile, token). The A-operand row is
# staged into shared memory once and reused by every thread; each thread owns a
# single output column so the K reduction per thread is exactly one full row
# (identical summation order to the scalar path, but ~(N/THREADS)x more CTAs).
# ---------------------------------------------------------------------------
@cute.kernel
def qkv_projection_kernel(
    hidden: cute.Tensor,
    weight: cute.Tensor,
    bias: cute.Tensor,
    output: cute.Tensor,
):
    tid, _, _ = cute.arch.thread_idx()
    n_tile, row, _ = cute.arch.block_idx()
    n = n_tile * THREADS + tid

    smem_h = cute.make_tensor(
        cute.arch.alloc_smem(FP8_DTYPE, HIDDEN_SIZE, 4),
        cute.make_layout(HIDDEN_SIZE),
    )
    for i in cutlass.range(HIDDEN_SIZE // THREADS):
        smem_h[i * THREADS + tid] = hidden[row, i * THREADS + tid]
    cute.arch.sync_threads()

    acc = cutlass.Float32(0.0)
    for k in cutlass.range(HIDDEN_SIZE):
        acc = acc + smem_h[k].to(cutlass.Float32) * weight[n, k].to(cutlass.Float32)
    real = acc * cutlass.Float32(NORM_SCALE * WEIGHT_H_SCALE) + bias[n].to(cutlass.Float32)
    output[row, n] = cutlass.Float8E4M3FN(real / cutlass.Float32(QKV_SCALE))


@cute.kernel
def attention_fused_kernel(qkv: cute.Tensor, context: cute.Tensor):
    # One CTA per query token; causal scores, softmax and context computed in
    # shared memory. THREADS == TOKENS so thread t owns key index t for every head.
    tid, _, _ = cute.arch.thread_idx()
    row, _, _ = cute.arch.block_idx()

    smem_score = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, NUM_HEADS * TOKENS, 4),
        cute.make_layout(NUM_HEADS * TOKENS),
    )
    smem_prob = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, NUM_HEADS * TOKENS, 4),
        cute.make_layout(NUM_HEADS * TOKENS),
    )
    smem_max = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, THREADS, 4),
        cute.make_layout(THREADS),
    )
    smem_sum = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, THREADS, 4),
        cute.make_layout(THREADS),
    )
    smem_mx = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, 1, 4),
        cute.make_layout(1),
    )
    smem_total = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, 1, 4),
        cute.make_layout(1),
    )

    # Stage 1: scores[h, tid] = q[row,h,:] . k[tid,h,:] / sqrt(64), causal masked.
    for h in cutlass.range(NUM_HEADS):
        acc = cutlass.Float32(0.0)
        for d in cutlass.range(HEAD_DIM):
            qv = qkv[row, h * HEAD_DIM + d].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE)
            kv = qkv[tid, HIDDEN_SIZE + h * HEAD_DIM + d].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE)
            acc = acc + qv * kv
        s = acc / cutlass.Float32(SQRT_HEAD_DIM)
        if tid > row:
            s = cutlass.Float32(NEG_INF)
        smem_score[h * TOKENS + tid] = s
    cute.arch.sync_threads()

    # Stage 2: per-head softmax over the key axis.
    for h in cutlass.range(NUM_HEADS):
        s = smem_score[h * TOKENS + tid]
        smem_max[tid] = s
        cute.arch.sync_threads()
        if tid == 0:
            mx = smem_max[0]
            for i in cutlass.range(1, THREADS):
                if smem_max[i] > mx:
                    mx = smem_max[i]
            smem_mx[0] = mx
        cute.arch.sync_threads()
        mx = smem_mx[0]
        e = cute.exp(s - mx)
        smem_sum[tid] = e
        cute.arch.sync_threads()
        if tid == 0:
            tot = smem_sum[0]
            for i in cutlass.range(1, THREADS):
                tot = tot + smem_sum[i]
            smem_total[0] = tot
        cute.arch.sync_threads()
        tot = smem_total[0]
        smem_prob[h * TOKENS + tid] = e / tot
        cute.arch.sync_threads()

    # Stage 3: context[row, h*64+d] = sum_n prob[h,n] * v[n,h,d], requantized.
    for j in cutlass.range(HIDDEN_SIZE // THREADS):
        idx = j * THREADS + tid
        h = idx // HEAD_DIM
        d = idx % HEAD_DIM
        acc = cutlass.Float32(0.0)
        for n in cutlass.range(TOKENS):
            p = smem_prob[h * TOKENS + n]
            v = qkv[n, 2 * HIDDEN_SIZE + h * HEAD_DIM + d].to(cutlass.Float32) * cutlass.Float32(QKV_SCALE)
            acc = acc + p * v
        context[row, h * HEAD_DIM + d] = cutlass.Float8E4M3FN(
            acc / cutlass.Float32(CONTEXT_SCALE)
        )


@cute.kernel
def attention_projection_kernel(
    hidden: cute.Tensor,
    context: cute.Tensor,
    weight: cute.Tensor,
    bias: cute.Tensor,
    residual: cute.Tensor,
):
    tid, _, _ = cute.arch.thread_idx()
    n_tile, row, _ = cute.arch.block_idx()
    col = n_tile * THREADS + tid

    smem_h = cute.make_tensor(
        cute.arch.alloc_smem(FP8_DTYPE, HIDDEN_SIZE, 4),
        cute.make_layout(HIDDEN_SIZE),
    )
    smem_c = cute.make_tensor(
        cute.arch.alloc_smem(FP8_DTYPE, HIDDEN_SIZE, 4),
        cute.make_layout(HIDDEN_SIZE),
    )
    for i in cutlass.range(HIDDEN_SIZE // THREADS):
        smem_h[i * THREADS + tid] = hidden[row, i * THREADS + tid]
        smem_c[i * THREADS + tid] = context[row, i * THREADS + tid]
    cute.arch.sync_threads()

    acc = cutlass.Float32(0.0)
    for k in cutlass.range(HIDDEN_SIZE):
        acc = acc + smem_c[k].to(cutlass.Float32) * weight[col, k].to(cutlass.Float32)
    real = acc * cutlass.Float32(CONTEXT_SCALE * WEIGHT_H_SCALE) + bias[col].to(cutlass.Float32)
    residual[row, col] = smem_h[col].to(cutlass.Float32) * cutlass.Float32(INPUT_SCALE) + real


@cute.kernel
def mlp_fc_gelu_kernel(
    hidden: cute.Tensor,
    weight: cute.Tensor,
    bias: cute.Tensor,
    output: cute.Tensor,
):
    tid, _, _ = cute.arch.thread_idx()
    n_tile, row, _ = cute.arch.block_idx()
    n = n_tile * THREADS + tid

    smem_h = cute.make_tensor(
        cute.arch.alloc_smem(FP8_DTYPE, HIDDEN_SIZE, 4),
        cute.make_layout(HIDDEN_SIZE),
    )
    for i in cutlass.range(HIDDEN_SIZE // THREADS):
        smem_h[i * THREADS + tid] = hidden[row, i * THREADS + tid]
    cute.arch.sync_threads()

    acc = cutlass.Float32(0.0)
    for k in cutlass.range(HIDDEN_SIZE):
        acc = acc + smem_h[k].to(cutlass.Float32) * weight[n, k].to(cutlass.Float32)
    fc_real = acc * cutlass.Float32(NORM_SCALE * WEIGHT_H_SCALE) + bias[n].to(cutlass.Float32)
    g = gelu_new(fc_real)
    output[row, n] = cutlass.Float8E4M3FN(g / cutlass.Float32(MLP_SCALE))


@cute.kernel
def mlp_projection_kernel(
    residual: cute.Tensor,
    hidden: cute.Tensor,
    weight: cute.Tensor,
    bias: cute.Tensor,
    output: cute.Tensor,
):
    tid, _, _ = cute.arch.thread_idx()
    n_tile, row, _ = cute.arch.block_idx()
    col = n_tile * THREADS + tid

    smem_h = cute.make_tensor(
        cute.arch.alloc_smem(FP8_DTYPE, MLP_SIZE, 4),
        cute.make_layout(MLP_SIZE),
    )
    for i in cutlass.range(MLP_SIZE // THREADS):
        smem_h[i * THREADS + tid] = hidden[row, i * THREADS + tid]
    cute.arch.sync_threads()

    acc = cutlass.Float32(0.0)
    for k in cutlass.range(MLP_SIZE):
        acc = acc + smem_h[k].to(cutlass.Float32) * weight[col, k].to(cutlass.Float32)
    real = acc * cutlass.Float32(MLP_SCALE * WEIGHT_MLP_SCALE) + bias[col].to(cutlass.Float32)
    output[row, col] = residual[row, col].to(cutlass.Float32) + real


@cute.jit
def gpt2_transformer_block(
    hidden: cute.Tensor,
    ln1_weight: cute.Tensor,
    ln1_bias: cute.Tensor,
    qkv_weight: cute.Tensor,
    qkv_bias: cute.Tensor,
    out_weight: cute.Tensor,
    out_bias: cute.Tensor,
    ln2_weight: cute.Tensor,
    ln2_bias: cute.Tensor,
    fc_weight: cute.Tensor,
    fc_bias: cute.Tensor,
    proj_weight: cute.Tensor,
    proj_bias: cute.Tensor,
    norm1_workspace: cute.Tensor,
    qkv_workspace: cute.Tensor,
    score_workspace: cute.Tensor,
    probability_workspace: cute.Tensor,
    context_workspace: cute.Tensor,
    residual_workspace: cute.Tensor,
    norm2_workspace: cute.Tensor,
    mlp_workspace: cute.Tensor,
    output: cute.Tensor,
):
    grid = (TOKENS, 1, 1)
    block = (THREADS, 1, 1)

    layer_norm_fp8_kernel(hidden, ln1_weight, ln1_bias, norm1_workspace).launch(grid=grid, block=block)
    qkv_projection_kernel(norm1_workspace, qkv_weight, qkv_bias, qkv_workspace).launch(
        grid=(QKV_SIZE // THREADS, TOKENS, 1), block=block
    )
    attention_fused_kernel(qkv_workspace, context_workspace).launch(grid=grid, block=block)
    attention_projection_kernel(hidden, context_workspace, out_weight, out_bias, residual_workspace).launch(
        grid=(HIDDEN_SIZE // THREADS, TOKENS, 1), block=block
    )
    layer_norm_fp32_kernel(residual_workspace, ln2_weight, ln2_bias, norm2_workspace).launch(grid=grid, block=block)
    mlp_fc_gelu_kernel(norm2_workspace, fc_weight, fc_bias, mlp_workspace).launch(
        grid=(MLP_SIZE // THREADS, TOKENS, 1), block=block
    )
    mlp_projection_kernel(residual_workspace, mlp_workspace, proj_weight, proj_bias, output).launch(
        grid=(HIDDEN_SIZE // THREADS, TOKENS, 1), block=block
    )


class ModelNew:
    forward = staticmethod(gpt2_transformer_block)
