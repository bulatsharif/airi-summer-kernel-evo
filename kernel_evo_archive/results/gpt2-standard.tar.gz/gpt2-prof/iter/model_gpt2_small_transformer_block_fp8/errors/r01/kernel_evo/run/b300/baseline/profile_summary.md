# B300 device profile of your last candidate

- device: NVIDIA B300 SXM6 AC, 148 SMs, 232448 B opt-in shared memory/block
- GPU busy: 199.750 ms total; kernels 199.719 ms over 613 launches of 42 distinct names
- memcpy: 0.029 ms over 15 calls; memset: 0.002 ms over 1 calls

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_mlp_projection_kernel_tensorptrf32gmemoi641_tensorptrf8E4M3FNgmemalign16… | 69.236 | 55 | 34.7 |
| kernel_cutlass_mlp_fc_gelu_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgm… | 62.132 | 55 | 31.1 |
| kernel_cutlass_qkv_projection_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3F… | 45.682 | 55 | 22.9 |
| kernel_cutlass_attention_projection_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf… | 17.286 | 55 | 8.7 |
| kernel_cutlass_attention_score_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gme… | 2.187 | 55 | 1.1 |
| kernel_cutlass_causal_softmax_kernel_tensorptrf32gmemoi641_tensorptrf32gmemoi641_3 | 1.489 | 55 | 0.8 |
| kernel_cutlass_attention_context_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32g… | 0.475 | 55 | 0.2 |
| kernel_cutlass_layer_norm_fp8_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmem… | 0.410 | 55 | 0.2 |
| kernel_cutlass_layer_norm_fp32_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo7681_tenso… | 0.389 | 55 | 0.2 |
| void sgemm_largek_lds64<true, false, 6, 3, 4, 5, 2, 66>(float*, float const*, float con… | 0.061 | 1 | 0.0 |
