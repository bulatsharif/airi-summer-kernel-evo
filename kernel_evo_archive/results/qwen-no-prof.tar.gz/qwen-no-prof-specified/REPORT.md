# CuTe documentation ablation

## Main results

### Iter

| Tier | Runs | Pass rate | Speed up (best raw) | Input tokens | Output tokens |
| --- | ---: | ---: | ---: | ---: | ---: |
| Error hints | 1 | 6/9 (66.7%) | 79.6621× | 14,663,824 | 132,493 |

Pass rate is over primary author calls; responses that do not produce a candidate count as failures. Best raw speedup is reference time divided by candidate time for the fastest passing mutation; it is not a stability-confirmed result.
Token columns are provider-reported totals across all runs, including repair calls.

## Stability across independent runs

| Approach | Tier | Runs | Pass rate/run (mean ± SD) | Solved runs | Best raw speedup/run (mean ± SD) |
| --- | --- | ---: | ---: | ---: | ---: |
| iter | Error hints | 1 | 66.7% ± 0.0% | 1/1 | 79.6621× ± 0.0000× |

## Cost

| Approach | Tier | Static docs¹ | Requests/attempt | Repair calls | Cap hits | Input/attempt | Cached/attempt | Output/attempt | Total/attempt |
| --- | --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| iter | errors | 33723 | 1.00 | 0 | 0 | 1629314 | 1576135 | 14721 | 1644035 |

¹ Static context is a cl100k estimate; provider usage columns are authoritative.

## Frequent failure

| Approach | Tier | Invalid attempts | No candidate | Missing jitted entry point | No remote result |
| --- | --- | ---: | ---: | ---: | ---: |
| iter | errors | 3 | 0 | 0 | 0 |

## Change from bare

| Approach | Tier | Pass change | Speedup ratio | Output change | Total change |
| --- | --- | ---: | ---: | ---: | ---: |

## By task

| Approach | Tier | Task | Attempts | Pass | Best | Geomean speedup¹ | Output/attempt |
| --- | --- | --- | ---: | ---: | ---: | ---: | ---: |
| iter | errors | model_qwen35_4b_full_attention_block_fp8 | 9 | 66.7% | 79.6621x | 79.662x | 14721 |

Runs included: 1.
