# B300 device profile of your last candidate

- device: NVIDIA B300 SXM6 AC, 148 SMs, 232448 B opt-in shared memory/block
- GPU busy: 176.901 ms total; kernels 176.866 ms over 900 launches of 57 distinct names
- memcpy: 0.031 ms over 17 calls; memset: 0.003 ms over 2 calls

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_gemm_down_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 52.395 | 55 | 29.6 |
| kernel_cutlass_gemm_out_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 23.805 | 55 | 13.5 |
| kernel_cutlass_gemm_fp8_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 20.709 | 55 | 11.7 |
| kernel_cutlass_gemm_fp8_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 20.660 | 55 | 11.7 |
| kernel_cutlass_gemm_fp8_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 20.612 | 55 | 11.7 |
| kernel_cutlass_gemm_fp8_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 14.193 | 55 | 8.0 |
| kernel_cutlass_gemm_fp8_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 14.147 | 55 | 8.0 |
| kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 4.748 | 55 | 2.7 |
| kernel_cutlass_rms_norm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo25601… | 1.679 | 55 | 0.9 |
| kernel_cutlass_post_norm_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo25601_tensorptrf… | 1.648 | 55 | 0.9 |
