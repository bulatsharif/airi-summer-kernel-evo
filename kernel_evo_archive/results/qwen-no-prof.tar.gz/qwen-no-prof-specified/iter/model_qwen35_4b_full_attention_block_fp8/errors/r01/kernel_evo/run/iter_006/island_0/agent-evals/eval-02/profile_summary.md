# B300 device profile of your last candidate

- device: NVIDIA B300 SXM6 AC, 148 SMs, 232448 B opt-in shared memory/block
- GPU busy: 568.608 ms total; kernels 568.574 ms over 900 launches of 57 distinct names
- memcpy: 0.031 ms over 17 calls; memset: 0.003 ms over 2 calls

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_gemm_down_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 180.839 | 55 | 31.8 |
| kernel_cutlass_gemm_out_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 80.503 | 55 | 14.2 |
| kernel_cutlass_gemm_fp8_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 51.205 | 55 | 9.0 |
| kernel_cutlass_gemm_fp8_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 51.163 | 55 | 9.0 |
| kernel_cutlass_gemm_fp8_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 51.015 | 55 | 9.0 |
| kernel_cutlass_gemm_fp8_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 50.866 | 55 | 8.9 |
| kernel_cutlass_gemm_fp8_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 50.863 | 55 | 8.9 |
| kernel_cutlass_swiglu_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmemali… | 33.359 | 55 | 5.9 |
| kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 14.268 | 55 | 2.5 |
| kernel_cutlass_post_norm_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo25601_tensorptrf… | 1.642 | 55 | 0.3 |
