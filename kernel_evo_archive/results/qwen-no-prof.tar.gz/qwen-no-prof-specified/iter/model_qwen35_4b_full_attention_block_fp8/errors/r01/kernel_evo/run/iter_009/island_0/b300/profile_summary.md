# B300 device profile of your last candidate

- device: NVIDIA B300 SXM6 AC, 148 SMs, 232448 B opt-in shared memory/block
- GPU busy: 34.270 ms total; kernels 34.236 ms over 900 launches of 57 distinct names
- memcpy: 0.031 ms over 17 calls; memset: 0.002 ms over 2 calls

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_fp8_gemm_kernel_TiledMMA_ThrLayoutVMNK11110000_PermutationMNK____MMAAtom… | 6.991 | 55 | 20.4 |
| kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 4.742 | 55 | 13.8 |
| kernel_cutlass_fp8_gemm_kernel_TiledMMA_ThrLayoutVMNK11110000_PermutationMNK____MMAAtom… | 3.841 | 55 | 11.2 |
| kernel_cutlass_fp8_gemm_kernel_TiledMMA_ThrLayoutVMNK11110000_PermutationMNK____MMAAtom… | 2.843 | 55 | 8.3 |
| kernel_cutlass_fp8_gemm_kernel_TiledMMA_ThrLayoutVMNK11110000_PermutationMNK____MMAAtom… | 2.732 | 55 | 8.0 |
| kernel_cutlass_fp8_gemm_kernel_TiledMMA_ThrLayoutVMNK11110000_PermutationMNK____MMAAtom… | 2.508 | 55 | 7.3 |
| kernel_cutlass_fp8_gemm_kernel_TiledMMA_ThrLayoutVMNK11110000_PermutationMNK____MMAAtom… | 2.496 | 55 | 7.3 |
| kernel_cutlass_fp8_gemm_kernel_TiledMMA_ThrLayoutVMNK11110000_PermutationMNK____MMAAtom… | 2.495 | 55 | 7.3 |
| kernel_cutlass_rms_norm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo25601… | 1.681 | 55 | 4.9 |
| kernel_cutlass_post_norm_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo25601_tensorptrf… | 1.644 | 55 | 4.8 |
