# B300 device profile of your last candidate

- device: NVIDIA B300 SXM6 AC, 148 SMs, 232448 B opt-in shared memory/block
- GPU busy: 8806.239 ms total; kernels 8806.203 ms over 900 launches of 57 distinct names
- memcpy: 0.032 ms over 17 calls; memset: 0.003 ms over 2 calls

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_proj_mlp_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 1908.499 | 55 | 21.7 |
| kernel_cutlass_proj_mlp_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 1908.490 | 55 | 21.7 |
| kernel_cutlass_down_proj_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 1760.741 | 55 | 20.0 |
| kernel_cutlass_proj_qkv_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 1696.597 | 55 | 19.3 |
| kernel_cutlass_out_proj_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 783.300 | 55 | 8.9 |
| kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 254.403 | 55 | 2.9 |
| kernel_cutlass_proj_qkv_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 213.473 | 55 | 2.4 |
| kernel_cutlass_proj_qkv_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 213.462 | 55 | 2.4 |
| kernel_cutlass_swiglu_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmemali… | 33.378 | 55 | 0.4 |
| kernel_cutlass_rms_norm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo25601… | 18.568 | 55 | 0.2 |
