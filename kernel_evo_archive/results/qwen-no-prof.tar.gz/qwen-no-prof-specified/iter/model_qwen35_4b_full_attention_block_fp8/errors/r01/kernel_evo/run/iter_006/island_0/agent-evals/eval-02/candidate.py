import cutlass
import cutlass.cute as cute


TOKENS = 128
HIDDEN_SIZE = 2560
NUM_HEADS = 16
NUM_KV_HEADS = 4
HEADS_PER_KV = NUM_HEADS // NUM_KV_HEADS
HEAD_DIM = 256
ROTARY_DIM = 64
ROTARY_HALF = ROTARY_DIM // 2
INTERMEDIATE_SIZE = 9216
Q_GATE_SIZE = 2 * NUM_HEADS * HEAD_DIM
KV_SIZE = NUM_KV_HEADS * HEAD_DIM
QUERY_SIZE = NUM_HEADS * HEAD_DIM
THREADS = 128
EPSILON = 1.0e-6

INPUT_SCALE = 1.0 / 448.0
NORM_SCALE = 1.0 / 64.0
QKV_SCALE = 1.0 / 64.0
CONTEXT_SCALE = 1.0 / 64.0
MLP_PROJECTION_SCALE = 1.0 / 64.0
MLP_ACTIVATION_SCALE = 1.0 / 32.0
WEIGHT_H_SCALE = HIDDEN_SIZE ** -0.5 / 448.0
WEIGHT_CONTEXT_SCALE = QUERY_SIZE ** -0.5 / 448.0
WEIGHT_MLP_SCALE = INTERMEDIATE_SIZE ** -0.5 / 448.0

# Combined scales that turn the raw FP8*FP8 MMA sum into the stored output.
S_QKV = NORM_SCALE * WEIGHT_H_SCALE / QKV_SCALE
S_MLP = NORM_SCALE * WEIGHT_H_SCALE / MLP_PROJECTION_SCALE
S_OUT = CONTEXT_SCALE * WEIGHT_CONTEXT_SCALE
S_DOWN = MLP_ACTIVATION_SCALE * WEIGHT_MLP_SCALE

FP8_DTYPE = cutlass.Float8E4M3FN
F32 = cutlass.Float32

# Tiled GEMM configuration.  Every projection has M = TOKENS = 128 rows.
BLOCK_N = 128          # output columns per CTA
BLOCK_K = 256          # K chunk per smem stage
RT = 4                 # register tile rows
RN = 4                 # register tile cols
GEMM_THREADS = (TOKENS // RT) * (BLOCK_N // RN)  # 32*32 = 1024
UNROLL_K = 32          # inner K unroll


@cute.kernel
def rms_norm_kernel(hidden: cute.Tensor, weight: cute.Tensor, output: cute.Tensor):
    t, _, _ = cute.arch.block_idx()
    th, _, _ = cute.arch.thread_idx()
    s = cutlass.Float32(0.0)
    for i in cutlass.range_constexpr(HIDDEN_SIZE // 32):
        x = hidden[t, i * 32 + th].to(cutlass.Float32) * INPUT_SCALE
        s = s + x * x
    s = s + cute.arch.shuffle_sync_bfly(s, 16)
    s = s + cute.arch.shuffle_sync_bfly(s, 8)
    s = s + cute.arch.shuffle_sync_bfly(s, 4)
    s = s + cute.arch.shuffle_sync_bfly(s, 2)
    s = s + cute.arch.shuffle_sync_bfly(s, 1)
    inv = cute.rsqrt(s / HIDDEN_SIZE + EPSILON)
    for i in cutlass.range_constexpr(HIDDEN_SIZE // 32):
        idx = i * 32 + th
        x = hidden[t, idx].to(cutlass.Float32) * INPUT_SCALE
        n = x * inv * (1.0 + weight[idx].to(cutlass.Float32))
        output[t, idx] = cutlass.Float8E4M3FN(n / NORM_SCALE)


@cute.kernel
def gemm_fp8_kernel(
    a_tensor: cute.Tensor,          # [TOKENS, K] FP8
    b_tensor: cute.Tensor,          # [N, K] FP8
    c_tensor: cute.Tensor,          # [TOKENS, N] FP8 out
    out_scale: cutlass.Constexpr,   # acc multiplier
    k_blocks: cutlass.Constexpr,    # K / BLOCK_K
):
    n_block, _, _ = cute.arch.block_idx()
    tid, _, _ = cute.arch.thread_idx()
    tx = tid % (TOKENS // RT)
    ty = tid // (TOKENS // RT)
    n_base = n_block * BLOCK_N

    smem_a = cute.arch.alloc_smem(FP8_DTYPE, TOKENS * BLOCK_K, alignment=128)
    smem_b = cute.arch.alloc_smem(FP8_DTYPE, BLOCK_N * BLOCK_K, alignment=128)
    a_s = cute.make_tensor(smem_a, cute.make_layout((TOKENS, BLOCK_K)))
    b_s = cute.make_tensor(smem_b, cute.make_layout((BLOCK_N, BLOCK_K)))

    acc = cute.make_rmem_tensor((RT, RN), cutlass.Float32)
    for r in cutlass.range_constexpr(RT):
        for n in cutlass.range_constexpr(RN):
            acc[r, n] = cutlass.Float32(0.0)

    for kb in cutlass.range(k_blocks):
        k_base = kb * BLOCK_K
        for i in cutlass.range_constexpr((TOKENS * BLOCK_K) // GEMM_THREADS):
            idx = i * GEMM_THREADS + tid
            a_s[idx // BLOCK_K, idx % BLOCK_K] = a_tensor[
                idx // BLOCK_K, k_base + idx % BLOCK_K
            ]
        for i in cutlass.range_constexpr((BLOCK_N * BLOCK_K) // GEMM_THREADS):
            idx = i * GEMM_THREADS + tid
            b_s[idx // BLOCK_K, idx % BLOCK_K] = b_tensor[
                n_base + idx // BLOCK_K, k_base + idx % BLOCK_K
            ]
        cute.arch.sync_threads()

        for kb_in in cutlass.range(BLOCK_K // UNROLL_K):
            for kk in cutlass.range_constexpr(UNROLL_K):
                for r in cutlass.range_constexpr(RT):
                    a_r = a_s[tx * RT + r, kb_in * UNROLL_K + kk].to(cutlass.Float32)
                    for n in cutlass.range_constexpr(RN):
                        acc[r, n] = acc[r, n] + a_r * b_s[
                            ty * RN + n, kb_in * UNROLL_K + kk
                        ].to(cutlass.Float32)
        cute.arch.sync_threads()

    for r in cutlass.range_constexpr(RT):
        for n in cutlass.range_constexpr(RN):
            c_tensor[tx * RT + r, n_base + ty * RN + n] = cutlass.Float8E4M3FN(
                acc[r, n] * out_scale
            )


@cute.kernel
def gemm_out_kernel(
    ctx: cute.Tensor,               # [TOKENS, QUERY_SIZE] FP8
    weight: cute.Tensor,            # [HIDDEN_SIZE, QUERY_SIZE] FP8
    hidden: cute.Tensor,            # [TOKENS, HIDDEN_SIZE] FP8
    residual: cute.Tensor,          # [TOKENS, HIDDEN_SIZE] FP32 out
    k_blocks: cutlass.Constexpr,
):
    n_block, _, _ = cute.arch.block_idx()
    tid, _, _ = cute.arch.thread_idx()
    tx = tid % (TOKENS // RT)
    ty = tid // (TOKENS // RT)
    n_base = n_block * BLOCK_N

    smem_a = cute.arch.alloc_smem(FP8_DTYPE, TOKENS * BLOCK_K, alignment=128)
    smem_b = cute.arch.alloc_smem(FP8_DTYPE, BLOCK_N * BLOCK_K, alignment=128)
    a_s = cute.make_tensor(smem_a, cute.make_layout((TOKENS, BLOCK_K)))
    b_s = cute.make_tensor(smem_b, cute.make_layout((BLOCK_N, BLOCK_K)))

    acc = cute.make_rmem_tensor((RT, RN), cutlass.Float32)
    for r in cutlass.range_constexpr(RT):
        for n in cutlass.range_constexpr(RN):
            acc[r, n] = cutlass.Float32(0.0)

    for kb in cutlass.range(k_blocks):
        k_base = kb * BLOCK_K
        for i in cutlass.range_constexpr((TOKENS * BLOCK_K) // GEMM_THREADS):
            idx = i * GEMM_THREADS + tid
            a_s[idx // BLOCK_K, idx % BLOCK_K] = ctx[
                idx // BLOCK_K, k_base + idx % BLOCK_K
            ]
        for i in cutlass.range_constexpr((BLOCK_N * BLOCK_K) // GEMM_THREADS):
            idx = i * GEMM_THREADS + tid
            b_s[idx // BLOCK_K, idx % BLOCK_K] = weight[
                n_base + idx // BLOCK_K, k_base + idx % BLOCK_K
            ]
        cute.arch.sync_threads()

        for kb_in in cutlass.range(BLOCK_K // UNROLL_K):
            for kk in cutlass.range_constexpr(UNROLL_K):
                for r in cutlass.range_constexpr(RT):
                    a_r = a_s[tx * RT + r, kb_in * UNROLL_K + kk].to(cutlass.Float32)
                    for n in cutlass.range_constexpr(RN):
                        acc[r, n] = acc[r, n] + a_r * b_s[
                            ty * RN + n, kb_in * UNROLL_K + kk
                        ].to(cutlass.Float32)
        cute.arch.sync_threads()

    for r in cutlass.range_constexpr(RT):
        for n in cutlass.range_constexpr(RN):
            residual[tx * RT + r, n_base + ty * RN + n] = (
                hidden[tx * RT + r, n_base + ty * RN + n].to(cutlass.Float32)
                * INPUT_SCALE
                + acc[r, n] * S_OUT
            )


@cute.kernel
def gemm_down_kernel(
    mlp: cute.Tensor,               # [TOKENS, INTERMEDIATE_SIZE] FP8
    weight: cute.Tensor,            # [HIDDEN_SIZE, INTERMEDIATE_SIZE] FP8
    residual: cute.Tensor,          # [TOKENS, HIDDEN_SIZE] FP32
    output: cute.Tensor,            # [TOKENS, HIDDEN_SIZE] FP32 out
    k_blocks: cutlass.Constexpr,
):
    n_block, _, _ = cute.arch.block_idx()
    tid, _, _ = cute.arch.thread_idx()
    tx = tid % (TOKENS // RT)
    ty = tid // (TOKENS // RT)
    n_base = n_block * BLOCK_N

    smem_a = cute.arch.alloc_smem(FP8_DTYPE, TOKENS * BLOCK_K, alignment=128)
    smem_b = cute.arch.alloc_smem(FP8_DTYPE, BLOCK_N * BLOCK_K, alignment=128)
    a_s = cute.make_tensor(smem_a, cute.make_layout((TOKENS, BLOCK_K)))
    b_s = cute.make_tensor(smem_b, cute.make_layout((BLOCK_N, BLOCK_K)))

    acc = cute.make_rmem_tensor((RT, RN), cutlass.Float32)
    for r in cutlass.range_constexpr(RT):
        for n in cutlass.range_constexpr(RN):
            acc[r, n] = cutlass.Float32(0.0)

    for kb in cutlass.range(k_blocks):
        k_base = kb * BLOCK_K
        for i in cutlass.range_constexpr((TOKENS * BLOCK_K) // GEMM_THREADS):
            idx = i * GEMM_THREADS + tid
            a_s[idx // BLOCK_K, idx % BLOCK_K] = mlp[
                idx // BLOCK_K, k_base + idx % BLOCK_K
            ]
        for i in cutlass.range_constexpr((BLOCK_N * BLOCK_K) // GEMM_THREADS):
            idx = i * GEMM_THREADS + tid
            b_s[idx // BLOCK_K, idx % BLOCK_K] = weight[
                n_base + idx // BLOCK_K, k_base + idx % BLOCK_K
            ]
        cute.arch.sync_threads()

        for kb_in in cutlass.range(BLOCK_K // UNROLL_K):
            for kk in cutlass.range_constexpr(UNROLL_K):
                for r in cutlass.range_constexpr(RT):
                    a_r = a_s[tx * RT + r, kb_in * UNROLL_K + kk].to(cutlass.Float32)
                    for n in cutlass.range_constexpr(RN):
                        acc[r, n] = acc[r, n] + a_r * b_s[
                            ty * RN + n, kb_in * UNROLL_K + kk
                        ].to(cutlass.Float32)
        cute.arch.sync_threads()

    for r in cutlass.range_constexpr(RT):
        for n in cutlass.range_constexpr(RN):
            output[tx * RT + r, n_base + ty * RN + n] = (
                residual[tx * RT + r, n_base + ty * RN + n].to(cutlass.Float32)
                + acc[r, n] * S_DOWN
            )


@cute.kernel
def q_headnorm_kernel(
    q_gate: cute.Tensor,
    q_norm_weight: cute.Tensor,
    cos: cute.Tensor,
    sin: cute.Tensor,
    query_out: cute.Tensor,
):
    # grid = (NUM_HEADS, TOKENS); warp per (head, token)
    h, t, _ = cute.arch.block_idx()
    th, _, _ = cute.arch.thread_idx()
    s = cutlass.Float32(0.0)
    for i in cutlass.range_constexpr(HEAD_DIM // 32):
        d = i * 32 + th
        x = q_gate[t, h * 512 + d].to(cutlass.Float32) * QKV_SCALE
        s = s + x * x
    s = s + cute.arch.shuffle_sync_bfly(s, 16)
    s = s + cute.arch.shuffle_sync_bfly(s, 8)
    s = s + cute.arch.shuffle_sync_bfly(s, 4)
    s = s + cute.arch.shuffle_sync_bfly(s, 2)
    s = s + cute.arch.shuffle_sync_bfly(s, 1)
    inv = cute.rsqrt(s / HEAD_DIM + EPSILON)
    for i in cutlass.range_constexpr(HEAD_DIM // 32):
        d = i * 32 + th
        x = q_gate[t, h * 512 + d].to(cutlass.Float32) * QKV_SCALE
        n = x * inv * (1.0 + q_norm_weight[d].to(cutlass.Float32))
        out_v = n
        if d < ROTARY_HALF:
            x2 = q_gate[t, h * 512 + (d + ROTARY_HALF)].to(cutlass.Float32) * QKV_SCALE
            n2 = x2 * inv * (1.0 + q_norm_weight[d + ROTARY_HALF].to(cutlass.Float32))
            c = cos[t, d].to(cutlass.Float32)
            si = sin[t, d].to(cutlass.Float32)
            out_v = n * c - n2 * si
        elif d < ROTARY_DIM:
            c = cos[t, d - ROTARY_HALF].to(cutlass.Float32)
            si = sin[t, d - ROTARY_HALF].to(cutlass.Float32)
            xp = q_gate[t, h * 512 + (d - ROTARY_HALF)].to(cutlass.Float32) * QKV_SCALE
            np = xp * inv * (1.0 + q_norm_weight[d - ROTARY_HALF].to(cutlass.Float32))
            out_v = n * c + np * si
        query_out[t, h * HEAD_DIM + d] = cutlass.Float8E4M3FN(out_v / QKV_SCALE)


@cute.kernel
def k_headnorm_kernel(
    k_in: cute.Tensor,
    k_norm_weight: cute.Tensor,
    cos: cute.Tensor,
    sin: cute.Tensor,
    key_out: cute.Tensor,
):
    # grid = (NUM_KV_HEADS, TOKENS); warp per (head, token)
    h, t, _ = cute.arch.block_idx()
    th, _, _ = cute.arch.thread_idx()
    s = cutlass.Float32(0.0)
    for i in cutlass.range_constexpr(HEAD_DIM // 32):
        d = i * 32 + th
        x = k_in[t, h * HEAD_DIM + d].to(cutlass.Float32) * QKV_SCALE
        s = s + x * x
    s = s + cute.arch.shuffle_sync_bfly(s, 16)
    s = s + cute.arch.shuffle_sync_bfly(s, 8)
    s = s + cute.arch.shuffle_sync_bfly(s, 4)
    s = s + cute.arch.shuffle_sync_bfly(s, 2)
    s = s + cute.arch.shuffle_sync_bfly(s, 1)
    inv = cute.rsqrt(s / HEAD_DIM + EPSILON)
    for i in cutlass.range_constexpr(HEAD_DIM // 32):
        d = i * 32 + th
        x = k_in[t, h * HEAD_DIM + d].to(cutlass.Float32) * QKV_SCALE
        n = x * inv * (1.0 + k_norm_weight[d].to(cutlass.Float32))
        out_v = n
        if d < ROTARY_HALF:
            x2 = k_in[t, h * HEAD_DIM + (d + ROTARY_HALF)].to(cutlass.Float32) * QKV_SCALE
            n2 = x2 * inv * (1.0 + k_norm_weight[d + ROTARY_HALF].to(cutlass.Float32))
            c = cos[t, d].to(cutlass.Float32)
            si = sin[t, d].to(cutlass.Float32)
            out_v = n * c - n2 * si
        elif d < ROTARY_DIM:
            c = cos[t, d - ROTARY_HALF].to(cutlass.Float32)
            si = sin[t, d - ROTARY_HALF].to(cutlass.Float32)
            xp = k_in[t, h * HEAD_DIM + (d - ROTARY_HALF)].to(cutlass.Float32) * QKV_SCALE
            np = xp * inv * (1.0 + k_norm_weight[d - ROTARY_HALF].to(cutlass.Float32))
            out_v = n * c + np * si
        key_out[t, h * HEAD_DIM + d] = cutlass.Float8E4M3FN(out_v / QKV_SCALE)


@cute.kernel
def attention_kernel(
    query: cute.Tensor,
    key: cute.Tensor,
    v: cute.Tensor,
    q_gate: cute.Tensor,
    score_ws: cute.Tensor,
    prob_ws: cute.Tensor,
    context_out: cute.Tensor,
):
    # grid = (NUM_HEADS, TOKENS); warp per (query head, token)
    qh, t, _ = cute.arch.block_idx()
    th, _, _ = cute.arch.thread_idx()
    kv = qh // HEADS_PER_KV
    q_base = qh * HEAD_DIM
    kv_base = kv * HEAD_DIM
    qg_base = qh * 2 * HEAD_DIM

    # Pass 1: raw scores to workspace, running max/sum for causal softmax.
    max_s = cutlass.Float32(-1.0e30)
    sum_e = cutlass.Float32(0.0)
    for s in cutlass.range(TOKENS):
        if s <= t:
            part = cutlass.Float32(0.0)
            for i in cutlass.range_constexpr(HEAD_DIM // 32):
                d = i * 32 + th
                qr = query[t, q_base + d].to(cutlass.Float32) * QKV_SCALE
                kr = key[s, kv_base + d].to(cutlass.Float32) * QKV_SCALE
                part = part + qr * kr
            part = part + cute.arch.shuffle_sync_bfly(part, 16)
            part = part + cute.arch.shuffle_sync_bfly(part, 8)
            part = part + cute.arch.shuffle_sync_bfly(part, 4)
            part = part + cute.arch.shuffle_sync_bfly(part, 2)
            part = part + cute.arch.shuffle_sync_bfly(part, 1)
            score = part / 16.0
            score_ws[t, qh * TOKENS + s] = score
            new_max = max_s
            if score > max_s:
                new_max = score
            sum_e = sum_e * cute.exp(max_s - new_max) + cute.exp(score - new_max)
            max_s = new_max

    # Pass 2: probabilities + context over the dims this lane owns, gate.
    for i in cutlass.range_constexpr(HEAD_DIM // 32):
        d = i * 32 + th
        ctx = cutlass.Float32(0.0)
        for s in cutlass.range(TOKENS):
            if s <= t:
                sc = score_ws[t, qh * TOKENS + s].to(cutlass.Float32)
                p = cute.exp(sc - max_s) / sum_e
                vr = v[s, kv_base + d].to(cutlass.Float32) * QKV_SCALE
                ctx = ctx + p * vr
        gr = q_gate[t, qg_base + HEAD_DIM + d].to(cutlass.Float32) * QKV_SCALE
        sig = 1.0 / (1.0 + cute.exp(-gr))
        context_out[t, q_base + d] = cutlass.Float8E4M3FN(ctx * sig / CONTEXT_SCALE)


@cute.kernel
def post_norm_kernel(residual: cute.Tensor, weight: cute.Tensor, output: cute.Tensor):
    t, _, _ = cute.arch.block_idx()
    th, _, _ = cute.arch.thread_idx()
    s = cutlass.Float32(0.0)
    for i in cutlass.range_constexpr(HIDDEN_SIZE // 32):
        x = residual[t, i * 32 + th].to(cutlass.Float32)
        s = s + x * x
    s = s + cute.arch.shuffle_sync_bfly(s, 16)
    s = s + cute.arch.shuffle_sync_bfly(s, 8)
    s = s + cute.arch.shuffle_sync_bfly(s, 4)
    s = s + cute.arch.shuffle_sync_bfly(s, 2)
    s = s + cute.arch.shuffle_sync_bfly(s, 1)
    inv = cute.rsqrt(s / HIDDEN_SIZE + EPSILON)
    for i in cutlass.range_constexpr(HIDDEN_SIZE // 32):
        idx = i * 32 + th
        x = residual[t, idx].to(cutlass.Float32)
        n = x * inv * (1.0 + weight[idx].to(cutlass.Float32))
        output[t, idx] = cutlass.Float8E4M3FN(n / NORM_SCALE)


@cute.kernel
def swiglu_kernel(gate: cute.Tensor, up: cute.Tensor, mlp_out: cute.Tensor):
    # grid = (INTERMEDIATE_SIZE, TOKENS)
    j, t, _ = cute.arch.block_idx()
    g = gate[t, j].to(cutlass.Float32) * MLP_PROJECTION_SCALE
    u = up[t, j].to(cutlass.Float32) * MLP_PROJECTION_SCALE
    silu = g / (1.0 + cute.exp(-g))
    mlp_out[t, j] = cutlass.Float8E4M3FN(silu * u / MLP_ACTIVATION_SCALE)


@cute.jit
def qwen35_full_attention_block(
    hidden: cute.Tensor,
    input_norm_weight: cute.Tensor,
    q_norm_weight: cute.Tensor,
    k_norm_weight: cute.Tensor,
    q_gate_weight: cute.Tensor,
    k_weight: cute.Tensor,
    v_weight: cute.Tensor,
    out_weight: cute.Tensor,
    post_norm_weight: cute.Tensor,
    gate_weight: cute.Tensor,
    up_weight: cute.Tensor,
    down_weight: cute.Tensor,
    cos: cute.Tensor,
    sin: cute.Tensor,
    norm1_workspace: cute.Tensor,
    q_gate_workspace: cute.Tensor,
    k_workspace: cute.Tensor,
    v_workspace: cute.Tensor,
    query_workspace: cute.Tensor,
    key_workspace: cute.Tensor,
    score_workspace: cute.Tensor,
    probability_workspace: cute.Tensor,
    context_workspace: cute.Tensor,
    residual_workspace: cute.Tensor,
    norm2_workspace: cute.Tensor,
    gate_workspace: cute.Tensor,
    up_workspace: cute.Tensor,
    mlp_workspace: cute.Tensor,
    output: cute.Tensor,
):
    rms_norm_kernel(hidden, input_norm_weight, norm1_workspace).launch(
        grid=(TOKENS, 1, 1), block=(32, 1, 1)
    )
    gemm_fp8_kernel(
        norm1_workspace, q_gate_weight, q_gate_workspace, S_QKV,
        HIDDEN_SIZE // BLOCK_K,
    ).launch(grid=(Q_GATE_SIZE // BLOCK_N, 1, 1), block=(GEMM_THREADS, 1, 1))
    gemm_fp8_kernel(
        norm1_workspace, k_weight, k_workspace, S_QKV, HIDDEN_SIZE // BLOCK_K
    ).launch(grid=(KV_SIZE // BLOCK_N, 1, 1), block=(GEMM_THREADS, 1, 1))
    gemm_fp8_kernel(
        norm1_workspace, v_weight, v_workspace, S_QKV, HIDDEN_SIZE // BLOCK_K
    ).launch(grid=(KV_SIZE // BLOCK_N, 1, 1), block=(GEMM_THREADS, 1, 1))
    q_headnorm_kernel(
        q_gate_workspace, q_norm_weight, cos, sin, query_workspace
    ).launch(grid=(NUM_HEADS, TOKENS, 1), block=(32, 1, 1))
    k_headnorm_kernel(
        k_workspace, k_norm_weight, cos, sin, key_workspace
    ).launch(grid=(NUM_KV_HEADS, TOKENS, 1), block=(32, 1, 1))
    attention_kernel(
        query_workspace, key_workspace, v_workspace, q_gate_workspace,
        score_workspace, probability_workspace, context_workspace,
    ).launch(grid=(NUM_HEADS, TOKENS, 1), block=(32, 1, 1))
    gemm_out_kernel(
        context_workspace, out_weight, hidden, residual_workspace,
        QUERY_SIZE // BLOCK_K,
    ).launch(grid=(HIDDEN_SIZE // BLOCK_N, 1, 1), block=(GEMM_THREADS, 1, 1))
    post_norm_kernel(residual_workspace, post_norm_weight, norm2_workspace).launch(
        grid=(TOKENS, 1, 1), block=(32, 1, 1)
    )
    gemm_fp8_kernel(
        norm2_workspace, gate_weight, gate_workspace, S_MLP, HIDDEN_SIZE // BLOCK_K
    ).launch(grid=(INTERMEDIATE_SIZE // BLOCK_N, 1, 1), block=(GEMM_THREADS, 1, 1))
    gemm_fp8_kernel(
        norm2_workspace, up_weight, up_workspace, S_MLP, HIDDEN_SIZE // BLOCK_K
    ).launch(grid=(INTERMEDIATE_SIZE // BLOCK_N, 1, 1), block=(GEMM_THREADS, 1, 1))
    swiglu_kernel(gate_workspace, up_workspace, mlp_workspace).launch(
        grid=(INTERMEDIATE_SIZE, TOKENS, 1), block=(1, 1, 1)
    )
    gemm_down_kernel(
        mlp_workspace, down_weight, residual_workspace, output,
        INTERMEDIATE_SIZE // BLOCK_K,
    ).launch(grid=(HIDDEN_SIZE // BLOCK_N, 1, 1), block=(GEMM_THREADS, 1, 1))


class ModelNew:
    forward = staticmethod(qwen35_full_attention_block)
