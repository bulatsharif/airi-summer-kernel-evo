import cutlass
import cutlass.cute as cute


TOKENS = 128
HIDDEN_SIZE = 2560
NUM_HEADS = 16
NUM_KV_HEADS = 4
HEAD_DIM = 256
ROTARY_DIM = 64
ROTARY_HALF = ROTARY_DIM // 2
INTERMEDIATE_SIZE = 9216
Q_GATE_SIZE = 2 * NUM_HEADS * HEAD_DIM
KV_SIZE = NUM_KV_HEADS * HEAD_DIM
QUERY_SIZE = NUM_HEADS * HEAD_DIM
EPSILON = 1.0e-6

INPUT_SCALE = 1.0 / 448.0
NORM_SCALE = 1.0 / 64.0
QKV_SCALE = 1.0 / 64.0
CONTEXT_SCALE = 1.0 / 64.0
MLP_PROJECTION_SCALE = 1.0 / 64.0
MLP_ACTIVATION_SCALE = 1.0 / 32.0
WEIGHT_H_SCALE = HIDDEN_SIZE ** -0.5 / 448.0
WEIGHT_CONTEXT_SCALE = QUERY_SIZE ** -0.5 / 448.0
WEIGHT_MLP_SCALE = INTERMEDIATE_SIZE ** -0.5 / 448.0
FP8_DTYPE = cutlass.Float8E4M3FN

F32 = cutlass.Float32


@cute.kernel
def rms_norm_kernel(hidden: cute.Tensor, weight: cute.Tensor, output: cute.Tensor):
    bx, t, bz = cute.arch.block_idx()
    j = bx
    _ = cute.arch.thread_idx()  # required by harness
    acc = 0.0
    for i in range(HIDDEN_SIZE):
        x = hidden[t, i].to(F32) * INPUT_SCALE
        acc += x * x
    rms = (acc / HIDDEN_SIZE + EPSILON) ** 0.5
    x0 = hidden[t, j].to(F32) * INPUT_SCALE
    val = (x0 / rms) * (1.0 + weight[j].to(F32))
    output[t, j] = FP8_DTYPE(val / NORM_SCALE)


@cute.kernel
def qkv_proj_kernel(input: cute.Tensor, w: cute.Tensor, output: cute.Tensor):
    bx, t, bz = cute.arch.block_idx()
    j = bx
    acc = 0.0
    for i in range(HIDDEN_SIZE):
        a = input[t, i].to(F32) * NORM_SCALE
        b = w[j, i].to(F32) * WEIGHT_H_SCALE
        acc += a * b
    output[t, j] = FP8_DTYPE(acc / QKV_SCALE)


@cute.kernel
def q_headnorm_kernel(
    q_gate: cute.Tensor,
    weight: cute.Tensor,
    cos: cute.Tensor,
    sin: cute.Tensor,
    query_out: cute.Tensor,
):
    bx, t, bz = cute.arch.block_idx()
    x = bx
    qh = x // HEAD_DIM
    d = x % HEAD_DIM
    base = qh * (2 * HEAD_DIM)
    acc = 0.0
    for e in range(HEAD_DIM):
        qv = q_gate[t, base + e].to(F32) * QKV_SCALE
        acc += qv * qv
    rms = (acc / HEAD_DIM + EPSILON) ** 0.5
    qv = q_gate[t, base + d].to(F32) * QKV_SCALE
    qn = (qv / rms) * (1.0 + weight[d].to(F32))
    d32 = d % ROTARY_HALF
    if d < ROTARY_HALF:
        qp = q_gate[t, base + d + ROTARY_HALF].to(F32) * QKV_SCALE
        qnp = (qp / rms) * (1.0 + weight[d + ROTARY_HALF].to(F32))
        out_v = qn * cos[t, d32] - qnp * sin[t, d32]
    elif d < ROTARY_DIM:
        qp = q_gate[t, base + d - ROTARY_HALF].to(F32) * QKV_SCALE
        qnp = (qp / rms) * (1.0 + weight[d - ROTARY_HALF].to(F32))
        out_v = qn * cos[t, d32] + qnp * sin[t, d32]
    else:
        out_v = qn
    query_out[t, qh * HEAD_DIM + d] = FP8_DTYPE(out_v / QKV_SCALE)


@cute.kernel
def k_headnorm_kernel(
    k_ws: cute.Tensor,
    weight: cute.Tensor,
    cos: cute.Tensor,
    sin: cute.Tensor,
    key_out: cute.Tensor,
):
    bx, t, bz = cute.arch.block_idx()
    x = bx
    kv = x // HEAD_DIM
    d = x % HEAD_DIM
    base = kv * HEAD_DIM
    acc = 0.0
    for e in range(HEAD_DIM):
        kv_e = k_ws[t, base + e].to(F32) * QKV_SCALE
        acc += kv_e * kv_e
    rms = (acc / HEAD_DIM + EPSILON) ** 0.5
    kv_d = k_ws[t, base + d].to(F32) * QKV_SCALE
    kn = (kv_d / rms) * (1.0 + weight[d].to(F32))
    d32 = d % ROTARY_HALF
    if d < ROTARY_HALF:
        kp = k_ws[t, base + d + ROTARY_HALF].to(F32) * QKV_SCALE
        knp = (kp / rms) * (1.0 + weight[d + ROTARY_HALF].to(F32))
        out_v = kn * cos[t, d32] - knp * sin[t, d32]
    elif d < ROTARY_DIM:
        kp = k_ws[t, base + d - ROTARY_HALF].to(F32) * QKV_SCALE
        knp = (kp / rms) * (1.0 + weight[d - ROTARY_HALF].to(F32))
        out_v = kn * cos[t, d32] + knp * sin[t, d32]
    else:
        out_v = kn
    key_out[t, base + d] = FP8_DTYPE(out_v / QKV_SCALE)


@cute.kernel
def attention_kernel(
    query_ws: cute.Tensor,
    key_ws: cute.Tensor,
    v_ws: cute.Tensor,
    q_gate: cute.Tensor,
    context_out: cute.Tensor,
):
    bx, t, bz = cute.arch.block_idx()
    x = bx
    qh = x // HEAD_DIM
    d = x % HEAD_DIM
    kv = qh // NUM_KV_HEADS
    kv_base = kv * HEAD_DIM
    q_base = qh * HEAD_DIM
    running_max = -1.0e30
    sum_e = 0.0
    ctx = 0.0
    for s in range(TOKENS):
        if s <= t:
            sc = 0.0
            for e in range(HEAD_DIM):
                qe = query_ws[t, q_base + e].to(F32) * QKV_SCALE
                ke = key_ws[s, kv_base + e].to(F32) * QKV_SCALE
                sc += qe * ke
            sc = sc / 16.0
            new_max = running_max if running_max >= sc else sc
            rescale = cute.exp(running_max - new_max)
            w = cute.exp(sc - new_max)
            sum_e = sum_e * rescale + w
            ve = v_ws[s, kv_base + d].to(F32) * QKV_SCALE
            ctx = ctx * rescale + ve * w
            running_max = new_max
    ctx_val = ctx / sum_e
    gv = q_gate[t, qh * (2 * HEAD_DIM) + HEAD_DIM + d].to(F32) * QKV_SCALE
    sg = 1.0 / (1.0 + cute.exp(-gv))
    out = ctx_val * sg
    context_out[t, q_base + d] = FP8_DTYPE(out / CONTEXT_SCALE)


@cute.kernel
def out_proj_kernel(
    input: cute.Tensor,
    w: cute.Tensor,
    hidden: cute.Tensor,
    output: cute.Tensor,
):
    bx, t, bz = cute.arch.block_idx()
    j = bx
    acc = 0.0
    for i in range(QUERY_SIZE):
        a = input[t, i].to(F32) * CONTEXT_SCALE
        b = w[j, i].to(F32) * WEIGHT_CONTEXT_SCALE
        acc += a * b
    output[t, j] = hidden[t, j].to(F32) * INPUT_SCALE + acc


@cute.kernel
def post_norm_kernel(input: cute.Tensor, weight: cute.Tensor, output: cute.Tensor):
    bx, t, bz = cute.arch.block_idx()
    j = bx
    acc = 0.0
    for i in range(HIDDEN_SIZE):
        x = input[t, i].to(F32)
        acc += x * x
    rms = (acc / HIDDEN_SIZE + EPSILON) ** 0.5
    x0 = input[t, j].to(F32)
    val = (x0 / rms) * (1.0 + weight[j].to(F32))
    output[t, j] = FP8_DTYPE(val / NORM_SCALE)


@cute.kernel
def mlp_proj_kernel(input: cute.Tensor, w: cute.Tensor, output: cute.Tensor):
    bx, t, bz = cute.arch.block_idx()
    j = bx
    acc = 0.0
    for i in range(HIDDEN_SIZE):
        a = input[t, i].to(F32) * NORM_SCALE
        b = w[j, i].to(F32) * WEIGHT_MLP_SCALE
        acc += a * b
    output[t, j] = FP8_DTYPE(acc / MLP_PROJECTION_SCALE)


@cute.kernel
def swiglu_kernel(gate: cute.Tensor, up: cute.Tensor, output: cute.Tensor):
    bx, t, bz = cute.arch.block_idx()
    j = bx
    gv = gate[t, j].to(F32) * MLP_PROJECTION_SCALE
    uv = up[t, j].to(F32) * MLP_PROJECTION_SCALE
    sil = gv / (1.0 + cute.exp(-gv))
    output[t, j] = FP8_DTYPE((sil * uv) / MLP_ACTIVATION_SCALE)


@cute.kernel
def down_proj_kernel(
    input: cute.Tensor,
    w: cute.Tensor,
    residual: cute.Tensor,
    output: cute.Tensor,
):
    bx, t, bz = cute.arch.block_idx()
    j = bx
    acc = 0.0
    for i in range(INTERMEDIATE_SIZE):
        a = input[t, i].to(F32) * MLP_ACTIVATION_SCALE
        b = w[j, i].to(F32) * WEIGHT_MLP_SCALE
        acc += a * b
    output[t, j] = residual[t, j].to(F32) + acc


@cute.jit
def qwen35_full_attention_block(
    hidden: cute.Tensor,
    input_norm_weight: cute.Tensor,
    q_norm_weight: cute.Tensor,
    k_norm_weight: cute.Tensor,
    q_gate_weight: cute.Tensor,
    k_weight: cute.Tensor,
    v_weight: cute.Tensor,
    out_weight: cute.Tensor,
    post_norm_weight: cute.Tensor,
    gate_weight: cute.Tensor,
    up_weight: cute.Tensor,
    down_weight: cute.Tensor,
    cos: cute.Tensor,
    sin: cute.Tensor,
    norm1_workspace: cute.Tensor,
    q_gate_workspace: cute.Tensor,
    k_workspace: cute.Tensor,
    v_workspace: cute.Tensor,
    query_workspace: cute.Tensor,
    key_workspace: cute.Tensor,
    score_workspace: cute.Tensor,
    probability_workspace: cute.Tensor,
    context_workspace: cute.Tensor,
    residual_workspace: cute.Tensor,
    norm2_workspace: cute.Tensor,
    gate_workspace: cute.Tensor,
    up_workspace: cute.Tensor,
    mlp_workspace: cute.Tensor,
    output: cute.Tensor,
):
    rms_norm_kernel(
        hidden=hidden, weight=input_norm_weight, output=norm1_workspace,
    ).launch(grid=(HIDDEN_SIZE, TOKENS), block=(1, 1, 1))
    qkv_proj_kernel(
        input=norm1_workspace, w=q_gate_weight, output=q_gate_workspace,
    ).launch(grid=(Q_GATE_SIZE, TOKENS), block=(1, 1, 1))
    qkv_proj_kernel(
        input=norm1_workspace, w=k_weight, output=k_workspace,
    ).launch(grid=(KV_SIZE, TOKENS), block=(1, 1, 1))
    qkv_proj_kernel(
        input=norm1_workspace, w=v_weight, output=v_workspace,
    ).launch(grid=(KV_SIZE, TOKENS), block=(1, 1, 1))
    q_headnorm_kernel(
        q_gate=q_gate_workspace, weight=q_norm_weight, cos=cos, sin=sin,
        query_out=query_workspace,
    ).launch(grid=(QUERY_SIZE, TOKENS), block=(1, 1, 1))
    k_headnorm_kernel(
        k_ws=k_workspace, weight=k_norm_weight, cos=cos, sin=sin,
        key_out=key_workspace,
    ).launch(grid=(KV_SIZE, TOKENS), block=(1, 1, 1))
    attention_kernel(
        query_ws=query_workspace, key_ws=key_workspace, v_ws=v_workspace,
        q_gate=q_gate_workspace, context_out=context_workspace,
    ).launch(grid=(QUERY_SIZE, TOKENS), block=(1, 1, 1))
    out_proj_kernel(
        input=context_workspace, w=out_weight, hidden=hidden,
        output=residual_workspace,
    ).launch(grid=(HIDDEN_SIZE, TOKENS), block=(1, 1, 1))
    post_norm_kernel(
        input=residual_workspace, weight=post_norm_weight, output=norm2_workspace,
    ).launch(grid=(HIDDEN_SIZE, TOKENS), block=(1, 1, 1))
    mlp_proj_kernel(
        input=norm2_workspace, w=gate_weight, output=gate_workspace,
    ).launch(grid=(INTERMEDIATE_SIZE, TOKENS), block=(1, 1, 1))
    mlp_proj_kernel(
        input=norm2_workspace, w=up_weight, output=up_workspace,
    ).launch(grid=(INTERMEDIATE_SIZE, TOKENS), block=(1, 1, 1))
    swiglu_kernel(
        gate=gate_workspace, up=up_workspace, output=mlp_workspace,
    ).launch(grid=(INTERMEDIATE_SIZE, TOKENS), block=(1, 1, 1))
    down_proj_kernel(
        input=mlp_workspace, w=down_weight, residual=residual_workspace,
        output=output,
    ).launch(grid=(HIDDEN_SIZE, TOKENS), block=(1, 1, 1))


class ModelNew:
    forward = staticmethod(qwen35_full_attention_block)
