# B300 device profile of your last candidate

- device: NVIDIA B300 SXM6 AC, 148 SMs, 232448 B opt-in shared memory/block
- GPU busy: 591.000 ms total; kernels 590.964 ms over 900 launches of 57 distinct names
- memcpy: 0.032 ms over 17 calls; memset: 0.003 ms over 2 calls

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 254.511 | 55 | 43.1 |
| kernel_cutlass_down_proj_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 62.869 | 55 | 10.6 |
| kernel_cutlass_proj_mlp_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 57.954 | 55 | 9.8 |
| kernel_cutlass_proj_mlp_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 57.912 | 55 | 9.8 |
| kernel_cutlass_proj_qkv_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 51.565 | 55 | 8.7 |
| kernel_cutlass_swiglu_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmemali… | 33.371 | 55 | 5.7 |
| kernel_cutlass_out_proj_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 25.431 | 55 | 4.3 |
| kernel_cutlass_rms_norm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo25601… | 18.557 | 55 | 3.1 |
| kernel_cutlass_post_norm_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo25601_tensorptrf… | 11.595 | 55 | 2.0 |
| kernel_cutlass_proj_qkv_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 6.788 | 55 | 1.1 |
