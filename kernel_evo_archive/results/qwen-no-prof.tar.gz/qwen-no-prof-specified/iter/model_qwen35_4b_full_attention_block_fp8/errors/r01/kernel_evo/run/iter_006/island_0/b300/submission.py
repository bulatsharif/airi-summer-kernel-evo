import cutlass
import cutlass.cute as cute


TOKENS = 128
HIDDEN_SIZE = 2560
NUM_HEADS = 16
NUM_KV_HEADS = 4
HEADS_PER_KV = NUM_HEADS // NUM_KV_HEADS
HEAD_DIM = 256
ROTARY_DIM = 64
ROTARY_HALF = ROTARY_DIM // 2
INTERMEDIATE_SIZE = 9216
Q_GATE_SIZE = 2 * NUM_HEADS * HEAD_DIM
KV_SIZE = NUM_KV_HEADS * HEAD_DIM
QUERY_SIZE = NUM_HEADS * HEAD_DIM
THREADS = 128
EPSILON = 1.0e-6

INPUT_SCALE = 1.0 / 448.0
NORM_SCALE = 1.0 / 64.0
QKV_SCALE = 1.0 / 64.0
CONTEXT_SCALE = 1.0 / 64.0
MLP_PROJECTION_SCALE = 1.0 / 64.0
MLP_ACTIVATION_SCALE = 1.0 / 32.0
WEIGHT_H_SCALE = HIDDEN_SIZE ** -0.5 / 448.0
WEIGHT_CONTEXT_SCALE = QUERY_SIZE ** -0.5 / 448.0
WEIGHT_MLP_SCALE = INTERMEDIATE_SIZE ** -0.5 / 448.0

# Combined scales that turn the raw FP8*FP8 sum into the stored output.
S_QKV = NORM_SCALE * WEIGHT_H_SCALE / QKV_SCALE
S_MLP = NORM_SCALE * WEIGHT_H_SCALE / MLP_PROJECTION_SCALE
S_OUT = CONTEXT_SCALE * WEIGHT_CONTEXT_SCALE
S_DOWN = MLP_ACTIVATION_SCALE * WEIGHT_MLP_SCALE

FP8_DTYPE = cutlass.Float8E4M3FN
F32 = cutlass.Float32


@cute.kernel
def rms_norm_kernel(hidden: cute.Tensor, weight: cute.Tensor, output: cute.Tensor):
    t, _, _ = cute.arch.block_idx()
    th, _, _ = cute.arch.thread_idx()
    s = cutlass.Float32(0.0)
    for i in cutlass.range_constexpr(HIDDEN_SIZE // 32):
        x = hidden[t, i * 32 + th].to(cutlass.Float32) * INPUT_SCALE
        s = s + x * x
    s = s + cute.arch.shuffle_sync_bfly(s, 16)
    s = s + cute.arch.shuffle_sync_bfly(s, 8)
    s = s + cute.arch.shuffle_sync_bfly(s, 4)
    s = s + cute.arch.shuffle_sync_bfly(s, 2)
    s = s + cute.arch.shuffle_sync_bfly(s, 1)
    inv = cute.rsqrt(s / HIDDEN_SIZE + EPSILON)
    for i in cutlass.range_constexpr(HIDDEN_SIZE // 32):
        idx = i * 32 + th
        x = hidden[t, idx].to(cutlass.Float32) * INPUT_SCALE
        n = x * inv * (1.0 + weight[idx].to(cutlass.Float32))
        output[t, idx] = cutlass.Float8E4M3FN(n / NORM_SCALE)


@cute.kernel
def proj_kernel(
    a_tensor: cute.Tensor,          # [TOKENS, K] FP8 activation
    weight: cute.Tensor,            # [N, K] FP8 weight
    output: cute.Tensor,            # [TOKENS, N] FP8 out
    out_scale: cutlass.Constexpr,   # combined output scale
    k_dim: cutlass.Constexpr,       # K
):
    # grid = (N,); block = (32,). One block per output column, all tokens.
    j, _, _ = cute.arch.block_idx()
    th, _, _ = cute.arch.thread_idx()
    smem_w = cute.arch.alloc_smem(FP8_DTYPE, k_dim, alignment=128)
    w_s = cute.make_tensor(smem_w, cute.make_layout(k_dim))
    for i in cutlass.range_constexpr(k_dim // 32):
        w_s[i * 32 + th] = weight[j, i * 32 + th]
    cute.arch.sync_threads()
    for t in cutlass.range_constexpr(TOKENS):
        acc = cutlass.Float32(0.0)
        for i in cutlass.range_constexpr(k_dim // 32):
            acc = acc + a_tensor[t, i * 32 + th].to(cutlass.Float32) * w_s[
                i * 32 + th
            ].to(cutlass.Float32)
        acc = acc + cute.arch.shuffle_sync_bfly(acc, 16)
        acc = acc + cute.arch.shuffle_sync_bfly(acc, 8)
        acc = acc + cute.arch.shuffle_sync_bfly(acc, 4)
        acc = acc + cute.arch.shuffle_sync_bfly(acc, 2)
        acc = acc + cute.arch.shuffle_sync_bfly(acc, 1)
        if th == 0:
            output[t, j] = cutlass.Float8E4M3FN(acc * out_scale)


@cute.kernel
def proj_out_kernel(
    ctx: cute.Tensor,               # [TOKENS, QUERY_SIZE] FP8
    weight: cute.Tensor,            # [HIDDEN_SIZE, QUERY_SIZE] FP8
    hidden: cute.Tensor,            # [TOKENS, HIDDEN_SIZE] FP8
    residual: cute.Tensor,          # [TOKENS, HIDDEN_SIZE] FP32 out
    k_dim: cutlass.Constexpr,
):
    j, _, _ = cute.arch.block_idx()
    th, _, _ = cute.arch.thread_idx()
    smem_w = cute.arch.alloc_smem(FP8_DTYPE, k_dim, alignment=128)
    w_s = cute.make_tensor(smem_w, cute.make_layout(k_dim))
    for i in cutlass.range_constexpr(k_dim // 32):
        w_s[i * 32 + th] = weight[j, i * 32 + th]
    cute.arch.sync_threads()
    for t in cutlass.range_constexpr(TOKENS):
        acc = cutlass.Float32(0.0)
        for i in cutlass.range_constexpr(k_dim // 32):
            acc = acc + ctx[t, i * 32 + th].to(cutlass.Float32) * w_s[
                i * 32 + th
            ].to(cutlass.Float32)
        acc = acc + cute.arch.shuffle_sync_bfly(acc, 16)
        acc = acc + cute.arch.shuffle_sync_bfly(acc, 8)
        acc = acc + cute.arch.shuffle_sync_bfly(acc, 4)
        acc = acc + cute.arch.shuffle_sync_bfly(acc, 2)
        acc = acc + cute.arch.shuffle_sync_bfly(acc, 1)
        if th == 0:
            residual[t, j] = (
                hidden[t, j].to(cutlass.Float32) * INPUT_SCALE + acc * S_OUT
            )


@cute.kernel
def proj_down_kernel(
    mlp: cute.Tensor,               # [TOKENS, INTERMEDIATE_SIZE] FP8
    weight: cute.Tensor,            # [HIDDEN_SIZE, INTERMEDIATE_SIZE] FP8
    residual: cute.Tensor,          # [TOKENS, HIDDEN_SIZE] FP32
    output: cute.Tensor,            # [TOKENS, HIDDEN_SIZE] FP32 out
    k_dim: cutlass.Constexpr,
):
    j, _, _ = cute.arch.block_idx()
    th, _, _ = cute.arch.thread_idx()
    smem_w = cute.arch.alloc_smem(FP8_DTYPE, k_dim, alignment=128)
    w_s = cute.make_tensor(smem_w, cute.make_layout(k_dim))
    for i in cutlass.range_constexpr(k_dim // 32):
        w_s[i * 32 + th] = weight[j, i * 32 + th]
    cute.arch.sync_threads()
    for t in cutlass.range_constexpr(TOKENS):
        acc = cutlass.Float32(0.0)
        for i in cutlass.range_constexpr(k_dim // 32):
            acc = acc + mlp[t, i * 32 + th].to(cutlass.Float32) * w_s[
                i * 32 + th
            ].to(cutlass.Float32)
        acc = acc + cute.arch.shuffle_sync_bfly(acc, 16)
        acc = acc + cute.arch.shuffle_sync_bfly(acc, 8)
        acc = acc + cute.arch.shuffle_sync_bfly(acc, 4)
        acc = acc + cute.arch.shuffle_sync_bfly(acc, 2)
        acc = acc + cute.arch.shuffle_sync_bfly(acc, 1)
        if th == 0:
            output[t, j] = (
                residual[t, j].to(cutlass.Float32) + acc * S_DOWN
            )


@cute.kernel
def q_headnorm_kernel(
    q_gate: cute.Tensor,
    q_norm_weight: cute.Tensor,
    cos: cute.Tensor,
    sin: cute.Tensor,
    query_out: cute.Tensor,
):
    # grid = (NUM_HEADS, TOKENS); warp per (head, token)
    h, t, _ = cute.arch.block_idx()
    th, _, _ = cute.arch.thread_idx()
    s = cutlass.Float32(0.0)
    for i in cutlass.range_constexpr(HEAD_DIM // 32):
        d = i * 32 + th
        x = q_gate[t, h * 512 + d].to(cutlass.Float32) * QKV_SCALE
        s = s + x * x
    s = s + cute.arch.shuffle_sync_bfly(s, 16)
    s = s + cute.arch.shuffle_sync_bfly(s, 8)
    s = s + cute.arch.shuffle_sync_bfly(s, 4)
    s = s + cute.arch.shuffle_sync_bfly(s, 2)
    s = s + cute.arch.shuffle_sync_bfly(s, 1)
    inv = cute.rsqrt(s / HEAD_DIM + EPSILON)
    for i in cutlass.range_constexpr(HEAD_DIM // 32):
        d = i * 32 + th
        x = q_gate[t, h * 512 + d].to(cutlass.Float32) * QKV_SCALE
        n = x * inv * (1.0 + q_norm_weight[d].to(cutlass.Float32))
        out_v = n
        if d < ROTARY_HALF:
            x2 = q_gate[t, h * 512 + (d + ROTARY_HALF)].to(cutlass.Float32) * QKV_SCALE
            n2 = x2 * inv * (1.0 + q_norm_weight[d + ROTARY_HALF].to(cutlass.Float32))
            c = cos[t, d].to(cutlass.Float32)
            si = sin[t, d].to(cutlass.Float32)
            out_v = n * c - n2 * si
        elif d < ROTARY_DIM:
            c = cos[t, d - ROTARY_HALF].to(cutlass.Float32)
            si = sin[t, d - ROTARY_HALF].to(cutlass.Float32)
            xp = q_gate[t, h * 512 + (d - ROTARY_HALF)].to(cutlass.Float32) * QKV_SCALE
            np = xp * inv * (1.0 + q_norm_weight[d - ROTARY_HALF].to(cutlass.Float32))
            out_v = n * c + np * si
        query_out[t, h * HEAD_DIM + d] = cutlass.Float8E4M3FN(out_v / QKV_SCALE)


@cute.kernel
def k_headnorm_kernel(
    k_in: cute.Tensor,
    k_norm_weight: cute.Tensor,
    cos: cute.Tensor,
    sin: cute.Tensor,
    key_out: cute.Tensor,
):
    # grid = (NUM_KV_HEADS, TOKENS); warp per (head, token)
    h, t, _ = cute.arch.block_idx()
    th, _, _ = cute.arch.thread_idx()
    s = cutlass.Float32(0.0)
    for i in cutlass.range_constexpr(HEAD_DIM // 32):
        d = i * 32 + th
        x = k_in[t, h * HEAD_DIM + d].to(cutlass.Float32) * QKV_SCALE
        s = s + x * x
    s = s + cute.arch.shuffle_sync_bfly(s, 16)
    s = s + cute.arch.shuffle_sync_bfly(s, 8)
    s = s + cute.arch.shuffle_sync_bfly(s, 4)
    s = s + cute.arch.shuffle_sync_bfly(s, 2)
    s = s + cute.arch.shuffle_sync_bfly(s, 1)
    inv = cute.rsqrt(s / HEAD_DIM + EPSILON)
    for i in cutlass.range_constexpr(HEAD_DIM // 32):
        d = i * 32 + th
        x = k_in[t, h * HEAD_DIM + d].to(cutlass.Float32) * QKV_SCALE
        n = x * inv * (1.0 + k_norm_weight[d].to(cutlass.Float32))
        out_v = n
        if d < ROTARY_HALF:
            x2 = k_in[t, h * HEAD_DIM + (d + ROTARY_HALF)].to(cutlass.Float32) * QKV_SCALE
            n2 = x2 * inv * (1.0 + k_norm_weight[d + ROTARY_HALF].to(cutlass.Float32))
            c = cos[t, d].to(cutlass.Float32)
            si = sin[t, d].to(cutlass.Float32)
            out_v = n * c - n2 * si
        elif d < ROTARY_DIM:
            c = cos[t, d - ROTARY_HALF].to(cutlass.Float32)
            si = sin[t, d - ROTARY_HALF].to(cutlass.Float32)
            xp = k_in[t, h * HEAD_DIM + (d - ROTARY_HALF)].to(cutlass.Float32) * QKV_SCALE
            np = xp * inv * (1.0 + k_norm_weight[d - ROTARY_HALF].to(cutlass.Float32))
            out_v = n * c + np * si
        key_out[t, h * HEAD_DIM + d] = cutlass.Float8E4M3FN(out_v / QKV_SCALE)


@cute.kernel
def attention_kernel(
    query: cute.Tensor,
    key: cute.Tensor,
    v: cute.Tensor,
    q_gate: cute.Tensor,
    score_ws: cute.Tensor,
    prob_ws: cute.Tensor,
    context_out: cute.Tensor,
):
    # grid = (NUM_HEADS, TOKENS); warp per (query head, token)
    qh, t, _ = cute.arch.block_idx()
    th, _, _ = cute.arch.thread_idx()
    kv = qh // HEADS_PER_KV
    q_base = qh * HEAD_DIM
    kv_base = kv * HEAD_DIM
    qg_base = qh * 2 * HEAD_DIM

    # Pass 1: raw scores to workspace, running max/sum for causal softmax.
    max_s = cutlass.Float32(-1.0e30)
    sum_e = cutlass.Float32(0.0)
    for s in cutlass.range(TOKENS):
        if s <= t:
            part = cutlass.Float32(0.0)
            for i in cutlass.range_constexpr(HEAD_DIM // 32):
                d = i * 32 + th
                qr = query[t, q_base + d].to(cutlass.Float32) * QKV_SCALE
                kr = key[s, kv_base + d].to(cutlass.Float32) * QKV_SCALE
                part = part + qr * kr
            part = part + cute.arch.shuffle_sync_bfly(part, 16)
            part = part + cute.arch.shuffle_sync_bfly(part, 8)
            part = part + cute.arch.shuffle_sync_bfly(part, 4)
            part = part + cute.arch.shuffle_sync_bfly(part, 2)
            part = part + cute.arch.shuffle_sync_bfly(part, 1)
            score = part / 16.0
            score_ws[t, qh * TOKENS + s] = score
            new_max = max_s
            if score > max_s:
                new_max = score
            sum_e = sum_e * cute.exp(max_s - new_max) + cute.exp(score - new_max)
            max_s = new_max

    # Pass 2: probabilities + context over the dims this lane owns, gate.
    for i in cutlass.range_constexpr(HEAD_DIM // 32):
        d = i * 32 + th
        ctx = cutlass.Float32(0.0)
        for s in cutlass.range(TOKENS):
            if s <= t:
                sc = score_ws[t, qh * TOKENS + s].to(cutlass.Float32)
                p = cute.exp(sc - max_s) / sum_e
                vr = v[s, kv_base + d].to(cutlass.Float32) * QKV_SCALE
                ctx = ctx + p * vr
        gr = q_gate[t, qg_base + HEAD_DIM + d].to(cutlass.Float32) * QKV_SCALE
        sig = 1.0 / (1.0 + cute.exp(-gr))
        context_out[t, q_base + d] = cutlass.Float8E4M3FN(ctx * sig / CONTEXT_SCALE)


@cute.kernel
def post_norm_kernel(residual: cute.Tensor, weight: cute.Tensor, output: cute.Tensor):
    t, _, _ = cute.arch.block_idx()
    th, _, _ = cute.arch.thread_idx()
    s = cutlass.Float32(0.0)
    for i in cutlass.range_constexpr(HIDDEN_SIZE // 32):
        x = residual[t, i * 32 + th].to(cutlass.Float32)
        s = s + x * x
    s = s + cute.arch.shuffle_sync_bfly(s, 16)
    s = s + cute.arch.shuffle_sync_bfly(s, 8)
    s = s + cute.arch.shuffle_sync_bfly(s, 4)
    s = s + cute.arch.shuffle_sync_bfly(s, 2)
    s = s + cute.arch.shuffle_sync_bfly(s, 1)
    inv = cute.rsqrt(s / HIDDEN_SIZE + EPSILON)
    for i in cutlass.range_constexpr(HIDDEN_SIZE // 32):
        idx = i * 32 + th
        x = residual[t, idx].to(cutlass.Float32)
        n = x * inv * (1.0 + weight[idx].to(cutlass.Float32))
        output[t, idx] = cutlass.Float8E4M3FN(n / NORM_SCALE)


@cute.kernel
def swiglu_kernel(gate: cute.Tensor, up: cute.Tensor, mlp_out: cute.Tensor):
    # grid = (INTERMEDIATE_SIZE, TOKENS)
    j, t, _ = cute.arch.block_idx()
    g = gate[t, j].to(cutlass.Float32) * MLP_PROJECTION_SCALE
    u = up[t, j].to(cutlass.Float32) * MLP_PROJECTION_SCALE
    silu = g / (1.0 + cute.exp(-g))
    mlp_out[t, j] = cutlass.Float8E4M3FN(silu * u / MLP_ACTIVATION_SCALE)


@cute.jit
def qwen35_full_attention_block(
    hidden: cute.Tensor,
    input_norm_weight: cute.Tensor,
    q_norm_weight: cute.Tensor,
    k_norm_weight: cute.Tensor,
    q_gate_weight: cute.Tensor,
    k_weight: cute.Tensor,
    v_weight: cute.Tensor,
    out_weight: cute.Tensor,
    post_norm_weight: cute.Tensor,
    gate_weight: cute.Tensor,
    up_weight: cute.Tensor,
    down_weight: cute.Tensor,
    cos: cute.Tensor,
    sin: cute.Tensor,
    norm1_workspace: cute.Tensor,
    q_gate_workspace: cute.Tensor,
    k_workspace: cute.Tensor,
    v_workspace: cute.Tensor,
    query_workspace: cute.Tensor,
    key_workspace: cute.Tensor,
    score_workspace: cute.Tensor,
    probability_workspace: cute.Tensor,
    context_workspace: cute.Tensor,
    residual_workspace: cute.Tensor,
    norm2_workspace: cute.Tensor,
    gate_workspace: cute.Tensor,
    up_workspace: cute.Tensor,
    mlp_workspace: cute.Tensor,
    output: cute.Tensor,
):
    rms_norm_kernel(hidden, input_norm_weight, norm1_workspace).launch(
        grid=(TOKENS, 1, 1), block=(32, 1, 1)
    )
    proj_kernel(
        norm1_workspace, q_gate_weight, q_gate_workspace, S_QKV, HIDDEN_SIZE
    ).launch(grid=(Q_GATE_SIZE, 1, 1), block=(32, 1, 1))
    proj_kernel(
        norm1_workspace, k_weight, k_workspace, S_QKV, HIDDEN_SIZE
    ).launch(grid=(KV_SIZE, 1, 1), block=(32, 1, 1))
    proj_kernel(
        norm1_workspace, v_weight, v_workspace, S_QKV, HIDDEN_SIZE
    ).launch(grid=(KV_SIZE, 1, 1), block=(32, 1, 1))
    q_headnorm_kernel(
        q_gate_workspace, q_norm_weight, cos, sin, query_workspace
    ).launch(grid=(NUM_HEADS, TOKENS, 1), block=(32, 1, 1))
    k_headnorm_kernel(
        k_workspace, k_norm_weight, cos, sin, key_workspace
    ).launch(grid=(NUM_KV_HEADS, TOKENS, 1), block=(32, 1, 1))
    attention_kernel(
        query_workspace, key_workspace, v_workspace, q_gate_workspace,
        score_workspace, probability_workspace, context_workspace,
    ).launch(grid=(NUM_HEADS, TOKENS, 1), block=(32, 1, 1))
    proj_out_kernel(
        context_workspace, out_weight, hidden, residual_workspace, QUERY_SIZE
    ).launch(grid=(HIDDEN_SIZE, 1, 1), block=(32, 1, 1))
    post_norm_kernel(residual_workspace, post_norm_weight, norm2_workspace).launch(
        grid=(TOKENS, 1, 1), block=(32, 1, 1)
    )
    proj_kernel(
        norm2_workspace, gate_weight, gate_workspace, S_MLP, HIDDEN_SIZE
    ).launch(grid=(INTERMEDIATE_SIZE, 1, 1), block=(32, 1, 1))
    proj_kernel(
        norm2_workspace, up_weight, up_workspace, S_MLP, HIDDEN_SIZE
    ).launch(grid=(INTERMEDIATE_SIZE, 1, 1), block=(32, 1, 1))
    swiglu_kernel(gate_workspace, up_workspace, mlp_workspace).launch(
        grid=(INTERMEDIATE_SIZE, TOKENS, 1), block=(1, 1, 1)
    )
    proj_down_kernel(
        mlp_workspace, down_weight, residual_workspace, output, INTERMEDIATE_SIZE
    ).launch(grid=(HIDDEN_SIZE, 1, 1), block=(32, 1, 1))


class ModelNew:
    forward = staticmethod(qwen35_full_attention_block)

# === CUTE_HARNESS_EVALUATOR_V1 ===
_CUTE_HARNESS_SEED = 0
_CUTE_HARNESS_WARMUP = 5
_CUTE_HARNESS_REPEATS = 50

import torch as _cute_harness_torch
import torch.nn.functional as _cute_harness_functional

import cutlass as _cute_harness_cutlass
import cutlass.cute as _cute_harness_cute
from cutlass.cute.runtime import from_dlpack as _cute_harness_from_dlpack
from cutlass.utils import create_cute_tensor_for_fp8 as _cute_harness_create_fp8


_CUTE_HARNESS_TOKENS = 128
_CUTE_HARNESS_HIDDEN = 2560
_CUTE_HARNESS_HEADS = 16
_CUTE_HARNESS_KV_HEADS = 4
_CUTE_HARNESS_HEAD_DIM = 256
_CUTE_HARNESS_ROTARY = 64
_CUTE_HARNESS_INTERMEDIATE = 9216
_CUTE_HARNESS_Q_GATE = 8192
_CUTE_HARNESS_KV = 1024
_CUTE_HARNESS_QUERY = 4096
_CUTE_HARNESS_EPSILON = 1.0e-6
_CUTE_HARNESS_INPUT_SCALE = 1.0 / 448.0
_CUTE_HARNESS_NORM_SCALE = 1.0 / 64.0
_CUTE_HARNESS_QKV_SCALE = 1.0 / 64.0
_CUTE_HARNESS_CONTEXT_SCALE = 1.0 / 64.0
_CUTE_HARNESS_MLP_PROJECTION_SCALE = 1.0 / 64.0
_CUTE_HARNESS_MLP_ACTIVATION_SCALE = 1.0 / 32.0
_CUTE_HARNESS_WEIGHT_H_BOUND = _CUTE_HARNESS_HIDDEN ** -0.5
_CUTE_HARNESS_WEIGHT_CONTEXT_BOUND = _CUTE_HARNESS_QUERY ** -0.5
_CUTE_HARNESS_WEIGHT_MLP_BOUND = _CUTE_HARNESS_INTERMEDIATE ** -0.5
_CUTE_HARNESS_WEIGHT_H_SCALE = _CUTE_HARNESS_WEIGHT_H_BOUND / 448.0
_CUTE_HARNESS_WEIGHT_CONTEXT_SCALE = (
    _CUTE_HARNESS_WEIGHT_CONTEXT_BOUND / 448.0
)
_CUTE_HARNESS_WEIGHT_MLP_SCALE = _CUTE_HARNESS_WEIGHT_MLP_BOUND / 448.0
_CUTE_HARNESS_FP8_DTYPE = _cute_harness_cutlass.Float8E4M3FN


def _cute_harness_fp8_tensor(source, scale):
    storage = _cute_harness_torch.empty(
        source.shape, device="cuda", dtype=_cute_harness_torch.uint8
    )
    tensor = _cute_harness_create_fp8(
        storage, _CUTE_HARNESS_FP8_DTYPE, 1, source / scale
    )
    return storage, tensor


def _cute_harness_empty_fp8(shape):
    return _cute_harness_fp8_tensor(
        _cute_harness_torch.zeros(shape, device="cuda"), 1.0
    )


def _cute_harness_scaled_linear(activation, weight, activation_scale, weight_scale):
    scale_a = _cute_harness_torch.tensor(activation_scale, device="cuda")
    scale_b = _cute_harness_torch.tensor(weight_scale, device="cuda")
    return _cute_harness_torch._scaled_mm(
        activation,
        weight.t(),
        scale_a=scale_a,
        scale_b=scale_b,
        out_dtype=_cute_harness_torch.float32,
    )


def _cute_harness_rms_norm(hidden, weight):
    inverse_rms = _cute_harness_torch.rsqrt(
        hidden.square().mean(dim=-1, keepdim=True) + _CUTE_HARNESS_EPSILON
    )
    return hidden * inverse_rms * (1.0 + weight)


def _cute_harness_apply_rope(hidden, cos, sin):
    rotary = hidden[..., :_CUTE_HARNESS_ROTARY]
    half = _CUTE_HARNESS_ROTARY // 2
    rotated = _cute_harness_torch.cat(
        (-rotary[..., half:], rotary[..., :half]), dim=-1
    )
    embedded = rotary * cos[:, None, :] + rotated * sin[:, None, :]
    return _cute_harness_torch.cat(
        (embedded, hidden[..., _CUTE_HARNESS_ROTARY:]), dim=-1
    )


def main():
    if not _cute_harness_torch.cuda.is_available():
        raise RuntimeError("A Blackwell CUDA device is required")

    _cute_harness_torch.manual_seed(_CUTE_HARNESS_SEED)
    hidden_source = _cute_harness_torch.empty(
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_HIDDEN), device="cuda"
    ).uniform_(-1.0, 1.0)
    input_norm_weight = 0.02 * _cute_harness_torch.randn(
        (_CUTE_HARNESS_HIDDEN,), device="cuda"
    )
    post_norm_weight = 0.02 * _cute_harness_torch.randn(
        (_CUTE_HARNESS_HIDDEN,), device="cuda"
    )
    q_norm_weight = 0.02 * _cute_harness_torch.randn(
        (_CUTE_HARNESS_HEAD_DIM,), device="cuda"
    )
    k_norm_weight = 0.02 * _cute_harness_torch.randn(
        (_CUTE_HARNESS_HEAD_DIM,), device="cuda"
    )

    positions = _cute_harness_torch.arange(
        _CUTE_HARNESS_TOKENS, device="cuda", dtype=_cute_harness_torch.float32
    )
    rotary_indices = _cute_harness_torch.arange(
        0,
        _CUTE_HARNESS_ROTARY,
        2,
        device="cuda",
        dtype=_cute_harness_torch.float32,
    )
    inverse_frequency = 1.0 / (
        10_000_000.0 ** (rotary_indices / _CUTE_HARNESS_ROTARY)
    )
    frequencies = positions[:, None] * inverse_frequency[None, :]
    embeddings = _cute_harness_torch.cat((frequencies, frequencies), dim=-1)
    cos_storage = embeddings.cos()
    sin_storage = embeddings.sin()

    weight_specs = (
        ("q_gate", _CUTE_HARNESS_Q_GATE, _CUTE_HARNESS_HIDDEN,
         _CUTE_HARNESS_WEIGHT_H_BOUND, _CUTE_HARNESS_WEIGHT_H_SCALE),
        ("k", _CUTE_HARNESS_KV, _CUTE_HARNESS_HIDDEN,
         _CUTE_HARNESS_WEIGHT_H_BOUND, _CUTE_HARNESS_WEIGHT_H_SCALE),
        ("v", _CUTE_HARNESS_KV, _CUTE_HARNESS_HIDDEN,
         _CUTE_HARNESS_WEIGHT_H_BOUND, _CUTE_HARNESS_WEIGHT_H_SCALE),
        ("out", _CUTE_HARNESS_HIDDEN, _CUTE_HARNESS_QUERY,
         _CUTE_HARNESS_WEIGHT_CONTEXT_BOUND, _CUTE_HARNESS_WEIGHT_CONTEXT_SCALE),
        ("gate", _CUTE_HARNESS_INTERMEDIATE, _CUTE_HARNESS_HIDDEN,
         _CUTE_HARNESS_WEIGHT_H_BOUND, _CUTE_HARNESS_WEIGHT_H_SCALE),
        ("up", _CUTE_HARNESS_INTERMEDIATE, _CUTE_HARNESS_HIDDEN,
         _CUTE_HARNESS_WEIGHT_H_BOUND, _CUTE_HARNESS_WEIGHT_H_SCALE),
        ("down", _CUTE_HARNESS_HIDDEN, _CUTE_HARNESS_INTERMEDIATE,
         _CUTE_HARNESS_WEIGHT_MLP_BOUND, _CUTE_HARNESS_WEIGHT_MLP_SCALE),
    )
    weight_storages = {}
    weight_tensors = {}
    for name, rows, columns, bound, scale in weight_specs:
        source = _cute_harness_torch.empty(
            (rows, columns), device="cuda"
        ).uniform_(-bound, bound)
        storage, tensor = _cute_harness_fp8_tensor(source, scale)
        weight_storages[name] = storage
        weight_tensors[name] = tensor

    hidden_storage, hidden = _cute_harness_fp8_tensor(
        hidden_source, _CUTE_HARNESS_INPUT_SCALE
    )
    fp8_workspace_shapes = (
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_HIDDEN),
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_Q_GATE),
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_KV),
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_KV),
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_QUERY),
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_KV),
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_QUERY),
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_HIDDEN),
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_INTERMEDIATE),
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_INTERMEDIATE),
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_INTERMEDIATE),
    )
    fp8_workspaces = [_cute_harness_empty_fp8(shape) for shape in fp8_workspace_shapes]
    (
        norm1_pair,
        q_gate_pair,
        k_pair,
        v_pair,
        query_pair,
        key_pair,
        context_pair,
        norm2_pair,
        gate_pair,
        up_pair,
        mlp_pair,
    ) = fp8_workspaces

    score_storage = _cute_harness_torch.empty(
        (_CUTE_HARNESS_HEADS * _CUTE_HARNESS_TOKENS, _CUTE_HARNESS_TOKENS),
        device="cuda",
    )
    probability_storage = _cute_harness_torch.empty_like(score_storage)
    residual_storage = _cute_harness_torch.empty(
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_HIDDEN), device="cuda"
    )
    output_storage = _cute_harness_torch.empty_like(residual_storage)
    dynamic = lambda tensor: _cute_harness_from_dlpack(tensor).mark_layout_dynamic(
        leading_dim=1
    )
    arguments = (
        hidden,
        _cute_harness_from_dlpack(input_norm_weight),
        _cute_harness_from_dlpack(q_norm_weight),
        _cute_harness_from_dlpack(k_norm_weight),
        weight_tensors["q_gate"],
        weight_tensors["k"],
        weight_tensors["v"],
        weight_tensors["out"],
        _cute_harness_from_dlpack(post_norm_weight),
        weight_tensors["gate"],
        weight_tensors["up"],
        weight_tensors["down"],
        dynamic(cos_storage),
        dynamic(sin_storage),
        *(pair[1] for pair in fp8_workspaces[:6]),
        dynamic(score_storage),
        dynamic(probability_storage),
        context_pair[1],
        dynamic(residual_storage),
        *(pair[1] for pair in fp8_workspaces[7:]),
        dynamic(output_storage),
    )
    compiled = _cute_harness_cute.compile(qwen35_full_attention_block, *arguments)
    for _ in range(_CUTE_HARNESS_WARMUP):
        compiled(*arguments)
    _cute_harness_torch.cuda.synchronize()

    timings_ms = []
    for _ in range(_CUTE_HARNESS_REPEATS):
        start = _cute_harness_torch.cuda.Event(enable_timing=True)
        end = _cute_harness_torch.cuda.Event(enable_timing=True)
        start.record()
        compiled(*arguments)
        end.record()
        end.synchronize()
        timings_ms.append(start.elapsed_time(end))
    kernel_time_ms = sorted(timings_ms)[len(timings_ms) // 2]

    fp8 = _cute_harness_torch.float8_e4m3fn
    hidden_fp8 = hidden_storage.view(fp8)
    weights_fp8 = {name: storage.view(fp8) for name, storage in weight_storages.items()}
    hidden_dequantized = hidden_fp8.float() * _CUTE_HARNESS_INPUT_SCALE
    norm1 = _cute_harness_rms_norm(hidden_dequantized, input_norm_weight)
    norm1_fp8 = (norm1 / _CUTE_HARNESS_NORM_SCALE).to(fp8)
    q_gate = _cute_harness_scaled_linear(
        norm1_fp8, weights_fp8["q_gate"], _CUTE_HARNESS_NORM_SCALE,
        _CUTE_HARNESS_WEIGHT_H_SCALE,
    )
    k = _cute_harness_scaled_linear(
        norm1_fp8, weights_fp8["k"], _CUTE_HARNESS_NORM_SCALE,
        _CUTE_HARNESS_WEIGHT_H_SCALE,
    )
    v = _cute_harness_scaled_linear(
        norm1_fp8, weights_fp8["v"], _CUTE_HARNESS_NORM_SCALE,
        _CUTE_HARNESS_WEIGHT_H_SCALE,
    )
    q_gate_fp8 = (q_gate / _CUTE_HARNESS_QKV_SCALE).to(fp8)
    k_fp8 = (k / _CUTE_HARNESS_QKV_SCALE).to(fp8)
    v_fp8 = (v / _CUTE_HARNESS_QKV_SCALE).to(fp8)
    q_gate_heads = (q_gate_fp8.float() * _CUTE_HARNESS_QKV_SCALE).reshape(
        _CUTE_HARNESS_TOKENS, _CUTE_HARNESS_HEADS, 2, _CUTE_HARNESS_HEAD_DIM
    )
    query = _cute_harness_rms_norm(q_gate_heads[:, :, 0], q_norm_weight)
    gate = q_gate_heads[:, :, 1]
    key = _cute_harness_rms_norm(
        (k_fp8.float() * _CUTE_HARNESS_QKV_SCALE).reshape(
            _CUTE_HARNESS_TOKENS, _CUTE_HARNESS_KV_HEADS, _CUTE_HARNESS_HEAD_DIM
        ),
        k_norm_weight,
    )
    query = _cute_harness_apply_rope(query, cos_storage, sin_storage)
    key = _cute_harness_apply_rope(key, cos_storage, sin_storage)
    query_fp8 = (query / _CUTE_HARNESS_QKV_SCALE).to(fp8)
    key_fp8 = (key / _CUTE_HARNESS_QKV_SCALE).to(fp8)
    query = query_fp8.float() * _CUTE_HARNESS_QKV_SCALE
    key = key_fp8.float() * _CUTE_HARNESS_QKV_SCALE
    key = key.repeat_interleave(
        _CUTE_HARNESS_HEADS // _CUTE_HARNESS_KV_HEADS, dim=1
    )
    value = (v_fp8.float() * _CUTE_HARNESS_QKV_SCALE).reshape(
        _CUTE_HARNESS_TOKENS, _CUTE_HARNESS_KV_HEADS, _CUTE_HARNESS_HEAD_DIM
    ).repeat_interleave(_CUTE_HARNESS_HEADS // _CUTE_HARNESS_KV_HEADS, dim=1)
    scores = _cute_harness_torch.einsum("thd,shd->hts", query, key) / 16.0
    causal_mask = _cute_harness_torch.triu(
        _cute_harness_torch.ones(
            (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_TOKENS),
            device="cuda",
            dtype=_cute_harness_torch.bool,
        ),
        diagonal=1,
    )
    probabilities = scores.masked_fill(causal_mask, -float("inf")).softmax(dim=-1)
    context = _cute_harness_torch.einsum(
        "hts,shd->thd", probabilities, value
    ) * _cute_harness_torch.sigmoid(gate)
    context_fp8 = (context.reshape(
        _CUTE_HARNESS_TOKENS, _CUTE_HARNESS_QUERY
    ) / _CUTE_HARNESS_CONTEXT_SCALE).to(fp8)
    residual = hidden_dequantized + _cute_harness_scaled_linear(
        context_fp8, weights_fp8["out"], _CUTE_HARNESS_CONTEXT_SCALE,
        _CUTE_HARNESS_WEIGHT_CONTEXT_SCALE,
    )
    norm2 = _cute_harness_rms_norm(residual, post_norm_weight)
    norm2_fp8 = (norm2 / _CUTE_HARNESS_NORM_SCALE).to(fp8)
    gate_mlp = _cute_harness_scaled_linear(
        norm2_fp8, weights_fp8["gate"], _CUTE_HARNESS_NORM_SCALE,
        _CUTE_HARNESS_WEIGHT_H_SCALE,
    )
    up_mlp = _cute_harness_scaled_linear(
        norm2_fp8, weights_fp8["up"], _CUTE_HARNESS_NORM_SCALE,
        _CUTE_HARNESS_WEIGHT_H_SCALE,
    )
    gate_fp8 = (gate_mlp / _CUTE_HARNESS_MLP_PROJECTION_SCALE).to(fp8)
    up_fp8 = (up_mlp / _CUTE_HARNESS_MLP_PROJECTION_SCALE).to(fp8)
    activation = _cute_harness_functional.silu(
        gate_fp8.float() * _CUTE_HARNESS_MLP_PROJECTION_SCALE
    ) * (up_fp8.float() * _CUTE_HARNESS_MLP_PROJECTION_SCALE)
    activation_fp8 = (activation / _CUTE_HARNESS_MLP_ACTIVATION_SCALE).to(fp8)
    reference = residual + _cute_harness_scaled_linear(
        activation_fp8, weights_fp8["down"], _CUTE_HARNESS_MLP_ACTIVATION_SCALE,
        _CUTE_HARNESS_WEIGHT_MLP_SCALE,
    )

    max_abs = (output_storage - reference).abs().max().item()
    if not _cute_harness_torch.isfinite(output_storage).all().item() or max_abs > 0.08:
        raise RuntimeError(f"validation failed: max_abs={max_abs:.6f}")
    print(
        "task=model_qwen35_4b_full_attention_block_fp8 "
        f"max_abs={max_abs:.6f} kernel_time_ms={kernel_time_ms:.6f} PASS"
    )
    _cute_harness_torch.cuda.synchronize()


main()
