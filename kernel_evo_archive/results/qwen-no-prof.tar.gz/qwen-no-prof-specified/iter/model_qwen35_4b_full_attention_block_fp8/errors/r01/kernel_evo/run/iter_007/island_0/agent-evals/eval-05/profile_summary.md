# B300 device profile of your last candidate

- device: NVIDIA B300 SXM6 AC, 148 SMs, 232448 B opt-in shared memory/block
- GPU busy: 176.587 ms total; kernels 176.551 ms over 900 launches of 57 distinct names
- memcpy: 0.033 ms over 17 calls; memset: 0.003 ms over 2 calls

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_gemm_down_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 52.230 | 55 | 29.6 |
| kernel_cutlass_gemm_out_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 23.841 | 55 | 13.5 |
| kernel_cutlass_gemm_fp8_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 20.679 | 55 | 11.7 |
| kernel_cutlass_gemm_fp8_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 20.654 | 55 | 11.7 |
| kernel_cutlass_gemm_fp8_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 20.618 | 55 | 11.7 |
| kernel_cutlass_gemm_fp8_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 14.220 | 55 | 8.1 |
| kernel_cutlass_gemm_fp8_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 14.202 | 55 | 8.0 |
| kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 4.695 | 55 | 2.7 |
| kernel_cutlass_post_norm_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo25601_tensorptrf… | 1.639 | 55 | 0.9 |
| kernel_cutlass_rms_norm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo25601… | 1.512 | 55 | 0.9 |
