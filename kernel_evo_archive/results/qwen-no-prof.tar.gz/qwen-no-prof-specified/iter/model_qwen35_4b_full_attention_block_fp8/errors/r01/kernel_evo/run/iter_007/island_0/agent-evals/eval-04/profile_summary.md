# B300 device profile of your last candidate

- device: NVIDIA B300 SXM6 AC, 148 SMs, 232448 B opt-in shared memory/block
- GPU busy: 250.496 ms total; kernels 250.459 ms over 900 launches of 57 distinct names
- memcpy: 0.034 ms over 17 calls; memset: 0.004 ms over 2 calls

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_gemm_down_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 81.062 | 55 | 32.4 |
| kernel_cutlass_gemm_out_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 36.885 | 55 | 14.7 |
| kernel_cutlass_gemm_fp8_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 22.967 | 55 | 9.2 |
| kernel_cutlass_gemm_fp8_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 22.739 | 55 | 9.1 |
| kernel_cutlass_gemm_fp8_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 22.417 | 55 | 8.9 |
| kernel_cutlass_gemm_fp8_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 22.349 | 55 | 8.9 |
| kernel_cutlass_gemm_fp8_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 22.341 | 55 | 8.9 |
| kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 14.280 | 55 | 5.7 |
| kernel_cutlass_post_norm_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo25601_tensorptrf… | 1.638 | 55 | 0.7 |
| kernel_cutlass_rms_norm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo25601… | 1.512 | 55 | 0.6 |
