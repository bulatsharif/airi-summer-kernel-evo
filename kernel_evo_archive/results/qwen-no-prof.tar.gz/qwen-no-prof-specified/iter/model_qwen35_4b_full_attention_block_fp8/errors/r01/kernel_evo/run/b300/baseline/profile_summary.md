# B300 device profile of your last candidate

- device: NVIDIA B300 SXM6 AC, 148 SMs, 232448 B opt-in shared memory/block
- GPU busy: 2743.481 ms total; kernels 2743.444 ms over 1010 launches of 59 distinct names
- memcpy: 0.033 ms over 17 calls; memset: 0.003 ms over 2 calls

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_down_projection_kernel_tensorptrf32gmemoi641_tensorptrf8E4M3FNgmemalign1… | 613.563 | 55 | 22.4 |
| kernel_cutlass_mlp_input_projection_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf… | 591.576 | 55 | 21.6 |
| kernel_cutlass_mlp_input_projection_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf… | 591.572 | 55 | 21.6 |
| kernel_cutlass_attention_input_projection_kernel_tensorptrf8E4M3FNgmemalign16oi641_tens… | 525.952 | 55 | 19.2 |
| kernel_cutlass_attention_output_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M… | 269.708 | 55 | 9.8 |
| kernel_cutlass_attention_input_projection_kernel_tensorptrf8E4M3FNgmemalign16oi641_tens… | 66.419 | 55 | 2.4 |
| kernel_cutlass_attention_input_projection_kernel_tensorptrf8E4M3FNgmemalign16oi641_tens… | 66.401 | 55 | 2.4 |
| kernel_cutlass_attention_score_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3… | 10.250 | 55 | 0.4 |
| kernel_cutlass_residual_rms_norm_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo25601_te… | 1.629 | 55 | 0.1 |
| kernel_cutlass_softmax_kernel_tensorptrf32gmemoi641_tensorptrf32gmemoi641_7 | 1.610 | 55 | 0.1 |
