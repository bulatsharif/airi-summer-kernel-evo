import cutlass
import cutlass.cute as cute


TOKENS = 128
HIDDEN_SIZE = 2560
NUM_HEADS = 16
NUM_KV_HEADS = 4
HEADS_PER_KV = NUM_HEADS // NUM_KV_HEADS
HEAD_DIM = 256
ROTARY_DIM = 64
ROTARY_HALF = ROTARY_DIM // 2
INTERMEDIATE_SIZE = 9216
Q_GATE_SIZE = 2 * NUM_HEADS * HEAD_DIM
KV_SIZE = NUM_KV_HEADS * HEAD_DIM
QUERY_SIZE = NUM_HEADS * HEAD_DIM
THREADS = 128
EPSILON = 1.0e-6

INPUT_SCALE = 1.0 / 448.0
NORM_SCALE = 1.0 / 64.0
QKV_SCALE = 1.0 / 64.0
CONTEXT_SCALE = 1.0 / 64.0
MLP_PROJECTION_SCALE = 1.0 / 64.0
MLP_ACTIVATION_SCALE = 1.0 / 32.0
WEIGHT_H_SCALE = HIDDEN_SIZE ** -0.5 / 448.0
WEIGHT_CONTEXT_SCALE = QUERY_SIZE ** -0.5 / 448.0
WEIGHT_MLP_SCALE = INTERMEDIATE_SIZE ** -0.5 / 448.0

FP8_DTYPE = cutlass.Float8E4M3FN
F32 = cutlass.Float32


@cute.kernel
def rms_norm_kernel(hidden: cute.Tensor, weight: cute.Tensor, output: cute.Tensor):
    t, _, _ = cute.arch.block_idx()
    _, _, _ = cute.arch.thread_idx()
    s = cutlass.Float32(0.0)
    for i in cutlass.range_constexpr(HIDDEN_SIZE):
        x = hidden[t, i].to(cutlass.Float32) * INPUT_SCALE
        s = s + x * x
    inv = cute.rsqrt(s / HIDDEN_SIZE + EPSILON)
    for i in cutlass.range_constexpr(HIDDEN_SIZE):
        x = hidden[t, i].to(cutlass.Float32) * INPUT_SCALE
        n = x * inv * (1.0 + weight[i].to(cutlass.Float32))
        output[t, i] = cutlass.Float8E4M3FN(n / NORM_SCALE)


@cute.kernel
def proj_qkv_kernel(n1: cute.Tensor, weight: cute.Tensor, output: cute.Tensor):
    # grid = (N, TOKENS); one thread per output element out[t, j]
    j, t, _ = cute.arch.block_idx()
    acc = cutlass.Float32(0.0)
    for i in cutlass.range(HIDDEN_SIZE):
        a = n1[t, i].to(cutlass.Float32) * NORM_SCALE
        b = weight[j, i].to(cutlass.Float32) * WEIGHT_H_SCALE
        acc = acc + a * b
    output[t, j] = cutlass.Float8E4M3FN(acc / QKV_SCALE)


@cute.kernel
def q_headnorm_kernel(
    q_gate: cute.Tensor,
    q_norm_weight: cute.Tensor,
    cos: cute.Tensor,
    sin: cute.Tensor,
    query_out: cute.Tensor,
):
    # grid = (NUM_HEADS, TOKENS); one thread per (head, token)
    h, t, _ = cute.arch.block_idx()
    s = cutlass.Float32(0.0)
    for d in cutlass.range_constexpr(HEAD_DIM):
        x = q_gate[t, h * 512 + d].to(cutlass.Float32) * QKV_SCALE
        s = s + x * x
    inv = cute.rsqrt(s / HEAD_DIM + EPSILON)
    for d in cutlass.range_constexpr(HEAD_DIM):
        x = q_gate[t, h * 512 + d].to(cutlass.Float32) * QKV_SCALE
        n = x * inv * (1.0 + q_norm_weight[d].to(cutlass.Float32))
        out_v = n
        if d < ROTARY_HALF:
            x2 = q_gate[t, h * 512 + (d + ROTARY_HALF)].to(cutlass.Float32) * QKV_SCALE
            n2 = x2 * inv * (1.0 + q_norm_weight[d + ROTARY_HALF].to(cutlass.Float32))
            c = cos[t, d].to(cutlass.Float32)
            si = sin[t, d].to(cutlass.Float32)
            out_v = n * c - n2 * si
        elif d < ROTARY_DIM:
            c = cos[t, d - ROTARY_HALF].to(cutlass.Float32)
            si = sin[t, d - ROTARY_HALF].to(cutlass.Float32)
            xp = q_gate[t, h * 512 + (d - ROTARY_HALF)].to(cutlass.Float32) * QKV_SCALE
            np = xp * inv * (1.0 + q_norm_weight[d - ROTARY_HALF].to(cutlass.Float32))
            out_v = n * c + np * si
        query_out[t, h * HEAD_DIM + d] = cutlass.Float8E4M3FN(out_v / QKV_SCALE)


@cute.kernel
def k_headnorm_kernel(
    k_in: cute.Tensor,
    k_norm_weight: cute.Tensor,
    cos: cute.Tensor,
    sin: cute.Tensor,
    key_out: cute.Tensor,
):
    # grid = (NUM_KV_HEADS, TOKENS)
    h, t, _ = cute.arch.block_idx()
    s = cutlass.Float32(0.0)
    for d in cutlass.range_constexpr(HEAD_DIM):
        x = k_in[t, h * HEAD_DIM + d].to(cutlass.Float32) * QKV_SCALE
        s = s + x * x
    inv = cute.rsqrt(s / HEAD_DIM + EPSILON)
    for d in cutlass.range_constexpr(HEAD_DIM):
        x = k_in[t, h * HEAD_DIM + d].to(cutlass.Float32) * QKV_SCALE
        n = x * inv * (1.0 + k_norm_weight[d].to(cutlass.Float32))
        out_v = n
        if d < ROTARY_HALF:
            x2 = k_in[t, h * HEAD_DIM + (d + ROTARY_HALF)].to(cutlass.Float32) * QKV_SCALE
            n2 = x2 * inv * (1.0 + k_norm_weight[d + ROTARY_HALF].to(cutlass.Float32))
            c = cos[t, d].to(cutlass.Float32)
            si = sin[t, d].to(cutlass.Float32)
            out_v = n * c - n2 * si
        elif d < ROTARY_DIM:
            c = cos[t, d - ROTARY_HALF].to(cutlass.Float32)
            si = sin[t, d - ROTARY_HALF].to(cutlass.Float32)
            xp = k_in[t, h * HEAD_DIM + (d - ROTARY_HALF)].to(cutlass.Float32) * QKV_SCALE
            np = xp * inv * (1.0 + k_norm_weight[d - ROTARY_HALF].to(cutlass.Float32))
            out_v = n * c + np * si
        key_out[t, h * HEAD_DIM + d] = cutlass.Float8E4M3FN(out_v / QKV_SCALE)


@cute.kernel
def attention_kernel(
    query: cute.Tensor,
    key: cute.Tensor,
    v: cute.Tensor,
    q_gate: cute.Tensor,
    score_ws: cute.Tensor,
    prob_ws: cute.Tensor,
    context_out: cute.Tensor,
):
    # grid = (NUM_HEADS, TOKENS); one thread per (query head, token)
    qh, t, _ = cute.arch.block_idx()
    kv = qh // HEADS_PER_KV
    q_base = qh * HEAD_DIM
    kv_base = kv * HEAD_DIM
    qg_base = qh * 2 * HEAD_DIM

    # Pass 1: raw scores to workspace, running max/sum for causal softmax.
    max_s = cutlass.Float32(-1.0e30)
    sum_e = cutlass.Float32(0.0)
    for s in cutlass.range(TOKENS):
        if s <= t:
            score = cutlass.Float32(0.0)
            for d in cutlass.range(HEAD_DIM):
                qr = query[t, q_base + d].to(cutlass.Float32) * QKV_SCALE
                kr = key[s, kv_base + d].to(cutlass.Float32) * QKV_SCALE
                score = score + qr * kr
            score = score / 16.0
            score_ws[t, qh * TOKENS + s] = score
            new_max = max_s
            if score > max_s:
                new_max = score
            sum_e = sum_e * cute.exp(max_s - new_max) + cute.exp(score - new_max)
            max_s = new_max

    # Pass 2: probabilities + context, then gate + requantize.
    for d in cutlass.range(HEAD_DIM):
        ctx = cutlass.Float32(0.0)
        for s in cutlass.range(TOKENS):
            if s <= t:
                p = cute.exp(score_ws[t, qh * TOKENS + s].to(cutlass.Float32) - max_s) / sum_e
                vr = v[s, kv_base + d].to(cutlass.Float32) * QKV_SCALE
                ctx = ctx + p * vr
        gr = q_gate[t, qg_base + HEAD_DIM + d].to(cutlass.Float32) * QKV_SCALE
        sig = 1.0 / (1.0 + cute.exp(-gr))
        context_out[t, q_base + d] = cutlass.Float8E4M3FN(ctx * sig / CONTEXT_SCALE)


@cute.kernel
def out_proj_kernel(
    ctx: cute.Tensor,
    weight: cute.Tensor,
    hidden: cute.Tensor,
    residual: cute.Tensor,
):
    # grid = (HIDDEN_SIZE, TOKENS)
    j, t, _ = cute.arch.block_idx()
    acc = cutlass.Float32(0.0)
    for i in cutlass.range(QUERY_SIZE):
        a = ctx[t, i].to(cutlass.Float32) * CONTEXT_SCALE
        b = weight[j, i].to(cutlass.Float32) * WEIGHT_CONTEXT_SCALE
        acc = acc + a * b
    residual[t, j] = hidden[t, j].to(cutlass.Float32) * INPUT_SCALE + acc


@cute.kernel
def post_norm_kernel(residual: cute.Tensor, weight: cute.Tensor, output: cute.Tensor):
    t, _, _ = cute.arch.block_idx()
    _, _, _ = cute.arch.thread_idx()
    s = cutlass.Float32(0.0)
    for i in cutlass.range_constexpr(HIDDEN_SIZE):
        x = residual[t, i].to(cutlass.Float32)
        s = s + x * x
    inv = cute.rsqrt(s / HIDDEN_SIZE + EPSILON)
    for i in cutlass.range_constexpr(HIDDEN_SIZE):
        x = residual[t, i].to(cutlass.Float32)
        n = x * inv * (1.0 + weight[i].to(cutlass.Float32))
        output[t, i] = cutlass.Float8E4M3FN(n / NORM_SCALE)


@cute.kernel
def proj_mlp_kernel(n2: cute.Tensor, weight: cute.Tensor, output: cute.Tensor):
    # grid = (INTERMEDIATE_SIZE, TOKENS)
    j, t, _ = cute.arch.block_idx()
    acc = cutlass.Float32(0.0)
    for i in cutlass.range(HIDDEN_SIZE):
        a = n2[t, i].to(cutlass.Float32) * NORM_SCALE
        b = weight[j, i].to(cutlass.Float32) * WEIGHT_H_SCALE
        acc = acc + a * b
    output[t, j] = cutlass.Float8E4M3FN(acc / MLP_PROJECTION_SCALE)


@cute.kernel
def swiglu_kernel(gate: cute.Tensor, up: cute.Tensor, mlp_out: cute.Tensor):
    # grid = (INTERMEDIATE_SIZE, TOKENS)
    j, t, _ = cute.arch.block_idx()
    g = gate[t, j].to(cutlass.Float32) * MLP_PROJECTION_SCALE
    u = up[t, j].to(cutlass.Float32) * MLP_PROJECTION_SCALE
    silu = g / (1.0 + cute.exp(-g))
    mlp_out[t, j] = cutlass.Float8E4M3FN(silu * u / MLP_ACTIVATION_SCALE)


@cute.kernel
def down_proj_kernel(
    mlp: cute.Tensor,
    weight: cute.Tensor,
    residual: cute.Tensor,
    output: cute.Tensor,
):
    # grid = (HIDDEN_SIZE, TOKENS)
    j, t, _ = cute.arch.block_idx()
    acc = cutlass.Float32(0.0)
    for i in cutlass.range(INTERMEDIATE_SIZE):
        a = mlp[t, i].to(cutlass.Float32) * MLP_ACTIVATION_SCALE
        b = weight[j, i].to(cutlass.Float32) * WEIGHT_MLP_SCALE
        acc = acc + a * b
    output[t, j] = residual[t, j].to(cutlass.Float32) + acc


@cute.jit
def qwen35_full_attention_block(
    hidden: cute.Tensor,
    input_norm_weight: cute.Tensor,
    q_norm_weight: cute.Tensor,
    k_norm_weight: cute.Tensor,
    q_gate_weight: cute.Tensor,
    k_weight: cute.Tensor,
    v_weight: cute.Tensor,
    out_weight: cute.Tensor,
    post_norm_weight: cute.Tensor,
    gate_weight: cute.Tensor,
    up_weight: cute.Tensor,
    down_weight: cute.Tensor,
    cos: cute.Tensor,
    sin: cute.Tensor,
    norm1_workspace: cute.Tensor,
    q_gate_workspace: cute.Tensor,
    k_workspace: cute.Tensor,
    v_workspace: cute.Tensor,
    query_workspace: cute.Tensor,
    key_workspace: cute.Tensor,
    score_workspace: cute.Tensor,
    probability_workspace: cute.Tensor,
    context_workspace: cute.Tensor,
    residual_workspace: cute.Tensor,
    norm2_workspace: cute.Tensor,
    gate_workspace: cute.Tensor,
    up_workspace: cute.Tensor,
    mlp_workspace: cute.Tensor,
    output: cute.Tensor,
):
    rms_norm_kernel(hidden, input_norm_weight, norm1_workspace).launch(
        grid=(TOKENS, 1, 1), block=(1, 1, 1)
    )
    proj_qkv_kernel(norm1_workspace, q_gate_weight, q_gate_workspace).launch(
        grid=(Q_GATE_SIZE, TOKENS, 1), block=(1, 1, 1)
    )
    proj_qkv_kernel(norm1_workspace, k_weight, k_workspace).launch(
        grid=(KV_SIZE, TOKENS, 1), block=(1, 1, 1)
    )
    proj_qkv_kernel(norm1_workspace, v_weight, v_workspace).launch(
        grid=(KV_SIZE, TOKENS, 1), block=(1, 1, 1)
    )
    q_headnorm_kernel(
        q_gate_workspace, q_norm_weight, cos, sin, query_workspace
    ).launch(grid=(NUM_HEADS, TOKENS, 1), block=(1, 1, 1))
    k_headnorm_kernel(
        k_workspace, k_norm_weight, cos, sin, key_workspace
    ).launch(grid=(NUM_KV_HEADS, TOKENS, 1), block=(1, 1, 1))
    attention_kernel(
        query_workspace, key_workspace, v_workspace, q_gate_workspace,
        score_workspace, probability_workspace, context_workspace,
    ).launch(grid=(NUM_HEADS, TOKENS, 1), block=(1, 1, 1))
    out_proj_kernel(
        context_workspace, out_weight, hidden, residual_workspace
    ).launch(grid=(HIDDEN_SIZE, TOKENS, 1), block=(1, 1, 1))
    post_norm_kernel(residual_workspace, post_norm_weight, norm2_workspace).launch(
        grid=(TOKENS, 1, 1), block=(1, 1, 1)
    )
    proj_mlp_kernel(norm2_workspace, gate_weight, gate_workspace).launch(
        grid=(INTERMEDIATE_SIZE, TOKENS, 1), block=(1, 1, 1)
    )
    proj_mlp_kernel(norm2_workspace, up_weight, up_workspace).launch(
        grid=(INTERMEDIATE_SIZE, TOKENS, 1), block=(1, 1, 1)
    )
    swiglu_kernel(gate_workspace, up_workspace, mlp_workspace).launch(
        grid=(INTERMEDIATE_SIZE, TOKENS, 1), block=(1, 1, 1)
    )
    down_proj_kernel(
        mlp_workspace, down_weight, residual_workspace, output
    ).launch(grid=(HIDDEN_SIZE, TOKENS, 1), block=(1, 1, 1))


class ModelNew:
    forward = staticmethod(qwen35_full_attention_block)
