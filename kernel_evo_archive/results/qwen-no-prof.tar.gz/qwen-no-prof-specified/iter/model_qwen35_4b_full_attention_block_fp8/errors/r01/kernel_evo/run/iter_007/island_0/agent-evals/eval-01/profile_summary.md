# B300 device profile of your last candidate

- device: NVIDIA B300 SXM6 AC, 148 SMs, 232448 B opt-in shared memory/block
- GPU busy: 321.391 ms total; kernels 321.353 ms over 900 launches of 57 distinct names
- memcpy: 0.034 ms over 17 calls; memset: 0.004 ms over 2 calls

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_down_proj_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 62.907 | 55 | 19.6 |
| kernel_cutlass_proj_mlp_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 57.922 | 55 | 18.0 |
| kernel_cutlass_proj_mlp_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 57.902 | 55 | 18.0 |
| kernel_cutlass_proj_qkv_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 51.548 | 55 | 16.0 |
| kernel_cutlass_swiglu_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmemali… | 33.370 | 55 | 10.4 |
| kernel_cutlass_out_proj_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 25.367 | 55 | 7.9 |
| kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 14.261 | 55 | 4.4 |
| kernel_cutlass_proj_qkv_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 6.791 | 55 | 2.1 |
| kernel_cutlass_proj_qkv_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 6.779 | 55 | 2.1 |
| kernel_cutlass_post_norm_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo25601_tensorptrf… | 1.639 | 55 | 0.5 |
