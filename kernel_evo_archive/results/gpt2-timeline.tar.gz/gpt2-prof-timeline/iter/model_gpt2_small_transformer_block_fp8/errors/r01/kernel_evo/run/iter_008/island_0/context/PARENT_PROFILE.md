# Parent profile and optimization guidance

# B300 complete GPU timeline of your last candidate

- complete GPU-side trace: 519 activities; CPU/Python profiler records are intentionally omitted
- whole capture: span 5323.310 ms; active union 18.570 ms; idle holes 5304.740 ms (99.7%); largest hole 5039.188 ms
- that idle figure covers input generation, JIT compilation and the reference as well as your block, so it is not a measure of your kernels; the per-iteration section below is
- summed activity time: 18.570 ms; this may exceed active union when streams overlap
- source labels are hints: `candidate:<symbol>` is matched against this candidate's `@cute.kernel` definitions; other labels describe likely harness/runtime work
- candidate `@cute.kernel` symbols: `attention_kernel`, `fc_gelu_kernel`, `ln1_kernel`, `ln2_kernel`, `out_gemm_kernel`, `proj_gemm_kernel`, `qkv_gemm_kernel`
- observed candidate symbols: `attention_kernel`, `fc_gelu_kernel`, `ln1_kernel`, `ln2_kernel`, `out_gemm_kernel`, `proj_gemm_kernel`, `qkv_gemm_kernel`
- candidate symbols not observed in this trace: none

## One iteration of your block, launch by launch

Median of 55 timed iterations, 7 launches each. Microseconds from the start of the iteration.

- wall span 331.329; kernels busy 328.802; idle between your kernels 2.527 (0.8% of the span)
- largest single gap 1.056 immediately before `qkv_gemm_kernel`
- 44.896 elapses between one iteration and the next; that is host-side dispatch outside your block, excluded from the idle figure above, and fusing cannot remove it

| # | kernel | id | start | end | dur | idle before |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 1 | ln1_kernel | K24 | 0.000 | 3.264 | 3.264 | — |
| 2 | qkv_gemm_kernel | K25 | 4.320 | 50.240 | 45.920 | 1.056 |
| 3 | attention_kernel | K26 | 50.528 | 106.816 | 56.288 | 0.288 |
| 4 | out_gemm_kernel | K27 | 107.232 | 141.120 | 33.888 | 0.416 |
| 5 | ln2_kernel | K28 | 141.376 | 144.640 | 3.264 | 0.256 |
| 6 | fc_gelu_kernel | K29 | 144.896 | 201.985 | 57.089 | 0.256 |
| 7 | proj_gemm_kernel | K30 | 202.240 | 331.329 | 129.089 | 0.255 |

## Hottest GPU kernels (legacy aggregate)

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_proj_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 7.124 | 55 | 38.4 |
| kernel_cutlass_fc_gelu_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmemal… | 3.145 | 55 | 16.9 |
| kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 3.097 | 55 | 16.7 |
| kernel_cutlass_qkv_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 2.527 | 55 | 13.6 |
| kernel_cutlass_out_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 1.868 | 55 | 10.1 |
| kernel_cutlass_ln2_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo7681_tensorptrf32gmemo… | 0.182 | 55 | 1.0 |
| kernel_cutlass_ln1_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo7681_tenso… | 0.176 | 55 | 0.9 |
| void sgemm_largek_lds64<true, false, 6, 3, 4, 5, 2, 66>(float*, float const*, float con… | 0.060 | 1 | 0.3 |
| cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 0.041 | 4 | 0.2 |
| void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 0.033 | 17 | 0.2 |

## Kernel legend

| id | source hint | kernel | calls | total us | launch |
| --- | --- | --- | ---: | ---: | --- |
| K1 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 1 | 2.591 | grid=384x1x1, block=256x1x1, smem=0, regs=56 |
| K2 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 6 | 12.128 | grid=3x1x1, block=256x1x1, smem=0, regs=56 |
| K3 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 6 | 10.689 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K4 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::CUDAFunctorOnSelf_add<flo… | 2 | 3.616 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K5 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 1 | 2.144 | grid=9x1x1, block=256x1x1, smem=0, regs=56 |
| K6 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 2 | 3.298 | grid=3x1x1, block=128x1x1, smem=0, regs=32 |
| K7 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 1 | 1.824 | grid=12x1x1, block=256x1x1, smem=0, regs=56 |
| K8 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 4 | 22.144 | grid=1184x1x1, block=256x1x1, smem=0, regs=56 |
| K9 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 7 | 11.840 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K10 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 4 | 7.456 | grid=256x1x1, block=128x1x1, smem=0, regs=20 |
| K11 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 1 | 2.784 | grid=1728x1x1, block=128x1x1, smem=0, regs=32 |
| K12 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 2 | 8.576 | grid=4608x1x1, block=128x1x1, smem=0, regs=20 |
| K13 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 1 | 2.017 | grid=576x1x1, block=128x1x1, smem=0, regs=32 |
| K14 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 2.560 | grid=1536x1x1, block=128x1x1, smem=0, regs=20 |
| K15 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 6.464 | grid=2304x1x1, block=128x1x1, smem=0, regs=32 |
| K16 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 5.056 | grid=6144x1x1, block=128x1x1, smem=0, regs=20 |
| K17 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::… | 3 | 4.384 | grid=96x1x1, block=128x1x1, smem=0, regs=16 |
| K18 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::… | 1 | 1.663 | grid=288x1x1, block=128x1x1, smem=0, regs=16 |
| K19 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 3.232 | grid=288x1x1, block=128x1x1, smem=0, regs=32 |
| K20 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 1.952 | grid=640x1x1, block=128x1x1, smem=0, regs=20 |
| K21 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::… | 1 | 1.376 | grid=384x1x1, block=128x1x1, smem=0, regs=16 |
| K22 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 3.200 | grid=384x1x1, block=128x1x1, smem=0, regs=32 |
| K23 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 2.080 | grid=768x1x1, block=128x1x1, smem=0, regs=20 |
| K24 | candidate:ln1_kernel | kernel_cutlass_ln1_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo7681_tenso… | 55 | 176.248 | grid=128x1x1, block=128x1x1, smem=1024, regs=32 |
| K25 | candidate:qkv_gemm_kernel | kernel_cutlass_qkv_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 55 | 2526.759 | grid=36x8x1, block=128x1x1, smem=20480, regs=128 |
| K26 | candidate:attention_kernel | kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 55 | 3096.680 | grid=12x128x1, block=128x1x1, smem=1024, regs=40 |
| K27 | candidate:out_gemm_kernel | kernel_cutlass_out_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 55 | 1867.653 | grid=12x8x1, block=128x1x1, smem=20480, regs=128 |
| K28 | candidate:ln2_kernel | kernel_cutlass_ln2_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo7681_tensorptrf32gmemo… | 55 | 181.663 | grid=128x1x1, block=128x1x1, smem=1024, regs=32 |
| K29 | candidate:fc_gelu_kernel | kernel_cutlass_fc_gelu_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmemal… | 55 | 3144.522 | grid=48x8x1, block=128x1x1, smem=20480, regs=128 |
| K30 | candidate:proj_gemm_kernel | kernel_cutlass_proj_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 55 | 7123.634 | grid=12x8x1, block=128x1x1, smem=20480, regs=128 |
| K31 | framework/validation | void at::native::unrolled_elementwise_kernel<at::native::direct_copy_kernel_cuda(at::Te… | 1 | 4.000 | grid=192x1x1, block=128x1x1, smem=0, regs=30 |
| K32 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 1 | 1.824 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K33 | framework/validation | void at::native::(anonymous namespace)::vectorized_layer_norm_kernel<float, float, fals… | 4 | 15.969 | grid=128x1x1, block=32x4x1, smem=24, regs=40 |
| K34 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::float8_copy_kernel_cuda(a… | 3 | 5.503 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K35 | framework/validation | nvjet_sm103_qqsss_64x32_128x16_2x1_2cta_v_bz_TNT | 1 | 3.136 | grid=144x1x1, block=256x1x1, smem=172552, regs=255 |
| K36 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 4.896 | grid=1152x1x1, block=128x1x1, smem=0, regs=20 |
| K37 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::float8_copy_kernel_cuda(a… | 1 | 2.048 | grid=288x1x1, block=128x1x1, smem=0, regs=32 |
| K38 | framework/validation | void at::native::unrolled_elementwise_kernel<at::native::direct_copy_kernel_cuda(at::Te… | 1 | 3.616 | grid=576x1x1, block=128x1x1, smem=0, regs=30 |
| K39 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 1 | 1.857 | grid=288x1x1, block=128x1x1, smem=0, regs=32 |
| K40 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 2 | 8.576 | grid=4x4x12, block=64x1x1, smem=13056, regs=72 |
| K41 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 3.457 | grid=192x1x1, block=128x1x1, smem=0, regs=32 |
| K42 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<bool>, std::a… | 1 | 1.184 | grid=8x1x1, block=128x1x1, smem=0, regs=16 |
| K43 | framework/validation | void at::native::triu_tril_kernel<bool, int, true, 8, false>(at::cuda::detail::TensorIn… | 1 | 2.273 | grid=16x1x1, block=128x1x1, smem=0, regs=30 |
| K44 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 4.545 | grid=768x1x1, block=128x1x1, smem=0, regs=20 |
| K45 | framework/validation | void (anonymous namespace)::softmax_warp_forward<float, float, float, 7, false, false>(… | 2 | 6.561 | grid=192x1x1, block=32x4x1, smem=0, regs=32 |
| K46 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_nnn_align1_bias_f32_relu | 2 | 10.208 | grid=2x4x12, block=64x1x1, smem=12672, regs=84 |
| K47 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 4.672 | grid=384x1x1, block=128x1x1, smem=0, regs=20 |
| K48 | framework/validation | nvjet_sm103_qqsss_64x16_128x16_2x4_2cta_h_bz_TNT | 2 | 7.008 | grid=96x1x1, block=256x1x1, smem=156168, regs=255 |
| K49 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 4 | 9.344 | grid=384x1x1, block=128x1x1, smem=0, regs=20 |
| K50 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::CUDAFunctor_add<float>, s… | 5 | 8.831 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K51 | framework/validation | nvjet_sm103_qqsss_48x64_128x16_2x2_2cta_h_bz_TNN | 1 | 3.296 | grid=128x1x1, block=256x1x1, smem=188944, regs=255 |
| K52 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 5.215 | grid=1536x1x1, block=128x1x1, smem=0, regs=20 |
| K53 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::GeluCUDAKernelImpl(at::Te… | 2 | 3.967 | grid=384x1x1, block=128x1x1, smem=0, regs=32 |
| K54 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::float8_copy_kernel_cuda(a… | 1 | 2.080 | grid=384x1x1, block=128x1x1, smem=0, regs=32 |
| K55 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 1 | 16.832 | grid=72x4x1, block=64x1x1, smem=13056, regs=72 |
| K56 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 1 | 15.488 | grid=24x4x1, block=64x1x1, smem=13056, regs=72 |
| K57 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_64x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 1 | 22.464 | grid=48x4x1, block=64x1x1, smem=19200, regs=146 |
| K58 | framework/validation | void scal_kernel<float, float, 1, true, 6, 5, 5, 3>(cublasTransposeParams<float>, float… | 1 | 1.312 | grid=12x4x1, block=256x1x1, smem=0, regs=24 |
| K59 | framework/validation | void sgemm_largek_lds64<true, false, 6, 3, 4, 5, 2, 66>(float*, float const*, float con… | 1 | 59.648 | grid=12x16x4, block=32x4x1, smem=4868, regs=32 |
| K60 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AbsFunctor<float>, std::a… | 2 | 3.552 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K61 | framework/validation | void at::native::reduce_kernel<512, 1, at::native::ReduceOp<float, at::native::func_wra… | 1 | 13.312 | grid=1x1x1, block=512x1x1, smem=2064, regs=30 |
| K62 | framework/validation | void at::native::(anonymous namespace)::indexSelectSmallIndex<float, long, unsigned int… | 2 | 8.129 | grid=6x1x1, block=128x1x1, smem=0, regs=28 |
| K63 | framework/validation | void at::native::(anonymous namespace)::indexSelectSmallIndex<float, long, unsigned int… | 2 | 7.680 | grid=1x1x1, block=7x1x1, smem=0, regs=28 |
| K64 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::CUDAFunctor_add<float>, s… | 1 | 1.729 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K65 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AbsFunctor<float>, std::a… | 1 | 1.760 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K66 | framework/validation | void at::native::reduce_kernel<512, 1, at::native::ReduceOp<float, at::native::func_wra… | 1 | 2.433 | grid=1x1x1, block=32x1x1, smem=16, regs=30 |
| K67 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 1 | 1.504 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K68 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BinaryFunctor<float, floa… | 1 | 1.536 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K69 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BinaryFunctor<bool, bool,… | 1 | 1.440 | grid=96x1x1, block=128x1x1, smem=0, regs=30 |
| K70 | framework/validation | void at::native::reduce_kernel<512, 1, at::native::ReduceOp<bool, at::native::func_wrap… | 1 | 12.544 | grid=1x1x1, block=512x1x1, smem=528, regs=28 |

## Ordered GPU activities

`gap before` is device-wide idle time since all earlier GPU activity ended; zero means overlap or no measurable hole.

| # | start ms | gap before us | duration us | lane | activity |
| ---: | ---: | ---: | ---: | --- | --- |
| 1 | 0.000 | 0.000 | 2.591 | d0/s7 | K1 |
| 2 | 0.150 | 147.553 | 2.144 | d0/s7 | K2 |
| 3 | 0.220 | 67.808 | 1.984 | d0/s7 | K3 |
| 4 | 0.290 | 67.584 | 1.984 | d0/s7 | K4 |
| 5 | 0.323 | 30.880 | 2.144 | d0/s7 | K2 |
| 6 | 0.337 | 12.128 | 1.568 | d0/s7 | K3 |
| 7 | 0.354 | 16.096 | 1.792 | d0/s7 | K2 |
| 8 | 0.367 | 10.528 | 1.568 | d0/s7 | K3 |
| 9 | 0.379 | 10.304 | 1.632 | d0/s7 | K4 |
| 10 | 0.396 | 15.360 | 2.112 | d0/s7 | K2 |
| 11 | 0.408 | 10.272 | 1.985 | d0/s7 | K3 |
| 12 | 0.426 | 15.903 | 2.144 | d0/s7 | K5 |
| 13 | 0.443 | 15.008 | 1.825 | d0/s7 | K6 |
| 14 | 0.461 | 15.935 | 1.792 | d0/s7 | K2 |
| 15 | 0.473 | 10.273 | 1.600 | d0/s7 | K3 |
| 16 | 0.490 | 16.000 | 1.824 | d0/s7 | K7 |
| 17 | 0.504 | 11.263 | 1.473 | d0/s7 | K6 |
| 18 | 0.521 | 15.936 | 2.144 | d0/s7 | K2 |
| 19 | 0.534 | 10.848 | 1.984 | d0/s7 | K3 |
| 20 | 0.556 | 20.352 | 5.920 | d0/s7 | K8 |
| 21 | 0.575 | 12.480 | 4.384 | d0/s7 | K8 |
| 22 | 0.594 | 14.752 | 5.920 | d0/s7 | K8 |
| 23 | 0.614 | 14.496 | 5.920 | d0/s7 | K8 |
| 24 | 0.652 | 31.648 | 1.664 | d0/s7 | K9 |
| 25 | 29.614 | 28960.969 | 1.824 | d0/s7 | K10 |
| 26 | 29.836 | 220.191 | 2.784 | d0/s7 | K11 |
| 27 | 54.882 | 25042.815 | 4.192 | d0/s7 | K12 |
| 28 | 55.085 | 198.624 | 2.017 | d0/s7 | K13 |
| 29 | 81.126 | 26038.945 | 2.560 | d0/s7 | K14 |
| 30 | 81.313 | 184.480 | 3.232 | d0/s7 | K15 |
| 31 | 106.106 | 24790.142 | 5.056 | d0/s7 | K16 |
| 32 | 106.300 | 188.737 | 3.232 | d0/s7 | K15 |
| 33 | 131.425 | 25122.047 | 4.384 | d0/s7 | K12 |
| 34 | 131.609 | 179.136 | 1.600 | d0/s7 | K17 |
| 35 | 131.674 | 63.041 | 1.792 | d0/s7 | K9 |
| 36 | 156.388 | 24712.509 | 1.856 | d0/s7 | K10 |
| 37 | 156.559 | 168.897 | 1.663 | d0/s7 | K18 |
| 38 | 156.621 | 60.865 | 1.472 | d0/s7 | K19 |
| 39 | 181.643 | 25019.999 | 1.952 | d0/s7 | K20 |
| 40 | 181.810 | 165.568 | 1.216 | d0/s7 | K17 |
| 41 | 181.873 | 62.144 | 1.408 | d0/s7 | K9 |
| 42 | 206.553 | 24678.238 | 1.856 | d0/s7 | K10 |
| 43 | 206.721 | 165.696 | 1.568 | d0/s7 | K17 |
| 44 | 206.784 | 61.312 | 1.728 | d0/s7 | K9 |
| 45 | 231.427 | 24642.046 | 1.920 | d0/s7 | K10 |
| 46 | 231.597 | 168.192 | 1.376 | d0/s7 | K21 |
| 47 | 231.661 | 62.080 | 1.600 | d0/s7 | K22 |
| 48 | 256.802 | 25139.968 | 2.080 | d0/s7 | K23 |
| 49 | 5295.993 | 5039188.290 | 3.872 | d0/s7 | K24 |
| 50 | 5296.010 | 13.504 | 52.545 | d0/s7 | K25 |
| 51 | 5296.063 | 0.255 | 56.449 | d0/s7 | K26 |
| 52 | 5296.120 | 0.256 | 39.807 | d0/s7 | K27 |
| 53 | 5296.160 | 0.289 | 3.360 | d0/s7 | K28 |
| 54 | 5296.163 | 0.256 | 59.904 | d0/s7 | K29 |
| 55 | 5296.224 | 0.256 | 152.640 | d0/s7 | K30 |
| 56 | 5296.376 | 0.256 | 3.136 | d0/s7 | K24 |
| 57 | 5296.380 | 0.255 | 45.536 | d0/s7 | K25 |
| 58 | 5296.426 | 0.256 | 56.225 | d0/s7 | K26 |
| 59 | 5296.482 | 0.480 | 33.887 | d0/s7 | K27 |
| 60 | 5296.516 | 0.257 | 3.328 | d0/s7 | K28 |
| 61 | 5296.520 | 0.255 | 57.089 | d0/s7 | K29 |
| 62 | 5296.577 | 0.256 | 128.928 | d0/s7 | K30 |
| 63 | 5296.707 | 0.288 | 3.104 | d0/s7 | K24 |
| 64 | 5296.710 | 0.256 | 45.696 | d0/s7 | K25 |
| 65 | 5296.756 | 0.256 | 56.288 | d0/s7 | K26 |
| 66 | 5296.813 | 0.512 | 33.888 | d0/s7 | K27 |
| 67 | 5296.847 | 0.255 | 3.328 | d0/s7 | K28 |
| 68 | 5296.850 | 0.256 | 56.993 | d0/s7 | K29 |
| 69 | 5296.908 | 0.256 | 129.152 | d0/s7 | K30 |
| 70 | 5297.037 | 0.289 | 3.104 | d0/s7 | K24 |
| 71 | 5297.041 | 0.256 | 45.824 | d0/s7 | K25 |
| 72 | 5297.087 | 0.256 | 56.192 | d0/s7 | K26 |
| 73 | 5297.143 | 0.448 | 33.856 | d0/s7 | K27 |
| 74 | 5297.177 | 0.256 | 3.328 | d0/s7 | K28 |
| 75 | 5297.181 | 0.288 | 57.472 | d0/s7 | K29 |
| 76 | 5297.239 | 0.257 | 129.152 | d0/s7 | K30 |
| 77 | 5297.368 | 0.256 | 3.264 | d0/s7 | K24 |
| 78 | 5297.372 | 0.256 | 45.696 | d0/s7 | K25 |
| 79 | 5297.418 | 0.256 | 56.224 | d0/s7 | K26 |
| 80 | 5297.474 | 0.479 | 33.856 | d0/s7 | K27 |
| 81 | 5297.508 | 0.256 | 3.264 | d0/s7 | K28 |
| 82 | 5297.512 | 0.256 | 57.120 | d0/s7 | K29 |
| 83 | 5297.569 | 0.256 | 129.057 | d0/s7 | K30 |
| 84 | 5297.928 | 229.664 | 3.264 | d0/s7 | K24 |
| 85 | 5297.933 | 1.312 | 45.888 | d0/s7 | K25 |
| 86 | 5297.979 | 0.256 | 56.096 | d0/s7 | K26 |
| 87 | 5298.035 | 0.480 | 33.857 | d0/s7 | K27 |
| 88 | 5298.069 | 0.256 | 3.295 | d0/s7 | K28 |
| 89 | 5298.073 | 0.257 | 57.184 | d0/s7 | K29 |
| 90 | 5298.130 | 0.224 | 129.184 | d0/s7 | K30 |
| 91 | 5298.340 | 80.544 | 3.264 | d0/s7 | K24 |
| 92 | 5298.345 | 1.216 | 45.889 | d0/s7 | K25 |
| 93 | 5298.391 | 0.255 | 56.257 | d0/s7 | K26 |
| 94 | 5298.447 | 0.448 | 33.792 | d0/s7 | K27 |
| 95 | 5298.481 | 0.256 | 3.264 | d0/s7 | K28 |
| 96 | 5298.485 | 0.256 | 57.280 | d0/s7 | K29 |
| 97 | 5298.543 | 0.224 | 128.992 | d0/s7 | K30 |
| 98 | 5298.717 | 45.888 | 3.232 | d0/s7 | K24 |
| 99 | 5298.722 | 0.928 | 45.760 | d0/s7 | K25 |
| 100 | 5298.768 | 0.256 | 56.417 | d0/s7 | K26 |
| 101 | 5298.824 | 0.480 | 33.856 | d0/s7 | K27 |
| 102 | 5298.859 | 0.256 | 3.264 | d0/s7 | K28 |
| 103 | 5298.862 | 0.256 | 57.280 | d0/s7 | K29 |
| 104 | 5298.920 | 0.256 | 129.184 | d0/s7 | K30 |
| 105 | 5299.099 | 50.240 | 3.104 | d0/s7 | K24 |
| 106 | 5299.103 | 1.312 | 45.984 | d0/s7 | K25 |
| 107 | 5299.150 | 0.256 | 56.352 | d0/s7 | K26 |
| 108 | 5299.207 | 0.480 | 33.857 | d0/s7 | K27 |
| 109 | 5299.241 | 0.256 | 3.360 | d0/s7 | K28 |
| 110 | 5299.244 | 0.256 | 57.056 | d0/s7 | K29 |
| 111 | 5299.302 | 0.256 | 128.992 | d0/s7 | K30 |
| 112 | 5299.477 | 46.048 | 3.104 | d0/s7 | K24 |
| 113 | 5299.481 | 0.960 | 45.888 | d0/s7 | K25 |
| 114 | 5299.527 | 0.256 | 56.448 | d0/s7 | K26 |
| 115 | 5299.584 | 0.479 | 33.889 | d0/s7 | K27 |
| 116 | 5299.618 | 0.256 | 3.327 | d0/s7 | K28 |
| 117 | 5299.621 | 0.257 | 57.280 | d0/s7 | K29 |
| 118 | 5299.679 | 0.224 | 129.184 | d0/s7 | K30 |
| 119 | 5299.853 | 44.896 | 3.136 | d0/s7 | K24 |
| 120 | 5299.859 | 2.368 | 45.888 | d0/s7 | K25 |
| 121 | 5299.905 | 0.224 | 56.256 | d0/s7 | K26 |
| 122 | 5299.961 | 0.449 | 33.855 | d0/s7 | K27 |
| 123 | 5299.996 | 0.257 | 3.328 | d0/s7 | K28 |
| 124 | 5299.999 | 0.288 | 56.992 | d0/s7 | K29 |
| 125 | 5300.056 | 0.256 | 129.152 | d0/s7 | K30 |
| 126 | 5300.230 | 44.608 | 3.136 | d0/s7 | K24 |
| 127 | 5300.234 | 0.960 | 45.856 | d0/s7 | K25 |
| 128 | 5300.280 | 0.256 | 56.449 | d0/s7 | K26 |
| 129 | 5300.337 | 0.447 | 33.793 | d0/s7 | K27 |
| 130 | 5300.371 | 0.256 | 3.360 | d0/s7 | K28 |
| 131 | 5300.375 | 0.256 | 57.152 | d0/s7 | K29 |
| 132 | 5300.432 | 0.256 | 129.184 | d0/s7 | K30 |
| 133 | 5300.605 | 43.616 | 3.296 | d0/s7 | K24 |
| 134 | 5300.610 | 1.376 | 45.856 | d0/s7 | K25 |
| 135 | 5300.656 | 0.256 | 56.193 | d0/s7 | K26 |
| 136 | 5300.713 | 0.480 | 33.792 | d0/s7 | K27 |
| 137 | 5300.747 | 0.288 | 3.264 | d0/s7 | K28 |
| 138 | 5300.750 | 0.256 | 56.992 | d0/s7 | K29 |
| 139 | 5300.807 | 0.256 | 129.184 | d0/s7 | K30 |
| 140 | 5300.981 | 43.968 | 3.264 | d0/s7 | K24 |
| 141 | 5300.985 | 0.896 | 45.825 | d0/s7 | K25 |
| 142 | 5301.031 | 0.223 | 56.352 | d0/s7 | K26 |
| 143 | 5301.088 | 0.480 | 33.729 | d0/s7 | K27 |
| 144 | 5301.122 | 0.255 | 3.265 | d0/s7 | K28 |
| 145 | 5301.125 | 0.255 | 57.057 | d0/s7 | K29 |
| 146 | 5301.182 | 0.224 | 129.184 | d0/s7 | K30 |
| 147 | 5301.355 | 43.008 | 3.232 | d0/s7 | K24 |
| 148 | 5301.359 | 1.280 | 45.632 | d0/s7 | K25 |
| 149 | 5301.405 | 0.256 | 56.385 | d0/s7 | K26 |
| 150 | 5301.462 | 0.447 | 33.857 | d0/s7 | K27 |
| 151 | 5301.496 | 0.256 | 3.264 | d0/s7 | K28 |
| 152 | 5301.499 | 0.256 | 57.088 | d0/s7 | K29 |
| 153 | 5301.557 | 0.256 | 129.120 | d0/s7 | K30 |
| 154 | 5301.729 | 43.392 | 3.296 | d0/s7 | K24 |
| 155 | 5301.733 | 0.768 | 45.824 | d0/s7 | K25 |
| 156 | 5301.779 | 0.288 | 56.256 | d0/s7 | K26 |
| 157 | 5301.836 | 0.449 | 33.887 | d0/s7 | K27 |
| 158 | 5301.870 | 0.255 | 3.232 | d0/s7 | K28 |
| 159 | 5301.874 | 0.257 | 57.248 | d0/s7 | K29 |
| 160 | 5301.931 | 0.287 | 129.121 | d0/s7 | K30 |
| 161 | 5302.105 | 44.704 | 3.104 | d0/s7 | K24 |
| 162 | 5302.114 | 5.664 | 45.856 | d0/s7 | K25 |
| 163 | 5302.160 | 0.256 | 56.288 | d0/s7 | K26 |
| 164 | 5302.217 | 0.480 | 33.889 | d0/s7 | K27 |
| 165 | 5302.251 | 0.256 | 3.327 | d0/s7 | K28 |
| 166 | 5302.255 | 0.257 | 57.152 | d0/s7 | K29 |
| 167 | 5302.312 | 0.256 | 128.992 | d0/s7 | K30 |
| 168 | 5302.485 | 44.479 | 3.136 | d0/s7 | K24 |
| 169 | 5302.490 | 1.536 | 45.760 | d0/s7 | K25 |
| 170 | 5302.536 | 0.256 | 56.288 | d0/s7 | K26 |
| 171 | 5302.593 | 0.448 | 33.921 | d0/s7 | K27 |
| 172 | 5302.627 | 0.255 | 3.328 | d0/s7 | K28 |
| 173 | 5302.631 | 0.257 | 57.215 | d0/s7 | K29 |
| 174 | 5302.688 | 0.225 | 129.216 | d0/s7 | K30 |
| 175 | 5302.860 | 43.200 | 3.136 | d0/s7 | K24 |
| 176 | 5302.867 | 3.136 | 45.632 | d0/s7 | K25 |
| 177 | 5302.913 | 0.256 | 56.224 | d0/s7 | K26 |
| 178 | 5302.969 | 0.480 | 33.952 | d0/s7 | K27 |
| 179 | 5303.004 | 0.256 | 3.329 | d0/s7 | K28 |
| 180 | 5303.007 | 0.255 | 57.025 | d0/s7 | K29 |
| 181 | 5303.064 | 0.255 | 129.249 | d0/s7 | K30 |
| 182 | 5303.238 | 44.832 | 3.104 | d0/s7 | K24 |
| 183 | 5303.242 | 0.800 | 45.856 | d0/s7 | K25 |
| 184 | 5303.289 | 0.256 | 56.256 | d0/s7 | K26 |
| 185 | 5303.345 | 0.480 | 33.792 | d0/s7 | K27 |
| 186 | 5303.379 | 0.256 | 3.360 | d0/s7 | K28 |
| 187 | 5303.383 | 0.257 | 57.056 | d0/s7 | K29 |
| 188 | 5303.440 | 0.224 | 129.056 | d0/s7 | K30 |
| 189 | 5303.613 | 43.776 | 3.296 | d0/s7 | K24 |
| 190 | 5303.617 | 1.024 | 45.824 | d0/s7 | K25 |
| 191 | 5303.663 | 0.256 | 56.128 | d0/s7 | K26 |
| 192 | 5303.720 | 0.480 | 33.857 | d0/s7 | K27 |
| 193 | 5303.754 | 0.255 | 3.265 | d0/s7 | K28 |
| 194 | 5303.758 | 0.255 | 57.249 | d0/s7 | K29 |
| 195 | 5303.815 | 0.256 | 129.248 | d0/s7 | K30 |
| 196 | 5303.989 | 44.896 | 3.264 | d0/s7 | K24 |
| 197 | 5303.994 | 1.056 | 45.920 | d0/s7 | K25 |
| 198 | 5304.040 | 0.288 | 56.288 | d0/s7 | K26 |
| 199 | 5304.097 | 0.416 | 33.888 | d0/s7 | K27 |
| 200 | 5304.131 | 0.256 | 3.264 | d0/s7 | K28 |
| 201 | 5304.134 | 0.256 | 57.089 | d0/s7 | K29 |
| 202 | 5304.192 | 0.255 | 129.089 | d0/s7 | K30 |
| 203 | 5304.364 | 43.840 | 3.264 | d0/s7 | K24 |
| 204 | 5304.369 | 1.472 | 45.824 | d0/s7 | K25 |
| 205 | 5304.415 | 0.256 | 56.224 | d0/s7 | K26 |
| 206 | 5304.472 | 0.480 | 33.792 | d0/s7 | K27 |
| 207 | 5304.506 | 0.257 | 3.263 | d0/s7 | K28 |
| 208 | 5304.510 | 0.257 | 57.184 | d0/s7 | K29 |
| 209 | 5304.567 | 0.256 | 128.864 | d0/s7 | K30 |
| 210 | 5304.741 | 45.120 | 3.264 | d0/s7 | K24 |
| 211 | 5304.745 | 0.864 | 45.792 | d0/s7 | K25 |
| 212 | 5304.791 | 0.256 | 56.256 | d0/s7 | K26 |
| 213 | 5304.848 | 0.480 | 33.888 | d0/s7 | K27 |
| 214 | 5304.882 | 0.256 | 3.264 | d0/s7 | K28 |
| 215 | 5304.886 | 0.256 | 57.121 | d0/s7 | K29 |
| 216 | 5304.943 | 0.256 | 129.056 | d0/s7 | K30 |
| 217 | 5305.116 | 44.032 | 3.136 | d0/s7 | K24 |
| 218 | 5305.120 | 0.608 | 45.824 | d0/s7 | K25 |
| 219 | 5305.166 | 0.256 | 56.320 | d0/s7 | K26 |
| 220 | 5305.223 | 0.448 | 33.888 | d0/s7 | K27 |
| 221 | 5305.257 | 0.257 | 3.360 | d0/s7 | K28 |
| 222 | 5305.260 | 0.255 | 57.089 | d0/s7 | K29 |
| 223 | 5305.318 | 0.256 | 129.120 | d0/s7 | K30 |
| 224 | 5305.489 | 42.592 | 3.104 | d0/s7 | K24 |
| 225 | 5305.494 | 1.056 | 45.856 | d0/s7 | K25 |
| 226 | 5305.540 | 0.256 | 56.416 | d0/s7 | K26 |
| 227 | 5305.597 | 0.448 | 33.856 | d0/s7 | K27 |
| 228 | 5305.631 | 0.288 | 3.328 | d0/s7 | K28 |
| 229 | 5305.634 | 0.257 | 57.055 | d0/s7 | K29 |
| 230 | 5305.692 | 0.257 | 129.024 | d0/s7 | K30 |
| 231 | 5305.863 | 42.496 | 3.136 | d0/s7 | K24 |
| 232 | 5305.868 | 2.112 | 45.888 | d0/s7 | K25 |
| 233 | 5305.915 | 0.256 | 56.192 | d0/s7 | K26 |
| 234 | 5305.971 | 0.480 | 33.856 | d0/s7 | K27 |
| 235 | 5306.005 | 0.256 | 3.328 | d0/s7 | K28 |
| 236 | 5306.009 | 0.288 | 56.993 | d0/s7 | K29 |
| 237 | 5306.066 | 0.255 | 129.217 | d0/s7 | K30 |
| 238 | 5306.238 | 42.625 | 3.136 | d0/s7 | K24 |
| 239 | 5306.242 | 1.056 | 45.888 | d0/s7 | K25 |
| 240 | 5306.288 | 0.224 | 56.352 | d0/s7 | K26 |
| 241 | 5306.345 | 0.480 | 33.824 | d0/s7 | K27 |
| 242 | 5306.379 | 0.224 | 3.392 | d0/s7 | K28 |
| 243 | 5306.383 | 0.256 | 57.089 | d0/s7 | K29 |
| 244 | 5306.440 | 0.255 | 128.929 | d0/s7 | K30 |
| 245 | 5306.610 | 41.184 | 3.264 | d0/s7 | K24 |
| 246 | 5306.615 | 1.216 | 45.888 | d0/s7 | K25 |
| 247 | 5306.661 | 0.288 | 56.448 | d0/s7 | K26 |
| 248 | 5306.718 | 0.448 | 33.856 | d0/s7 | K27 |
| 249 | 5306.752 | 0.256 | 3.232 | d0/s7 | K28 |
| 250 | 5306.755 | 0.288 | 57.345 | d0/s7 | K29 |
| 251 | 5306.813 | 0.255 | 129.377 | d0/s7 | K30 |
| 252 | 5306.985 | 42.944 | 3.264 | d0/s7 | K24 |
| 253 | 5306.989 | 0.479 | 45.824 | d0/s7 | K25 |
| 254 | 5307.035 | 0.224 | 56.256 | d0/s7 | K26 |
| 255 | 5307.092 | 0.448 | 33.792 | d0/s7 | K27 |
| 256 | 5307.126 | 0.256 | 3.264 | d0/s7 | K28 |
| 257 | 5307.129 | 0.256 | 57.025 | d0/s7 | K29 |
| 258 | 5307.187 | 0.255 | 129.121 | d0/s7 | K30 |
| 259 | 5307.360 | 44.256 | 3.296 | d0/s7 | K24 |
| 260 | 5307.365 | 1.568 | 45.824 | d0/s7 | K25 |
| 261 | 5307.411 | 0.255 | 56.352 | d0/s7 | K26 |
| 262 | 5307.468 | 0.480 | 33.792 | d0/s7 | K27 |
| 263 | 5307.502 | 0.256 | 3.296 | d0/s7 | K28 |
| 264 | 5307.506 | 0.256 | 57.088 | d0/s7 | K29 |
| 265 | 5307.563 | 0.256 | 129.057 | d0/s7 | K30 |
| 266 | 5307.736 | 44.479 | 3.264 | d0/s7 | K24 |
| 267 | 5307.741 | 0.928 | 46.016 | d0/s7 | K25 |
| 268 | 5307.787 | 0.256 | 56.256 | d0/s7 | K26 |
| 269 | 5307.844 | 0.448 | 33.920 | d0/s7 | K27 |
| 270 | 5307.878 | 0.256 | 3.232 | d0/s7 | K28 |
| 271 | 5307.881 | 0.288 | 57.152 | d0/s7 | K29 |
| 272 | 5307.939 | 0.257 | 129.024 | d0/s7 | K30 |
| 273 | 5308.111 | 43.552 | 3.104 | d0/s7 | K24 |
| 274 | 5308.115 | 0.608 | 45.696 | d0/s7 | K25 |
| 275 | 5308.161 | 0.256 | 56.256 | d0/s7 | K26 |
| 276 | 5308.218 | 0.448 | 33.888 | d0/s7 | K27 |
| 277 | 5308.252 | 0.256 | 3.328 | d0/s7 | K28 |
| 278 | 5308.255 | 0.256 | 57.024 | d0/s7 | K29 |
| 279 | 5308.313 | 0.256 | 129.025 | d0/s7 | K30 |
| 280 | 5308.486 | 44.416 | 3.136 | d0/s7 | K24 |
| 281 | 5308.490 | 1.088 | 45.760 | d0/s7 | K25 |
| 282 | 5308.536 | 0.256 | 56.320 | d0/s7 | K26 |
| 283 | 5308.593 | 0.480 | 33.792 | d0/s7 | K27 |
| 284 | 5308.627 | 0.256 | 3.328 | d0/s7 | K28 |
| 285 | 5308.631 | 0.256 | 57.184 | d0/s7 | K29 |
| 286 | 5308.688 | 0.256 | 128.993 | d0/s7 | K30 |
| 287 | 5308.861 | 44.000 | 3.104 | d0/s7 | K24 |
| 288 | 5308.867 | 2.688 | 45.856 | d0/s7 | K25 |
| 289 | 5308.913 | 0.256 | 56.448 | d0/s7 | K26 |
| 290 | 5308.970 | 0.448 | 33.888 | d0/s7 | K27 |
| 291 | 5309.004 | 0.256 | 3.328 | d0/s7 | K28 |
| 292 | 5309.008 | 0.256 | 57.056 | d0/s7 | K29 |
| 293 | 5309.065 | 0.224 | 129.057 | d0/s7 | K30 |
| 294 | 5309.239 | 44.576 | 3.104 | d0/s7 | K24 |
| 295 | 5309.243 | 0.992 | 45.792 | d0/s7 | K25 |
| 296 | 5309.289 | 0.256 | 56.480 | d0/s7 | K26 |
| 297 | 5309.346 | 0.448 | 33.760 | d0/s7 | K27 |
| 298 | 5309.380 | 0.256 | 3.360 | d0/s7 | K28 |
| 299 | 5309.383 | 0.256 | 57.184 | d0/s7 | K29 |
| 300 | 5309.441 | 0.256 | 128.993 | d0/s7 | K30 |
| 301 | 5309.615 | 45.567 | 3.296 | d0/s7 | K24 |
| 302 | 5309.620 | 1.185 | 45.600 | d0/s7 | K25 |
| 303 | 5309.666 | 0.288 | 56.288 | d0/s7 | K26 |
| 304 | 5309.722 | 0.480 | 33.824 | d0/s7 | K27 |
| 305 | 5309.757 | 0.256 | 3.264 | d0/s7 | K28 |
| 306 | 5309.760 | 0.288 | 57.152 | d0/s7 | K29 |
| 307 | 5309.817 | 0.256 | 129.185 | d0/s7 | K30 |
| 308 | 5309.991 | 44.448 | 3.232 | d0/s7 | K24 |
| 309 | 5309.995 | 0.896 | 45.824 | d0/s7 | K25 |
| 310 | 5310.041 | 0.256 | 56.384 | d0/s7 | K26 |
| 311 | 5310.098 | 0.448 | 33.856 | d0/s7 | K27 |
| 312 | 5310.132 | 0.256 | 3.264 | d0/s7 | K28 |
| 313 | 5310.136 | 0.256 | 57.184 | d0/s7 | K29 |
| 314 | 5310.193 | 0.256 | 129.248 | d0/s7 | K30 |
| 315 | 5310.369 | 46.497 | 3.264 | d0/s7 | K24 |
| 316 | 5310.374 | 1.536 | 45.760 | d0/s7 | K25 |
| 317 | 5310.420 | 0.256 | 56.256 | d0/s7 | K26 |
| 318 | 5310.476 | 0.448 | 33.824 | d0/s7 | K27 |
| 319 | 5310.511 | 0.288 | 3.264 | d0/s7 | K28 |
| 320 | 5310.514 | 0.256 | 57.184 | d0/s7 | K29 |
| 321 | 5310.572 | 0.256 | 128.993 | d0/s7 | K30 |
| 322 | 5310.745 | 44.480 | 3.264 | d0/s7 | K24 |
| 323 | 5310.749 | 0.928 | 45.856 | d0/s7 | K25 |
| 324 | 5310.795 | 0.256 | 56.256 | d0/s7 | K26 |
| 325 | 5310.852 | 0.480 | 33.888 | d0/s7 | K27 |
| 326 | 5310.886 | 0.256 | 3.264 | d0/s7 | K28 |
| 327 | 5310.890 | 0.256 | 57.120 | d0/s7 | K29 |
| 328 | 5310.947 | 0.256 | 129.152 | d0/s7 | K30 |
| 329 | 5311.120 | 43.874 | 3.136 | d0/s7 | K24 |
| 330 | 5311.124 | 0.864 | 45.856 | d0/s7 | K25 |
| 331 | 5311.170 | 0.256 | 56.192 | d0/s7 | K26 |
| 332 | 5311.227 | 0.480 | 33.856 | d0/s7 | K27 |
| 333 | 5311.261 | 0.256 | 3.328 | d0/s7 | K28 |
| 334 | 5311.265 | 0.256 | 56.896 | d0/s7 | K29 |
| 335 | 5311.322 | 0.256 | 129.152 | d0/s7 | K30 |
| 336 | 5311.496 | 45.505 | 3.104 | d0/s7 | K24 |
| 337 | 5311.501 | 1.311 | 45.793 | d0/s7 | K25 |
| 338 | 5311.547 | 0.256 | 56.320 | d0/s7 | K26 |
| 339 | 5311.604 | 0.448 | 33.888 | d0/s7 | K27 |
| 340 | 5311.638 | 0.256 | 3.360 | d0/s7 | K28 |
| 341 | 5311.641 | 0.256 | 57.216 | d0/s7 | K29 |
| 342 | 5311.699 | 0.256 | 128.961 | d0/s7 | K30 |
| 343 | 5311.872 | 44.512 | 3.136 | d0/s7 | K24 |
| 344 | 5311.878 | 2.848 | 45.824 | d0/s7 | K25 |
| 345 | 5311.924 | 0.256 | 56.480 | d0/s7 | K26 |
| 346 | 5311.981 | 0.448 | 33.888 | d0/s7 | K27 |
| 347 | 5312.016 | 0.256 | 3.328 | d0/s7 | K28 |
| 348 | 5312.019 | 0.256 | 57.056 | d0/s7 | K29 |
| 349 | 5312.076 | 0.288 | 129.121 | d0/s7 | K30 |
| 350 | 5312.249 | 43.328 | 3.104 | d0/s7 | K24 |
| 351 | 5312.253 | 0.800 | 45.888 | d0/s7 | K25 |
| 352 | 5312.299 | 0.288 | 56.384 | d0/s7 | K26 |
| 353 | 5312.356 | 0.480 | 33.792 | d0/s7 | K27 |
| 354 | 5312.390 | 0.256 | 3.360 | d0/s7 | K28 |
| 355 | 5312.393 | 0.256 | 57.216 | d0/s7 | K29 |
| 356 | 5312.451 | 0.256 | 129.120 | d0/s7 | K30 |
| 357 | 5312.623 | 43.201 | 3.263 | d0/s7 | K24 |
| 358 | 5312.628 | 1.248 | 45.985 | d0/s7 | K25 |
| 359 | 5312.674 | 0.256 | 56.192 | d0/s7 | K26 |
| 360 | 5312.731 | 0.512 | 33.760 | d0/s7 | K27 |
| 361 | 5312.765 | 0.289 | 3.264 | d0/s7 | K28 |
| 362 | 5312.768 | 0.255 | 57.120 | d0/s7 | K29 |
| 363 | 5312.826 | 0.256 | 129.121 | d0/s7 | K30 |
| 364 | 5312.998 | 43.456 | 3.264 | d0/s7 | K24 |
| 365 | 5313.002 | 0.927 | 45.985 | d0/s7 | K25 |
| 366 | 5313.049 | 0.256 | 56.160 | d0/s7 | K26 |
| 367 | 5313.105 | 0.448 | 33.824 | d0/s7 | K27 |
| 368 | 5313.139 | 0.256 | 3.264 | d0/s7 | K28 |
| 369 | 5313.143 | 0.256 | 56.928 | d0/s7 | K29 |
| 370 | 5313.200 | 0.256 | 129.120 | d0/s7 | K30 |
| 371 | 5313.378 | 49.121 | 3.231 | d0/s7 | K24 |
| 372 | 5313.384 | 1.952 | 45.761 | d0/s7 | K25 |
| 373 | 5313.430 | 0.256 | 56.352 | d0/s7 | K26 |
| 374 | 5313.486 | 0.448 | 33.824 | d0/s7 | K27 |
| 375 | 5313.520 | 0.256 | 3.264 | d0/s7 | K28 |
| 376 | 5313.524 | 0.256 | 57.216 | d0/s7 | K29 |
| 377 | 5313.581 | 0.256 | 129.024 | d0/s7 | K30 |
| 378 | 5313.755 | 44.865 | 3.232 | d0/s7 | K24 |
| 379 | 5313.759 | 0.735 | 45.793 | d0/s7 | K25 |
| 380 | 5313.805 | 0.256 | 56.256 | d0/s7 | K26 |
| 381 | 5313.862 | 0.448 | 33.856 | d0/s7 | K27 |
| 382 | 5313.896 | 0.256 | 3.264 | d0/s7 | K28 |
| 383 | 5313.900 | 0.256 | 57.056 | d0/s7 | K29 |
| 384 | 5313.957 | 0.288 | 129.024 | d0/s7 | K30 |
| 385 | 5314.131 | 45.089 | 3.103 | d0/s7 | K24 |
| 386 | 5314.135 | 0.769 | 45.824 | d0/s7 | K25 |
| 387 | 5314.181 | 0.256 | 56.096 | d0/s7 | K26 |
| 388 | 5314.238 | 0.448 | 33.920 | d0/s7 | K27 |
| 389 | 5314.272 | 0.256 | 3.360 | d0/s7 | K28 |
| 390 | 5314.275 | 0.256 | 57.184 | d0/s7 | K29 |
| 391 | 5314.333 | 0.256 | 128.992 | d0/s7 | K30 |
| 392 | 5314.506 | 44.097 | 3.135 | d0/s7 | K24 |
| 393 | 5314.510 | 0.705 | 45.792 | d0/s7 | K25 |
| 394 | 5314.556 | 0.256 | 56.576 | d0/s7 | K26 |
| 395 | 5314.613 | 0.480 | 33.888 | d0/s7 | K27 |
| 396 | 5314.647 | 0.288 | 3.328 | d0/s7 | K28 |
| 397 | 5314.651 | 0.256 | 57.024 | d0/s7 | K29 |
| 398 | 5314.708 | 0.224 | 128.928 | d0/s7 | K30 |
| 399 | 5314.880 | 42.945 | 3.135 | d0/s7 | K24 |
| 400 | 5314.884 | 1.217 | 45.823 | d0/s7 | K25 |
| 401 | 5314.930 | 0.257 | 56.192 | d0/s7 | K26 |
| 402 | 5314.987 | 0.448 | 33.856 | d0/s7 | K27 |
| 403 | 5315.021 | 0.256 | 3.328 | d0/s7 | K28 |
| 404 | 5315.025 | 0.288 | 56.960 | d0/s7 | K29 |
| 405 | 5315.082 | 0.224 | 129.056 | d0/s7 | K30 |
| 406 | 5315.254 | 42.977 | 3.135 | d0/s7 | K24 |
| 407 | 5315.258 | 0.833 | 45.887 | d0/s7 | K25 |
| 408 | 5315.304 | 0.257 | 56.320 | d0/s7 | K26 |
| 409 | 5315.361 | 0.448 | 33.824 | d0/s7 | K27 |
| 410 | 5315.395 | 0.256 | 3.360 | d0/s7 | K28 |
| 411 | 5315.398 | 0.256 | 57.056 | d0/s7 | K29 |
| 412 | 5315.456 | 0.256 | 129.056 | d0/s7 | K30 |
| 413 | 5315.629 | 43.841 | 3.263 | d0/s7 | K24 |
| 414 | 5315.633 | 1.280 | 45.792 | d0/s7 | K25 |
| 415 | 5315.679 | 0.257 | 56.384 | d0/s7 | K26 |
| 416 | 5315.736 | 0.448 | 33.856 | d0/s7 | K27 |
| 417 | 5315.770 | 0.256 | 3.264 | d0/s7 | K28 |
| 418 | 5315.774 | 0.256 | 57.152 | d0/s7 | K29 |
| 419 | 5315.831 | 0.256 | 129.216 | d0/s7 | K30 |
| 420 | 5316.004 | 43.297 | 3.263 | d0/s7 | K24 |
| 421 | 5316.008 | 1.024 | 45.792 | d0/s7 | K25 |
| 422 | 5316.054 | 0.255 | 56.257 | d0/s7 | K26 |
| 423 | 5316.111 | 0.448 | 33.888 | d0/s7 | K27 |
| 424 | 5316.145 | 0.256 | 3.264 | d0/s7 | K28 |
| 425 | 5316.148 | 0.256 | 57.216 | d0/s7 | K29 |
| 426 | 5316.206 | 0.256 | 129.120 | d0/s7 | K30 |
| 427 | 5316.379 | 44.000 | 3.264 | d0/s7 | K24 |
| 428 | 5316.383 | 1.248 | 45.761 | d0/s7 | K25 |
| 429 | 5316.429 | 0.256 | 56.448 | d0/s7 | K26 |
| 430 | 5316.486 | 0.480 | 33.792 | d0/s7 | K27 |
| 431 | 5316.520 | 0.256 | 3.264 | d0/s7 | K28 |
| 432 | 5316.524 | 0.256 | 57.024 | d0/s7 | K29 |
| 433 | 5316.581 | 0.224 | 128.928 | d0/s7 | K30 |
| 434 | 5317.378 | 667.938 | 4.000 | d0/s7 | K31 |
| 435 | 5317.585 | 202.689 | 1.824 | d0/s7 | K32 |
| 436 | 5317.868 | 281.216 | 4.065 | d0/s7 | K33 |
| 437 | 5318.039 | 167.168 | 1.824 | d0/s7 | K9 |
| 438 | 5318.129 | 88.640 | 1.728 | d0/s7 | K34 |
| 439 | 5318.346 | 214.592 | 1.729 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 440 | 5318.428 | 80.704 | 1.888 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 441 | 5318.817 | 387.393 | 3.136 | d0/s7 | K35 |
| 442 | 5318.952 | 131.296 | 2.496 | d0/s7 | K36 |
| 443 | 5318.979 | 25.120 | 1.760 | d0/s7 | K19 |
| 444 | 5319.006 | 25.184 | 2.048 | d0/s7 | K37 |
| 445 | 5319.027 | 18.944 | 3.616 | d0/s7 | K38 |
| 446 | 5319.056 | 25.248 | 1.857 | d0/s7 | K39 |
| 447 | 5319.579 | 521.185 | 4.480 | d0/s7 | K40 |
| 448 | 5319.665 | 81.248 | 1.664 | d0/s7 | K41 |
| 449 | 5319.811 | 144.256 | 1.184 | d0/s7 | K42 |
| 450 | 5319.930 | 117.632 | 2.273 | d0/s7 | K43 |
| 451 | 5320.078 | 145.664 | 1.728 | d0/s7 | Memcpy DtoD (Device -> Device) (786432 B) |
| 452 | 5320.148 | 68.608 | 2.368 | d0/s7 | K44 |
| 453 | 5320.230 | 80.063 | 3.265 | d0/s7 | K45 |
| 454 | 5320.381 | 147.552 | 5.152 | d0/s7 | K46 |
| 455 | 5320.454 | 67.328 | 2.400 | d0/s7 | K47 |
| 456 | 5320.496 | 39.936 | 1.664 | d0/s7 | K9 |
| 457 | 5320.537 | 39.200 | 1.728 | d0/s7 | K34 |
| 458 | 5320.581 | 42.272 | 1.888 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 459 | 5320.628 | 45.120 | 1.952 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 460 | 5320.750 | 119.712 | 2.848 | d0/s7 | K48 |
| 461 | 5320.791 | 38.144 | 2.304 | d0/s7 | K49 |
| 462 | 5320.835 | 42.368 | 1.824 | d0/s7 | K50 |
| 463 | 5320.909 | 71.584 | 4.032 | d0/s7 | K33 |
| 464 | 5320.931 | 18.144 | 1.760 | d0/s7 | K9 |
| 465 | 5320.958 | 25.377 | 2.047 | d0/s7 | K34 |
| 466 | 5320.993 | 32.577 | 1.920 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 467 | 5321.024 | 29.120 | 1.920 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 468 | 5321.115 | 89.344 | 3.296 | d0/s7 | K51 |
| 469 | 5321.140 | 21.472 | 2.592 | d0/s7 | K52 |
| 470 | 5321.210 | 68.000 | 1.984 | d0/s7 | K53 |
| 471 | 5321.229 | 16.512 | 1.600 | d0/s7 | K22 |
| 472 | 5321.245 | 14.176 | 2.080 | d0/s7 | K54 |
| 473 | 5321.264 | 17.632 | 1.056 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 474 | 5321.291 | 25.632 | 1.984 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 475 | 5321.368 | 75.328 | 4.160 | d0/s7 | K48 |
| 476 | 5321.384 | 11.425 | 2.304 | d0/s7 | K49 |
| 477 | 5321.396 | 9.728 | 1.855 | d0/s7 | K50 |
| 478 | 5321.428 | 30.593 | 3.840 | d0/s7 | K33 |
| 479 | 5321.526 | 94.112 | 16.832 | d0/s7 | K55 |
| 480 | 5321.543 | 0.256 | 2.400 | d0/s7 | K36 |
| 481 | 5321.684 | 138.048 | 4.096 | d0/s7 | K40 |
| 482 | 5321.722 | 34.368 | 1.793 | d0/s7 | K41 |
| 483 | 5321.763 | 39.135 | 1.824 | d0/s7 | Memcpy DtoD (Device -> Device) (786432 B) |
| 484 | 5321.783 | 17.760 | 2.177 | d0/s7 | K44 |
| 485 | 5321.808 | 23.360 | 3.296 | d0/s7 | K45 |
| 486 | 5321.872 | 60.032 | 5.056 | d0/s7 | K46 |
| 487 | 5321.919 | 42.528 | 2.272 | d0/s7 | K47 |
| 488 | 5321.964 | 42.688 | 15.488 | d0/s7 | K56 |
| 489 | 5321.982 | 2.208 | 1.664 | d0/s7 | K50 |
| 490 | 5322.000 | 16.768 | 2.432 | d0/s7 | K49 |
| 491 | 5322.034 | 31.136 | 4.032 | d0/s7 | K33 |
| 492 | 5322.102 | 64.512 | 22.464 | d0/s7 | K57 |
| 493 | 5322.128 | 3.265 | 2.623 | d0/s7 | K52 |
| 494 | 5322.146 | 14.881 | 1.983 | d0/s7 | K53 |
| 495 | 5322.257 | 109.313 | 1.920 | d0/s7 | Memset (Device) (1536 B) |
| 496 | 5322.291 | 32.032 | 1.312 | d0/s7 | K58 |
| 497 | 5322.314 | 21.408 | 59.648 | d0/s7 | K59 |
| 498 | 5322.374 | 0.256 | 1.696 | d0/s7 | K50 |
| 499 | 5322.376 | 0.256 | 2.304 | d0/s7 | K49 |
| 500 | 5322.398 | 20.224 | 1.792 | d0/s7 | K50 |
| 501 | 5322.485 | 85.440 | 1.760 | d0/s7 | K60 |
| 502 | 5322.559 | 71.713 | 13.312 | d0/s7 | K61 |
| 503 | 5322.643 | 70.720 | 3.488 | d0/s7 | Memcpy DtoH (Device -> Pinned) (4 B) |
| 504 | 5322.718 | 71.872 | 1.920 | d0/s7 | Memcpy HtoD (Pageable -> Device) (56 B) |
| 505 | 5322.761 | 40.928 | 1.920 | d0/s7 | Memcpy HtoD (Pageable -> Device) (48 B) |
| 506 | 5322.859 | 96.256 | 4.160 | d0/s7 | K62 |
| 507 | 5322.877 | 13.760 | 3.840 | d0/s7 | K63 |
| 508 | 5322.915 | 34.240 | 3.969 | d0/s7 | K62 |
| 509 | 5322.930 | 10.880 | 3.840 | d0/s7 | K63 |
| 510 | 5322.950 | 16.223 | 1.729 | d0/s7 | K64 |
| 511 | 5322.969 | 17.408 | 1.760 | d0/s7 | K65 |
| 512 | 5322.989 | 18.495 | 2.433 | d0/s7 | K66 |
| 513 | 5323.004 | 11.840 | 3.808 | d0/s7 | Memcpy DtoH (Device -> Pinned) (4 B) |
| 514 | 5323.050 | 42.528 | 1.792 | d0/s7 | K60 |
| 515 | 5323.113 | 60.992 | 1.504 | d0/s7 | K67 |
| 516 | 5323.153 | 38.496 | 1.536 | d0/s7 | K68 |
| 517 | 5323.186 | 31.328 | 1.440 | d0/s7 | K69 |
| 518 | 5323.284 | 97.024 | 12.544 | d0/s7 | K70 |
| 519 | 5323.307 | 10.208 | 3.489 | d0/s7 | Memcpy DtoH (Device -> Pinned) (1 B) |
