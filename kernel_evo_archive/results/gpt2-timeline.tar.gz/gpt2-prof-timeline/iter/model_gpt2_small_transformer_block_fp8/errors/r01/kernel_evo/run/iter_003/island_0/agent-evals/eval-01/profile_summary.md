# B300 device profile of your last candidate

- device: NVIDIA B300 SXM6 AC, 148 SMs, 232448 B opt-in shared memory/block
- GPU busy: 1551.253 ms total; kernels 1551.222 ms over 393 launches of 38 distinct names
- memcpy: 0.030 ms over 15 calls; memset: 0.001 ms over 1 calls

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_ln2_fc_gelu_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo7681_tensorptr… | 1406.551 | 55 | 90.7 |
| kernel_cutlass_proj_residual_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FN… | 69.128 | 55 | 4.5 |
| kernel_cutlass_ln1_qkv_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo7681_t… | 54.713 | 55 | 3.5 |
| kernel_cutlass_out_residual_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNg… | 17.312 | 55 | 1.1 |
| kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 3.100 | 55 | 0.2 |
| void sgemm_largek_lds64<true, false, 6, 3, 4, 5, 2, 66>(float*, float const*, float con… | 0.060 | 1 | 0.0 |
| cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 0.041 | 4 | 0.0 |
| void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 0.033 | 17 | 0.0 |
| kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 0.028 | 10 | 0.0 |
| void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 0.025 | 5 | 0.0 |
