# B300 device profile of your last candidate

- device: NVIDIA B300 SXM6 AC, 148 SMs, 232448 B opt-in shared memory/block
- GPU busy: 25.014 ms total; kernels 24.981 ms over 503 launches of 40 distinct names
- memcpy: 0.031 ms over 15 calls; memset: 0.002 ms over 1 calls

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_proj_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 8.117 | 55 | 32.5 |
| kernel_cutlass_fc_gelu_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmemal… | 7.098 | 55 | 28.4 |
| kernel_cutlass_qkv_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 3.657 | 55 | 14.6 |
| kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 3.099 | 55 | 12.4 |
| kernel_cutlass_out_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 2.229 | 55 | 8.9 |
| kernel_cutlass_ln1_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo7681_tenso… | 0.177 | 55 | 0.7 |
| kernel_cutlass_ln2_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo7681_tensorptrf32gmemo… | 0.176 | 55 | 0.7 |
| void sgemm_largek_lds64<true, false, 6, 3, 4, 5, 2, 66>(float*, float const*, float con… | 0.061 | 1 | 0.2 |
| cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 0.047 | 4 | 0.2 |
| void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 0.034 | 17 | 0.1 |
