# B300 complete GPU timeline of your last candidate

- complete GPU-side trace: 519 activities; CPU/Python profiler records are intentionally omitted
- whole capture: span 3643.365 ms; active union 16.863 ms; idle holes 3626.502 ms (99.5%); largest hole 3364.468 ms
- that idle figure covers input generation, JIT compilation and the reference as well as your block, so it is not a measure of your kernels; the per-iteration section below is
- summed activity time: 16.863 ms; this may exceed active union when streams overlap
- source labels are hints: `candidate:<symbol>` is matched against this candidate's `@cute.kernel` definitions; other labels describe likely harness/runtime work
- candidate `@cute.kernel` symbols: `attention_kernel`, `fc_gelu_kernel`, `ln1_kernel`, `ln2_kernel`, `out_gemm_kernel`, `proj_gemm_kernel`, `qkv_gemm_kernel`
- observed candidate symbols: `attention_kernel`, `fc_gelu_kernel`, `ln1_kernel`, `ln2_kernel`, `out_gemm_kernel`, `proj_gemm_kernel`, `qkv_gemm_kernel`
- candidate symbols not observed in this trace: none

## One iteration of your block, launch by launch

Median of 55 timed iterations, 7 launches each. Microseconds from the start of the iteration.

- wall span 300.641; kernels busy 298.690; idle between your kernels 1.951 (0.7% of the span)
- largest single gap 0.671 immediately before `qkv_gemm_kernel`
- 44.480 elapses between one iteration and the next; that is host-side dispatch outside your block, excluded from the idle figure above, and fusing cannot remove it

| # | kernel | id | start | end | dur | idle before |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 1 | ln1_kernel | K24 | 0.000 | 3.105 | 3.105 | — |
| 2 | qkv_gemm_kernel | K25 | 3.776 | 47.297 | 43.521 | 0.671 |
| 3 | attention_kernel | K26 | 47.553 | 103.905 | 56.352 | 0.256 |
| 4 | out_gemm_kernel | K27 | 104.161 | 131.105 | 26.944 | 0.256 |
| 5 | ln2_kernel | K28 | 131.361 | 134.721 | 3.360 | 0.256 |
| 6 | fc_gelu_kernel | K29 | 134.977 | 198.337 | 63.360 | 0.256 |
| 7 | proj_gemm_kernel | K30 | 198.593 | 300.641 | 102.048 | 0.256 |

## Hottest GPU kernels (legacy aggregate)

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_proj_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 5.614 | 55 | 33.3 |
| kernel_cutlass_fc_gelu_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmemal… | 3.467 | 55 | 20.6 |
| kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 3.088 | 55 | 18.3 |
| kernel_cutlass_qkv_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 2.400 | 55 | 14.2 |
| kernel_cutlass_out_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 1.484 | 55 | 8.8 |
| kernel_cutlass_ln2_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo7681_tensorptrf32gmemo… | 0.182 | 55 | 1.1 |
| kernel_cutlass_ln1_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo7681_tenso… | 0.176 | 55 | 1.0 |
| void sgemm_largek_lds64<true, false, 6, 3, 4, 5, 2, 66>(float*, float const*, float con… | 0.062 | 1 | 0.4 |
| cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 0.041 | 4 | 0.2 |
| void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 0.034 | 17 | 0.2 |

## Kernel legend

| id | source hint | kernel | calls | total us | launch |
| --- | --- | --- | ---: | ---: | --- |
| K1 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 1 | 2.560 | grid=384x1x1, block=256x1x1, smem=0, regs=56 |
| K2 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 6 | 11.489 | grid=3x1x1, block=256x1x1, smem=0, regs=56 |
| K3 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 6 | 10.721 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K4 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::CUDAFunctorOnSelf_add<flo… | 2 | 3.616 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K5 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 1 | 1.792 | grid=9x1x1, block=256x1x1, smem=0, regs=56 |
| K6 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 2 | 3.455 | grid=3x1x1, block=128x1x1, smem=0, regs=32 |
| K7 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 1 | 2.176 | grid=12x1x1, block=256x1x1, smem=0, regs=56 |
| K8 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 4 | 22.176 | grid=1184x1x1, block=256x1x1, smem=0, regs=56 |
| K9 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 7 | 11.424 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K10 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 4 | 7.200 | grid=256x1x1, block=128x1x1, smem=0, regs=20 |
| K11 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 1 | 2.623 | grid=1728x1x1, block=128x1x1, smem=0, regs=32 |
| K12 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 2 | 8.639 | grid=4608x1x1, block=128x1x1, smem=0, regs=20 |
| K13 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 1 | 1.888 | grid=576x1x1, block=128x1x1, smem=0, regs=32 |
| K14 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 2.464 | grid=1536x1x1, block=128x1x1, smem=0, regs=20 |
| K15 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 6.752 | grid=2304x1x1, block=128x1x1, smem=0, regs=32 |
| K16 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 5.088 | grid=6144x1x1, block=128x1x1, smem=0, regs=20 |
| K17 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::… | 3 | 4.128 | grid=96x1x1, block=128x1x1, smem=0, regs=16 |
| K18 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::… | 1 | 1.376 | grid=288x1x1, block=128x1x1, smem=0, regs=16 |
| K19 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 3.649 | grid=288x1x1, block=128x1x1, smem=0, regs=32 |
| K20 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 2.048 | grid=640x1x1, block=128x1x1, smem=0, regs=20 |
| K21 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::… | 1 | 1.632 | grid=384x1x1, block=128x1x1, smem=0, regs=16 |
| K22 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 3.775 | grid=384x1x1, block=128x1x1, smem=0, regs=32 |
| K23 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 2.144 | grid=768x1x1, block=128x1x1, smem=0, regs=20 |
| K24 | candidate:ln1_kernel | kernel_cutlass_ln1_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo7681_tenso… | 55 | 175.812 | grid=128x1x1, block=128x1x1, smem=1024, regs=32 |
| K25 | candidate:qkv_gemm_kernel | kernel_cutlass_qkv_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 55 | 2399.915 | grid=72x8x1, block=128x1x1, smem=12288, regs=62 |
| K26 | candidate:attention_kernel | kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 55 | 3087.941 | grid=12x128x1, block=128x1x1, smem=1024, regs=40 |
| K27 | candidate:out_gemm_kernel | kernel_cutlass_out_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 55 | 1484.352 | grid=24x8x1, block=128x1x1, smem=12288, regs=62 |
| K28 | candidate:ln2_kernel | kernel_cutlass_ln2_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo7681_tensorptrf32gmemo… | 55 | 181.629 | grid=128x1x1, block=128x1x1, smem=1024, regs=32 |
| K29 | candidate:fc_gelu_kernel | kernel_cutlass_fc_gelu_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmemal… | 55 | 3467.272 | grid=96x8x1, block=128x1x1, smem=12288, regs=62 |
| K30 | candidate:proj_gemm_kernel | kernel_cutlass_proj_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 55 | 5613.772 | grid=24x8x1, block=128x1x1, smem=12288, regs=62 |
| K31 | framework/validation | void at::native::unrolled_elementwise_kernel<at::native::direct_copy_kernel_cuda(at::Te… | 1 | 3.456 | grid=192x1x1, block=128x1x1, smem=0, regs=30 |
| K32 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 1 | 1.664 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K33 | framework/validation | void at::native::(anonymous namespace)::vectorized_layer_norm_kernel<float, float, fals… | 4 | 16.032 | grid=128x1x1, block=32x4x1, smem=24, regs=40 |
| K34 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::float8_copy_kernel_cuda(a… | 3 | 5.696 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K35 | framework/validation | nvjet_sm103_qqsss_64x32_128x16_2x1_2cta_v_bz_TNT | 1 | 3.168 | grid=144x1x1, block=256x1x1, smem=172552, regs=255 |
| K36 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 5.024 | grid=1152x1x1, block=128x1x1, smem=0, regs=20 |
| K37 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::float8_copy_kernel_cuda(a… | 1 | 1.792 | grid=288x1x1, block=128x1x1, smem=0, regs=32 |
| K38 | framework/validation | void at::native::unrolled_elementwise_kernel<at::native::direct_copy_kernel_cuda(at::Te… | 1 | 3.552 | grid=576x1x1, block=128x1x1, smem=0, regs=30 |
| K39 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 1 | 1.760 | grid=288x1x1, block=128x1x1, smem=0, regs=32 |
| K40 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 2 | 8.608 | grid=4x4x12, block=64x1x1, smem=13056, regs=72 |
| K41 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 3.392 | grid=192x1x1, block=128x1x1, smem=0, regs=32 |
| K42 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<bool>, std::a… | 1 | 1.600 | grid=8x1x1, block=128x1x1, smem=0, regs=16 |
| K43 | framework/validation | void at::native::triu_tril_kernel<bool, int, true, 8, false>(at::cuda::detail::TensorIn… | 1 | 2.240 | grid=16x1x1, block=128x1x1, smem=0, regs=30 |
| K44 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 4.512 | grid=768x1x1, block=128x1x1, smem=0, regs=20 |
| K45 | framework/validation | void (anonymous namespace)::softmax_warp_forward<float, float, float, 7, false, false>(… | 2 | 6.239 | grid=192x1x1, block=32x4x1, smem=0, regs=32 |
| K46 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_nnn_align1_bias_f32_relu | 2 | 10.176 | grid=2x4x12, block=64x1x1, smem=12672, regs=84 |
| K47 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 4.736 | grid=384x1x1, block=128x1x1, smem=0, regs=20 |
| K48 | framework/validation | nvjet_sm103_qqsss_64x16_128x16_2x4_2cta_h_bz_TNT | 2 | 6.976 | grid=96x1x1, block=256x1x1, smem=156168, regs=255 |
| K49 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 4 | 9.152 | grid=384x1x1, block=128x1x1, smem=0, regs=20 |
| K50 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::CUDAFunctor_add<float>, s… | 5 | 9.024 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K51 | framework/validation | nvjet_sm103_qqsss_48x64_128x16_2x2_2cta_h_bz_TNN | 1 | 3.296 | grid=128x1x1, block=256x1x1, smem=188944, regs=255 |
| K52 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 5.248 | grid=1536x1x1, block=128x1x1, smem=0, regs=20 |
| K53 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::GeluCUDAKernelImpl(at::Te… | 2 | 4.192 | grid=384x1x1, block=128x1x1, smem=0, regs=32 |
| K54 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::float8_copy_kernel_cuda(a… | 1 | 1.856 | grid=384x1x1, block=128x1x1, smem=0, regs=32 |
| K55 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 1 | 16.864 | grid=72x4x1, block=64x1x1, smem=13056, regs=72 |
| K56 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 1 | 15.680 | grid=24x4x1, block=64x1x1, smem=13056, regs=72 |
| K57 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_64x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 1 | 22.304 | grid=48x4x1, block=64x1x1, smem=19200, regs=146 |
| K58 | framework/validation | void scal_kernel<float, float, 1, true, 6, 5, 5, 3>(cublasTransposeParams<float>, float… | 1 | 1.632 | grid=12x4x1, block=256x1x1, smem=0, regs=24 |
| K59 | framework/validation | void sgemm_largek_lds64<true, false, 6, 3, 4, 5, 2, 66>(float*, float const*, float con… | 1 | 61.728 | grid=12x16x4, block=32x4x1, smem=4868, regs=32 |
| K60 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AbsFunctor<float>, std::a… | 2 | 2.880 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K61 | framework/validation | void at::native::reduce_kernel<512, 1, at::native::ReduceOp<float, at::native::func_wra… | 1 | 12.928 | grid=1x1x1, block=512x1x1, smem=2064, regs=30 |
| K62 | framework/validation | void at::native::(anonymous namespace)::indexSelectSmallIndex<float, long, unsigned int… | 2 | 8.576 | grid=6x1x1, block=128x1x1, smem=0, regs=28 |
| K63 | framework/validation | void at::native::(anonymous namespace)::indexSelectSmallIndex<float, long, unsigned int… | 2 | 8.448 | grid=1x1x1, block=7x1x1, smem=0, regs=28 |
| K64 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::CUDAFunctor_add<float>, s… | 1 | 1.376 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K65 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AbsFunctor<float>, std::a… | 1 | 1.344 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K66 | framework/validation | void at::native::reduce_kernel<512, 1, at::native::ReduceOp<float, at::native::func_wra… | 1 | 2.048 | grid=1x1x1, block=32x1x1, smem=16, regs=30 |
| K67 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 1 | 1.792 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K68 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BinaryFunctor<float, floa… | 1 | 1.792 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K69 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BinaryFunctor<bool, bool,… | 1 | 1.823 | grid=96x1x1, block=128x1x1, smem=0, regs=30 |
| K70 | framework/validation | void at::native::reduce_kernel<512, 1, at::native::ReduceOp<bool, at::native::func_wrap… | 1 | 13.024 | grid=1x1x1, block=512x1x1, smem=528, regs=28 |

## Ordered GPU activities

`gap before` is device-wide idle time since all earlier GPU activity ended; zero means overlap or no measurable hole.

| # | start ms | gap before us | duration us | lane | activity |
| ---: | ---: | ---: | ---: | --- | --- |
| 1 | 0.000 | 0.000 | 2.560 | d0/s7 | K1 |
| 2 | 0.114 | 111.777 | 1.824 | d0/s7 | K2 |
| 3 | 0.161 | 44.896 | 1.600 | d0/s7 | K3 |
| 4 | 0.201 | 38.080 | 1.600 | d0/s7 | K4 |
| 5 | 0.222 | 20.128 | 1.792 | d0/s7 | K2 |
| 6 | 0.233 | 8.736 | 1.984 | d0/s7 | K3 |
| 7 | 0.249 | 13.728 | 2.144 | d0/s7 | K2 |
| 8 | 0.265 | 14.368 | 1.984 | d0/s7 | K3 |
| 9 | 0.275 | 8.096 | 2.016 | d0/s7 | K4 |
| 10 | 0.291 | 14.112 | 1.792 | d0/s7 | K2 |
| 11 | 0.302 | 8.384 | 1.600 | d0/s7 | K3 |
| 12 | 0.317 | 13.920 | 1.792 | d0/s7 | K5 |
| 13 | 0.331 | 11.745 | 1.663 | d0/s7 | K6 |
| 14 | 0.345 | 13.120 | 2.145 | d0/s7 | K2 |
| 15 | 0.356 | 7.935 | 1.985 | d0/s7 | K3 |
| 16 | 0.372 | 14.304 | 2.176 | d0/s7 | K7 |
| 17 | 0.382 | 8.000 | 1.792 | d0/s7 | K6 |
| 18 | 0.398 | 14.048 | 1.792 | d0/s7 | K2 |
| 19 | 0.409 | 9.344 | 1.568 | d0/s7 | K3 |
| 20 | 0.433 | 22.720 | 5.792 | d0/s7 | K8 |
| 21 | 0.449 | 10.240 | 4.224 | d0/s7 | K8 |
| 22 | 0.465 | 11.840 | 6.080 | d0/s7 | K8 |
| 23 | 0.482 | 10.560 | 6.080 | d0/s7 | K8 |
| 24 | 0.521 | 33.344 | 1.792 | d0/s7 | K9 |
| 25 | 30.287 | 29764.121 | 1.920 | d0/s7 | K10 |
| 26 | 30.487 | 197.281 | 2.623 | d0/s7 | K11 |
| 27 | 56.239 | 25749.902 | 4.255 | d0/s7 | K12 |
| 28 | 56.437 | 193.889 | 1.888 | d0/s7 | K13 |
| 29 | 82.194 | 25754.733 | 2.464 | d0/s7 | K14 |
| 30 | 82.350 | 154.017 | 3.360 | d0/s7 | K15 |
| 31 | 108.134 | 25780.621 | 5.088 | d0/s7 | K16 |
| 32 | 108.330 | 190.304 | 3.392 | d0/s7 | K15 |
| 33 | 133.275 | 24941.611 | 4.384 | d0/s7 | K12 |
| 34 | 133.451 | 171.521 | 1.280 | d0/s7 | K17 |
| 35 | 133.511 | 59.424 | 1.408 | d0/s7 | K9 |
| 36 | 157.966 | 24453.257 | 1.760 | d0/s7 | K10 |
| 37 | 158.123 | 155.712 | 1.376 | d0/s7 | K18 |
| 38 | 158.182 | 57.056 | 1.793 | d0/s7 | K19 |
| 39 | 182.919 | 24735.242 | 2.048 | d0/s7 | K20 |
| 40 | 183.072 | 151.488 | 1.632 | d0/s7 | K17 |
| 41 | 183.132 | 57.728 | 1.792 | d0/s7 | K9 |
| 42 | 207.597 | 24463.113 | 1.728 | d0/s7 | K10 |
| 43 | 207.765 | 166.593 | 1.216 | d0/s7 | K17 |
| 44 | 207.824 | 58.144 | 1.376 | d0/s7 | K9 |
| 45 | 232.186 | 24360.745 | 1.792 | d0/s7 | K10 |
| 46 | 232.340 | 152.064 | 1.632 | d0/s7 | K21 |
| 47 | 232.400 | 57.729 | 1.855 | d0/s7 | K22 |
| 48 | 257.355 | 24953.515 | 2.144 | d0/s7 | K23 |
| 49 | 3621.825 | 3364467.889 | 3.840 | d0/s7 | K24 |
| 50 | 3621.835 | 5.600 | 44.417 | d0/s7 | K25 |
| 51 | 3621.879 | 0.256 | 56.192 | d0/s7 | K26 |
| 52 | 3621.936 | 0.256 | 27.840 | d0/s7 | K27 |
| 53 | 3621.964 | 0.256 | 3.488 | d0/s7 | K28 |
| 54 | 3621.968 | 0.256 | 63.136 | d0/s7 | K29 |
| 55 | 3622.031 | 0.288 | 103.552 | d0/s7 | K30 |
| 56 | 3622.135 | 0.256 | 3.264 | d0/s7 | K24 |
| 57 | 3622.138 | 0.256 | 43.616 | d0/s7 | K25 |
| 58 | 3622.182 | 0.257 | 56.128 | d0/s7 | K26 |
| 59 | 3622.239 | 0.288 | 27.040 | d0/s7 | K27 |
| 60 | 3622.266 | 0.256 | 3.264 | d0/s7 | K28 |
| 61 | 3622.269 | 0.256 | 63.040 | d0/s7 | K29 |
| 62 | 3622.333 | 0.256 | 101.824 | d0/s7 | K30 |
| 63 | 3622.435 | 0.256 | 3.264 | d0/s7 | K24 |
| 64 | 3622.438 | 0.256 | 43.520 | d0/s7 | K25 |
| 65 | 3622.482 | 0.256 | 56.193 | d0/s7 | K26 |
| 66 | 3622.538 | 0.256 | 26.944 | d0/s7 | K27 |
| 67 | 3622.566 | 0.256 | 3.264 | d0/s7 | K28 |
| 68 | 3622.569 | 0.256 | 63.200 | d0/s7 | K29 |
| 69 | 3622.633 | 0.256 | 102.016 | d0/s7 | K30 |
| 70 | 3622.735 | 0.256 | 3.264 | d0/s7 | K24 |
| 71 | 3622.738 | 0.256 | 43.552 | d0/s7 | K25 |
| 72 | 3622.782 | 0.256 | 56.160 | d0/s7 | K26 |
| 73 | 3622.839 | 0.257 | 27.008 | d0/s7 | K27 |
| 74 | 3622.866 | 0.256 | 3.231 | d0/s7 | K28 |
| 75 | 3622.869 | 0.257 | 63.104 | d0/s7 | K29 |
| 76 | 3622.933 | 0.256 | 102.144 | d0/s7 | K30 |
| 77 | 3623.035 | 0.288 | 3.072 | d0/s7 | K24 |
| 78 | 3623.039 | 0.256 | 43.424 | d0/s7 | K25 |
| 79 | 3623.082 | 0.256 | 56.352 | d0/s7 | K26 |
| 80 | 3623.139 | 0.256 | 26.913 | d0/s7 | K27 |
| 81 | 3623.166 | 0.255 | 3.328 | d0/s7 | K28 |
| 82 | 3623.170 | 0.257 | 62.848 | d0/s7 | K29 |
| 83 | 3623.233 | 0.256 | 102.112 | d0/s7 | K30 |
| 84 | 3623.415 | 80.544 | 3.104 | d0/s7 | K24 |
| 85 | 3623.420 | 1.440 | 43.680 | d0/s7 | K25 |
| 86 | 3623.464 | 0.255 | 56.128 | d0/s7 | K26 |
| 87 | 3623.520 | 0.257 | 26.944 | d0/s7 | K27 |
| 88 | 3623.547 | 0.256 | 3.328 | d0/s7 | K28 |
| 89 | 3623.551 | 0.256 | 63.200 | d0/s7 | K29 |
| 90 | 3623.614 | 0.255 | 102.240 | d0/s7 | K30 |
| 91 | 3623.776 | 59.008 | 3.072 | d0/s7 | K24 |
| 92 | 3623.780 | 1.473 | 43.681 | d0/s7 | K25 |
| 93 | 3623.824 | 0.255 | 56.160 | d0/s7 | K26 |
| 94 | 3623.881 | 0.256 | 26.944 | d0/s7 | K27 |
| 95 | 3623.908 | 0.256 | 3.360 | d0/s7 | K28 |
| 96 | 3623.911 | 0.256 | 63.296 | d0/s7 | K29 |
| 97 | 3623.975 | 0.288 | 101.856 | d0/s7 | K30 |
| 98 | 3624.122 | 45.153 | 3.103 | d0/s7 | K24 |
| 99 | 3624.126 | 1.248 | 43.649 | d0/s7 | K25 |
| 100 | 3624.170 | 0.255 | 56.065 | d0/s7 | K26 |
| 101 | 3624.227 | 0.256 | 27.008 | d0/s7 | K27 |
| 102 | 3624.254 | 0.256 | 3.360 | d0/s7 | K28 |
| 103 | 3624.257 | 0.256 | 63.296 | d0/s7 | K29 |
| 104 | 3624.321 | 0.256 | 101.952 | d0/s7 | K30 |
| 105 | 3624.467 | 44.033 | 3.295 | d0/s7 | K24 |
| 106 | 3624.471 | 0.993 | 43.776 | d0/s7 | K25 |
| 107 | 3624.515 | 0.256 | 56.032 | d0/s7 | K26 |
| 108 | 3624.572 | 0.256 | 26.944 | d0/s7 | K27 |
| 109 | 3624.599 | 0.256 | 3.264 | d0/s7 | K28 |
| 110 | 3624.602 | 0.255 | 63.264 | d0/s7 | K29 |
| 111 | 3624.666 | 0.256 | 101.952 | d0/s7 | K30 |
| 112 | 3624.812 | 44.161 | 3.264 | d0/s7 | K24 |
| 113 | 3624.816 | 0.831 | 43.712 | d0/s7 | K25 |
| 114 | 3624.860 | 0.225 | 56.064 | d0/s7 | K26 |
| 115 | 3624.916 | 0.288 | 26.944 | d0/s7 | K27 |
| 116 | 3624.944 | 0.288 | 3.264 | d0/s7 | K28 |
| 117 | 3624.947 | 0.256 | 62.944 | d0/s7 | K29 |
| 118 | 3625.010 | 0.256 | 101.984 | d0/s7 | K30 |
| 119 | 3625.157 | 44.897 | 3.231 | d0/s7 | K24 |
| 120 | 3625.161 | 1.025 | 43.712 | d0/s7 | K25 |
| 121 | 3625.205 | 0.256 | 56.192 | d0/s7 | K26 |
| 122 | 3625.262 | 0.256 | 26.912 | d0/s7 | K27 |
| 123 | 3625.289 | 0.288 | 3.232 | d0/s7 | K28 |
| 124 | 3625.293 | 0.256 | 63.008 | d0/s7 | K29 |
| 125 | 3625.356 | 0.256 | 102.145 | d0/s7 | K30 |
| 126 | 3625.502 | 44.192 | 3.264 | d0/s7 | K24 |
| 127 | 3625.506 | 0.640 | 43.648 | d0/s7 | K25 |
| 128 | 3625.550 | 0.256 | 56.256 | d0/s7 | K26 |
| 129 | 3625.606 | 0.256 | 26.944 | d0/s7 | K27 |
| 130 | 3625.634 | 0.256 | 3.264 | d0/s7 | K28 |
| 131 | 3625.637 | 0.256 | 62.880 | d0/s7 | K29 |
| 132 | 3625.700 | 0.224 | 102.049 | d0/s7 | K30 |
| 133 | 3625.845 | 42.815 | 3.105 | d0/s7 | K24 |
| 134 | 3625.849 | 1.120 | 43.680 | d0/s7 | K25 |
| 135 | 3625.893 | 0.256 | 56.352 | d0/s7 | K26 |
| 136 | 3625.950 | 0.256 | 26.976 | d0/s7 | K27 |
| 137 | 3625.977 | 0.288 | 3.328 | d0/s7 | K28 |
| 138 | 3625.981 | 0.256 | 62.976 | d0/s7 | K29 |
| 139 | 3626.044 | 0.256 | 101.921 | d0/s7 | K30 |
| 140 | 3626.190 | 44.000 | 3.104 | d0/s7 | K24 |
| 141 | 3626.194 | 0.896 | 43.424 | d0/s7 | K25 |
| 142 | 3626.238 | 0.256 | 56.416 | d0/s7 | K26 |
| 143 | 3626.294 | 0.256 | 27.008 | d0/s7 | K27 |
| 144 | 3626.322 | 0.256 | 3.328 | d0/s7 | K28 |
| 145 | 3626.325 | 0.256 | 63.264 | d0/s7 | K29 |
| 146 | 3626.389 | 0.256 | 102.049 | d0/s7 | K30 |
| 147 | 3626.534 | 43.808 | 3.104 | d0/s7 | K24 |
| 148 | 3626.538 | 0.896 | 43.520 | d0/s7 | K25 |
| 149 | 3626.582 | 0.256 | 55.840 | d0/s7 | K26 |
| 150 | 3626.638 | 0.256 | 27.008 | d0/s7 | K27 |
| 151 | 3626.666 | 0.256 | 3.328 | d0/s7 | K28 |
| 152 | 3626.669 | 0.256 | 62.848 | d0/s7 | K29 |
| 153 | 3626.732 | 0.257 | 101.887 | d0/s7 | K30 |
| 154 | 3626.878 | 44.033 | 3.104 | d0/s7 | K24 |
| 155 | 3626.882 | 0.704 | 43.584 | d0/s7 | K25 |
| 156 | 3626.926 | 0.256 | 55.904 | d0/s7 | K26 |
| 157 | 3626.982 | 0.256 | 27.040 | d0/s7 | K27 |
| 158 | 3627.009 | 0.256 | 3.360 | d0/s7 | K28 |
| 159 | 3627.013 | 0.256 | 63.168 | d0/s7 | K29 |
| 160 | 3627.076 | 0.256 | 102.016 | d0/s7 | K30 |
| 161 | 3627.222 | 43.553 | 3.296 | d0/s7 | K24 |
| 162 | 3627.227 | 1.376 | 43.680 | d0/s7 | K25 |
| 163 | 3627.271 | 0.256 | 55.936 | d0/s7 | K26 |
| 164 | 3627.327 | 0.256 | 27.008 | d0/s7 | K27 |
| 165 | 3627.354 | 0.256 | 3.232 | d0/s7 | K28 |
| 166 | 3627.358 | 0.288 | 63.264 | d0/s7 | K29 |
| 167 | 3627.421 | 0.256 | 101.889 | d0/s7 | K30 |
| 168 | 3627.566 | 42.912 | 3.232 | d0/s7 | K24 |
| 169 | 3627.570 | 1.248 | 43.648 | d0/s7 | K25 |
| 170 | 3627.614 | 0.256 | 55.968 | d0/s7 | K26 |
| 171 | 3627.670 | 0.256 | 27.008 | d0/s7 | K27 |
| 172 | 3627.698 | 0.256 | 3.264 | d0/s7 | K28 |
| 173 | 3627.701 | 0.256 | 63.041 | d0/s7 | K29 |
| 174 | 3627.765 | 0.255 | 101.985 | d0/s7 | K30 |
| 175 | 3627.910 | 43.648 | 3.264 | d0/s7 | K24 |
| 176 | 3627.914 | 0.928 | 43.616 | d0/s7 | K25 |
| 177 | 3627.958 | 0.255 | 56.160 | d0/s7 | K26 |
| 178 | 3628.015 | 0.288 | 26.976 | d0/s7 | K27 |
| 179 | 3628.042 | 0.256 | 3.264 | d0/s7 | K28 |
| 180 | 3628.045 | 0.256 | 63.169 | d0/s7 | K29 |
| 181 | 3628.109 | 0.255 | 102.177 | d0/s7 | K30 |
| 182 | 3628.255 | 44.096 | 3.232 | d0/s7 | K24 |
| 183 | 3628.259 | 0.736 | 43.648 | d0/s7 | K25 |
| 184 | 3628.303 | 0.256 | 56.448 | d0/s7 | K26 |
| 185 | 3628.360 | 0.256 | 26.880 | d0/s7 | K27 |
| 186 | 3628.387 | 0.256 | 3.264 | d0/s7 | K28 |
| 187 | 3628.390 | 0.256 | 63.105 | d0/s7 | K29 |
| 188 | 3628.454 | 0.255 | 102.241 | d0/s7 | K30 |
| 189 | 3628.598 | 42.144 | 3.136 | d0/s7 | K24 |
| 190 | 3628.602 | 0.992 | 43.648 | d0/s7 | K25 |
| 191 | 3628.646 | 0.256 | 56.288 | d0/s7 | K26 |
| 192 | 3628.703 | 0.256 | 27.072 | d0/s7 | K27 |
| 193 | 3628.730 | 0.256 | 3.360 | d0/s7 | K28 |
| 194 | 3628.734 | 0.257 | 63.007 | d0/s7 | K29 |
| 195 | 3628.797 | 0.257 | 102.176 | d0/s7 | K30 |
| 196 | 3628.944 | 44.928 | 3.136 | d0/s7 | K24 |
| 197 | 3628.948 | 0.928 | 43.488 | d0/s7 | K25 |
| 198 | 3628.992 | 0.256 | 56.224 | d0/s7 | K26 |
| 199 | 3629.048 | 0.256 | 26.944 | d0/s7 | K27 |
| 200 | 3629.075 | 0.256 | 3.360 | d0/s7 | K28 |
| 201 | 3629.079 | 0.257 | 63.136 | d0/s7 | K29 |
| 202 | 3629.143 | 0.256 | 102.048 | d0/s7 | K30 |
| 203 | 3629.287 | 42.496 | 3.072 | d0/s7 | K24 |
| 204 | 3629.292 | 1.472 | 43.552 | d0/s7 | K25 |
| 205 | 3629.335 | 0.256 | 56.128 | d0/s7 | K26 |
| 206 | 3629.392 | 0.257 | 26.975 | d0/s7 | K27 |
| 207 | 3629.419 | 0.257 | 3.360 | d0/s7 | K28 |
| 208 | 3629.423 | 0.255 | 63.393 | d0/s7 | K29 |
| 209 | 3629.486 | 0.256 | 101.856 | d0/s7 | K30 |
| 210 | 3629.640 | 52.192 | 3.104 | d0/s7 | K24 |
| 211 | 3629.644 | 0.672 | 43.520 | d0/s7 | K25 |
| 212 | 3629.688 | 0.256 | 55.969 | d0/s7 | K26 |
| 213 | 3629.744 | 0.255 | 27.008 | d0/s7 | K27 |
| 214 | 3629.771 | 0.257 | 3.328 | d0/s7 | K28 |
| 215 | 3629.775 | 0.287 | 63.009 | d0/s7 | K29 |
| 216 | 3629.838 | 0.256 | 102.080 | d0/s7 | K30 |
| 217 | 3629.983 | 43.072 | 3.296 | d0/s7 | K24 |
| 218 | 3629.987 | 0.736 | 43.552 | d0/s7 | K25 |
| 219 | 3630.031 | 0.256 | 56.096 | d0/s7 | K26 |
| 220 | 3630.088 | 0.256 | 26.881 | d0/s7 | K27 |
| 221 | 3630.115 | 0.256 | 3.264 | d0/s7 | K28 |
| 222 | 3630.118 | 0.256 | 62.976 | d0/s7 | K29 |
| 223 | 3630.181 | 0.256 | 101.856 | d0/s7 | K30 |
| 224 | 3630.326 | 42.976 | 3.264 | d0/s7 | K24 |
| 225 | 3630.331 | 1.440 | 43.648 | d0/s7 | K25 |
| 226 | 3630.375 | 0.288 | 56.033 | d0/s7 | K26 |
| 227 | 3630.431 | 0.256 | 27.007 | d0/s7 | K27 |
| 228 | 3630.459 | 0.257 | 3.263 | d0/s7 | K28 |
| 229 | 3630.462 | 0.257 | 62.912 | d0/s7 | K29 |
| 230 | 3630.525 | 0.256 | 101.888 | d0/s7 | K30 |
| 231 | 3630.671 | 43.424 | 3.264 | d0/s7 | K24 |
| 232 | 3630.675 | 1.376 | 43.712 | d0/s7 | K25 |
| 233 | 3630.719 | 0.257 | 56.320 | d0/s7 | K26 |
| 234 | 3630.776 | 0.255 | 26.945 | d0/s7 | K27 |
| 235 | 3630.803 | 0.256 | 3.264 | d0/s7 | K28 |
| 236 | 3630.806 | 0.255 | 62.912 | d0/s7 | K29 |
| 237 | 3630.870 | 0.256 | 102.016 | d0/s7 | K30 |
| 238 | 3631.016 | 44.640 | 3.264 | d0/s7 | K24 |
| 239 | 3631.021 | 1.088 | 43.648 | d0/s7 | K25 |
| 240 | 3631.064 | 0.256 | 56.224 | d0/s7 | K26 |
| 241 | 3631.121 | 0.257 | 26.912 | d0/s7 | K27 |
| 242 | 3631.148 | 0.256 | 3.232 | d0/s7 | K28 |
| 243 | 3631.152 | 0.256 | 62.848 | d0/s7 | K29 |
| 244 | 3631.215 | 0.256 | 102.080 | d0/s7 | K30 |
| 245 | 3631.360 | 42.976 | 3.136 | d0/s7 | K24 |
| 246 | 3631.363 | 0.448 | 43.552 | d0/s7 | K25 |
| 247 | 3631.407 | 0.257 | 56.256 | d0/s7 | K26 |
| 248 | 3631.464 | 0.289 | 26.944 | d0/s7 | K27 |
| 249 | 3631.491 | 0.288 | 3.328 | d0/s7 | K28 |
| 250 | 3631.495 | 0.256 | 62.848 | d0/s7 | K29 |
| 251 | 3631.558 | 0.256 | 102.112 | d0/s7 | K30 |
| 252 | 3631.704 | 43.968 | 3.104 | d0/s7 | K24 |
| 253 | 3631.708 | 1.345 | 43.584 | d0/s7 | K25 |
| 254 | 3631.752 | 0.256 | 56.160 | d0/s7 | K26 |
| 255 | 3631.808 | 0.256 | 26.912 | d0/s7 | K27 |
| 256 | 3631.836 | 0.288 | 3.328 | d0/s7 | K28 |
| 257 | 3631.839 | 0.256 | 63.520 | d0/s7 | K29 |
| 258 | 3631.903 | 0.288 | 102.240 | d0/s7 | K30 |
| 259 | 3632.049 | 44.160 | 3.072 | d0/s7 | K24 |
| 260 | 3632.053 | 0.928 | 43.552 | d0/s7 | K25 |
| 261 | 3632.097 | 0.257 | 56.000 | d0/s7 | K26 |
| 262 | 3632.153 | 0.256 | 26.944 | d0/s7 | K27 |
| 263 | 3632.181 | 0.288 | 3.328 | d0/s7 | K28 |
| 264 | 3632.184 | 0.256 | 63.168 | d0/s7 | K29 |
| 265 | 3632.248 | 0.256 | 102.112 | d0/s7 | K30 |
| 266 | 3632.393 | 43.488 | 3.105 | d0/s7 | K24 |
| 267 | 3632.397 | 0.703 | 43.521 | d0/s7 | K25 |
| 268 | 3632.441 | 0.256 | 56.160 | d0/s7 | K26 |
| 269 | 3632.497 | 0.255 | 26.880 | d0/s7 | K27 |
| 270 | 3632.524 | 0.256 | 3.360 | d0/s7 | K28 |
| 271 | 3632.528 | 0.256 | 63.040 | d0/s7 | K29 |
| 272 | 3632.591 | 0.256 | 101.888 | d0/s7 | K30 |
| 273 | 3632.736 | 43.104 | 3.265 | d0/s7 | K24 |
| 274 | 3632.741 | 1.087 | 43.585 | d0/s7 | K25 |
| 275 | 3632.785 | 0.255 | 55.969 | d0/s7 | K26 |
| 276 | 3632.841 | 0.255 | 26.944 | d0/s7 | K27 |
| 277 | 3632.868 | 0.256 | 3.264 | d0/s7 | K28 |
| 278 | 3632.872 | 0.256 | 63.072 | d0/s7 | K29 |
| 279 | 3632.935 | 0.256 | 101.856 | d0/s7 | K30 |
| 280 | 3633.079 | 42.752 | 3.265 | d0/s7 | K24 |
| 281 | 3633.084 | 1.055 | 43.649 | d0/s7 | K25 |
| 282 | 3633.128 | 0.256 | 55.904 | d0/s7 | K26 |
| 283 | 3633.184 | 0.256 | 26.976 | d0/s7 | K27 |
| 284 | 3633.211 | 0.256 | 3.264 | d0/s7 | K28 |
| 285 | 3633.215 | 0.255 | 63.008 | d0/s7 | K29 |
| 286 | 3633.278 | 0.256 | 101.952 | d0/s7 | K30 |
| 287 | 3633.421 | 41.152 | 3.265 | d0/s7 | K24 |
| 288 | 3633.426 | 1.503 | 43.553 | d0/s7 | K25 |
| 289 | 3633.470 | 0.288 | 56.192 | d0/s7 | K26 |
| 290 | 3633.526 | 0.256 | 26.976 | d0/s7 | K27 |
| 291 | 3633.553 | 0.256 | 3.264 | d0/s7 | K28 |
| 292 | 3633.557 | 0.256 | 62.944 | d0/s7 | K29 |
| 293 | 3633.620 | 0.256 | 102.144 | d0/s7 | K30 |
| 294 | 3633.765 | 42.720 | 3.265 | d0/s7 | K24 |
| 295 | 3633.769 | 0.832 | 43.712 | d0/s7 | K25 |
| 296 | 3633.813 | 0.256 | 56.224 | d0/s7 | K26 |
| 297 | 3633.869 | 0.256 | 27.008 | d0/s7 | K27 |
| 298 | 3633.897 | 0.256 | 3.232 | d0/s7 | K28 |
| 299 | 3633.900 | 0.256 | 62.912 | d0/s7 | K29 |
| 300 | 3633.963 | 0.256 | 102.081 | d0/s7 | K30 |
| 301 | 3634.109 | 43.584 | 3.072 | d0/s7 | K24 |
| 302 | 3634.113 | 1.312 | 43.681 | d0/s7 | K25 |
| 303 | 3634.157 | 0.256 | 56.192 | d0/s7 | K26 |
| 304 | 3634.214 | 0.256 | 26.944 | d0/s7 | K27 |
| 305 | 3634.241 | 0.256 | 3.328 | d0/s7 | K28 |
| 306 | 3634.245 | 0.256 | 62.752 | d0/s7 | K29 |
| 307 | 3634.308 | 0.256 | 101.984 | d0/s7 | K30 |
| 308 | 3634.453 | 43.712 | 3.169 | d0/s7 | K24 |
| 309 | 3634.457 | 1.088 | 43.808 | d0/s7 | K25 |
| 310 | 3634.502 | 0.256 | 56.160 | d0/s7 | K26 |
| 311 | 3634.558 | 0.288 | 26.912 | d0/s7 | K27 |
| 312 | 3634.585 | 0.256 | 3.360 | d0/s7 | K28 |
| 313 | 3634.589 | 0.256 | 63.040 | d0/s7 | K29 |
| 314 | 3634.652 | 0.288 | 102.080 | d0/s7 | K30 |
| 315 | 3634.796 | 41.569 | 3.136 | d0/s7 | K24 |
| 316 | 3634.800 | 1.440 | 43.648 | d0/s7 | K25 |
| 317 | 3634.844 | 0.224 | 56.160 | d0/s7 | K26 |
| 318 | 3634.901 | 0.256 | 27.008 | d0/s7 | K27 |
| 319 | 3634.928 | 0.256 | 3.328 | d0/s7 | K28 |
| 320 | 3634.931 | 0.256 | 63.104 | d0/s7 | K29 |
| 321 | 3634.995 | 0.256 | 101.984 | d0/s7 | K30 |
| 322 | 3635.140 | 42.849 | 3.104 | d0/s7 | K24 |
| 323 | 3635.144 | 1.184 | 43.488 | d0/s7 | K25 |
| 324 | 3635.188 | 0.256 | 56.096 | d0/s7 | K26 |
| 325 | 3635.244 | 0.256 | 26.944 | d0/s7 | K27 |
| 326 | 3635.271 | 0.288 | 3.328 | d0/s7 | K28 |
| 327 | 3635.275 | 0.256 | 63.040 | d0/s7 | K29 |
| 328 | 3635.338 | 0.257 | 101.792 | d0/s7 | K30 |
| 329 | 3635.483 | 43.200 | 3.264 | d0/s7 | K24 |
| 330 | 3635.487 | 1.024 | 43.520 | d0/s7 | K25 |
| 331 | 3635.531 | 0.256 | 56.160 | d0/s7 | K26 |
| 332 | 3635.588 | 0.256 | 26.976 | d0/s7 | K27 |
| 333 | 3635.615 | 0.256 | 3.264 | d0/s7 | K28 |
| 334 | 3635.618 | 0.256 | 62.944 | d0/s7 | K29 |
| 335 | 3635.682 | 0.256 | 101.889 | d0/s7 | K30 |
| 336 | 3635.826 | 42.944 | 3.200 | d0/s7 | K24 |
| 337 | 3635.831 | 1.087 | 43.808 | d0/s7 | K25 |
| 338 | 3635.875 | 0.256 | 56.032 | d0/s7 | K26 |
| 339 | 3635.931 | 0.255 | 26.912 | d0/s7 | K27 |
| 340 | 3635.958 | 0.256 | 3.232 | d0/s7 | K28 |
| 341 | 3635.962 | 0.256 | 62.913 | d0/s7 | K29 |
| 342 | 3636.025 | 0.255 | 101.857 | d0/s7 | K30 |
| 343 | 3636.170 | 43.488 | 3.232 | d0/s7 | K24 |
| 344 | 3636.175 | 1.120 | 43.680 | d0/s7 | K25 |
| 345 | 3636.218 | 0.256 | 56.224 | d0/s7 | K26 |
| 346 | 3636.275 | 0.288 | 27.040 | d0/s7 | K27 |
| 347 | 3636.302 | 0.256 | 3.264 | d0/s7 | K28 |
| 348 | 3636.306 | 0.256 | 62.944 | d0/s7 | K29 |
| 349 | 3636.369 | 0.256 | 102.113 | d0/s7 | K30 |
| 350 | 3636.515 | 44.128 | 3.232 | d0/s7 | K24 |
| 351 | 3636.519 | 0.992 | 43.744 | d0/s7 | K25 |
| 352 | 3636.563 | 0.256 | 56.256 | d0/s7 | K26 |
| 353 | 3636.620 | 0.256 | 27.008 | d0/s7 | K27 |
| 354 | 3636.647 | 0.256 | 3.264 | d0/s7 | K28 |
| 355 | 3636.651 | 0.256 | 62.784 | d0/s7 | K29 |
| 356 | 3636.714 | 0.257 | 102.176 | d0/s7 | K30 |
| 357 | 3636.884 | 67.840 | 3.136 | d0/s7 | K24 |
| 358 | 3636.888 | 0.608 | 43.744 | d0/s7 | K25 |
| 359 | 3636.932 | 0.224 | 56.128 | d0/s7 | K26 |
| 360 | 3636.988 | 0.288 | 27.009 | d0/s7 | K27 |
| 361 | 3637.015 | 0.288 | 3.327 | d0/s7 | K28 |
| 362 | 3637.019 | 0.256 | 62.849 | d0/s7 | K29 |
| 363 | 3637.082 | 0.255 | 101.953 | d0/s7 | K30 |
| 364 | 3637.227 | 43.552 | 3.104 | d0/s7 | K24 |
| 365 | 3637.232 | 1.184 | 43.392 | d0/s7 | K25 |
| 366 | 3637.275 | 0.256 | 56.288 | d0/s7 | K26 |
| 367 | 3637.332 | 0.288 | 26.944 | d0/s7 | K27 |
| 368 | 3637.359 | 0.257 | 3.328 | d0/s7 | K28 |
| 369 | 3637.363 | 0.287 | 63.009 | d0/s7 | K29 |
| 370 | 3637.426 | 0.256 | 102.240 | d0/s7 | K30 |
| 371 | 3637.573 | 44.672 | 3.136 | d0/s7 | K24 |
| 372 | 3637.578 | 1.504 | 43.424 | d0/s7 | K25 |
| 373 | 3637.621 | 0.256 | 56.032 | d0/s7 | K26 |
| 374 | 3637.678 | 0.289 | 26.975 | d0/s7 | K27 |
| 375 | 3637.705 | 0.257 | 3.328 | d0/s7 | K28 |
| 376 | 3637.708 | 0.288 | 62.752 | d0/s7 | K29 |
| 377 | 3637.771 | 0.256 | 101.920 | d0/s7 | K30 |
| 378 | 3637.918 | 44.224 | 3.104 | d0/s7 | K24 |
| 379 | 3637.922 | 0.928 | 43.456 | d0/s7 | K25 |
| 380 | 3637.965 | 0.256 | 56.000 | d0/s7 | K26 |
| 381 | 3638.022 | 0.257 | 26.944 | d0/s7 | K27 |
| 382 | 3638.049 | 0.256 | 3.360 | d0/s7 | K28 |
| 383 | 3638.052 | 0.255 | 63.041 | d0/s7 | K29 |
| 384 | 3638.116 | 0.224 | 102.240 | d0/s7 | K30 |
| 385 | 3638.260 | 41.728 | 3.296 | d0/s7 | K24 |
| 386 | 3638.264 | 0.992 | 44.000 | d0/s7 | K25 |
| 387 | 3638.308 | 0.257 | 56.095 | d0/s7 | K26 |
| 388 | 3638.365 | 0.257 | 27.135 | d0/s7 | K27 |
| 389 | 3638.392 | 0.289 | 3.264 | d0/s7 | K28 |
| 390 | 3638.395 | 0.256 | 63.040 | d0/s7 | K29 |
| 391 | 3638.459 | 0.256 | 102.304 | d0/s7 | K30 |
| 392 | 3638.602 | 41.184 | 3.264 | d0/s7 | K24 |
| 393 | 3638.607 | 1.376 | 43.776 | d0/s7 | K25 |
| 394 | 3638.651 | 0.257 | 56.064 | d0/s7 | K26 |
| 395 | 3638.707 | 0.256 | 27.168 | d0/s7 | K27 |
| 396 | 3638.735 | 0.256 | 3.264 | d0/s7 | K28 |
| 397 | 3638.738 | 0.256 | 63.200 | d0/s7 | K29 |
| 398 | 3638.802 | 0.256 | 102.112 | d0/s7 | K30 |
| 399 | 3638.948 | 43.840 | 3.264 | d0/s7 | K24 |
| 400 | 3638.952 | 1.216 | 43.648 | d0/s7 | K25 |
| 401 | 3638.996 | 0.256 | 56.129 | d0/s7 | K26 |
| 402 | 3639.052 | 0.256 | 26.944 | d0/s7 | K27 |
| 403 | 3639.080 | 0.256 | 3.264 | d0/s7 | K28 |
| 404 | 3639.083 | 0.256 | 62.752 | d0/s7 | K29 |
| 405 | 3639.146 | 0.288 | 101.984 | d0/s7 | K30 |
| 406 | 3639.290 | 41.856 | 3.264 | d0/s7 | K24 |
| 407 | 3639.294 | 0.992 | 43.712 | d0/s7 | K25 |
| 408 | 3639.338 | 0.257 | 56.192 | d0/s7 | K26 |
| 409 | 3639.395 | 0.256 | 26.976 | d0/s7 | K27 |
| 410 | 3639.422 | 0.256 | 3.264 | d0/s7 | K28 |
| 411 | 3639.425 | 0.256 | 63.232 | d0/s7 | K29 |
| 412 | 3639.489 | 0.224 | 102.656 | d0/s7 | K30 |
| 413 | 3639.642 | 50.688 | 3.136 | d0/s7 | K24 |
| 414 | 3639.646 | 0.352 | 43.777 | d0/s7 | K25 |
| 415 | 3639.690 | 0.256 | 56.128 | d0/s7 | K26 |
| 416 | 3639.746 | 0.256 | 26.912 | d0/s7 | K27 |
| 417 | 3639.773 | 0.256 | 3.328 | d0/s7 | K28 |
| 418 | 3639.777 | 0.256 | 62.752 | d0/s7 | K29 |
| 419 | 3639.840 | 0.256 | 102.208 | d0/s7 | K30 |
| 420 | 3639.987 | 44.480 | 3.105 | d0/s7 | K24 |
| 421 | 3639.990 | 0.671 | 43.521 | d0/s7 | K25 |
| 422 | 3640.034 | 0.256 | 56.352 | d0/s7 | K26 |
| 423 | 3640.091 | 0.256 | 26.944 | d0/s7 | K27 |
| 424 | 3640.118 | 0.256 | 3.360 | d0/s7 | K28 |
| 425 | 3640.122 | 0.256 | 63.360 | d0/s7 | K29 |
| 426 | 3640.185 | 0.256 | 102.048 | d0/s7 | K30 |
| 427 | 3640.330 | 42.945 | 3.103 | d0/s7 | K24 |
| 428 | 3640.335 | 1.504 | 43.425 | d0/s7 | K25 |
| 429 | 3640.378 | 0.256 | 56.160 | d0/s7 | K26 |
| 430 | 3640.435 | 0.256 | 27.040 | d0/s7 | K27 |
| 431 | 3640.462 | 0.256 | 3.360 | d0/s7 | K28 |
| 432 | 3640.466 | 0.256 | 63.008 | d0/s7 | K29 |
| 433 | 3640.529 | 0.256 | 101.856 | d0/s7 | K30 |
| 434 | 3640.774 | 142.881 | 3.456 | d0/s7 | K31 |
| 435 | 3640.822 | 45.056 | 1.664 | d0/s7 | K32 |
| 436 | 3640.879 | 55.520 | 4.000 | d0/s7 | K33 |
| 437 | 3640.913 | 29.408 | 1.664 | d0/s7 | K9 |
| 438 | 3640.939 | 24.384 | 1.984 | d0/s7 | K34 |
| 439 | 3640.989 | 47.841 | 0.864 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 440 | 3641.026 | 36.576 | 0.864 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 441 | 3641.167 | 140.352 | 3.168 | d0/s7 | K35 |
| 442 | 3641.198 | 27.776 | 2.528 | d0/s7 | K36 |
| 443 | 3641.216 | 15.521 | 1.856 | d0/s7 | K19 |
| 444 | 3641.234 | 15.392 | 1.792 | d0/s7 | K37 |
| 445 | 3641.247 | 11.904 | 3.552 | d0/s7 | K38 |
| 446 | 3641.262 | 11.040 | 1.760 | d0/s7 | K39 |
| 447 | 3641.437 | 173.089 | 4.384 | d0/s7 | K40 |
| 448 | 3641.465 | 24.032 | 1.856 | d0/s7 | K41 |
| 449 | 3641.498 | 30.976 | 1.600 | d0/s7 | K42 |
| 450 | 3641.525 | 25.312 | 2.240 | d0/s7 | K43 |
| 451 | 3641.572 | 44.896 | 1.856 | d0/s7 | Memcpy DtoD (Device -> Device) (786432 B) |
| 452 | 3641.597 | 22.944 | 2.272 | d0/s7 | K44 |
| 453 | 3641.638 | 39.265 | 3.135 | d0/s7 | K45 |
| 454 | 3641.711 | 69.377 | 5.056 | d0/s7 | K46 |
| 455 | 3641.738 | 22.464 | 2.336 | d0/s7 | K47 |
| 456 | 3641.760 | 19.072 | 1.792 | d0/s7 | K9 |
| 457 | 3641.778 | 16.640 | 2.016 | d0/s7 | K34 |
| 458 | 3641.808 | 27.680 | 1.888 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 459 | 3641.842 | 31.712 | 1.952 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 460 | 3641.932 | 88.000 | 2.848 | d0/s7 | K48 |
| 461 | 3641.954 | 19.584 | 2.400 | d0/s7 | K49 |
| 462 | 3641.975 | 18.593 | 1.695 | d0/s7 | K50 |
| 463 | 3642.010 | 33.440 | 4.000 | d0/s7 | K33 |
| 464 | 3642.027 | 13.185 | 1.600 | d0/s7 | K9 |
| 465 | 3642.042 | 13.120 | 1.696 | d0/s7 | K34 |
| 466 | 3642.060 | 16.512 | 1.728 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 467 | 3642.088 | 26.400 | 1.888 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 468 | 3642.142 | 52.160 | 3.296 | d0/s7 | K51 |
| 469 | 3642.156 | 10.304 | 2.656 | d0/s7 | K52 |
| 470 | 3642.181 | 22.400 | 2.048 | d0/s7 | K53 |
| 471 | 3642.194 | 10.432 | 1.920 | d0/s7 | K22 |
| 472 | 3642.208 | 12.224 | 1.856 | d0/s7 | K54 |
| 473 | 3642.223 | 13.952 | 1.024 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 474 | 3642.250 | 25.632 | 2.080 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 475 | 3642.295 | 42.368 | 4.128 | d0/s7 | K48 |
| 476 | 3642.307 | 7.872 | 2.240 | d0/s7 | K49 |
| 477 | 3642.318 | 9.152 | 1.665 | d0/s7 | K50 |
| 478 | 3642.338 | 18.592 | 4.032 | d0/s7 | K33 |
| 479 | 3642.397 | 54.944 | 16.864 | d0/s7 | K55 |
| 480 | 3642.414 | 0.256 | 2.496 | d0/s7 | K36 |
| 481 | 3642.494 | 77.600 | 4.224 | d0/s7 | K40 |
| 482 | 3642.518 | 19.392 | 1.536 | d0/s7 | K41 |
| 483 | 3642.550 | 30.464 | 1.728 | d0/s7 | Memcpy DtoD (Device -> Device) (786432 B) |
| 484 | 3642.567 | 14.912 | 2.240 | d0/s7 | K44 |
| 485 | 3642.586 | 16.896 | 3.104 | d0/s7 | K45 |
| 486 | 3642.648 | 59.265 | 5.120 | d0/s7 | K46 |
| 487 | 3642.674 | 20.223 | 2.400 | d0/s7 | K47 |
| 488 | 3642.702 | 26.561 | 15.680 | d0/s7 | K56 |
| 489 | 3642.718 | 0.256 | 1.984 | d0/s7 | K50 |
| 490 | 3642.728 | 7.360 | 2.272 | d0/s7 | K49 |
| 491 | 3642.751 | 20.768 | 4.000 | d0/s7 | K33 |
| 492 | 3642.778 | 23.200 | 22.304 | d0/s7 | K57 |
| 493 | 3642.801 | 0.256 | 2.592 | d0/s7 | K52 |
| 494 | 3642.804 | 0.480 | 2.144 | d0/s7 | K53 |
| 495 | 3642.830 | 24.608 | 1.920 | d0/s7 | Memset (Device) (1536 B) |
| 496 | 3642.841 | 9.152 | 1.632 | d0/s7 | K58 |
| 497 | 3642.851 | 8.128 | 61.728 | d0/s7 | K59 |
| 498 | 3642.913 | 0.256 | 2.048 | d0/s7 | K50 |
| 499 | 3642.915 | 0.224 | 2.240 | d0/s7 | K49 |
| 500 | 3642.918 | 0.224 | 1.632 | d0/s7 | K50 |
| 501 | 3642.924 | 4.064 | 1.472 | d0/s7 | K60 |
| 502 | 3642.954 | 28.608 | 12.928 | d0/s7 | K61 |
| 503 | 3642.987 | 20.672 | 3.905 | d0/s7 | Memcpy DtoH (Device -> Pinned) (4 B) |
| 504 | 3643.038 | 47.232 | 1.856 | d0/s7 | Memcpy HtoD (Pageable -> Device) (56 B) |
| 505 | 3643.072 | 31.712 | 1.952 | d0/s7 | Memcpy HtoD (Pageable -> Device) (48 B) |
| 506 | 3643.117 | 42.720 | 4.384 | d0/s7 | K62 |
| 507 | 3643.134 | 13.344 | 4.224 | d0/s7 | K63 |
| 508 | 3643.148 | 9.376 | 4.192 | d0/s7 | K62 |
| 509 | 3643.161 | 8.960 | 4.224 | d0/s7 | K63 |
| 510 | 3643.173 | 7.648 | 1.376 | d0/s7 | K64 |
| 511 | 3643.188 | 13.280 | 1.344 | d0/s7 | K65 |
| 512 | 3643.205 | 16.064 | 2.048 | d0/s7 | K66 |
| 513 | 3643.216 | 8.992 | 2.816 | d0/s7 | Memcpy DtoH (Device -> Pinned) (4 B) |
| 514 | 3643.246 | 27.360 | 1.408 | d0/s7 | K60 |
| 515 | 3643.271 | 23.232 | 1.792 | d0/s7 | K67 |
| 516 | 3643.290 | 17.568 | 1.792 | d0/s7 | K68 |
| 517 | 3643.306 | 14.049 | 1.823 | d0/s7 | K69 |
| 518 | 3643.345 | 37.249 | 13.024 | d0/s7 | K70 |
| 519 | 3643.361 | 3.168 | 3.776 | d0/s7 | Memcpy DtoH (Device -> Pinned) (1 B) |
