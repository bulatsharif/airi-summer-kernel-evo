# Parent profile and optimization guidance

# B300 complete GPU timeline of your last candidate

- complete GPU-side trace: 519 activities; CPU/Python profiler records are intentionally omitted
- whole capture: span 9165.097 ms; active union 27.510 ms; idle holes 9137.587 ms (99.7%); largest hole 8877.672 ms
- that idle figure covers input generation, JIT compilation and the reference as well as your block, so it is not a measure of your kernels; the per-iteration section below is
- summed activity time: 27.510 ms; this may exceed active union when streams overlap
- source labels are hints: `candidate:<symbol>` is matched against this candidate's `@cute.kernel` definitions; other labels describe likely harness/runtime work
- candidate `@cute.kernel` symbols: `attention_kernel`, `fc_gelu_kernel`, `ln1_kernel`, `ln2_kernel`, `out_gemm_kernel`, `proj_gemm_kernel`, `qkv_gemm_kernel`
- observed candidate symbols: `attention_kernel`, `fc_gelu_kernel`, `ln1_kernel`, `ln2_kernel`, `out_gemm_kernel`, `proj_gemm_kernel`, `qkv_gemm_kernel`
- candidate symbols not observed in this trace: none

## One iteration of your block, launch by launch

Median of 55 timed iterations, 7 launches each. Microseconds from the start of the iteration.

- wall span 493.793; kernels busy 491.810; idle between your kernels 1.983 (0.4% of the span)
- largest single gap 0.672 immediately before `qkv_gemm_kernel`
- 46.048 elapses between one iteration and the next; that is host-side dispatch outside your block, excluded from the idle figure above, and fusing cannot remove it

| # | kernel | id | start | end | dur | idle before |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 1 | ln1_kernel | K24 | 0.000 | 3.104 | 3.104 | — |
| 2 | qkv_gemm_kernel | K25 | 3.776 | 62.656 | 58.880 | 0.672 |
| 3 | attention_kernel | K26 | 62.912 | 119.360 | 56.448 | 0.256 |
| 4 | out_gemm_kernel | K27 | 119.648 | 179.233 | 59.585 | 0.288 |
| 5 | ln2_kernel | K28 | 179.488 | 182.880 | 3.392 | 0.255 |
| 6 | fc_gelu_kernel | K29 | 183.136 | 265.217 | 82.081 | 0.256 |
| 7 | proj_gemm_kernel | K30 | 265.473 | 493.793 | 228.320 | 0.256 |

## Hottest GPU kernels (legacy aggregate)

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_proj_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 12.539 | 55 | 45.6 |
| kernel_cutlass_fc_gelu_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmemal… | 4.554 | 55 | 16.6 |
| kernel_cutlass_out_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 3.267 | 55 | 11.9 |
| kernel_cutlass_qkv_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 3.242 | 55 | 11.8 |
| kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 3.097 | 55 | 11.3 |
| kernel_cutlass_ln2_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo7681_tensorptrf32gmemo… | 0.184 | 55 | 0.7 |
| kernel_cutlass_ln1_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo7681_tenso… | 0.173 | 55 | 0.6 |
| void sgemm_largek_lds64<true, false, 6, 3, 4, 5, 2, 66>(float*, float const*, float con… | 0.061 | 1 | 0.2 |
| cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 0.041 | 4 | 0.1 |
| void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 0.033 | 17 | 0.1 |

## Kernel legend

| id | source hint | kernel | calls | total us | launch |
| --- | --- | --- | ---: | ---: | --- |
| K1 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 1 | 2.560 | grid=384x1x1, block=256x1x1, smem=0, regs=56 |
| K2 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 6 | 11.874 | grid=3x1x1, block=256x1x1, smem=0, regs=56 |
| K3 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 6 | 11.200 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K4 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::CUDAFunctorOnSelf_add<flo… | 2 | 3.585 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K5 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 1 | 1.823 | grid=9x1x1, block=256x1x1, smem=0, regs=56 |
| K6 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 2 | 3.233 | grid=3x1x1, block=128x1x1, smem=0, regs=32 |
| K7 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 1 | 2.144 | grid=12x1x1, block=256x1x1, smem=0, regs=56 |
| K8 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 4 | 21.888 | grid=1184x1x1, block=256x1x1, smem=0, regs=56 |
| K9 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 7 | 11.712 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K10 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 4 | 7.296 | grid=256x1x1, block=128x1x1, smem=0, regs=20 |
| K11 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 1 | 2.656 | grid=1728x1x1, block=128x1x1, smem=0, regs=32 |
| K12 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 2 | 8.576 | grid=4608x1x1, block=128x1x1, smem=0, regs=20 |
| K13 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 1 | 1.888 | grid=576x1x1, block=128x1x1, smem=0, regs=32 |
| K14 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 2.464 | grid=1536x1x1, block=128x1x1, smem=0, regs=20 |
| K15 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 6.464 | grid=2304x1x1, block=128x1x1, smem=0, regs=32 |
| K16 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 5.025 | grid=6144x1x1, block=128x1x1, smem=0, regs=20 |
| K17 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::… | 3 | 4.800 | grid=96x1x1, block=128x1x1, smem=0, regs=16 |
| K18 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::… | 1 | 1.376 | grid=288x1x1, block=128x1x1, smem=0, regs=16 |
| K19 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 3.296 | grid=288x1x1, block=128x1x1, smem=0, regs=32 |
| K20 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 1.952 | grid=640x1x1, block=128x1x1, smem=0, regs=20 |
| K21 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::… | 1 | 1.376 | grid=384x1x1, block=128x1x1, smem=0, regs=16 |
| K22 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 3.456 | grid=384x1x1, block=128x1x1, smem=0, regs=32 |
| K23 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 2.144 | grid=768x1x1, block=128x1x1, smem=0, regs=20 |
| K24 | candidate:ln1_kernel | kernel_cutlass_ln1_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo7681_tenso… | 55 | 172.962 | grid=128x1x1, block=128x1x1, smem=1024, regs=32 |
| K25 | candidate:qkv_gemm_kernel | kernel_cutlass_qkv_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 55 | 3241.995 | grid=18x8x1, block=128x1x1, smem=36864, regs=255 |
| K26 | candidate:attention_kernel | kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 55 | 3097.132 | grid=12x128x1, block=128x1x1, smem=1024, regs=40 |
| K27 | candidate:out_gemm_kernel | kernel_cutlass_out_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 55 | 3267.432 | grid=6x8x1, block=128x1x1, smem=36864, regs=255 |
| K28 | candidate:ln2_kernel | kernel_cutlass_ln2_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo7681_tensorptrf32gmemo… | 55 | 184.352 | grid=128x1x1, block=128x1x1, smem=1024, regs=32 |
| K29 | candidate:fc_gelu_kernel | kernel_cutlass_fc_gelu_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmemal… | 55 | 4554.413 | grid=24x8x1, block=128x1x1, smem=36864, regs=255 |
| K30 | candidate:proj_gemm_kernel | kernel_cutlass_proj_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 55 | 12539.425 | grid=6x8x1, block=128x1x1, smem=36864, regs=255 |
| K31 | framework/validation | void at::native::unrolled_elementwise_kernel<at::native::direct_copy_kernel_cuda(at::Te… | 1 | 4.032 | grid=192x1x1, block=128x1x1, smem=0, regs=30 |
| K32 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 1 | 1.760 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K33 | framework/validation | void at::native::(anonymous namespace)::vectorized_layer_norm_kernel<float, float, fals… | 4 | 15.744 | grid=128x1x1, block=32x4x1, smem=24, regs=40 |
| K34 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::float8_copy_kernel_cuda(a… | 3 | 5.089 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K35 | framework/validation | nvjet_sm103_qqsss_64x32_128x16_2x1_2cta_v_bz_TNT | 1 | 3.168 | grid=144x1x1, block=256x1x1, smem=172552, regs=255 |
| K36 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 5.088 | grid=1152x1x1, block=128x1x1, smem=0, regs=20 |
| K37 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::float8_copy_kernel_cuda(a… | 1 | 2.049 | grid=288x1x1, block=128x1x1, smem=0, regs=32 |
| K38 | framework/validation | void at::native::unrolled_elementwise_kernel<at::native::direct_copy_kernel_cuda(at::Te… | 1 | 3.712 | grid=576x1x1, block=128x1x1, smem=0, regs=30 |
| K39 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 1 | 1.760 | grid=288x1x1, block=128x1x1, smem=0, regs=32 |
| K40 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 2 | 8.480 | grid=4x4x12, block=64x1x1, smem=13056, regs=72 |
| K41 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 3.487 | grid=192x1x1, block=128x1x1, smem=0, regs=32 |
| K42 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<bool>, std::a… | 1 | 1.216 | grid=8x1x1, block=128x1x1, smem=0, regs=16 |
| K43 | framework/validation | void at::native::triu_tril_kernel<bool, int, true, 8, false>(at::cuda::detail::TensorIn… | 1 | 2.272 | grid=16x1x1, block=128x1x1, smem=0, regs=30 |
| K44 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 4.608 | grid=768x1x1, block=128x1x1, smem=0, regs=20 |
| K45 | framework/validation | void (anonymous namespace)::softmax_warp_forward<float, float, float, 7, false, false>(… | 2 | 6.431 | grid=192x1x1, block=32x4x1, smem=0, regs=32 |
| K46 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_nnn_align1_bias_f32_relu | 2 | 10.176 | grid=2x4x12, block=64x1x1, smem=12672, regs=84 |
| K47 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 4.608 | grid=384x1x1, block=128x1x1, smem=0, regs=20 |
| K48 | framework/validation | nvjet_sm103_qqsss_64x16_128x16_2x4_2cta_h_bz_TNT | 2 | 7.072 | grid=96x1x1, block=256x1x1, smem=156168, regs=255 |
| K49 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 4 | 9.216 | grid=384x1x1, block=128x1x1, smem=0, regs=20 |
| K50 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::CUDAFunctor_add<float>, s… | 5 | 8.960 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K51 | framework/validation | nvjet_sm103_qqsss_48x64_128x16_2x2_2cta_h_bz_TNN | 1 | 3.360 | grid=128x1x1, block=256x1x1, smem=188944, regs=255 |
| K52 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 5.217 | grid=1536x1x1, block=128x1x1, smem=0, regs=20 |
| K53 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::GeluCUDAKernelImpl(at::Te… | 2 | 4.064 | grid=384x1x1, block=128x1x1, smem=0, regs=32 |
| K54 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::float8_copy_kernel_cuda(a… | 1 | 2.080 | grid=384x1x1, block=128x1x1, smem=0, regs=32 |
| K55 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 1 | 16.896 | grid=72x4x1, block=64x1x1, smem=13056, regs=72 |
| K56 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 1 | 15.232 | grid=24x4x1, block=64x1x1, smem=13056, regs=72 |
| K57 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_64x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 1 | 22.240 | grid=48x4x1, block=64x1x1, smem=19200, regs=146 |
| K58 | framework/validation | void scal_kernel<float, float, 1, true, 6, 5, 5, 3>(cublasTransposeParams<float>, float… | 1 | 1.312 | grid=12x4x1, block=256x1x1, smem=0, regs=24 |
| K59 | framework/validation | void sgemm_largek_lds64<true, false, 6, 3, 4, 5, 2, 66>(float*, float const*, float con… | 1 | 61.344 | grid=12x16x4, block=32x4x1, smem=4868, regs=32 |
| K60 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AbsFunctor<float>, std::a… | 2 | 2.880 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K61 | framework/validation | void at::native::reduce_kernel<512, 1, at::native::ReduceOp<float, at::native::func_wra… | 1 | 12.992 | grid=1x1x1, block=512x1x1, smem=2064, regs=30 |
| K62 | framework/validation | void at::native::(anonymous namespace)::indexSelectSmallIndex<float, long, unsigned int… | 2 | 9.120 | grid=6x1x1, block=128x1x1, smem=0, regs=28 |
| K63 | framework/validation | void at::native::(anonymous namespace)::indexSelectSmallIndex<float, long, unsigned int… | 2 | 8.255 | grid=1x1x1, block=7x1x1, smem=0, regs=28 |
| K64 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::CUDAFunctor_add<float>, s… | 1 | 1.983 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K65 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AbsFunctor<float>, std::a… | 1 | 1.825 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K66 | framework/validation | void at::native::reduce_kernel<512, 1, at::native::ReduceOp<float, at::native::func_wra… | 1 | 2.240 | grid=1x1x1, block=32x1x1, smem=16, regs=30 |
| K67 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 1 | 1.504 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K68 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BinaryFunctor<float, floa… | 1 | 1.536 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K69 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BinaryFunctor<bool, bool,… | 1 | 1.792 | grid=96x1x1, block=128x1x1, smem=0, regs=30 |
| K70 | framework/validation | void at::native::reduce_kernel<512, 1, at::native::ReduceOp<bool, at::native::func_wrap… | 1 | 13.088 | grid=1x1x1, block=512x1x1, smem=528, regs=28 |

## Ordered GPU activities

`gap before` is device-wide idle time since all earlier GPU activity ended; zero means overlap or no measurable hole.

| # | start ms | gap before us | duration us | lane | activity |
| ---: | ---: | ---: | ---: | --- | --- |
| 1 | 0.000 | 0.000 | 2.560 | d0/s7 | K1 |
| 2 | 0.114 | 111.104 | 2.144 | d0/s7 | K2 |
| 3 | 0.158 | 42.496 | 1.984 | d0/s7 | K3 |
| 4 | 0.195 | 34.400 | 1.600 | d0/s7 | K4 |
| 5 | 0.216 | 19.456 | 1.792 | d0/s7 | K2 |
| 6 | 0.228 | 10.080 | 1.600 | d0/s7 | K3 |
| 7 | 0.243 | 13.984 | 1.792 | d0/s7 | K2 |
| 8 | 0.255 | 9.537 | 1.983 | d0/s7 | K3 |
| 9 | 0.266 | 8.992 | 1.985 | d0/s7 | K4 |
| 10 | 0.287 | 19.423 | 2.177 | d0/s7 | K2 |
| 11 | 0.298 | 8.607 | 2.017 | d0/s7 | K3 |
| 12 | 0.313 | 13.760 | 1.823 | d0/s7 | K5 |
| 13 | 0.326 | 11.040 | 1.473 | d0/s7 | K6 |
| 14 | 0.342 | 14.207 | 1.825 | d0/s7 | K2 |
| 15 | 0.352 | 7.808 | 1.600 | d0/s7 | K3 |
| 16 | 0.367 | 14.048 | 2.144 | d0/s7 | K7 |
| 17 | 0.378 | 8.128 | 1.760 | d0/s7 | K6 |
| 18 | 0.392 | 13.024 | 2.144 | d0/s7 | K2 |
| 19 | 0.404 | 9.280 | 2.016 | d0/s7 | K3 |
| 20 | 0.429 | 23.520 | 5.760 | d0/s7 | K8 |
| 21 | 0.445 | 10.176 | 4.224 | d0/s7 | K8 |
| 22 | 0.461 | 11.328 | 5.984 | d0/s7 | K8 |
| 23 | 0.477 | 10.016 | 5.920 | d0/s7 | K8 |
| 24 | 0.519 | 35.936 | 1.792 | d0/s7 | K9 |
| 25 | 30.618 | 30097.748 | 1.920 | d0/s7 | K10 |
| 26 | 30.808 | 187.457 | 2.656 | d0/s7 | K11 |
| 27 | 56.050 | 25239.591 | 4.224 | d0/s7 | K12 |
| 28 | 56.210 | 155.712 | 1.888 | d0/s7 | K13 |
| 29 | 81.516 | 25304.519 | 2.464 | d0/s7 | K14 |
| 30 | 81.699 | 180.160 | 3.200 | d0/s7 | K15 |
| 31 | 107.217 | 25515.495 | 5.025 | d0/s7 | K16 |
| 32 | 107.406 | 183.776 | 3.264 | d0/s7 | K15 |
| 33 | 131.764 | 24353.957 | 4.352 | d0/s7 | K12 |
| 34 | 131.952 | 183.712 | 1.600 | d0/s7 | K17 |
| 35 | 132.013 | 59.360 | 1.792 | d0/s7 | K9 |
| 36 | 155.939 | 23924.963 | 1.760 | d0/s7 | K10 |
| 37 | 156.093 | 151.552 | 1.376 | d0/s7 | K18 |
| 38 | 156.153 | 58.881 | 1.471 | d0/s7 | K19 |
| 39 | 181.929 | 25774.664 | 1.952 | d0/s7 | K20 |
| 40 | 182.089 | 158.497 | 1.568 | d0/s7 | K17 |
| 41 | 182.155 | 63.680 | 1.792 | d0/s7 | K9 |
| 42 | 205.987 | 23830.979 | 1.856 | d0/s7 | K10 |
| 43 | 206.140 | 150.945 | 1.632 | d0/s7 | K17 |
| 44 | 206.199 | 57.600 | 1.408 | d0/s7 | K9 |
| 45 | 230.094 | 23892.674 | 1.760 | d0/s7 | K10 |
| 46 | 230.252 | 156.193 | 1.376 | d0/s7 | K21 |
| 47 | 230.319 | 66.144 | 1.568 | d0/s7 | K22 |
| 48 | 254.642 | 24321.604 | 2.144 | d0/s7 | K23 |
| 49 | 9132.317 | 8877672.430 | 3.712 | d0/s7 | K24 |
| 50 | 9132.330 | 9.600 | 61.888 | d0/s7 | K25 |
| 51 | 9132.392 | 0.256 | 56.416 | d0/s7 | K26 |
| 52 | 9132.449 | 0.256 | 62.241 | d0/s7 | K27 |
| 53 | 9132.511 | 0.256 | 3.935 | d0/s7 | K28 |
| 54 | 9132.516 | 0.257 | 84.192 | d0/s7 | K29 |
| 55 | 9132.600 | 0.256 | 241.440 | d0/s7 | K30 |
| 56 | 9132.842 | 0.257 | 3.200 | d0/s7 | K24 |
| 57 | 9132.845 | 0.255 | 58.880 | d0/s7 | K25 |
| 58 | 9132.904 | 0.257 | 56.352 | d0/s7 | K26 |
| 59 | 9132.961 | 0.256 | 59.392 | d0/s7 | K27 |
| 60 | 9133.021 | 0.256 | 3.296 | d0/s7 | K28 |
| 61 | 9133.024 | 0.256 | 82.336 | d0/s7 | K29 |
| 62 | 9133.107 | 0.256 | 227.681 | d0/s7 | K30 |
| 63 | 9133.335 | 0.256 | 3.072 | d0/s7 | K24 |
| 64 | 9133.338 | 0.256 | 58.752 | d0/s7 | K25 |
| 65 | 9133.397 | 0.256 | 56.416 | d0/s7 | K26 |
| 66 | 9133.454 | 0.256 | 59.584 | d0/s7 | K27 |
| 67 | 9133.514 | 0.256 | 3.360 | d0/s7 | K28 |
| 68 | 9133.517 | 0.288 | 83.136 | d0/s7 | K29 |
| 69 | 9133.601 | 0.257 | 228.000 | d0/s7 | K30 |
| 70 | 9133.829 | 0.256 | 3.104 | d0/s7 | K24 |
| 71 | 9133.832 | 0.256 | 58.816 | d0/s7 | K25 |
| 72 | 9133.891 | 0.256 | 56.448 | d0/s7 | K26 |
| 73 | 9133.948 | 0.256 | 59.360 | d0/s7 | K27 |
| 74 | 9134.008 | 0.256 | 3.391 | d0/s7 | K28 |
| 75 | 9134.011 | 0.257 | 82.176 | d0/s7 | K29 |
| 76 | 9134.094 | 0.224 | 228.193 | d0/s7 | K30 |
| 77 | 9134.322 | 0.288 | 3.072 | d0/s7 | K24 |
| 78 | 9134.325 | 0.255 | 58.689 | d0/s7 | K25 |
| 79 | 9134.384 | 0.256 | 56.128 | d0/s7 | K26 |
| 80 | 9134.441 | 0.256 | 59.232 | d0/s7 | K27 |
| 81 | 9134.500 | 0.256 | 3.392 | d0/s7 | K28 |
| 82 | 9134.504 | 0.256 | 82.240 | d0/s7 | K29 |
| 83 | 9134.586 | 0.256 | 227.393 | d0/s7 | K30 |
| 84 | 9134.922 | 108.512 | 3.104 | d0/s7 | K24 |
| 85 | 9134.927 | 1.632 | 58.848 | d0/s7 | K25 |
| 86 | 9134.986 | 0.256 | 56.257 | d0/s7 | K26 |
| 87 | 9135.043 | 0.255 | 59.265 | d0/s7 | K27 |
| 88 | 9135.102 | 0.255 | 3.393 | d0/s7 | K28 |
| 89 | 9135.106 | 0.256 | 82.368 | d0/s7 | K29 |
| 90 | 9135.188 | 0.256 | 227.457 | d0/s7 | K30 |
| 91 | 9135.478 | 61.920 | 3.200 | d0/s7 | K24 |
| 92 | 9135.482 | 1.023 | 58.880 | d0/s7 | K25 |
| 93 | 9135.541 | 0.256 | 56.192 | d0/s7 | K26 |
| 94 | 9135.598 | 0.256 | 59.168 | d0/s7 | K27 |
| 95 | 9135.657 | 0.256 | 3.296 | d0/s7 | K28 |
| 96 | 9135.661 | 0.288 | 82.304 | d0/s7 | K29 |
| 97 | 9135.743 | 0.288 | 227.649 | d0/s7 | K30 |
| 98 | 9136.016 | 44.832 | 3.168 | d0/s7 | K24 |
| 99 | 9136.021 | 1.984 | 59.104 | d0/s7 | K25 |
| 100 | 9136.080 | 0.256 | 56.225 | d0/s7 | K26 |
| 101 | 9136.137 | 0.255 | 59.457 | d0/s7 | K27 |
| 102 | 9136.196 | 0.255 | 3.297 | d0/s7 | K28 |
| 103 | 9136.200 | 0.256 | 83.456 | d0/s7 | K29 |
| 104 | 9136.284 | 0.256 | 228.160 | d0/s7 | K30 |
| 105 | 9136.557 | 44.673 | 3.167 | d0/s7 | K24 |
| 106 | 9136.561 | 1.185 | 58.912 | d0/s7 | K25 |
| 107 | 9136.620 | 0.256 | 56.448 | d0/s7 | K26 |
| 108 | 9136.677 | 0.256 | 59.200 | d0/s7 | K27 |
| 109 | 9136.736 | 0.256 | 3.296 | d0/s7 | K28 |
| 110 | 9136.740 | 0.256 | 82.560 | d0/s7 | K29 |
| 111 | 9136.823 | 0.256 | 228.673 | d0/s7 | K30 |
| 112 | 9137.096 | 44.288 | 3.200 | d0/s7 | K24 |
| 113 | 9137.100 | 1.152 | 59.136 | d0/s7 | K25 |
| 114 | 9137.159 | 0.256 | 56.448 | d0/s7 | K26 |
| 115 | 9137.216 | 0.288 | 59.744 | d0/s7 | K27 |
| 116 | 9137.276 | 0.257 | 3.295 | d0/s7 | K28 |
| 117 | 9137.280 | 0.257 | 83.744 | d0/s7 | K29 |
| 118 | 9137.364 | 0.288 | 227.264 | d0/s7 | K30 |
| 119 | 9137.633 | 42.305 | 3.072 | d0/s7 | K24 |
| 120 | 9137.637 | 0.832 | 58.816 | d0/s7 | K25 |
| 121 | 9137.696 | 0.256 | 56.384 | d0/s7 | K26 |
| 122 | 9137.753 | 0.256 | 59.392 | d0/s7 | K27 |
| 123 | 9137.812 | 0.256 | 3.392 | d0/s7 | K28 |
| 124 | 9137.816 | 0.256 | 82.208 | d0/s7 | K29 |
| 125 | 9137.899 | 0.256 | 227.713 | d0/s7 | K30 |
| 126 | 9138.172 | 46.048 | 3.104 | d0/s7 | K24 |
| 127 | 9138.176 | 0.672 | 58.880 | d0/s7 | K25 |
| 128 | 9138.235 | 0.256 | 56.448 | d0/s7 | K26 |
| 129 | 9138.292 | 0.288 | 59.585 | d0/s7 | K27 |
| 130 | 9138.352 | 0.255 | 3.392 | d0/s7 | K28 |
| 131 | 9138.355 | 0.256 | 82.081 | d0/s7 | K29 |
| 132 | 9138.438 | 0.256 | 228.320 | d0/s7 | K30 |
| 133 | 9138.710 | 43.520 | 3.105 | d0/s7 | K24 |
| 134 | 9138.714 | 1.151 | 58.849 | d0/s7 | K25 |
| 135 | 9138.773 | 0.255 | 56.065 | d0/s7 | K26 |
| 136 | 9138.829 | 0.256 | 59.328 | d0/s7 | K27 |
| 137 | 9138.889 | 0.256 | 3.392 | d0/s7 | K28 |
| 138 | 9138.893 | 0.256 | 82.240 | d0/s7 | K29 |
| 139 | 9138.975 | 0.256 | 227.585 | d0/s7 | K30 |
| 140 | 9139.246 | 43.200 | 3.040 | d0/s7 | K24 |
| 141 | 9139.250 | 1.504 | 58.688 | d0/s7 | K25 |
| 142 | 9139.309 | 0.256 | 56.416 | d0/s7 | K26 |
| 143 | 9139.366 | 0.256 | 59.392 | d0/s7 | K27 |
| 144 | 9139.426 | 0.257 | 3.391 | d0/s7 | K28 |
| 145 | 9139.429 | 0.256 | 83.137 | d0/s7 | K29 |
| 146 | 9139.513 | 0.255 | 227.968 | d0/s7 | K30 |
| 147 | 9139.785 | 44.289 | 3.200 | d0/s7 | K24 |
| 148 | 9139.790 | 1.664 | 58.880 | d0/s7 | K25 |
| 149 | 9139.849 | 0.257 | 56.096 | d0/s7 | K26 |
| 150 | 9139.905 | 0.256 | 59.392 | d0/s7 | K27 |
| 151 | 9139.965 | 0.256 | 3.296 | d0/s7 | K28 |
| 152 | 9139.968 | 0.256 | 83.488 | d0/s7 | K29 |
| 153 | 9140.052 | 0.256 | 227.681 | d0/s7 | K30 |
| 154 | 9140.323 | 43.584 | 3.168 | d0/s7 | K24 |
| 155 | 9140.327 | 0.864 | 58.848 | d0/s7 | K25 |
| 156 | 9140.387 | 0.256 | 56.320 | d0/s7 | K26 |
| 157 | 9140.443 | 0.256 | 59.296 | d0/s7 | K27 |
| 158 | 9140.503 | 0.256 | 3.264 | d0/s7 | K28 |
| 159 | 9140.506 | 0.288 | 82.273 | d0/s7 | K29 |
| 160 | 9140.589 | 0.256 | 228.256 | d0/s7 | K30 |
| 161 | 9140.872 | 54.496 | 3.200 | d0/s7 | K24 |
| 162 | 9140.876 | 0.928 | 58.977 | d0/s7 | K25 |
| 163 | 9140.935 | 0.255 | 56.609 | d0/s7 | K26 |
| 164 | 9140.992 | 0.256 | 59.200 | d0/s7 | K27 |
| 165 | 9141.051 | 0.256 | 3.328 | d0/s7 | K28 |
| 166 | 9141.055 | 0.256 | 82.272 | d0/s7 | K29 |
| 167 | 9141.137 | 0.256 | 228.225 | d0/s7 | K30 |
| 168 | 9141.408 | 42.784 | 3.200 | d0/s7 | K24 |
| 169 | 9141.413 | 1.120 | 59.040 | d0/s7 | K25 |
| 170 | 9141.472 | 0.256 | 56.384 | d0/s7 | K26 |
| 171 | 9141.529 | 0.289 | 59.456 | d0/s7 | K27 |
| 172 | 9141.588 | 0.256 | 3.296 | d0/s7 | K28 |
| 173 | 9141.592 | 0.256 | 82.337 | d0/s7 | K29 |
| 174 | 9141.675 | 0.255 | 227.809 | d0/s7 | K30 |
| 175 | 9141.947 | 44.928 | 3.072 | d0/s7 | K24 |
| 176 | 9141.951 | 0.896 | 58.816 | d0/s7 | K25 |
| 177 | 9142.010 | 0.256 | 56.417 | d0/s7 | K26 |
| 178 | 9142.067 | 0.256 | 59.392 | d0/s7 | K27 |
| 179 | 9142.127 | 0.256 | 3.392 | d0/s7 | K28 |
| 180 | 9142.130 | 0.256 | 83.552 | d0/s7 | K29 |
| 181 | 9142.214 | 0.256 | 227.425 | d0/s7 | K30 |
| 182 | 9142.485 | 43.393 | 3.104 | d0/s7 | K24 |
| 183 | 9142.490 | 2.336 | 58.912 | d0/s7 | K25 |
| 184 | 9142.549 | 0.256 | 56.352 | d0/s7 | K26 |
| 185 | 9142.606 | 0.256 | 59.552 | d0/s7 | K27 |
| 186 | 9142.666 | 0.288 | 3.392 | d0/s7 | K28 |
| 187 | 9142.670 | 0.256 | 82.273 | d0/s7 | K29 |
| 188 | 9142.752 | 0.255 | 227.553 | d0/s7 | K30 |
| 189 | 9143.024 | 44.704 | 3.072 | d0/s7 | K24 |
| 190 | 9143.029 | 1.472 | 58.849 | d0/s7 | K25 |
| 191 | 9143.088 | 0.255 | 56.320 | d0/s7 | K26 |
| 192 | 9143.145 | 0.257 | 59.392 | d0/s7 | K27 |
| 193 | 9143.204 | 0.256 | 3.392 | d0/s7 | K28 |
| 194 | 9143.208 | 0.255 | 83.841 | d0/s7 | K29 |
| 195 | 9143.292 | 0.256 | 227.456 | d0/s7 | K30 |
| 196 | 9143.562 | 42.529 | 3.072 | d0/s7 | K24 |
| 197 | 9143.566 | 0.991 | 58.881 | d0/s7 | K25 |
| 198 | 9143.625 | 0.288 | 56.256 | d0/s7 | K26 |
| 199 | 9143.682 | 0.256 | 59.232 | d0/s7 | K27 |
| 200 | 9143.741 | 0.256 | 3.392 | d0/s7 | K28 |
| 201 | 9143.745 | 0.256 | 83.104 | d0/s7 | K29 |
| 202 | 9143.828 | 0.256 | 227.393 | d0/s7 | K30 |
| 203 | 9144.100 | 44.288 | 3.200 | d0/s7 | K24 |
| 204 | 9144.104 | 1.280 | 58.912 | d0/s7 | K25 |
| 205 | 9144.164 | 0.256 | 56.192 | d0/s7 | K26 |
| 206 | 9144.220 | 0.288 | 59.169 | d0/s7 | K27 |
| 207 | 9144.279 | 0.256 | 3.296 | d0/s7 | K28 |
| 208 | 9144.283 | 0.256 | 82.272 | d0/s7 | K29 |
| 209 | 9144.366 | 0.288 | 227.616 | d0/s7 | K30 |
| 210 | 9144.638 | 44.481 | 3.200 | d0/s7 | K24 |
| 211 | 9144.642 | 0.896 | 59.072 | d0/s7 | K25 |
| 212 | 9144.701 | 0.256 | 56.320 | d0/s7 | K26 |
| 213 | 9144.758 | 0.256 | 59.264 | d0/s7 | K27 |
| 214 | 9144.817 | 0.256 | 3.264 | d0/s7 | K28 |
| 215 | 9144.821 | 0.288 | 83.232 | d0/s7 | K29 |
| 216 | 9144.904 | 0.256 | 227.553 | d0/s7 | K30 |
| 217 | 9145.173 | 41.120 | 3.200 | d0/s7 | K24 |
| 218 | 9145.177 | 0.480 | 59.008 | d0/s7 | K25 |
| 219 | 9145.236 | 0.256 | 56.288 | d0/s7 | K26 |
| 220 | 9145.292 | 0.256 | 59.425 | d0/s7 | K27 |
| 221 | 9145.352 | 0.288 | 3.296 | d0/s7 | K28 |
| 222 | 9145.356 | 0.257 | 83.872 | d0/s7 | K29 |
| 223 | 9145.440 | 0.256 | 227.936 | d0/s7 | K30 |
| 224 | 9145.708 | 39.841 | 3.200 | d0/s7 | K24 |
| 225 | 9145.712 | 0.831 | 59.073 | d0/s7 | K25 |
| 226 | 9145.771 | 0.288 | 56.256 | d0/s7 | K26 |
| 227 | 9145.827 | 0.256 | 59.424 | d0/s7 | K27 |
| 228 | 9145.887 | 0.256 | 3.296 | d0/s7 | K28 |
| 229 | 9145.891 | 0.256 | 83.808 | d0/s7 | K29 |
| 230 | 9145.975 | 0.256 | 227.649 | d0/s7 | K30 |
| 231 | 9146.247 | 44.160 | 3.104 | d0/s7 | K24 |
| 232 | 9146.250 | 0.704 | 58.848 | d0/s7 | K25 |
| 233 | 9146.309 | 0.256 | 56.448 | d0/s7 | K26 |
| 234 | 9146.366 | 0.255 | 59.264 | d0/s7 | K27 |
| 235 | 9146.426 | 0.256 | 3.393 | d0/s7 | K28 |
| 236 | 9146.429 | 0.255 | 82.432 | d0/s7 | K29 |
| 237 | 9146.512 | 0.257 | 227.456 | d0/s7 | K30 |
| 238 | 9146.781 | 41.376 | 3.072 | d0/s7 | K24 |
| 239 | 9146.785 | 1.537 | 58.912 | d0/s7 | K25 |
| 240 | 9146.845 | 0.256 | 56.576 | d0/s7 | K26 |
| 241 | 9146.901 | 0.256 | 59.552 | d0/s7 | K27 |
| 242 | 9146.961 | 0.256 | 3.392 | d0/s7 | K28 |
| 243 | 9146.965 | 0.256 | 81.792 | d0/s7 | K29 |
| 244 | 9147.047 | 0.256 | 227.841 | d0/s7 | K30 |
| 245 | 9147.315 | 40.096 | 3.104 | d0/s7 | K24 |
| 246 | 9147.318 | 0.448 | 58.816 | d0/s7 | K25 |
| 247 | 9147.378 | 0.256 | 56.192 | d0/s7 | K26 |
| 248 | 9147.434 | 0.256 | 59.200 | d0/s7 | K27 |
| 249 | 9147.493 | 0.256 | 3.360 | d0/s7 | K28 |
| 250 | 9147.497 | 0.288 | 83.808 | d0/s7 | K29 |
| 251 | 9147.581 | 0.257 | 227.616 | d0/s7 | K30 |
| 252 | 9147.854 | 45.567 | 3.104 | d0/s7 | K24 |
| 253 | 9147.858 | 0.256 | 58.849 | d0/s7 | K25 |
| 254 | 9147.917 | 0.255 | 56.129 | d0/s7 | K26 |
| 255 | 9147.973 | 0.256 | 59.520 | d0/s7 | K27 |
| 256 | 9148.033 | 0.256 | 3.392 | d0/s7 | K28 |
| 257 | 9148.037 | 0.256 | 81.792 | d0/s7 | K29 |
| 258 | 9148.119 | 0.256 | 227.745 | d0/s7 | K30 |
| 259 | 9148.387 | 41.088 | 3.200 | d0/s7 | K24 |
| 260 | 9148.391 | 0.512 | 58.848 | d0/s7 | K25 |
| 261 | 9148.450 | 0.256 | 55.936 | d0/s7 | K26 |
| 262 | 9148.506 | 0.256 | 59.200 | d0/s7 | K27 |
| 263 | 9148.566 | 0.256 | 3.296 | d0/s7 | K28 |
| 264 | 9148.570 | 0.288 | 82.305 | d0/s7 | K29 |
| 265 | 9148.652 | 0.255 | 227.745 | d0/s7 | K30 |
| 266 | 9148.923 | 42.720 | 3.168 | d0/s7 | K24 |
| 267 | 9148.926 | 0.256 | 58.912 | d0/s7 | K25 |
| 268 | 9148.985 | 0.257 | 56.095 | d0/s7 | K26 |
| 269 | 9149.042 | 0.257 | 59.232 | d0/s7 | K27 |
| 270 | 9149.101 | 0.256 | 3.296 | d0/s7 | K28 |
| 271 | 9149.105 | 0.256 | 83.488 | d0/s7 | K29 |
| 272 | 9149.188 | 0.256 | 227.744 | d0/s7 | K30 |
| 273 | 9149.458 | 42.272 | 3.200 | d0/s7 | K24 |
| 274 | 9149.462 | 0.320 | 58.913 | d0/s7 | K25 |
| 275 | 9149.521 | 0.256 | 56.544 | d0/s7 | K26 |
| 276 | 9149.578 | 0.256 | 59.328 | d0/s7 | K27 |
| 277 | 9149.637 | 0.256 | 3.296 | d0/s7 | K28 |
| 278 | 9149.641 | 0.256 | 82.208 | d0/s7 | K29 |
| 279 | 9149.723 | 0.256 | 227.873 | d0/s7 | K30 |
| 280 | 9149.993 | 41.472 | 3.200 | d0/s7 | K24 |
| 281 | 9149.996 | 0.416 | 58.848 | d0/s7 | K25 |
| 282 | 9150.055 | 0.256 | 56.192 | d0/s7 | K26 |
| 283 | 9150.112 | 0.257 | 59.424 | d0/s7 | K27 |
| 284 | 9150.172 | 0.256 | 3.264 | d0/s7 | K28 |
| 285 | 9150.175 | 0.256 | 83.872 | d0/s7 | K29 |
| 286 | 9150.259 | 0.256 | 227.905 | d0/s7 | K30 |
| 287 | 9150.528 | 40.480 | 3.072 | d0/s7 | K24 |
| 288 | 9150.531 | 0.543 | 58.913 | d0/s7 | K25 |
| 289 | 9150.590 | 0.256 | 56.384 | d0/s7 | K26 |
| 290 | 9150.647 | 0.256 | 59.328 | d0/s7 | K27 |
| 291 | 9150.707 | 0.256 | 3.392 | d0/s7 | K28 |
| 292 | 9150.710 | 0.256 | 82.176 | d0/s7 | K29 |
| 293 | 9150.793 | 0.256 | 227.649 | d0/s7 | K30 |
| 294 | 9151.060 | 39.521 | 3.104 | d0/s7 | K24 |
| 295 | 9151.065 | 1.568 | 58.912 | d0/s7 | K25 |
| 296 | 9151.124 | 0.256 | 56.321 | d0/s7 | K26 |
| 297 | 9151.180 | 0.287 | 59.777 | d0/s7 | K27 |
| 298 | 9151.240 | 0.256 | 3.360 | d0/s7 | K28 |
| 299 | 9151.244 | 0.255 | 82.177 | d0/s7 | K29 |
| 300 | 9151.326 | 0.256 | 228.000 | d0/s7 | K30 |
| 301 | 9151.597 | 43.040 | 3.072 | d0/s7 | K24 |
| 302 | 9151.601 | 0.865 | 58.752 | d0/s7 | K25 |
| 303 | 9151.660 | 0.255 | 56.289 | d0/s7 | K26 |
| 304 | 9151.717 | 0.256 | 59.200 | d0/s7 | K27 |
| 305 | 9151.776 | 0.256 | 3.360 | d0/s7 | K28 |
| 306 | 9151.780 | 0.288 | 83.712 | d0/s7 | K29 |
| 307 | 9151.864 | 0.288 | 227.553 | d0/s7 | K30 |
| 308 | 9152.134 | 41.952 | 3.072 | d0/s7 | K24 |
| 309 | 9152.137 | 0.288 | 58.784 | d0/s7 | K25 |
| 310 | 9152.196 | 0.256 | 56.224 | d0/s7 | K26 |
| 311 | 9152.252 | 0.256 | 59.264 | d0/s7 | K27 |
| 312 | 9152.312 | 0.256 | 3.392 | d0/s7 | K28 |
| 313 | 9152.316 | 0.288 | 83.425 | d0/s7 | K29 |
| 314 | 9152.399 | 0.256 | 227.776 | d0/s7 | K30 |
| 315 | 9152.669 | 41.920 | 3.200 | d0/s7 | K24 |
| 316 | 9152.673 | 1.025 | 58.880 | d0/s7 | K25 |
| 317 | 9152.732 | 0.255 | 56.161 | d0/s7 | K26 |
| 318 | 9152.789 | 0.288 | 59.232 | d0/s7 | K27 |
| 319 | 9152.848 | 0.256 | 3.296 | d0/s7 | K28 |
| 320 | 9152.852 | 0.256 | 83.744 | d0/s7 | K29 |
| 321 | 9152.936 | 0.256 | 227.553 | d0/s7 | K30 |
| 322 | 9153.205 | 41.376 | 3.168 | d0/s7 | K24 |
| 323 | 9153.209 | 0.928 | 59.104 | d0/s7 | K25 |
| 324 | 9153.268 | 0.256 | 56.192 | d0/s7 | K26 |
| 325 | 9153.325 | 0.256 | 59.264 | d0/s7 | K27 |
| 326 | 9153.384 | 0.256 | 3.296 | d0/s7 | K28 |
| 327 | 9153.388 | 0.256 | 82.305 | d0/s7 | K29 |
| 328 | 9153.470 | 0.256 | 227.584 | d0/s7 | K30 |
| 329 | 9153.740 | 42.432 | 3.200 | d0/s7 | K24 |
| 330 | 9153.744 | 0.512 | 58.880 | d0/s7 | K25 |
| 331 | 9153.803 | 0.257 | 56.608 | d0/s7 | K26 |
| 332 | 9153.860 | 0.256 | 59.168 | d0/s7 | K27 |
| 333 | 9153.919 | 0.256 | 3.328 | d0/s7 | K28 |
| 334 | 9153.923 | 0.256 | 82.304 | d0/s7 | K29 |
| 335 | 9154.006 | 0.256 | 227.808 | d0/s7 | K30 |
| 336 | 9154.275 | 41.537 | 3.200 | d0/s7 | K24 |
| 337 | 9154.279 | 0.480 | 58.944 | d0/s7 | K25 |
| 338 | 9154.338 | 0.256 | 56.512 | d0/s7 | K26 |
| 339 | 9154.395 | 0.288 | 59.456 | d0/s7 | K27 |
| 340 | 9154.454 | 0.256 | 3.296 | d0/s7 | K28 |
| 341 | 9154.458 | 0.256 | 82.272 | d0/s7 | K29 |
| 342 | 9154.540 | 0.288 | 227.745 | d0/s7 | K30 |
| 343 | 9154.810 | 42.080 | 3.072 | d0/s7 | K24 |
| 344 | 9154.814 | 0.256 | 58.849 | d0/s7 | K25 |
| 345 | 9154.873 | 0.255 | 56.385 | d0/s7 | K26 |
| 346 | 9154.929 | 0.255 | 59.265 | d0/s7 | K27 |
| 347 | 9154.989 | 0.256 | 3.392 | d0/s7 | K28 |
| 348 | 9154.993 | 0.256 | 83.456 | d0/s7 | K29 |
| 349 | 9155.076 | 0.256 | 227.777 | d0/s7 | K30 |
| 350 | 9155.345 | 41.472 | 3.072 | d0/s7 | K24 |
| 351 | 9155.351 | 2.048 | 58.880 | d0/s7 | K25 |
| 352 | 9155.410 | 0.256 | 56.384 | d0/s7 | K26 |
| 353 | 9155.466 | 0.256 | 59.488 | d0/s7 | K27 |
| 354 | 9155.526 | 0.288 | 3.360 | d0/s7 | K28 |
| 355 | 9155.530 | 0.256 | 82.208 | d0/s7 | K29 |
| 356 | 9155.612 | 0.257 | 227.744 | d0/s7 | K30 |
| 357 | 9155.884 | 44.352 | 3.072 | d0/s7 | K24 |
| 358 | 9155.888 | 0.640 | 58.848 | d0/s7 | K25 |
| 359 | 9155.947 | 0.256 | 56.128 | d0/s7 | K26 |
| 360 | 9156.004 | 0.257 | 59.552 | d0/s7 | K27 |
| 361 | 9156.063 | 0.256 | 3.360 | d0/s7 | K28 |
| 362 | 9156.067 | 0.256 | 83.616 | d0/s7 | K29 |
| 363 | 9156.151 | 0.256 | 227.745 | d0/s7 | K30 |
| 364 | 9156.422 | 43.487 | 3.073 | d0/s7 | K24 |
| 365 | 9156.426 | 0.671 | 58.816 | d0/s7 | K25 |
| 366 | 9156.485 | 0.256 | 56.160 | d0/s7 | K26 |
| 367 | 9156.541 | 0.256 | 59.328 | d0/s7 | K27 |
| 368 | 9156.601 | 0.256 | 3.392 | d0/s7 | K28 |
| 369 | 9156.605 | 0.256 | 81.792 | d0/s7 | K29 |
| 370 | 9156.687 | 0.256 | 227.457 | d0/s7 | K30 |
| 371 | 9156.958 | 43.968 | 3.168 | d0/s7 | K24 |
| 372 | 9156.963 | 1.440 | 58.720 | d0/s7 | K25 |
| 373 | 9157.022 | 0.256 | 56.224 | d0/s7 | K26 |
| 374 | 9157.078 | 0.257 | 59.232 | d0/s7 | K27 |
| 375 | 9157.138 | 0.255 | 3.297 | d0/s7 | K28 |
| 376 | 9157.141 | 0.256 | 82.304 | d0/s7 | K29 |
| 377 | 9157.224 | 0.256 | 227.585 | d0/s7 | K30 |
| 378 | 9157.492 | 41.055 | 3.168 | d0/s7 | K24 |
| 379 | 9157.497 | 1.377 | 58.912 | d0/s7 | K25 |
| 380 | 9157.556 | 0.255 | 56.193 | d0/s7 | K26 |
| 381 | 9157.612 | 0.256 | 59.296 | d0/s7 | K27 |
| 382 | 9157.672 | 0.288 | 3.296 | d0/s7 | K28 |
| 383 | 9157.676 | 0.256 | 82.464 | d0/s7 | K29 |
| 384 | 9157.758 | 0.256 | 227.617 | d0/s7 | K30 |
| 385 | 9158.030 | 44.000 | 3.168 | d0/s7 | K24 |
| 386 | 9158.034 | 0.896 | 58.880 | d0/s7 | K25 |
| 387 | 9158.093 | 0.256 | 56.736 | d0/s7 | K26 |
| 388 | 9158.150 | 0.256 | 59.200 | d0/s7 | K27 |
| 389 | 9158.210 | 0.257 | 3.295 | d0/s7 | K28 |
| 390 | 9158.213 | 0.288 | 82.305 | d0/s7 | K29 |
| 391 | 9158.296 | 0.256 | 227.648 | d0/s7 | K30 |
| 392 | 9158.565 | 41.984 | 3.201 | d0/s7 | K24 |
| 393 | 9158.570 | 1.120 | 59.103 | d0/s7 | K25 |
| 394 | 9158.629 | 0.257 | 56.352 | d0/s7 | K26 |
| 395 | 9158.686 | 0.288 | 59.552 | d0/s7 | K27 |
| 396 | 9158.746 | 0.256 | 3.264 | d0/s7 | K28 |
| 397 | 9158.749 | 0.288 | 82.176 | d0/s7 | K29 |
| 398 | 9158.831 | 0.256 | 227.809 | d0/s7 | K30 |
| 399 | 9159.103 | 43.424 | 3.072 | d0/s7 | K24 |
| 400 | 9159.107 | 0.736 | 58.816 | d0/s7 | K25 |
| 401 | 9159.166 | 0.256 | 56.448 | d0/s7 | K26 |
| 402 | 9159.222 | 0.256 | 59.328 | d0/s7 | K27 |
| 403 | 9159.282 | 0.256 | 3.393 | d0/s7 | K28 |
| 404 | 9159.286 | 0.287 | 83.649 | d0/s7 | K29 |
| 405 | 9159.369 | 0.256 | 227.872 | d0/s7 | K30 |
| 406 | 9159.642 | 44.704 | 3.104 | d0/s7 | K24 |
| 407 | 9159.647 | 2.048 | 58.945 | d0/s7 | K25 |
| 408 | 9159.706 | 0.255 | 56.289 | d0/s7 | K26 |
| 409 | 9159.763 | 0.256 | 59.296 | d0/s7 | K27 |
| 410 | 9159.822 | 0.256 | 3.392 | d0/s7 | K28 |
| 411 | 9159.826 | 0.256 | 83.872 | d0/s7 | K29 |
| 412 | 9159.910 | 0.256 | 227.841 | d0/s7 | K30 |
| 413 | 9160.181 | 43.136 | 3.072 | d0/s7 | K24 |
| 414 | 9160.185 | 0.960 | 58.848 | d0/s7 | K25 |
| 415 | 9160.244 | 0.256 | 56.096 | d0/s7 | K26 |
| 416 | 9160.301 | 0.256 | 59.232 | d0/s7 | K27 |
| 417 | 9160.360 | 0.256 | 3.392 | d0/s7 | K28 |
| 418 | 9160.364 | 0.256 | 82.273 | d0/s7 | K29 |
| 419 | 9160.446 | 0.256 | 227.488 | d0/s7 | K30 |
| 420 | 9160.718 | 43.840 | 3.072 | d0/s7 | K24 |
| 421 | 9160.722 | 1.088 | 59.009 | d0/s7 | K25 |
| 422 | 9160.781 | 0.255 | 56.257 | d0/s7 | K26 |
| 423 | 9160.838 | 0.288 | 59.328 | d0/s7 | K27 |
| 424 | 9160.897 | 0.256 | 3.392 | d0/s7 | K28 |
| 425 | 9160.901 | 0.256 | 82.368 | d0/s7 | K29 |
| 426 | 9160.984 | 0.256 | 227.457 | d0/s7 | K30 |
| 427 | 9161.254 | 43.136 | 3.200 | d0/s7 | K24 |
| 428 | 9161.259 | 1.312 | 58.848 | d0/s7 | K25 |
| 429 | 9161.318 | 0.256 | 56.224 | d0/s7 | K26 |
| 430 | 9161.374 | 0.256 | 59.392 | d0/s7 | K27 |
| 431 | 9161.434 | 0.256 | 3.296 | d0/s7 | K28 |
| 432 | 9161.437 | 0.256 | 83.616 | d0/s7 | K29 |
| 433 | 9161.521 | 0.257 | 227.744 | d0/s7 | K30 |
| 434 | 9161.965 | 215.969 | 4.032 | d0/s7 | K31 |
| 435 | 9162.028 | 59.008 | 1.760 | d0/s7 | K32 |
| 436 | 9162.117 | 87.328 | 3.904 | d0/s7 | K33 |
| 437 | 9162.168 | 46.656 | 1.664 | d0/s7 | K9 |
| 438 | 9162.203 | 33.376 | 1.697 | d0/s7 | K34 |
| 439 | 9162.271 | 66.975 | 1.697 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 440 | 9162.315 | 41.440 | 1.568 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 441 | 9162.515 | 198.944 | 3.168 | d0/s7 | K35 |
| 442 | 9162.567 | 48.864 | 2.592 | d0/s7 | K36 |
| 443 | 9162.587 | 17.792 | 1.825 | d0/s7 | K19 |
| 444 | 9162.606 | 16.511 | 2.049 | d0/s7 | K37 |
| 445 | 9162.621 | 12.735 | 3.712 | d0/s7 | K38 |
| 446 | 9162.637 | 12.193 | 1.760 | d0/s7 | K39 |
| 447 | 9162.881 | 243.041 | 4.320 | d0/s7 | K40 |
| 448 | 9162.914 | 28.416 | 1.632 | d0/s7 | K41 |
| 449 | 9162.962 | 46.112 | 1.216 | d0/s7 | K42 |
| 450 | 9163.000 | 37.472 | 2.272 | d0/s7 | K43 |
| 451 | 9163.063 | 59.969 | 1.856 | d0/s7 | Memcpy DtoD (Device -> Device) (786432 B) |
| 452 | 9163.100 | 34.976 | 2.368 | d0/s7 | K44 |
| 453 | 9163.141 | 39.328 | 3.296 | d0/s7 | K45 |
| 454 | 9163.214 | 69.248 | 5.088 | d0/s7 | K46 |
| 455 | 9163.247 | 28.480 | 2.304 | d0/s7 | K47 |
| 456 | 9163.270 | 20.192 | 1.664 | d0/s7 | K9 |
| 457 | 9163.288 | 16.384 | 1.696 | d0/s7 | K34 |
| 458 | 9163.320 | 30.689 | 1.951 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 459 | 9163.354 | 32.063 | 1.760 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 460 | 9163.445 | 88.897 | 2.880 | d0/s7 | K48 |
| 461 | 9163.467 | 18.912 | 2.400 | d0/s7 | K49 |
| 462 | 9163.487 | 18.048 | 1.824 | d0/s7 | K50 |
| 463 | 9163.519 | 30.208 | 4.032 | d0/s7 | K33 |
| 464 | 9163.537 | 14.208 | 1.600 | d0/s7 | K9 |
| 465 | 9163.554 | 14.432 | 1.696 | d0/s7 | K34 |
| 466 | 9163.572 | 17.216 | 1.568 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 467 | 9163.601 | 27.072 | 1.600 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 468 | 9163.675 | 72.832 | 3.360 | d0/s7 | K51 |
| 469 | 9163.688 | 9.600 | 2.625 | d0/s7 | K52 |
| 470 | 9163.721 | 29.503 | 2.080 | d0/s7 | K53 |
| 471 | 9163.733 | 10.529 | 1.888 | d0/s7 | K22 |
| 472 | 9163.748 | 13.086 | 2.080 | d0/s7 | K54 |
| 473 | 9163.765 | 15.073 | 0.895 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 474 | 9163.790 | 24.129 | 0.896 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 475 | 9163.838 | 47.104 | 4.192 | d0/s7 | K48 |
| 476 | 9163.865 | 22.592 | 2.144 | d0/s7 | K49 |
| 477 | 9163.877 | 9.440 | 1.696 | d0/s7 | K50 |
| 478 | 9163.901 | 22.304 | 3.776 | d0/s7 | K33 |
| 479 | 9163.959 | 54.944 | 16.896 | d0/s7 | K55 |
| 480 | 9163.977 | 0.256 | 2.496 | d0/s7 | K36 |
| 481 | 9164.066 | 86.592 | 4.160 | d0/s7 | K40 |
| 482 | 9164.093 | 22.945 | 1.855 | d0/s7 | K41 |
| 483 | 9164.127 | 32.673 | 1.824 | d0/s7 | Memcpy DtoD (Device -> Device) (786432 B) |
| 484 | 9164.145 | 16.160 | 2.240 | d0/s7 | K44 |
| 485 | 9164.167 | 19.328 | 3.135 | d0/s7 | K45 |
| 486 | 9164.217 | 47.073 | 5.088 | d0/s7 | K46 |
| 487 | 9164.242 | 19.680 | 2.304 | d0/s7 | K47 |
| 488 | 9164.272 | 28.032 | 15.232 | d0/s7 | K56 |
| 489 | 9164.288 | 0.256 | 1.792 | d0/s7 | K50 |
| 490 | 9164.297 | 7.520 | 2.368 | d0/s7 | K49 |
| 491 | 9164.321 | 22.048 | 4.032 | d0/s7 | K33 |
| 492 | 9164.360 | 34.784 | 22.240 | d0/s7 | K57 |
| 493 | 9164.383 | 0.256 | 2.592 | d0/s7 | K52 |
| 494 | 9164.387 | 1.984 | 1.984 | d0/s7 | K53 |
| 495 | 9164.426 | 36.640 | 1.056 | d0/s7 | Memset (Device) (1536 B) |
| 496 | 9164.446 | 19.200 | 1.312 | d0/s7 | K58 |
| 497 | 9164.465 | 17.665 | 61.344 | d0/s7 | K59 |
| 498 | 9164.527 | 0.255 | 1.824 | d0/s7 | K50 |
| 499 | 9164.529 | 0.256 | 2.304 | d0/s7 | K49 |
| 500 | 9164.531 | 0.256 | 1.824 | d0/s7 | K50 |
| 501 | 9164.551 | 17.472 | 1.472 | d0/s7 | K60 |
| 502 | 9164.591 | 39.072 | 12.992 | d0/s7 | K61 |
| 503 | 9164.630 | 25.919 | 3.840 | d0/s7 | Memcpy DtoH (Device -> Pinned) (4 B) |
| 504 | 9164.692 | 58.176 | 1.568 | d0/s7 | Memcpy HtoD (Pageable -> Device) (56 B) |
| 505 | 9164.726 | 31.840 | 1.536 | d0/s7 | Memcpy HtoD (Pageable -> Device) (48 B) |
| 506 | 9164.779 | 51.808 | 4.384 | d0/s7 | K62 |
| 507 | 9164.796 | 12.512 | 4.032 | d0/s7 | K63 |
| 508 | 9164.811 | 11.552 | 4.736 | d0/s7 | K62 |
| 509 | 9164.825 | 8.897 | 4.223 | d0/s7 | K63 |
| 510 | 9164.836 | 6.849 | 1.983 | d0/s7 | K64 |
| 511 | 9164.861 | 22.720 | 1.825 | d0/s7 | K65 |
| 512 | 9164.879 | 16.063 | 2.240 | d0/s7 | K66 |
| 513 | 9164.891 | 10.432 | 3.808 | d0/s7 | Memcpy DtoH (Device -> Pinned) (4 B) |
| 514 | 9164.928 | 33.120 | 1.408 | d0/s7 | K60 |
| 515 | 9164.964 | 34.432 | 1.504 | d0/s7 | K67 |
| 516 | 9164.990 | 24.576 | 1.536 | d0/s7 | K68 |
| 517 | 9165.011 | 18.784 | 1.792 | d0/s7 | K69 |
| 518 | 9165.076 | 63.744 | 13.088 | d0/s7 | K70 |
| 519 | 9165.093 | 3.712 | 3.904 | d0/s7 | Memcpy DtoH (Device -> Pinned) (1 B) |
