# B300 complete GPU timeline of your last candidate

- complete GPU-side trace: 519 activities; CPU/Python profiler records are intentionally omitted
- whole capture: span 5192.027 ms; active union 18.569 ms; idle holes 5173.458 ms (99.6%); largest hole 4913.065 ms
- that idle figure covers input generation, JIT compilation and the reference as well as your block, so it is not a measure of your kernels; the per-iteration section below is
- summed activity time: 18.569 ms; this may exceed active union when streams overlap
- source labels are hints: `candidate:<symbol>` is matched against this candidate's `@cute.kernel` definitions; other labels describe likely harness/runtime work
- candidate `@cute.kernel` symbols: `attention_kernel`, `fc_gelu_kernel`, `ln1_kernel`, `ln2_kernel`, `out_gemm_kernel`, `proj_gemm_kernel`, `qkv_gemm_kernel`
- observed candidate symbols: `attention_kernel`, `fc_gelu_kernel`, `ln1_kernel`, `ln2_kernel`, `out_gemm_kernel`, `proj_gemm_kernel`, `qkv_gemm_kernel`
- candidate symbols not observed in this trace: none

## One iteration of your block, launch by launch

Median of 55 timed iterations, 7 launches each. Microseconds from the start of the iteration.

- wall span 331.201; kernels busy 328.643; idle between your kernels 2.558 (0.8% of the span)
- largest single gap 1.088 immediately before `qkv_gemm_kernel`
- 43.360 elapses between one iteration and the next; that is host-side dispatch outside your block, excluded from the idle figure above, and fusing cannot remove it

| # | kernel | id | start | end | dur | idle before |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 1 | ln1_kernel | K24 | 0.000 | 3.104 | 3.104 | — |
| 2 | qkv_gemm_kernel | K25 | 4.192 | 49.985 | 45.793 | 1.088 |
| 3 | attention_kernel | K26 | 50.240 | 106.593 | 56.353 | 0.255 |
| 4 | out_gemm_kernel | K27 | 107.040 | 140.961 | 33.921 | 0.447 |
| 5 | ln2_kernel | K28 | 141.217 | 144.545 | 3.328 | 0.256 |
| 6 | fc_gelu_kernel | K29 | 144.801 | 201.889 | 57.088 | 0.256 |
| 7 | proj_gemm_kernel | K30 | 202.145 | 331.201 | 129.056 | 0.256 |

## Hottest GPU kernels (legacy aggregate)

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_proj_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 7.125 | 55 | 38.4 |
| kernel_cutlass_fc_gelu_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmemal… | 3.145 | 55 | 16.9 |
| kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 3.097 | 55 | 16.7 |
| kernel_cutlass_qkv_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 2.526 | 55 | 13.6 |
| kernel_cutlass_out_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 1.865 | 55 | 10.0 |
| kernel_cutlass_ln2_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo7681_tensorptrf32gmemo… | 0.182 | 55 | 1.0 |
| kernel_cutlass_ln1_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo7681_tenso… | 0.176 | 55 | 0.9 |
| void sgemm_largek_lds64<true, false, 6, 3, 4, 5, 2, 66>(float*, float const*, float con… | 0.062 | 1 | 0.3 |
| cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 0.041 | 4 | 0.2 |
| void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 0.033 | 17 | 0.2 |

## Kernel legend

| id | source hint | kernel | calls | total us | launch |
| --- | --- | --- | ---: | ---: | --- |
| K1 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 1 | 2.528 | grid=384x1x1, block=256x1x1, smem=0, regs=56 |
| K2 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 6 | 11.778 | grid=3x1x1, block=256x1x1, smem=0, regs=56 |
| K3 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 6 | 11.201 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K4 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::CUDAFunctorOnSelf_add<flo… | 2 | 3.744 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K5 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 1 | 1.824 | grid=9x1x1, block=256x1x1, smem=0, regs=56 |
| K6 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 2 | 3.392 | grid=3x1x1, block=128x1x1, smem=0, regs=32 |
| K7 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 1 | 2.144 | grid=12x1x1, block=256x1x1, smem=0, regs=56 |
| K8 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 4 | 21.856 | grid=1184x1x1, block=256x1x1, smem=0, regs=56 |
| K9 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 7 | 11.680 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K10 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 4 | 7.327 | grid=256x1x1, block=128x1x1, smem=0, regs=20 |
| K11 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 1 | 2.752 | grid=1728x1x1, block=128x1x1, smem=0, regs=32 |
| K12 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 2 | 8.608 | grid=4608x1x1, block=128x1x1, smem=0, regs=20 |
| K13 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 1 | 1.887 | grid=576x1x1, block=128x1x1, smem=0, regs=32 |
| K14 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 2.464 | grid=1536x1x1, block=128x1x1, smem=0, regs=20 |
| K15 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 6.465 | grid=2304x1x1, block=128x1x1, smem=0, regs=32 |
| K16 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 5.056 | grid=6144x1x1, block=128x1x1, smem=0, regs=20 |
| K17 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::… | 3 | 4.832 | grid=96x1x1, block=128x1x1, smem=0, regs=16 |
| K18 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::… | 1 | 1.375 | grid=288x1x1, block=128x1x1, smem=0, regs=16 |
| K19 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 3.329 | grid=288x1x1, block=128x1x1, smem=0, regs=32 |
| K20 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 1.952 | grid=640x1x1, block=128x1x1, smem=0, regs=20 |
| K21 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::… | 1 | 1.376 | grid=384x1x1, block=128x1x1, smem=0, regs=16 |
| K22 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 3.455 | grid=384x1x1, block=128x1x1, smem=0, regs=32 |
| K23 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 2.144 | grid=768x1x1, block=128x1x1, smem=0, regs=20 |
| K24 | candidate:ln1_kernel | kernel_cutlass_ln1_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo7681_tenso… | 55 | 175.650 | grid=128x1x1, block=128x1x1, smem=1024, regs=32 |
| K25 | candidate:qkv_gemm_kernel | kernel_cutlass_qkv_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 55 | 2525.639 | grid=36x8x1, block=128x1x1, smem=20480, regs=128 |
| K26 | candidate:attention_kernel | kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 55 | 3097.482 | grid=12x128x1, block=128x1x1, smem=1024, regs=40 |
| K27 | candidate:out_gemm_kernel | kernel_cutlass_out_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 55 | 1865.090 | grid=12x8x1, block=128x1x1, smem=20480, regs=128 |
| K28 | candidate:ln2_kernel | kernel_cutlass_ln2_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo7681_tensorptrf32gmemo… | 55 | 181.854 | grid=128x1x1, block=128x1x1, smem=1024, regs=32 |
| K29 | candidate:fc_gelu_kernel | kernel_cutlass_fc_gelu_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmemal… | 55 | 3144.548 | grid=48x8x1, block=128x1x1, smem=20480, regs=128 |
| K30 | candidate:proj_gemm_kernel | kernel_cutlass_proj_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 55 | 7125.181 | grid=12x8x1, block=128x1x1, smem=20480, regs=128 |
| K31 | framework/validation | void at::native::unrolled_elementwise_kernel<at::native::direct_copy_kernel_cuda(at::Te… | 1 | 4.000 | grid=192x1x1, block=128x1x1, smem=0, regs=30 |
| K32 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 1 | 1.824 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K33 | framework/validation | void at::native::(anonymous namespace)::vectorized_layer_norm_kernel<float, float, fals… | 4 | 15.936 | grid=128x1x1, block=32x4x1, smem=24, regs=40 |
| K34 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::float8_copy_kernel_cuda(a… | 3 | 5.184 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K35 | framework/validation | nvjet_sm103_qqsss_64x32_128x16_2x1_2cta_v_bz_TNT | 1 | 3.169 | grid=144x1x1, block=256x1x1, smem=172552, regs=255 |
| K36 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 5.025 | grid=1152x1x1, block=128x1x1, smem=0, regs=20 |
| K37 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::float8_copy_kernel_cuda(a… | 1 | 2.048 | grid=288x1x1, block=128x1x1, smem=0, regs=32 |
| K38 | framework/validation | void at::native::unrolled_elementwise_kernel<at::native::direct_copy_kernel_cuda(at::Te… | 1 | 3.648 | grid=576x1x1, block=128x1x1, smem=0, regs=30 |
| K39 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 1 | 1.728 | grid=288x1x1, block=128x1x1, smem=0, regs=32 |
| K40 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 2 | 8.608 | grid=4x4x12, block=64x1x1, smem=13056, regs=72 |
| K41 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 3.522 | grid=192x1x1, block=128x1x1, smem=0, regs=32 |
| K42 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<bool>, std::a… | 1 | 1.215 | grid=8x1x1, block=128x1x1, smem=0, regs=16 |
| K43 | framework/validation | void at::native::triu_tril_kernel<bool, int, true, 8, false>(at::cuda::detail::TensorIn… | 1 | 2.240 | grid=16x1x1, block=128x1x1, smem=0, regs=30 |
| K44 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 4.576 | grid=768x1x1, block=128x1x1, smem=0, regs=20 |
| K45 | framework/validation | void (anonymous namespace)::softmax_warp_forward<float, float, float, 7, false, false>(… | 2 | 6.368 | grid=192x1x1, block=32x4x1, smem=0, regs=32 |
| K46 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_nnn_align1_bias_f32_relu | 2 | 10.048 | grid=2x4x12, block=64x1x1, smem=12672, regs=84 |
| K47 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 4.576 | grid=384x1x1, block=128x1x1, smem=0, regs=20 |
| K48 | framework/validation | nvjet_sm103_qqsss_64x16_128x16_2x4_2cta_h_bz_TNT | 2 | 7.040 | grid=96x1x1, block=256x1x1, smem=156168, regs=255 |
| K49 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 4 | 9.248 | grid=384x1x1, block=128x1x1, smem=0, regs=20 |
| K50 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::CUDAFunctor_add<float>, s… | 5 | 9.280 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K51 | framework/validation | nvjet_sm103_qqsss_48x64_128x16_2x2_2cta_h_bz_TNN | 1 | 3.360 | grid=128x1x1, block=256x1x1, smem=188944, regs=255 |
| K52 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 5.184 | grid=1536x1x1, block=128x1x1, smem=0, regs=20 |
| K53 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::GeluCUDAKernelImpl(at::Te… | 2 | 4.031 | grid=384x1x1, block=128x1x1, smem=0, regs=32 |
| K54 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::float8_copy_kernel_cuda(a… | 1 | 2.048 | grid=384x1x1, block=128x1x1, smem=0, regs=32 |
| K55 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 1 | 16.800 | grid=72x4x1, block=64x1x1, smem=13056, regs=72 |
| K56 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 1 | 15.168 | grid=24x4x1, block=64x1x1, smem=13056, regs=72 |
| K57 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_64x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 1 | 22.496 | grid=48x4x1, block=64x1x1, smem=19200, regs=146 |
| K58 | framework/validation | void scal_kernel<float, float, 1, true, 6, 5, 5, 3>(cublasTransposeParams<float>, float… | 1 | 1.311 | grid=12x4x1, block=256x1x1, smem=0, regs=24 |
| K59 | framework/validation | void sgemm_largek_lds64<true, false, 6, 3, 4, 5, 2, 66>(float*, float const*, float con… | 1 | 61.824 | grid=12x16x4, block=32x4x1, smem=4868, regs=32 |
| K60 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AbsFunctor<float>, std::a… | 2 | 2.816 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K61 | framework/validation | void at::native::reduce_kernel<512, 1, at::native::ReduceOp<float, at::native::func_wra… | 1 | 12.928 | grid=1x1x1, block=512x1x1, smem=2064, regs=30 |
| K62 | framework/validation | void at::native::(anonymous namespace)::indexSelectSmallIndex<float, long, unsigned int… | 2 | 8.352 | grid=6x1x1, block=128x1x1, smem=0, regs=28 |
| K63 | framework/validation | void at::native::(anonymous namespace)::indexSelectSmallIndex<float, long, unsigned int… | 2 | 8.000 | grid=1x1x1, block=7x1x1, smem=0, regs=28 |
| K64 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::CUDAFunctor_add<float>, s… | 1 | 1.760 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K65 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AbsFunctor<float>, std::a… | 1 | 1.760 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K66 | framework/validation | void at::native::reduce_kernel<512, 1, at::native::ReduceOp<float, at::native::func_wra… | 1 | 2.047 | grid=1x1x1, block=32x1x1, smem=16, regs=30 |
| K67 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 1 | 1.504 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K68 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BinaryFunctor<float, floa… | 1 | 1.536 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K69 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BinaryFunctor<bool, bool,… | 1 | 1.792 | grid=96x1x1, block=128x1x1, smem=0, regs=30 |
| K70 | framework/validation | void at::native::reduce_kernel<512, 1, at::native::ReduceOp<bool, at::native::func_wrap… | 1 | 13.056 | grid=1x1x1, block=512x1x1, smem=528, regs=28 |

## Ordered GPU activities

`gap before` is device-wide idle time since all earlier GPU activity ended; zero means overlap or no measurable hole.

| # | start ms | gap before us | duration us | lane | activity |
| ---: | ---: | ---: | ---: | --- | --- |
| 1 | 0.000 | 0.000 | 2.528 | d0/s7 | K1 |
| 2 | 0.102 | 99.744 | 2.176 | d0/s7 | K2 |
| 3 | 0.147 | 43.008 | 2.017 | d0/s7 | K3 |
| 4 | 0.184 | 34.815 | 1.728 | d0/s7 | K4 |
| 5 | 0.204 | 18.080 | 1.761 | d0/s7 | K2 |
| 6 | 0.217 | 11.200 | 1.600 | d0/s7 | K3 |
| 7 | 0.233 | 14.623 | 1.793 | d0/s7 | K2 |
| 8 | 0.245 | 9.600 | 1.952 | d0/s7 | K3 |
| 9 | 0.255 | 8.768 | 2.016 | d0/s7 | K4 |
| 10 | 0.277 | 19.840 | 2.144 | d0/s7 | K2 |
| 11 | 0.288 | 8.320 | 2.016 | d0/s7 | K3 |
| 12 | 0.304 | 13.856 | 1.824 | d0/s7 | K5 |
| 13 | 0.317 | 11.136 | 1.632 | d0/s7 | K6 |
| 14 | 0.333 | 14.752 | 1.792 | d0/s7 | K2 |
| 15 | 0.344 | 8.960 | 1.600 | d0/s7 | K3 |
| 16 | 0.360 | 14.336 | 2.144 | d0/s7 | K7 |
| 17 | 0.370 | 8.224 | 1.760 | d0/s7 | K6 |
| 18 | 0.385 | 13.440 | 2.112 | d0/s7 | K2 |
| 19 | 0.396 | 8.960 | 2.016 | d0/s7 | K3 |
| 20 | 0.423 | 24.543 | 5.728 | d0/s7 | K8 |
| 21 | 0.439 | 10.496 | 4.224 | d0/s7 | K8 |
| 22 | 0.455 | 11.296 | 5.952 | d0/s7 | K8 |
| 23 | 0.472 | 11.584 | 5.952 | d0/s7 | K8 |
| 24 | 0.510 | 31.744 | 1.792 | d0/s7 | K9 |
| 25 | 30.045 | 29533.132 | 1.920 | d0/s7 | K10 |
| 26 | 30.239 | 192.289 | 2.752 | d0/s7 | K11 |
| 27 | 56.015 | 25773.666 | 4.256 | d0/s7 | K12 |
| 28 | 56.203 | 183.329 | 1.887 | d0/s7 | K13 |
| 29 | 81.999 | 25794.403 | 2.464 | d0/s7 | K14 |
| 30 | 82.193 | 191.392 | 3.168 | d0/s7 | K15 |
| 31 | 107.684 | 25488.162 | 5.056 | d0/s7 | K16 |
| 32 | 107.877 | 187.488 | 3.297 | d0/s7 | K15 |
| 33 | 132.330 | 24449.343 | 4.352 | d0/s7 | K12 |
| 34 | 132.501 | 167.552 | 1.632 | d0/s7 | K17 |
| 35 | 132.563 | 59.680 | 1.792 | d0/s7 | K9 |
| 36 | 156.310 | 23745.757 | 1.760 | d0/s7 | K10 |
| 37 | 156.463 | 150.625 | 1.375 | d0/s7 | K18 |
| 38 | 156.520 | 55.553 | 1.504 | d0/s7 | K19 |
| 39 | 181.214 | 24692.383 | 1.952 | d0/s7 | K20 |
| 40 | 181.374 | 158.784 | 1.568 | d0/s7 | K17 |
| 41 | 181.431 | 55.456 | 1.760 | d0/s7 | K9 |
| 42 | 205.507 | 24073.664 | 1.855 | d0/s7 | K10 |
| 43 | 205.662 | 153.057 | 1.632 | d0/s7 | K17 |
| 44 | 205.720 | 57.120 | 1.408 | d0/s7 | K9 |
| 45 | 230.071 | 24349.407 | 1.792 | d0/s7 | K10 |
| 46 | 230.220 | 147.200 | 1.376 | d0/s7 | K21 |
| 47 | 230.299 | 77.888 | 1.568 | d0/s7 | K22 |
| 48 | 255.015 | 24713.536 | 2.144 | d0/s7 | K23 |
| 49 | 5168.082 | 4913064.868 | 3.712 | d0/s7 | K24 |
| 50 | 5168.094 | 8.928 | 52.160 | d0/s7 | K25 |
| 51 | 5168.147 | 0.288 | 56.641 | d0/s7 | K26 |
| 52 | 5168.204 | 0.255 | 39.840 | d0/s7 | K27 |
| 53 | 5168.244 | 0.257 | 3.488 | d0/s7 | K28 |
| 54 | 5168.247 | 0.255 | 59.744 | d0/s7 | K29 |
| 55 | 5168.307 | 0.257 | 153.248 | d0/s7 | K30 |
| 56 | 5168.461 | 0.256 | 3.264 | d0/s7 | K24 |
| 57 | 5168.464 | 0.256 | 45.824 | d0/s7 | K25 |
| 58 | 5168.511 | 0.256 | 56.416 | d0/s7 | K26 |
| 59 | 5168.567 | 0.448 | 33.824 | d0/s7 | K27 |
| 60 | 5168.601 | 0.256 | 3.264 | d0/s7 | K28 |
| 61 | 5168.605 | 0.256 | 57.185 | d0/s7 | K29 |
| 62 | 5168.662 | 0.223 | 129.153 | d0/s7 | K30 |
| 63 | 5168.792 | 0.256 | 3.136 | d0/s7 | K24 |
| 64 | 5168.795 | 0.256 | 45.792 | d0/s7 | K25 |
| 65 | 5168.841 | 0.256 | 56.544 | d0/s7 | K26 |
| 66 | 5168.898 | 0.480 | 33.792 | d0/s7 | K27 |
| 67 | 5168.932 | 0.256 | 3.360 | d0/s7 | K28 |
| 68 | 5168.936 | 0.256 | 57.216 | d0/s7 | K29 |
| 69 | 5168.993 | 0.256 | 128.993 | d0/s7 | K30 |
| 70 | 5169.123 | 0.256 | 3.072 | d0/s7 | K24 |
| 71 | 5169.126 | 0.256 | 45.696 | d0/s7 | K25 |
| 72 | 5169.172 | 0.256 | 56.224 | d0/s7 | K26 |
| 73 | 5169.229 | 0.448 | 33.824 | d0/s7 | K27 |
| 74 | 5169.263 | 0.256 | 3.328 | d0/s7 | K28 |
| 75 | 5169.266 | 0.256 | 57.024 | d0/s7 | K29 |
| 76 | 5169.324 | 0.256 | 129.089 | d0/s7 | K30 |
| 77 | 5169.453 | 0.256 | 3.072 | d0/s7 | K24 |
| 78 | 5169.456 | 0.255 | 45.665 | d0/s7 | K25 |
| 79 | 5169.502 | 0.256 | 56.352 | d0/s7 | K26 |
| 80 | 5169.559 | 0.480 | 33.824 | d0/s7 | K27 |
| 81 | 5169.593 | 0.255 | 3.360 | d0/s7 | K28 |
| 82 | 5169.597 | 0.256 | 56.992 | d0/s7 | K29 |
| 83 | 5169.654 | 0.256 | 128.993 | d0/s7 | K30 |
| 84 | 5169.922 | 139.424 | 3.136 | d0/s7 | K24 |
| 85 | 5169.926 | 1.024 | 45.696 | d0/s7 | K25 |
| 86 | 5169.972 | 0.256 | 56.384 | d0/s7 | K26 |
| 87 | 5170.029 | 0.448 | 33.824 | d0/s7 | K27 |
| 88 | 5170.063 | 0.256 | 3.360 | d0/s7 | K28 |
| 89 | 5170.067 | 0.288 | 57.088 | d0/s7 | K29 |
| 90 | 5170.124 | 0.256 | 129.153 | d0/s7 | K30 |
| 91 | 5170.323 | 69.536 | 3.296 | d0/s7 | K24 |
| 92 | 5170.328 | 1.760 | 45.792 | d0/s7 | K25 |
| 93 | 5170.374 | 0.224 | 56.352 | d0/s7 | K26 |
| 94 | 5170.431 | 0.448 | 33.760 | d0/s7 | K27 |
| 95 | 5170.465 | 0.256 | 3.264 | d0/s7 | K28 |
| 96 | 5170.468 | 0.288 | 57.056 | d0/s7 | K29 |
| 97 | 5170.526 | 0.257 | 129.184 | d0/s7 | K30 |
| 98 | 5170.700 | 45.056 | 3.232 | d0/s7 | K24 |
| 99 | 5170.704 | 0.864 | 45.856 | d0/s7 | K25 |
| 100 | 5170.750 | 0.288 | 56.160 | d0/s7 | K26 |
| 101 | 5170.807 | 0.448 | 33.760 | d0/s7 | K27 |
| 102 | 5170.841 | 0.256 | 3.264 | d0/s7 | K28 |
| 103 | 5170.844 | 0.256 | 57.152 | d0/s7 | K29 |
| 104 | 5170.902 | 0.256 | 129.057 | d0/s7 | K30 |
| 105 | 5171.077 | 46.048 | 3.232 | d0/s7 | K24 |
| 106 | 5171.081 | 0.896 | 45.856 | d0/s7 | K25 |
| 107 | 5171.127 | 0.256 | 56.448 | d0/s7 | K26 |
| 108 | 5171.184 | 0.448 | 33.696 | d0/s7 | K27 |
| 109 | 5171.218 | 0.288 | 3.264 | d0/s7 | K28 |
| 110 | 5171.222 | 0.256 | 57.280 | d0/s7 | K29 |
| 111 | 5171.279 | 0.256 | 129.025 | d0/s7 | K30 |
| 112 | 5171.454 | 46.336 | 3.232 | d0/s7 | K24 |
| 113 | 5171.459 | 1.120 | 45.888 | d0/s7 | K25 |
| 114 | 5171.505 | 0.256 | 56.320 | d0/s7 | K26 |
| 115 | 5171.562 | 0.448 | 33.952 | d0/s7 | K27 |
| 116 | 5171.596 | 0.256 | 3.264 | d0/s7 | K28 |
| 117 | 5171.599 | 0.288 | 57.152 | d0/s7 | K29 |
| 118 | 5171.657 | 0.224 | 129.057 | d0/s7 | K30 |
| 119 | 5171.830 | 44.288 | 3.136 | d0/s7 | K24 |
| 120 | 5171.835 | 1.184 | 45.920 | d0/s7 | K25 |
| 121 | 5171.881 | 0.256 | 56.512 | d0/s7 | K26 |
| 122 | 5171.938 | 0.448 | 33.856 | d0/s7 | K27 |
| 123 | 5171.972 | 0.256 | 3.328 | d0/s7 | K28 |
| 124 | 5171.975 | 0.256 | 57.280 | d0/s7 | K29 |
| 125 | 5172.033 | 0.256 | 129.153 | d0/s7 | K30 |
| 126 | 5172.215 | 53.248 | 3.072 | d0/s7 | K24 |
| 127 | 5172.219 | 0.833 | 45.568 | d0/s7 | K25 |
| 128 | 5172.265 | 0.256 | 56.320 | d0/s7 | K26 |
| 129 | 5172.322 | 0.480 | 33.824 | d0/s7 | K27 |
| 130 | 5172.356 | 0.256 | 3.360 | d0/s7 | K28 |
| 131 | 5172.360 | 0.256 | 57.088 | d0/s7 | K29 |
| 132 | 5172.417 | 0.256 | 128.929 | d0/s7 | K30 |
| 133 | 5172.590 | 44.255 | 3.136 | d0/s7 | K24 |
| 134 | 5172.594 | 0.928 | 45.888 | d0/s7 | K25 |
| 135 | 5172.640 | 0.255 | 56.224 | d0/s7 | K26 |
| 136 | 5172.697 | 0.480 | 33.888 | d0/s7 | K27 |
| 137 | 5172.731 | 0.256 | 3.328 | d0/s7 | K28 |
| 138 | 5172.735 | 0.256 | 57.024 | d0/s7 | K29 |
| 139 | 5172.792 | 0.256 | 129.312 | d0/s7 | K30 |
| 140 | 5172.964 | 42.657 | 3.104 | d0/s7 | K24 |
| 141 | 5172.968 | 0.960 | 45.632 | d0/s7 | K25 |
| 142 | 5173.014 | 0.224 | 56.256 | d0/s7 | K26 |
| 143 | 5173.071 | 0.448 | 33.664 | d0/s7 | K27 |
| 144 | 5173.105 | 0.288 | 3.360 | d0/s7 | K28 |
| 145 | 5173.108 | 0.256 | 56.864 | d0/s7 | K29 |
| 146 | 5173.165 | 0.289 | 129.025 | d0/s7 | K30 |
| 147 | 5173.339 | 44.383 | 3.297 | d0/s7 | K24 |
| 148 | 5173.343 | 1.152 | 45.792 | d0/s7 | K25 |
| 149 | 5173.389 | 0.256 | 56.384 | d0/s7 | K26 |
| 150 | 5173.446 | 0.480 | 33.728 | d0/s7 | K27 |
| 151 | 5173.480 | 0.256 | 3.264 | d0/s7 | K28 |
| 152 | 5173.484 | 0.256 | 57.280 | d0/s7 | K29 |
| 153 | 5173.541 | 0.256 | 129.184 | d0/s7 | K30 |
| 154 | 5173.713 | 42.465 | 3.264 | d0/s7 | K24 |
| 155 | 5173.717 | 0.864 | 45.856 | d0/s7 | K25 |
| 156 | 5173.763 | 0.256 | 56.224 | d0/s7 | K26 |
| 157 | 5173.820 | 0.416 | 33.760 | d0/s7 | K27 |
| 158 | 5173.854 | 0.288 | 3.264 | d0/s7 | K28 |
| 159 | 5173.857 | 0.256 | 57.248 | d0/s7 | K29 |
| 160 | 5173.915 | 0.256 | 129.025 | d0/s7 | K30 |
| 161 | 5174.087 | 43.488 | 3.232 | d0/s7 | K24 |
| 162 | 5174.092 | 1.728 | 45.824 | d0/s7 | K25 |
| 163 | 5174.138 | 0.256 | 56.480 | d0/s7 | K26 |
| 164 | 5174.195 | 0.448 | 33.696 | d0/s7 | K27 |
| 165 | 5174.229 | 0.256 | 3.296 | d0/s7 | K28 |
| 166 | 5174.233 | 0.256 | 57.504 | d0/s7 | K29 |
| 167 | 5174.290 | 0.224 | 129.280 | d0/s7 | K30 |
| 168 | 5174.469 | 49.344 | 3.265 | d0/s7 | K24 |
| 169 | 5174.473 | 0.575 | 45.697 | d0/s7 | K25 |
| 170 | 5174.519 | 0.256 | 56.384 | d0/s7 | K26 |
| 171 | 5174.576 | 0.448 | 33.888 | d0/s7 | K27 |
| 172 | 5174.610 | 0.255 | 3.232 | d0/s7 | K28 |
| 173 | 5174.613 | 0.256 | 57.184 | d0/s7 | K29 |
| 174 | 5174.671 | 0.256 | 128.961 | d0/s7 | K30 |
| 175 | 5174.845 | 45.376 | 3.103 | d0/s7 | K24 |
| 176 | 5174.849 | 1.088 | 45.889 | d0/s7 | K25 |
| 177 | 5174.895 | 0.256 | 56.544 | d0/s7 | K26 |
| 178 | 5174.952 | 0.480 | 33.888 | d0/s7 | K27 |
| 179 | 5174.987 | 0.256 | 3.328 | d0/s7 | K28 |
| 180 | 5174.990 | 0.288 | 57.184 | d0/s7 | K29 |
| 181 | 5175.048 | 0.256 | 129.153 | d0/s7 | K30 |
| 182 | 5175.220 | 43.008 | 3.135 | d0/s7 | K24 |
| 183 | 5175.224 | 1.280 | 45.953 | d0/s7 | K25 |
| 184 | 5175.270 | 0.256 | 56.224 | d0/s7 | K26 |
| 185 | 5175.327 | 0.448 | 33.792 | d0/s7 | K27 |
| 186 | 5175.361 | 0.256 | 3.360 | d0/s7 | K28 |
| 187 | 5175.365 | 0.256 | 56.960 | d0/s7 | K29 |
| 188 | 5175.422 | 0.256 | 129.056 | d0/s7 | K30 |
| 189 | 5175.595 | 43.520 | 3.105 | d0/s7 | K24 |
| 190 | 5175.599 | 1.184 | 45.760 | d0/s7 | K25 |
| 191 | 5175.645 | 0.256 | 56.224 | d0/s7 | K26 |
| 192 | 5175.702 | 0.480 | 33.792 | d0/s7 | K27 |
| 193 | 5175.736 | 0.256 | 3.328 | d0/s7 | K28 |
| 194 | 5175.739 | 0.256 | 57.152 | d0/s7 | K29 |
| 195 | 5175.797 | 0.256 | 129.184 | d0/s7 | K30 |
| 196 | 5175.969 | 43.232 | 3.104 | d0/s7 | K24 |
| 197 | 5175.973 | 1.120 | 45.953 | d0/s7 | K25 |
| 198 | 5176.019 | 0.255 | 56.289 | d0/s7 | K26 |
| 199 | 5176.076 | 0.448 | 33.760 | d0/s7 | K27 |
| 200 | 5176.110 | 0.256 | 3.360 | d0/s7 | K28 |
| 201 | 5176.114 | 0.256 | 56.992 | d0/s7 | K29 |
| 202 | 5176.171 | 0.256 | 129.153 | d0/s7 | K30 |
| 203 | 5176.349 | 48.383 | 3.297 | d0/s7 | K24 |
| 204 | 5176.354 | 1.632 | 45.855 | d0/s7 | K25 |
| 205 | 5176.400 | 0.257 | 56.064 | d0/s7 | K26 |
| 206 | 5176.456 | 0.480 | 33.792 | d0/s7 | K27 |
| 207 | 5176.490 | 0.256 | 3.264 | d0/s7 | K28 |
| 208 | 5176.494 | 0.256 | 57.088 | d0/s7 | K29 |
| 209 | 5176.551 | 0.224 | 129.056 | d0/s7 | K30 |
| 210 | 5176.725 | 44.513 | 3.263 | d0/s7 | K24 |
| 211 | 5176.728 | 0.544 | 45.857 | d0/s7 | K25 |
| 212 | 5176.775 | 0.256 | 56.288 | d0/s7 | K26 |
| 213 | 5176.831 | 0.448 | 33.760 | d0/s7 | K27 |
| 214 | 5176.865 | 0.256 | 3.264 | d0/s7 | K28 |
| 215 | 5176.869 | 0.256 | 57.056 | d0/s7 | K29 |
| 216 | 5176.926 | 0.256 | 129.152 | d0/s7 | K30 |
| 217 | 5177.098 | 42.464 | 3.264 | d0/s7 | K24 |
| 218 | 5177.102 | 0.864 | 45.856 | d0/s7 | K25 |
| 219 | 5177.148 | 0.257 | 56.480 | d0/s7 | K26 |
| 220 | 5177.205 | 0.480 | 33.728 | d0/s7 | K27 |
| 221 | 5177.239 | 0.256 | 3.264 | d0/s7 | K28 |
| 222 | 5177.242 | 0.255 | 57.408 | d0/s7 | K29 |
| 223 | 5177.300 | 0.256 | 129.120 | d0/s7 | K30 |
| 224 | 5177.474 | 44.864 | 3.232 | d0/s7 | K24 |
| 225 | 5177.479 | 1.217 | 45.792 | d0/s7 | K25 |
| 226 | 5177.525 | 0.255 | 56.257 | d0/s7 | K26 |
| 227 | 5177.581 | 0.448 | 33.888 | d0/s7 | K27 |
| 228 | 5177.615 | 0.256 | 3.264 | d0/s7 | K28 |
| 229 | 5177.619 | 0.256 | 57.248 | d0/s7 | K29 |
| 230 | 5177.676 | 0.256 | 129.088 | d0/s7 | K30 |
| 231 | 5177.850 | 44.320 | 3.104 | d0/s7 | K24 |
| 232 | 5177.854 | 0.832 | 45.793 | d0/s7 | K25 |
| 233 | 5177.900 | 0.223 | 56.289 | d0/s7 | K26 |
| 234 | 5177.957 | 0.479 | 33.856 | d0/s7 | K27 |
| 235 | 5177.991 | 0.256 | 3.360 | d0/s7 | K28 |
| 236 | 5177.994 | 0.256 | 57.216 | d0/s7 | K29 |
| 237 | 5178.052 | 0.256 | 128.992 | d0/s7 | K30 |
| 238 | 5178.224 | 43.360 | 3.104 | d0/s7 | K24 |
| 239 | 5178.228 | 1.088 | 45.793 | d0/s7 | K25 |
| 240 | 5178.274 | 0.255 | 56.353 | d0/s7 | K26 |
| 241 | 5178.331 | 0.447 | 33.921 | d0/s7 | K27 |
| 242 | 5178.365 | 0.256 | 3.328 | d0/s7 | K28 |
| 243 | 5178.369 | 0.256 | 57.088 | d0/s7 | K29 |
| 244 | 5178.426 | 0.256 | 129.056 | d0/s7 | K30 |
| 245 | 5178.599 | 43.776 | 3.104 | d0/s7 | K24 |
| 246 | 5178.603 | 0.928 | 45.856 | d0/s7 | K25 |
| 247 | 5178.649 | 0.288 | 56.321 | d0/s7 | K26 |
| 248 | 5178.706 | 0.448 | 33.888 | d0/s7 | K27 |
| 249 | 5178.740 | 0.256 | 3.328 | d0/s7 | K28 |
| 250 | 5178.744 | 0.256 | 56.992 | d0/s7 | K29 |
| 251 | 5178.801 | 0.256 | 129.184 | d0/s7 | K30 |
| 252 | 5178.973 | 42.912 | 3.104 | d0/s7 | K24 |
| 253 | 5178.977 | 0.992 | 45.856 | d0/s7 | K25 |
| 254 | 5179.023 | 0.256 | 56.225 | d0/s7 | K26 |
| 255 | 5179.080 | 0.480 | 33.728 | d0/s7 | K27 |
| 256 | 5179.114 | 0.287 | 3.329 | d0/s7 | K28 |
| 257 | 5179.118 | 0.256 | 57.056 | d0/s7 | K29 |
| 258 | 5179.175 | 0.288 | 129.184 | d0/s7 | K30 |
| 259 | 5179.348 | 43.424 | 3.264 | d0/s7 | K24 |
| 260 | 5179.352 | 1.216 | 45.728 | d0/s7 | K25 |
| 261 | 5179.398 | 0.256 | 56.321 | d0/s7 | K26 |
| 262 | 5179.455 | 0.448 | 33.792 | d0/s7 | K27 |
| 263 | 5179.489 | 0.255 | 3.265 | d0/s7 | K28 |
| 264 | 5179.492 | 0.255 | 57.281 | d0/s7 | K29 |
| 265 | 5179.550 | 0.256 | 129.216 | d0/s7 | K30 |
| 266 | 5179.723 | 43.456 | 3.264 | d0/s7 | K24 |
| 267 | 5179.727 | 0.960 | 45.824 | d0/s7 | K25 |
| 268 | 5179.773 | 0.256 | 56.257 | d0/s7 | K26 |
| 269 | 5179.830 | 0.447 | 33.728 | d0/s7 | K27 |
| 270 | 5179.864 | 0.257 | 3.263 | d0/s7 | K28 |
| 271 | 5179.867 | 0.257 | 57.152 | d0/s7 | K29 |
| 272 | 5179.925 | 0.256 | 129.152 | d0/s7 | K30 |
| 273 | 5180.096 | 42.816 | 3.264 | d0/s7 | K24 |
| 274 | 5180.101 | 1.120 | 45.760 | d0/s7 | K25 |
| 275 | 5180.147 | 0.256 | 56.512 | d0/s7 | K26 |
| 276 | 5180.204 | 0.448 | 33.761 | d0/s7 | K27 |
| 277 | 5180.238 | 0.256 | 3.264 | d0/s7 | K28 |
| 278 | 5180.241 | 0.256 | 57.056 | d0/s7 | K29 |
| 279 | 5180.299 | 0.256 | 129.088 | d0/s7 | K30 |
| 280 | 5180.476 | 48.640 | 3.264 | d0/s7 | K24 |
| 281 | 5180.481 | 1.376 | 45.824 | d0/s7 | K25 |
| 282 | 5180.527 | 0.256 | 56.320 | d0/s7 | K26 |
| 283 | 5180.584 | 0.449 | 33.855 | d0/s7 | K27 |
| 284 | 5180.618 | 0.257 | 3.231 | d0/s7 | K28 |
| 285 | 5180.622 | 0.257 | 56.992 | d0/s7 | K29 |
| 286 | 5180.679 | 0.256 | 128.992 | d0/s7 | K30 |
| 287 | 5180.850 | 42.272 | 3.136 | d0/s7 | K24 |
| 288 | 5180.854 | 1.120 | 45.760 | d0/s7 | K25 |
| 289 | 5180.900 | 0.256 | 56.384 | d0/s7 | K26 |
| 290 | 5180.957 | 0.480 | 33.824 | d0/s7 | K27 |
| 291 | 5180.991 | 0.256 | 3.360 | d0/s7 | K28 |
| 292 | 5180.995 | 0.257 | 57.087 | d0/s7 | K29 |
| 293 | 5181.052 | 0.225 | 129.088 | d0/s7 | K30 |
| 294 | 5181.225 | 43.680 | 3.104 | d0/s7 | K24 |
| 295 | 5181.230 | 1.600 | 45.728 | d0/s7 | K25 |
| 296 | 5181.276 | 0.256 | 56.480 | d0/s7 | K26 |
| 297 | 5181.333 | 0.448 | 33.793 | d0/s7 | K27 |
| 298 | 5181.367 | 0.288 | 3.327 | d0/s7 | K28 |
| 299 | 5181.370 | 0.256 | 57.121 | d0/s7 | K29 |
| 300 | 5181.428 | 0.223 | 129.057 | d0/s7 | K30 |
| 301 | 5181.603 | 45.920 | 3.136 | d0/s7 | K24 |
| 302 | 5181.607 | 1.056 | 45.920 | d0/s7 | K25 |
| 303 | 5181.653 | 0.256 | 56.033 | d0/s7 | K26 |
| 304 | 5181.709 | 0.480 | 33.855 | d0/s7 | K27 |
| 305 | 5181.744 | 0.257 | 3.360 | d0/s7 | K28 |
| 306 | 5181.747 | 0.255 | 57.025 | d0/s7 | K29 |
| 307 | 5181.804 | 0.255 | 129.217 | d0/s7 | K30 |
| 308 | 5181.977 | 43.360 | 3.136 | d0/s7 | K24 |
| 309 | 5181.981 | 0.992 | 45.856 | d0/s7 | K25 |
| 310 | 5182.027 | 0.256 | 56.192 | d0/s7 | K26 |
| 311 | 5182.084 | 0.448 | 33.760 | d0/s7 | K27 |
| 312 | 5182.118 | 0.256 | 3.328 | d0/s7 | K28 |
| 313 | 5182.122 | 0.289 | 57.055 | d0/s7 | K29 |
| 314 | 5182.179 | 0.257 | 129.056 | d0/s7 | K30 |
| 315 | 5182.356 | 47.647 | 3.264 | d0/s7 | K24 |
| 316 | 5182.360 | 1.568 | 45.760 | d0/s7 | K25 |
| 317 | 5182.406 | 0.289 | 56.224 | d0/s7 | K26 |
| 318 | 5182.463 | 0.448 | 33.729 | d0/s7 | K27 |
| 319 | 5182.497 | 0.255 | 3.232 | d0/s7 | K28 |
| 320 | 5182.501 | 0.288 | 57.089 | d0/s7 | K29 |
| 321 | 5182.558 | 0.256 | 129.152 | d0/s7 | K30 |
| 322 | 5182.730 | 42.656 | 3.264 | d0/s7 | K24 |
| 323 | 5182.734 | 1.024 | 45.760 | d0/s7 | K25 |
| 324 | 5182.780 | 0.256 | 56.160 | d0/s7 | K26 |
| 325 | 5182.837 | 0.448 | 33.728 | d0/s7 | K27 |
| 326 | 5182.871 | 0.257 | 3.295 | d0/s7 | K28 |
| 327 | 5182.874 | 0.256 | 57.184 | d0/s7 | K29 |
| 328 | 5182.932 | 0.257 | 129.056 | d0/s7 | K30 |
| 329 | 5183.104 | 43.040 | 3.264 | d0/s7 | K24 |
| 330 | 5183.108 | 0.832 | 45.984 | d0/s7 | K25 |
| 331 | 5183.154 | 0.256 | 56.480 | d0/s7 | K26 |
| 332 | 5183.211 | 0.448 | 33.696 | d0/s7 | K27 |
| 333 | 5183.245 | 0.256 | 3.296 | d0/s7 | K28 |
| 334 | 5183.249 | 0.257 | 57.120 | d0/s7 | K29 |
| 335 | 5183.306 | 0.255 | 129.345 | d0/s7 | K30 |
| 336 | 5183.478 | 42.496 | 3.264 | d0/s7 | K24 |
| 337 | 5183.483 | 1.600 | 45.760 | d0/s7 | K25 |
| 338 | 5183.529 | 0.256 | 56.128 | d0/s7 | K26 |
| 339 | 5183.585 | 0.448 | 33.824 | d0/s7 | K27 |
| 340 | 5183.619 | 0.256 | 3.264 | d0/s7 | K28 |
| 341 | 5183.623 | 0.256 | 57.057 | d0/s7 | K29 |
| 342 | 5183.680 | 0.255 | 129.025 | d0/s7 | K30 |
| 343 | 5183.854 | 45.216 | 3.136 | d0/s7 | K24 |
| 344 | 5183.859 | 1.152 | 45.856 | d0/s7 | K25 |
| 345 | 5183.905 | 0.256 | 56.448 | d0/s7 | K26 |
| 346 | 5183.962 | 0.480 | 33.888 | d0/s7 | K27 |
| 347 | 5183.996 | 0.256 | 3.328 | d0/s7 | K28 |
| 348 | 5183.999 | 0.256 | 56.928 | d0/s7 | K29 |
| 349 | 5184.057 | 0.256 | 129.121 | d0/s7 | K30 |
| 350 | 5184.230 | 44.224 | 3.136 | d0/s7 | K24 |
| 351 | 5184.234 | 0.736 | 45.824 | d0/s7 | K25 |
| 352 | 5184.280 | 0.256 | 56.160 | d0/s7 | K26 |
| 353 | 5184.336 | 0.448 | 33.824 | d0/s7 | K27 |
| 354 | 5184.371 | 0.256 | 3.328 | d0/s7 | K28 |
| 355 | 5184.374 | 0.288 | 57.088 | d0/s7 | K29 |
| 356 | 5184.432 | 0.256 | 129.057 | d0/s7 | K30 |
| 357 | 5184.603 | 42.880 | 3.104 | d0/s7 | K24 |
| 358 | 5184.607 | 0.928 | 45.760 | d0/s7 | K25 |
| 359 | 5184.654 | 0.256 | 56.128 | d0/s7 | K26 |
| 360 | 5184.710 | 0.480 | 33.888 | d0/s7 | K27 |
| 361 | 5184.744 | 0.256 | 3.328 | d0/s7 | K28 |
| 362 | 5184.748 | 0.256 | 57.088 | d0/s7 | K29 |
| 363 | 5184.805 | 0.257 | 129.056 | d0/s7 | K30 |
| 364 | 5184.977 | 42.976 | 3.136 | d0/s7 | K24 |
| 365 | 5184.981 | 0.864 | 45.792 | d0/s7 | K25 |
| 366 | 5185.027 | 0.256 | 56.096 | d0/s7 | K26 |
| 367 | 5185.084 | 0.479 | 33.760 | d0/s7 | K27 |
| 368 | 5185.118 | 0.256 | 3.328 | d0/s7 | K28 |
| 369 | 5185.121 | 0.256 | 57.312 | d0/s7 | K29 |
| 370 | 5185.179 | 0.256 | 129.089 | d0/s7 | K30 |
| 371 | 5185.356 | 47.968 | 3.296 | d0/s7 | K24 |
| 372 | 5185.361 | 1.184 | 45.952 | d0/s7 | K25 |
| 373 | 5185.407 | 0.256 | 56.192 | d0/s7 | K26 |
| 374 | 5185.463 | 0.480 | 33.728 | d0/s7 | K27 |
| 375 | 5185.497 | 0.256 | 3.264 | d0/s7 | K28 |
| 376 | 5185.501 | 0.256 | 57.248 | d0/s7 | K29 |
| 377 | 5185.558 | 0.256 | 128.993 | d0/s7 | K30 |
| 378 | 5185.731 | 43.520 | 3.232 | d0/s7 | K24 |
| 379 | 5185.735 | 0.672 | 45.792 | d0/s7 | K25 |
| 380 | 5185.781 | 0.256 | 56.352 | d0/s7 | K26 |
| 381 | 5185.838 | 0.480 | 33.728 | d0/s7 | K27 |
| 382 | 5185.872 | 0.256 | 3.264 | d0/s7 | K28 |
| 383 | 5185.875 | 0.256 | 57.024 | d0/s7 | K29 |
| 384 | 5185.932 | 0.224 | 129.153 | d0/s7 | K30 |
| 385 | 5186.106 | 44.672 | 3.232 | d0/s7 | K24 |
| 386 | 5186.110 | 0.832 | 45.792 | d0/s7 | K25 |
| 387 | 5186.156 | 0.256 | 56.608 | d0/s7 | K26 |
| 388 | 5186.214 | 0.480 | 33.760 | d0/s7 | K27 |
| 389 | 5186.248 | 0.256 | 3.264 | d0/s7 | K28 |
| 390 | 5186.251 | 0.256 | 57.216 | d0/s7 | K29 |
| 391 | 5186.309 | 0.256 | 129.089 | d0/s7 | K30 |
| 392 | 5186.481 | 43.136 | 3.264 | d0/s7 | K24 |
| 393 | 5186.486 | 2.016 | 45.824 | d0/s7 | K25 |
| 394 | 5186.532 | 0.256 | 56.224 | d0/s7 | K26 |
| 395 | 5186.589 | 0.448 | 33.888 | d0/s7 | K27 |
| 396 | 5186.623 | 0.256 | 3.232 | d0/s7 | K28 |
| 397 | 5186.626 | 0.256 | 57.184 | d0/s7 | K29 |
| 398 | 5186.684 | 0.256 | 128.993 | d0/s7 | K30 |
| 399 | 5186.857 | 44.384 | 3.103 | d0/s7 | K24 |
| 400 | 5186.861 | 0.545 | 45.696 | d0/s7 | K25 |
| 401 | 5186.907 | 0.256 | 56.384 | d0/s7 | K26 |
| 402 | 5186.964 | 0.448 | 33.824 | d0/s7 | K27 |
| 403 | 5186.998 | 0.255 | 3.360 | d0/s7 | K28 |
| 404 | 5187.001 | 0.256 | 57.216 | d0/s7 | K29 |
| 405 | 5187.059 | 0.256 | 129.185 | d0/s7 | K30 |
| 406 | 5187.233 | 44.800 | 3.072 | d0/s7 | K24 |
| 407 | 5187.237 | 0.928 | 45.728 | d0/s7 | K25 |
| 408 | 5187.283 | 0.256 | 56.512 | d0/s7 | K26 |
| 409 | 5187.340 | 0.448 | 33.920 | d0/s7 | K27 |
| 410 | 5187.374 | 0.256 | 3.328 | d0/s7 | K28 |
| 411 | 5187.378 | 0.288 | 56.992 | d0/s7 | K29 |
| 412 | 5187.435 | 0.256 | 129.184 | d0/s7 | K30 |
| 413 | 5187.608 | 44.032 | 3.105 | d0/s7 | K24 |
| 414 | 5187.612 | 1.088 | 45.792 | d0/s7 | K25 |
| 415 | 5187.658 | 0.256 | 56.224 | d0/s7 | K26 |
| 416 | 5187.715 | 0.448 | 33.856 | d0/s7 | K27 |
| 417 | 5187.749 | 0.256 | 3.328 | d0/s7 | K28 |
| 418 | 5187.753 | 0.256 | 57.024 | d0/s7 | K29 |
| 419 | 5187.810 | 0.256 | 129.121 | d0/s7 | K30 |
| 420 | 5187.983 | 43.487 | 3.105 | d0/s7 | K24 |
| 421 | 5187.987 | 0.928 | 45.888 | d0/s7 | K25 |
| 422 | 5188.033 | 0.256 | 56.192 | d0/s7 | K26 |
| 423 | 5188.089 | 0.480 | 33.728 | d0/s7 | K27 |
| 424 | 5188.123 | 0.288 | 3.328 | d0/s7 | K28 |
| 425 | 5188.127 | 0.256 | 56.960 | d0/s7 | K29 |
| 426 | 5188.184 | 0.256 | 129.313 | d0/s7 | K30 |
| 427 | 5188.358 | 44.736 | 3.296 | d0/s7 | K24 |
| 428 | 5188.363 | 1.120 | 45.664 | d0/s7 | K25 |
| 429 | 5188.409 | 0.256 | 56.288 | d0/s7 | K26 |
| 430 | 5188.465 | 0.480 | 33.760 | d0/s7 | K27 |
| 431 | 5188.499 | 0.256 | 3.264 | d0/s7 | K28 |
| 432 | 5188.503 | 0.256 | 57.248 | d0/s7 | K29 |
| 433 | 5188.560 | 0.256 | 129.184 | d0/s7 | K30 |
| 434 | 5188.934 | 244.641 | 4.000 | d0/s7 | K31 |
| 435 | 5188.999 | 60.384 | 1.824 | d0/s7 | K32 |
| 436 | 5189.094 | 93.953 | 3.968 | d0/s7 | K33 |
| 437 | 5189.135 | 36.800 | 1.664 | d0/s7 | K9 |
| 438 | 5189.171 | 33.984 | 1.728 | d0/s7 | K34 |
| 439 | 5189.242 | 69.888 | 1.952 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 440 | 5189.294 | 49.984 | 1.920 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 441 | 5189.463 | 166.688 | 3.169 | d0/s7 | K35 |
| 442 | 5189.506 | 39.935 | 2.529 | d0/s7 | K36 |
| 443 | 5189.525 | 16.063 | 1.825 | d0/s7 | K19 |
| 444 | 5189.542 | 15.552 | 2.048 | d0/s7 | K37 |
| 445 | 5189.557 | 12.640 | 3.648 | d0/s7 | K38 |
| 446 | 5189.574 | 14.048 | 1.728 | d0/s7 | K39 |
| 447 | 5189.792 | 216.064 | 4.416 | d0/s7 | K40 |
| 448 | 5189.831 | 34.144 | 1.665 | d0/s7 | K41 |
| 449 | 5189.872 | 39.360 | 1.215 | d0/s7 | K42 |
| 450 | 5189.906 | 32.737 | 2.240 | d0/s7 | K43 |
| 451 | 5189.962 | 53.920 | 1.824 | d0/s7 | Memcpy DtoD (Device -> Device) (786432 B) |
| 452 | 5189.997 | 33.664 | 2.400 | d0/s7 | K44 |
| 453 | 5190.040 | 39.776 | 3.264 | d0/s7 | K45 |
| 454 | 5190.113 | 70.432 | 5.056 | d0/s7 | K46 |
| 455 | 5190.142 | 23.264 | 2.304 | d0/s7 | K47 |
| 456 | 5190.163 | 19.200 | 1.664 | d0/s7 | K9 |
| 457 | 5190.181 | 16.384 | 1.728 | d0/s7 | K34 |
| 458 | 5190.210 | 27.456 | 1.952 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 459 | 5190.245 | 33.152 | 1.952 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 460 | 5190.354 | 106.817 | 2.880 | d0/s7 | K48 |
| 461 | 5190.379 | 21.472 | 2.368 | d0/s7 | K49 |
| 462 | 5190.396 | 15.392 | 1.824 | d0/s7 | K50 |
| 463 | 5190.432 | 33.952 | 4.064 | d0/s7 | K33 |
| 464 | 5190.451 | 14.816 | 1.600 | d0/s7 | K9 |
| 465 | 5190.468 | 15.040 | 1.728 | d0/s7 | K34 |
| 466 | 5190.488 | 18.464 | 1.920 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 467 | 5190.519 | 29.088 | 1.728 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 468 | 5190.592 | 71.360 | 3.360 | d0/s7 | K51 |
| 469 | 5190.608 | 12.448 | 2.592 | d0/s7 | K52 |
| 470 | 5190.651 | 40.257 | 2.047 | d0/s7 | K53 |
| 471 | 5190.665 | 12.513 | 1.887 | d0/s7 | K22 |
| 472 | 5190.680 | 12.959 | 2.048 | d0/s7 | K54 |
| 473 | 5190.699 | 16.832 | 1.025 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 474 | 5190.724 | 24.576 | 1.952 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 475 | 5190.772 | 45.152 | 4.160 | d0/s7 | K48 |
| 476 | 5190.786 | 10.336 | 2.208 | d0/s7 | K49 |
| 477 | 5190.798 | 9.984 | 1.696 | d0/s7 | K50 |
| 478 | 5190.823 | 22.784 | 3.840 | d0/s7 | K33 |
| 479 | 5190.888 | 61.504 | 16.800 | d0/s7 | K55 |
| 480 | 5190.905 | 0.256 | 2.496 | d0/s7 | K36 |
| 481 | 5191.002 | 94.304 | 4.192 | d0/s7 | K40 |
| 482 | 5191.028 | 21.600 | 1.857 | d0/s7 | K41 |
| 483 | 5191.065 | 35.936 | 1.856 | d0/s7 | Memcpy DtoD (Device -> Device) (786432 B) |
| 484 | 5191.082 | 14.656 | 2.176 | d0/s7 | K44 |
| 485 | 5191.105 | 21.120 | 3.104 | d0/s7 | K45 |
| 486 | 5191.155 | 46.624 | 4.992 | d0/s7 | K46 |
| 487 | 5191.182 | 21.696 | 2.272 | d0/s7 | K47 |
| 488 | 5191.214 | 30.144 | 15.168 | d0/s7 | K56 |
| 489 | 5191.230 | 0.256 | 1.952 | d0/s7 | K50 |
| 490 | 5191.239 | 7.520 | 2.400 | d0/s7 | K49 |
| 491 | 5191.264 | 23.008 | 4.064 | d0/s7 | K33 |
| 492 | 5191.317 | 48.288 | 22.496 | d0/s7 | K57 |
| 493 | 5191.340 | 0.256 | 2.592 | d0/s7 | K52 |
| 494 | 5191.345 | 3.168 | 1.984 | d0/s7 | K53 |
| 495 | 5191.380 | 32.416 | 1.889 | d0/s7 | Memset (Device) (1536 B) |
| 496 | 5191.398 | 16.512 | 1.311 | d0/s7 | K58 |
| 497 | 5191.416 | 16.480 | 61.824 | d0/s7 | K59 |
| 498 | 5191.478 | 0.257 | 1.984 | d0/s7 | K50 |
| 499 | 5191.480 | 0.288 | 2.272 | d0/s7 | K49 |
| 500 | 5191.483 | 0.256 | 1.824 | d0/s7 | K50 |
| 501 | 5191.506 | 21.503 | 1.440 | d0/s7 | K60 |
| 502 | 5191.547 | 39.872 | 12.928 | d0/s7 | K61 |
| 503 | 5191.584 | 23.616 | 2.720 | d0/s7 | Memcpy DtoH (Device -> Pinned) (4 B) |
| 504 | 5191.641 | 54.304 | 1.888 | d0/s7 | Memcpy HtoD (Pageable -> Device) (56 B) |
| 505 | 5191.678 | 35.040 | 1.696 | d0/s7 | Memcpy HtoD (Pageable -> Device) (48 B) |
| 506 | 5191.735 | 55.232 | 4.192 | d0/s7 | K62 |
| 507 | 5191.752 | 13.184 | 3.808 | d0/s7 | K63 |
| 508 | 5191.767 | 10.752 | 4.160 | d0/s7 | K62 |
| 509 | 5191.780 | 8.896 | 4.192 | d0/s7 | K63 |
| 510 | 5191.792 | 8.097 | 1.760 | d0/s7 | K64 |
| 511 | 5191.808 | 13.888 | 1.760 | d0/s7 | K65 |
| 512 | 5191.827 | 17.600 | 2.047 | d0/s7 | K66 |
| 513 | 5191.838 | 8.897 | 2.880 | d0/s7 | Memcpy DtoH (Device -> Pinned) (4 B) |
| 514 | 5191.872 | 31.040 | 1.376 | d0/s7 | K60 |
| 515 | 5191.905 | 32.064 | 1.504 | d0/s7 | K67 |
| 516 | 5191.932 | 25.120 | 1.536 | d0/s7 | K68 |
| 517 | 5191.951 | 17.568 | 1.792 | d0/s7 | K69 |
| 518 | 5192.006 | 53.056 | 13.056 | d0/s7 | K70 |
| 519 | 5192.022 | 3.424 | 4.064 | d0/s7 | Memcpy DtoH (Device -> Pinned) (1 B) |
