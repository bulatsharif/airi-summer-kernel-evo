import cutlass
import cutlass.cute as cute
import cutlass.pipeline as pipeline
import cutlass.utils as utils
import cutlass.utils.blackwell_helpers as sm100_utils
from cutlass.cute.nvgpu import cpasync, tcgen05

TOKENS = 128
HIDDEN_SIZE = 768
NUM_HEADS = 12
HEAD_DIM = 64
MLP_SIZE = 3072
QKV_SIZE = 3 * HIDDEN_SIZE
THREADS = 128
EPSILON = 1.0e-5

INPUT_SCALE = 1.0 / 448.0
NORM_SCALE = 1.0 / 64.0
QKV_SCALE = 1.0 / 64.0
CONTEXT_SCALE = 1.0 / 64.0
MLP_SCALE = 1.0 / 64.0
WEIGHT_H_SCALE = HIDDEN_SIZE ** -0.5 / 448.0
WEIGHT_MLP_SCALE = MLP_SIZE ** -0.5 / 448.0

S_QKV = NORM_SCALE * WEIGHT_H_SCALE
S_OUT = CONTEXT_SCALE * WEIGHT_H_SCALE
S_FC = NORM_SCALE * WEIGHT_H_SCALE
S_PROJ = MLP_SCALE * WEIGHT_MLP_SCALE
SCORE_SCALE = QKV_SCALE * QKV_SCALE / 8.0
CONTEXT_RATIO = QKV_SCALE / CONTEXT_SCALE

FP8_DTYPE = cutlass.Float8E4M3FN
ACC_DTYPE = cutlass.Float32

# tcgen05 tensor-core GEMM tiling.
MMA_M = 128
MMA_N = 128
MMA_K = 64
MMA_TILER_MNK = (MMA_M, MMA_N, MMA_K)
THREADS_PER_CTA = 128
AB_STAGES = 3
ACC_STAGES = 1

# Epilogue modes.
MODE_QKV = 0
MODE_OUT = 1
MODE_FC = 2
MODE_PROJ = 3


@cute.jit
def gelu_new(x):
    c = cutlass.Float32(0.7978845608028654)  # sqrt(2/pi)
    t = x + cutlass.Float32(0.044715) * x * x * x
    return cutlass.Float32(0.5) * x * (cutlass.Float32(1.0) + cute.tanh(c * t))


@cute.jit
def layernorm_stats(hidden, token, tid, smem, in_scale):
    s = cutlass.Float32(0.0)
    ss = cutlass.Float32(0.0)
    for t in cutlass.range_constexpr(HIDDEN_SIZE // THREADS):
        f = t * THREADS + tid
        x = hidden[token, f].to(cutlass.Float32) * cutlass.Float32(in_scale)
        s = s + x
        ss = ss + x * x
    smem[tid] = s
    smem[THREADS + tid] = ss
    cute.arch.sync_threads()
    total = cutlass.Float32(0.0)
    total_ss = cutlass.Float32(0.0)
    for j in cutlass.range_constexpr(THREADS):
        total = total + smem[j]
    for j in cutlass.range_constexpr(THREADS):
        total_ss = total_ss + smem[THREADS + j]
    mean = total / cutlass.Float32(HIDDEN_SIZE)
    var = total_ss / cutlass.Float32(HIDDEN_SIZE) - mean * mean
    rstd = cute.rsqrt(var + cutlass.Float32(EPSILON))
    return mean, rstd


@cute.struct
class SharedStorage:
    ab_mbar_ptr: cute.struct.MemRange[cutlass.Int64, AB_STAGES * 2]
    acc_mbar_ptr: cute.struct.MemRange[cutlass.Int64, ACC_STAGES * 2]
    tmem_holding_buf: cutlass.Int32


@cute.kernel
def tile_gemm_kernel(
    tiled_mma: cute.TiledMma,
    tma_atom_a: cute.CopyAtom,
    tma_tensor_a: cute.Tensor,
    tma_atom_b: cute.CopyAtom,
    tma_tensor_b: cute.Tensor,
    output: cute.Tensor,
    smem_layout_a: cute.ComposedLayout,
    smem_layout_b: cute.ComposedLayout,
    bias: cute.Tensor,
    residual: cute.Tensor,
    mode: cutlass.Constexpr,
):
    thread_idx, _, _ = cute.arch.thread_idx()
    warp_idx = cute.arch.make_warp_uniform(cute.arch.warp_idx())
    bx, _, _ = cute.arch.block_idx()
    n_base = bx * MMA_N

    smem = utils.SmemAllocator()
    storage = smem.allocate(SharedStorage)
    smem_a = smem.allocate_tensor(
        element_type=FP8_DTYPE,
        layout=smem_layout_a.outer,
        byte_alignment=128,
        swizzle=smem_layout_a.inner,
    )
    smem_b = smem.allocate_tensor(
        element_type=FP8_DTYPE,
        layout=smem_layout_b.outer,
        byte_alignment=128,
        swizzle=smem_layout_b.inner,
    )

    tmem_barrier = pipeline.NamedBarrier(
        barrier_id=1,
        num_threads=THREADS_PER_CTA,
    )
    tmem = utils.TmemAllocator(
        storage.tmem_holding_buf.ptr,
        barrier_for_retrieve=tmem_barrier,
    )
    tmem.allocate(512)

    if warp_idx == 0:
        cpasync.prefetch_descriptor(tma_atom_a)
        cpasync.prefetch_descriptor(tma_atom_b)

    one_stage_a = cute.select(smem_layout_a, mode=[0, 1, 2])
    one_stage_b = cute.select(smem_layout_b, mode=[0, 1, 2])
    transaction_bytes = cute.size_in_bytes(
        FP8_DTYPE, one_stage_a
    ) + cute.size_in_bytes(FP8_DTYPE, one_stage_b)
    ab_producer, ab_consumer = pipeline.PipelineTmaUmma.create(
        num_stages=AB_STAGES,
        producer_group=pipeline.CooperativeGroup(pipeline.Agent.Thread),
        consumer_group=pipeline.CooperativeGroup(pipeline.Agent.Thread),
        tx_count=transaction_bytes,
        barrier_storage=storage.ab_mbar_ptr.data_ptr(),
    ).make_participants()
    acc_producer, acc_consumer = pipeline.PipelineUmmaAsync.create(
        num_stages=ACC_STAGES,
        producer_group=pipeline.CooperativeGroup(pipeline.Agent.Thread),
        consumer_group=pipeline.CooperativeGroup(
            pipeline.Agent.Thread,
            THREADS_PER_CTA,
        ),
        barrier_storage=storage.acc_mbar_ptr.data_ptr(),
    ).make_participants()

    global_a = cute.local_tile(
        tma_tensor_a,
        MMA_TILER_MNK,
        (0, None, None),
        proj=(1, None, 1),
    )
    global_b = cute.local_tile(
        tma_tensor_b,
        MMA_TILER_MNK,
        (None, bx, None),
        proj=(None, 1, 1),
    )
    global_c = cute.local_tile(
        output,
        MMA_TILER_MNK,
        (0, bx, None),
        proj=(1, 1, None),
    )

    thr_mma = tiled_mma.get_slice(0)
    mma_global_a = thr_mma.partition_A(global_a)
    mma_global_b = thr_mma.partition_B(global_b)
    mma_global_c = thr_mma.partition_C(global_c)
    mma_smem_a = tiled_mma.make_fragment_A(smem_a)
    mma_smem_b = tiled_mma.make_fragment_B(smem_b)
    acc_shape = tiled_mma.partition_shape_C(MMA_TILER_MNK[:2])
    tmem_acc = tiled_mma.make_fragment_C(acc_shape)

    tma_smem_a, tma_global_a = cpasync.tma_partition(
        tma_atom_a,
        0,
        cute.make_layout(1),
        cute.group_modes(smem_a, 0, 3),
        cute.group_modes(mma_global_a, 0, 3),
    )
    tma_smem_b, tma_global_b = cpasync.tma_partition(
        tma_atom_b,
        0,
        cute.make_layout(1),
        cute.group_modes(smem_b, 0, 3),
        cute.group_modes(mma_global_b, 0, 3),
    )

    tmem.wait_for_alloc()
    tmem_ptr = tmem.retrieve_ptr(ACC_DTYPE)
    tmem_acc = cute.make_tensor(tmem_ptr, tmem_acc.layout)

    # Bias broadcast tile [MMA_M, MMA_N] with stride (0, 1).
    bias_tile = cute.make_tensor(
        bias.data_ptr() + n_base,
        cute.make_layout((MMA_M, MMA_N), stride=(0, 1)),
    )
    mma_bias = thr_mma.partition_C(bias_tile)

    subtile_count = 2
    epilogue_tiler = (
        (
            cute.size(tmem_acc, mode=[0, 0]),
            cute.size(tmem_acc, mode=[0, 1]) // subtile_count,
        ),
    )
    tmem_acc_epilogue = cute.zipped_divide(tmem_acc, epilogue_tiler)
    global_c_epilogue = cute.zipped_divide(mma_global_c, epilogue_tiler)
    bias_epilogue = cute.zipped_divide(mma_bias, epilogue_tiler)
    tmem_atom = cute.make_copy_atom(
        tcgen05.Ld32x32bOp(tcgen05.Repetition.x64),
        ACC_DTYPE,
    )
    tmem_tiled_copy = tcgen05.make_tmem_copy(
        tmem_atom,
        tmem_acc_epilogue[None, 0],
    )
    tmem_thread_copy = tmem_tiled_copy.get_slice(thread_idx)
    tmem_source = tmem_thread_copy.partition_S(tmem_acc_epilogue)
    global_destination = tmem_thread_copy.partition_D(global_c_epilogue)
    bias_fragment = tmem_thread_copy.partition_D(bias_epilogue)
    register_acc = cute.make_rmem_tensor(
        global_destination[None, None, 0].shape,
        ACC_DTYPE,
    )

    if warp_idx == 0:
        acc_empty = acc_producer.acquire_and_advance()
        num_k_tiles = cute.size(global_a, mode=[2])
        for _ in cutlass.range(num_k_tiles, prefetch_stages=AB_STAGES - 2):
            ab_empty = ab_producer.acquire_and_advance()
            cute.copy(
                tma_atom_a,
                tma_global_a[(None, ab_empty.count)],
                tma_smem_a[(None, ab_empty.index)],
                tma_bar_ptr=ab_empty.barrier,
            )
            cute.copy(
                tma_atom_b,
                tma_global_b[(None, ab_empty.count)],
                tma_smem_b[(None, ab_empty.index)],
                tma_bar_ptr=ab_empty.barrier,
            )
            ab_full = ab_consumer.wait_and_advance()
            num_k_blocks = cute.size(mma_smem_a, mode=[2])
            for k_block in cutlass.range_constexpr(num_k_blocks):
                coord = (None, None, k_block, ab_full.index)
                cute.gemm(
                    tiled_mma,
                    tmem_acc,
                    mma_smem_a[coord],
                    mma_smem_b[coord],
                    tmem_acc,
                )
                tiled_mma.set(tcgen05.Field.ACCUMULATE, True)
            ab_full.release()
        acc_empty.commit()

    tmem.relinquish_alloc_permit()
    acc_full = acc_consumer.wait_and_advance()
    n_out = cute.size(register_acc)
    for tile_idx in cute.range(cute.size(tmem_source, mode=[2])):
        cute.copy(
            tmem_tiled_copy,
            tmem_source[None, None, tile_idx],
            register_acc,
        )
        for d in cute.range(n_out):
            av = register_acc[d]
            bv = bias_fragment[d]
            if cutlass.const_expr(mode == MODE_QKV):
                val = av * cutlass.Float32(S_QKV) + bv
                register_acc[d] = FP8_DTYPE(val / cutlass.Float32(QKV_SCALE))
            elif cutlass.const_expr(mode == MODE_FC):
                g = gelu_new(av * cutlass.Float32(S_FC) + bv)
                register_acc[d] = FP8_DTYPE(g / cutlass.Float32(MLP_SCALE))
            elif cutlass.const_expr(mode == MODE_OUT):
                register_acc[d] = (
                    residual[None, None, tile_idx][d]
                    * cutlass.Float32(INPUT_SCALE)
                    + av * cutlass.Float32(S_OUT)
                    + bv
                )
            else:
                register_acc[d] = (
                    residual[None, None, tile_idx][d]
                    + av * cutlass.Float32(S_PROJ)
                    + bv
                )
        cute.autovec_copy(
            register_acc,
            global_destination[None, None, tile_idx],
        )
    acc_full.release()

    pipeline.sync(barrier_id=1)
    tmem.free(tmem_ptr)


@cute.jit
def launch_gemm(
    a: cute.Tensor,
    b: cute.Tensor,
    bias: cute.Tensor,
    out: cute.Tensor,
    residual: cute.Tensor,
    mode: cutlass.Constexpr,
):
    a_major = utils.LayoutEnum.from_tensor(a).mma_major_mode()
    b_major = utils.LayoutEnum.from_tensor(b).mma_major_mode()
    tiled_mma = sm100_utils.make_trivial_tiled_mma(
        a.element_type,
        a_major,
        b_major,
        ACC_DTYPE,
        tcgen05.CtaGroup.ONE,
        MMA_TILER_MNK[:2],
    )
    smem_layout_a = sm100_utils.make_smem_layout_a(
        tiled_mma,
        MMA_TILER_MNK,
        a.element_type,
        AB_STAGES,
    )
    smem_layout_b = sm100_utils.make_smem_layout_b(
        tiled_mma,
        MMA_TILER_MNK,
        b.element_type,
        AB_STAGES,
    )
    tma_a = cute.nvgpu.make_tiled_tma_atom_A(
        sm100_utils.CopyBulkTensorTileG2SOp(),
        a,
        cute.select(smem_layout_a, mode=[0, 1, 2]),
        MMA_TILER_MNK,
        tiled_mma,
    )
    tma_b = cute.nvgpu.make_tiled_tma_atom_B(
        sm100_utils.CopyBulkTensorTileG2SOp(),
        b,
        cute.select(smem_layout_b, mode=[0, 1, 2]),
        MMA_TILER_MNK,
        tiled_mma,
    )
    n_tiles = cute.size(out, mode=1) // MMA_N
    tile_gemm_kernel(
        tiled_mma,
        tma_a.atom,
        tma_a.tma_tensor,
        tma_b.atom,
        tma_b.tma_tensor,
        out,
        smem_layout_a,
        smem_layout_b,
        bias,
        residual,
        mode,
    ).launch(
        grid=(n_tiles, 1, 1),
        block=(THREADS_PER_CTA, 1, 1),
    )


@cute.kernel
def ln1_kernel(
    hidden: cute.Tensor,
    ln1_weight: cute.Tensor,
    ln1_bias: cute.Tensor,
    out: cute.Tensor,
):
    tid, _, _ = cute.arch.thread_idx()
    token, _, _ = cute.arch.block_idx()
    alloc = utils.SmemAllocator()
    red = alloc.allocate_tensor(
        cutlass.Float32, cute.make_layout(2 * THREADS), 4
    )
    mean, rstd = layernorm_stats(hidden, token, tid, red, INPUT_SCALE)
    for t in cutlass.range_constexpr(HIDDEN_SIZE // THREADS):
        f = t * THREADS + tid
        x = hidden[token, f].to(cutlass.Float32) * cutlass.Float32(INPUT_SCALE)
        norm = (x - mean) * rstd * ln1_weight[f] + ln1_bias[f]
        out[token, f] = FP8_DTYPE(norm / cutlass.Float32(NORM_SCALE))


@cute.kernel
def attention_kernel(qkv: cute.Tensor, context: cute.Tensor):
    h, i, _ = cute.arch.block_idx()
    j = cute.arch.thread_idx()[0]
    alloc = utils.SmemAllocator()
    score = alloc.allocate_tensor(cutlass.Float32, cute.make_layout(TOKENS), 4)
    prob = alloc.allocate_tensor(cutlass.Float32, cute.make_layout(TOKENS), 4)
    base = h * HEAD_DIM
    acc = cutlass.Float32(0.0)
    for d in cutlass.range_constexpr(HEAD_DIM):
        acc = acc + qkv[i, base + d].to(cutlass.Float32) * qkv[
            j, HIDDEN_SIZE + base + d
        ].to(cutlass.Float32)
    sval = acc * cutlass.Float32(SCORE_SCALE)
    causal = sval if (j <= i) else cutlass.Float32(-3.0e38)
    score[j] = causal
    cute.arch.sync_threads()
    mx = cutlass.Float32(-3.0e38)
    for jj in cutlass.range_constexpr(TOKENS):
        vv = score[jj]
        mx = vv if (vv > mx) else mx
    e = cute.exp(causal - mx)
    prob[j] = e
    cute.arch.sync_threads()
    tot = cutlass.Float32(0.0)
    for jj in cutlass.range_constexpr(TOKENS):
        tot = tot + prob[jj]
    if j < HEAD_DIM:
        cacc = cutlass.Float32(0.0)
        for kk in cutlass.range_constexpr(TOKENS):
            cacc = cacc + prob[kk] * qkv[
                kk, 2 * HIDDEN_SIZE + base + j
            ].to(cutlass.Float32)
        cacc = cacc / tot
        context[i, base + j] = FP8_DTYPE(cacc * cutlass.Float32(CONTEXT_RATIO))


@cute.kernel
def ln2_kernel(
    residual: cute.Tensor,
    ln2_weight: cute.Tensor,
    ln2_bias: cute.Tensor,
    out: cute.Tensor,
):
    tid, _, _ = cute.arch.thread_idx()
    token, _, _ = cute.arch.block_idx()
    alloc = utils.SmemAllocator()
    red = alloc.allocate_tensor(
        cutlass.Float32, cute.make_layout(2 * THREADS), 4
    )
    mean, rstd = layernorm_stats(residual, token, tid, red, 1.0)
    for t in cutlass.range_constexpr(HIDDEN_SIZE // THREADS):
        f = t * THREADS + tid
        x = residual[token, f].to(cutlass.Float32)
        norm = (x - mean) * rstd * ln2_weight[f] + ln2_bias[f]
        out[token, f] = FP8_DTYPE(norm / cutlass.Float32(NORM_SCALE))


@cute.jit
def gpt2_transformer_block(
    hidden: cute.Tensor,
    ln1_weight: cute.Tensor,
    ln1_bias: cute.Tensor,
    qkv_weight: cute.Tensor,
    qkv_bias: cute.Tensor,
    out_weight: cute.Tensor,
    out_bias: cute.Tensor,
    ln2_weight: cute.Tensor,
    ln2_bias: cute.Tensor,
    fc_weight: cute.Tensor,
    fc_bias: cute.Tensor,
    proj_weight: cute.Tensor,
    proj_bias: cute.Tensor,
    norm1_workspace: cute.Tensor,
    qkv_workspace: cute.Tensor,
    score_workspace: cute.Tensor,
    probability_workspace: cute.Tensor,
    context_workspace: cute.Tensor,
    residual_workspace: cute.Tensor,
    norm2_workspace: cute.Tensor,
    mlp_workspace: cute.Tensor,
    output: cute.Tensor,
):
    ln1_kernel(hidden, ln1_weight, ln1_bias, norm1_workspace).launch(
        grid=(TOKENS, 1, 1), block=(THREADS, 1, 1)
    )
    launch_gemm(
        norm1_workspace,
        qkv_weight,
        qkv_bias,
        qkv_workspace,
        qkv_workspace,
        cutlass.Constexpr(MODE_QKV),
    )
    attention_kernel(qkv_workspace, context_workspace).launch(
        grid=(NUM_HEADS, TOKENS, 1), block=(THREADS, 1, 1)
    )
    launch_gemm(
        context_workspace,
        out_weight,
        out_bias,
        residual_workspace,
        hidden,
        cutlass.Constexpr(MODE_OUT),
    )
    ln2_kernel(residual_workspace, ln2_weight, ln2_bias, norm2_workspace).launch(
        grid=(TOKENS, 1, 1), block=(THREADS, 1, 1)
    )
    launch_gemm(
        norm2_workspace,
        fc_weight,
        fc_bias,
        mlp_workspace,
        mlp_workspace,
        cutlass.Constexpr(MODE_FC),
    )
    launch_gemm(
        mlp_workspace,
        proj_weight,
        proj_bias,
        output,
        residual_workspace,
        cutlass.Constexpr(MODE_PROJ),
    )


class ModelNew:
    forward = staticmethod(gpt2_transformer_block)
