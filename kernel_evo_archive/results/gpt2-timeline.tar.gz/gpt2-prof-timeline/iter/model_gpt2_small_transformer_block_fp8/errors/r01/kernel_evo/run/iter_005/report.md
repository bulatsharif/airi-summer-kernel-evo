# KernelEvo iteration 5

Run: `run`  
Barrier status: **evaluated**  
Valid: 1 · Promoted: 1

| Island | Result | Progress | Runtime | Speedup | Promoted | Idea |
|---:|---|---:|---:|---:|:---:|---|
| 0 | valid | — | 509.504 µs | 7.056x | yes | Implement the task's CuTe DSL FP8 kernel so it compiles and produces numerically correct output on… |

Global best: `iter-005-island-0` at **7.056x** speedup.

## Compact profile objectives

- Island 0 (b300_trace): inner device — µs, — kernels, — memcpys; eager layer — µs, dispatch gaps — µs; graph no, replay — µs.

Compact profile review required for island(s): 0. Use `kernel-evo iter review-profiles`, then `kernel-evo island review-submit`.
