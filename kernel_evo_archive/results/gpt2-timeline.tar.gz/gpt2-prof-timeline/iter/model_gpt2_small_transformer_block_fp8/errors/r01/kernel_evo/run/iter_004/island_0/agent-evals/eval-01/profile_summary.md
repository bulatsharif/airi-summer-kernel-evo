# B300 device profile of your last candidate

- device: NVIDIA B300 SXM6 AC, 148 SMs, 232448 B opt-in shared memory/block
- GPU busy: 65.078 ms total; kernels 65.049 ms over 503 launches of 40 distinct names
- memcpy: 0.028 ms over 15 calls; memset: 0.002 ms over 1 calls

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_proj_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 34.364 | 55 | 52.8 |
| kernel_cutlass_out_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 9.045 | 55 | 13.9 |
| kernel_cutlass_fc_gelu_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmemal… | 9.016 | 55 | 13.8 |
| kernel_cutlass_qkv_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 8.734 | 55 | 13.4 |
| kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 3.103 | 55 | 4.8 |
| kernel_cutlass_ln2_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo7681_tensorptrf32gmemo… | 0.186 | 55 | 0.3 |
| kernel_cutlass_ln1_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo7681_tenso… | 0.174 | 55 | 0.3 |
| void sgemm_largek_lds64<true, false, 6, 3, 4, 5, 2, 66>(float*, float const*, float con… | 0.060 | 1 | 0.1 |
| cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 0.047 | 4 | 0.1 |
| void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 0.033 | 17 | 0.1 |
