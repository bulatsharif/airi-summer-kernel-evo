import cutlass
import cutlass.cute as cute
import cutlass.utils as utils

TOKENS = 128
HIDDEN_SIZE = 768
NUM_HEADS = 12
HEAD_DIM = 64
MLP_SIZE = 3072
QKV_SIZE = 3 * HIDDEN_SIZE
THREADS = 128
EPSILON = 1.0e-5

INPUT_SCALE = 1.0 / 448.0
NORM_SCALE = 1.0 / 64.0
QKV_SCALE = 1.0 / 64.0
CONTEXT_SCALE = 1.0 / 64.0
MLP_SCALE = 1.0 / 64.0
WEIGHT_H_SCALE = HIDDEN_SIZE ** -0.5 / 448.0
WEIGHT_MLP_SCALE = MLP_SIZE ** -0.5 / 448.0

# Per-GEMM combined scale = input_scale * weight_scale.
S_QKV = NORM_SCALE * WEIGHT_H_SCALE
S_OUT = CONTEXT_SCALE * WEIGHT_H_SCALE
S_FC = NORM_SCALE * WEIGHT_H_SCALE
S_PROJ = MLP_SCALE * WEIGHT_MLP_SCALE
# attention scores: q@k.T / sqrt(64) with both operands scaled by QKV_SCALE.
SCORE_SCALE = QKV_SCALE * QKV_SCALE / 8.0
# context requant: P @ v_fp8 * QKV_SCALE / CONTEXT_SCALE
CONTEXT_RATIO = QKV_SCALE / CONTEXT_SCALE

FP8_DTYPE = cutlass.Float8E4M3FN


@cute.jit
def gelu_new(x):
    c = cutlass.Float32(0.7978845608028654)  # sqrt(2/pi)
    t = x + cutlass.Float32(0.044715) * x * x * x
    return cutlass.Float32(0.5) * x * (cutlass.Float32(1.0) + cute.tanh(c * t))


@cute.jit
def layernorm_stats(hidden, token, tid, smem, in_scale):
    s = cutlass.Float32(0.0)
    ss = cutlass.Float32(0.0)
    for t in cutlass.range_constexpr(HIDDEN_SIZE // THREADS):
        f = t * THREADS + tid
        x = hidden[token, f].to(cutlass.Float32) * cutlass.Float32(in_scale)
        s = s + x
        ss = ss + x * x
    smem[tid] = s
    smem[THREADS + tid] = ss
    cute.arch.sync_threads()
    total = cutlass.Float32(0.0)
    total_ss = cutlass.Float32(0.0)
    for j in cutlass.range_constexpr(THREADS):
        total = total + smem[j]
    for j in cutlass.range_constexpr(THREADS):
        total_ss = total_ss + smem[THREADS + j]
    mean = total / cutlass.Float32(HIDDEN_SIZE)
    var = total_ss / cutlass.Float32(HIDDEN_SIZE) - mean * mean
    rstd = cute.rsqrt(var + cutlass.Float32(EPSILON))
    return mean, rstd


@cute.kernel
def ln1_qkv_kernel(
    hidden: cute.Tensor,
    ln1_weight: cute.Tensor,
    ln1_bias: cute.Tensor,
    qkv_weight: cute.Tensor,
    qkv_bias: cute.Tensor,
    qkv_out: cute.Tensor,
):
    tid, _, _ = cute.arch.thread_idx()
    token, _, _ = cute.arch.block_idx()
    alloc = utils.SmemAllocator()
    red = alloc.allocate_tensor(
        cutlass.Float32, cute.make_layout(2 * THREADS), 4
    )
    n1 = alloc.allocate_tensor(
        FP8_DTYPE, cute.make_layout(HIDDEN_SIZE), 128
    )
    mean, rstd = layernorm_stats(hidden, token, tid, red, INPUT_SCALE)
    for t in cutlass.range_constexpr(HIDDEN_SIZE // THREADS):
        f = t * THREADS + tid
        x = hidden[token, f].to(cutlass.Float32) * cutlass.Float32(INPUT_SCALE)
        norm = (x - mean) * rstd * ln1_weight[f] + ln1_bias[f]
        n1[f] = FP8_DTYPE(norm / cutlass.Float32(NORM_SCALE))
    cute.arch.sync_threads()
    for t in cutlass.range_constexpr(QKV_SIZE // THREADS):
        n0 = t * THREADS + tid
        acc = cutlass.Float32(0.0)
        for k in cutlass.range(HIDDEN_SIZE):
            acc = acc + n1[k].to(cutlass.Float32) * qkv_weight[n0, k].to(
                cutlass.Float32
            )
        val = acc * cutlass.Float32(S_QKV) + qkv_bias[n0].to(cutlass.Float32)
        qkv_out[token, n0] = FP8_DTYPE(val / cutlass.Float32(QKV_SCALE))


@cute.kernel
def attention_kernel(qkv: cute.Tensor, context: cute.Tensor):
    h, i, _ = cute.arch.block_idx()
    j = cute.arch.thread_idx()[0]
    alloc = utils.SmemAllocator()
    score = alloc.allocate_tensor(cutlass.Float32, cute.make_layout(TOKENS), 4)
    prob = alloc.allocate_tensor(cutlass.Float32, cute.make_layout(TOKENS), 4)
    base = h * HEAD_DIM
    acc = cutlass.Float32(0.0)
    for d in cutlass.range_constexpr(HEAD_DIM):
        acc = acc + qkv[i, base + d].to(cutlass.Float32) * qkv[
            j, HIDDEN_SIZE + base + d
        ].to(cutlass.Float32)
    sval = acc * cutlass.Float32(SCORE_SCALE)
    causal = sval if (j <= i) else cutlass.Float32(-3.0e38)
    score[j] = causal
    cute.arch.sync_threads()
    mx = cutlass.Float32(-3.0e38)
    for jj in cutlass.range_constexpr(TOKENS):
        vv = score[jj]
        mx = vv if (vv > mx) else mx
    e = cute.exp(causal - mx)
    prob[j] = e
    cute.arch.sync_threads()
    tot = cutlass.Float32(0.0)
    for jj in cutlass.range_constexpr(TOKENS):
        tot = tot + prob[jj]
    if j < HEAD_DIM:
        cacc = cutlass.Float32(0.0)
        for kk in cutlass.range_constexpr(TOKENS):
            cacc = cacc + prob[kk] * qkv[
                kk, 2 * HIDDEN_SIZE + base + j
            ].to(cutlass.Float32)
        cacc = cacc / tot
        context[i, base + j] = FP8_DTYPE(cacc * cutlass.Float32(CONTEXT_RATIO))


@cute.kernel
def out_residual_kernel(
    context: cute.Tensor,
    out_weight: cute.Tensor,
    out_bias: cute.Tensor,
    hidden: cute.Tensor,
    residual: cute.Tensor,
):
    tid, _, _ = cute.arch.thread_idx()
    bx, by, _ = cute.arch.block_idx()
    n0 = bx * THREADS + tid
    m = by
    acc = cutlass.Float32(0.0)
    for k in cutlass.range(HIDDEN_SIZE):
        acc = acc + context[m, k].to(cutlass.Float32) * out_weight[n0, k].to(
            cutlass.Float32
        )
    r = (
        hidden[m, n0].to(cutlass.Float32) * cutlass.Float32(INPUT_SCALE)
        + acc * cutlass.Float32(S_OUT)
        + out_bias[n0].to(cutlass.Float32)
    )
    residual[m, n0] = r


@cute.kernel
def ln2_fc_gelu_kernel(
    residual: cute.Tensor,
    ln2_weight: cute.Tensor,
    ln2_bias: cute.Tensor,
    fc_weight: cute.Tensor,
    fc_bias: cute.Tensor,
    mlp_out: cute.Tensor,
):
    tid, _, _ = cute.arch.thread_idx()
    bx, token, _ = cute.arch.block_idx()
    alloc = utils.SmemAllocator()
    red = alloc.allocate_tensor(
        cutlass.Float32, cute.make_layout(2 * THREADS), 4
    )
    n2 = alloc.allocate_tensor(
        FP8_DTYPE, cute.make_layout(HIDDEN_SIZE), 128
    )
    mean, rstd = layernorm_stats(residual, token, tid, red, 1.0)
    for t in cutlass.range_constexpr(HIDDEN_SIZE // THREADS):
        f = t * THREADS + tid
        x = residual[token, f].to(cutlass.Float32)
        norm = (x - mean) * rstd * ln2_weight[f] + ln2_bias[f]
        n2[f] = FP8_DTYPE(norm / cutlass.Float32(NORM_SCALE))
    cute.arch.sync_threads()
    for t in cutlass.range_constexpr(MLP_SIZE // THREADS):
        n0 = t * THREADS + tid
        acc = cutlass.Float32(0.0)
        for k in cutlass.range(HIDDEN_SIZE):
            acc = acc + n2[k].to(cutlass.Float32) * fc_weight[n0, k].to(
                cutlass.Float32
            )
        g = gelu_new(acc * cutlass.Float32(S_FC) + fc_bias[n0].to(cutlass.Float32))
        mlp_out[token, n0] = FP8_DTYPE(g / cutlass.Float32(MLP_SCALE))


@cute.kernel
def proj_residual_kernel(
    mlp: cute.Tensor,
    proj_weight: cute.Tensor,
    proj_bias: cute.Tensor,
    residual: cute.Tensor,
    output: cute.Tensor,
):
    tid, _, _ = cute.arch.thread_idx()
    bx, by, _ = cute.arch.block_idx()
    n0 = bx * THREADS + tid
    m = by
    acc = cutlass.Float32(0.0)
    for k in cutlass.range(MLP_SIZE):
        acc = acc + mlp[m, k].to(cutlass.Float32) * proj_weight[n0, k].to(
            cutlass.Float32
        )
    output[m, n0] = (
        residual[m, n0].to(cutlass.Float32)
        + acc * cutlass.Float32(S_PROJ)
        + proj_bias[n0].to(cutlass.Float32)
    )


@cute.jit
def gpt2_transformer_block(
    hidden: cute.Tensor,
    ln1_weight: cute.Tensor,
    ln1_bias: cute.Tensor,
    qkv_weight: cute.Tensor,
    qkv_bias: cute.Tensor,
    out_weight: cute.Tensor,
    out_bias: cute.Tensor,
    ln2_weight: cute.Tensor,
    ln2_bias: cute.Tensor,
    fc_weight: cute.Tensor,
    fc_bias: cute.Tensor,
    proj_weight: cute.Tensor,
    proj_bias: cute.Tensor,
    norm1_workspace: cute.Tensor,
    qkv_workspace: cute.Tensor,
    score_workspace: cute.Tensor,
    probability_workspace: cute.Tensor,
    context_workspace: cute.Tensor,
    residual_workspace: cute.Tensor,
    norm2_workspace: cute.Tensor,
    mlp_workspace: cute.Tensor,
    output: cute.Tensor,
):
    # n1 = layer_norm(hidden, ln1); q,k,v = split(qkv_linear(n1)) -> FP8 qkv
    ln1_qkv_kernel(
        hidden, ln1_weight, ln1_bias, qkv_weight, qkv_bias, qkv_workspace
    ).launch(grid=(TOKENS, 1, 1), block=(THREADS, 1, 1))

    # context = causal_softmax(q @ k.T / sqrt(64)) @ v -> FP8
    attention_kernel(qkv_workspace, context_workspace).launch(
        grid=(NUM_HEADS, TOKENS, 1), block=(THREADS, 1, 1)
    )

    # residual = hidden + out_linear(context)  (FP32)
    out_residual_kernel(
        context_workspace, out_weight, out_bias, hidden, residual_workspace
    ).launch(grid=(HIDDEN_SIZE // THREADS, TOKENS, 1), block=(THREADS, 1, 1))

    # n2 = layer_norm(residual, ln2); mlp = gelu(fc_linear(n2)) -> FP8
    ln2_fc_gelu_kernel(
        residual_workspace, ln2_weight, ln2_bias, fc_weight, fc_bias, mlp_workspace
    ).launch(grid=(MLP_SIZE // THREADS, TOKENS, 1), block=(THREADS, 1, 1))

    # output = residual + proj_linear(mlp)  (FP32)
    proj_residual_kernel(
        mlp_workspace, proj_weight, proj_bias, residual_workspace, output
    ).launch(grid=(HIDDEN_SIZE // THREADS, TOKENS, 1), block=(THREADS, 1, 1))


class ModelNew:
    forward = staticmethod(gpt2_transformer_block)
