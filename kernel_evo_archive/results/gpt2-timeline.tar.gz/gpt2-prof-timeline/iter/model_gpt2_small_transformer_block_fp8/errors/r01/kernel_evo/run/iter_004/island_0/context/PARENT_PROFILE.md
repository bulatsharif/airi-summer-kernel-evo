# Parent profile and optimization guidance

# B300 complete GPU timeline of your last candidate

- complete GPU-side trace: 519 activities; CPU/Python profiler records are intentionally omitted
- whole capture: span 20339.961 ms; active union 65.155 ms; idle holes 20274.806 ms (99.7%); largest hole 20011.934 ms
- that idle figure covers input generation, JIT compilation and the reference as well as your block, so it is not a measure of your kernels; the per-iteration section below is
- summed activity time: 65.155 ms; this may exceed active union when streams overlap
- source labels are hints: `candidate:<symbol>` is matched against this candidate's `@cute.kernel` definitions; other labels describe likely harness/runtime work
- candidate `@cute.kernel` symbols: `attention_kernel`, `fc_gelu_kernel`, `ln1_kernel`, `ln2_kernel`, `out_gemm_kernel`, `proj_gemm_kernel`, `qkv_gemm_kernel`
- observed candidate symbols: `attention_kernel`, `fc_gelu_kernel`, `ln1_kernel`, `ln2_kernel`, `out_gemm_kernel`, `proj_gemm_kernel`, `qkv_gemm_kernel`
- candidate symbols not observed in this trace: none

## One iteration of your block, launch by launch

Median of 55 timed iterations, 7 launches each. Microseconds from the start of the iteration.

- wall span 1176.899; kernels busy 1174.148; idle between your kernels 2.751 (0.2% of the span)
- largest single gap 1.280 immediately before `qkv_gemm_kernel`
- 44.288 elapses between one iteration and the next; that is host-side dispatch outside your block, excluded from the idle figure above, and fusing cannot remove it

| # | kernel | id | start | end | dur | idle before |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 1 | ln1_kernel | K24 | 0.000 | 3.104 | 3.104 | — |
| 2 | qkv_gemm_kernel | K25 | 4.384 | 163.105 | 158.721 | 1.280 |
| 3 | attention_kernel | K26 | 163.361 | 219.585 | 56.224 | 0.256 |
| 4 | out_gemm_kernel | K27 | 219.841 | 384.034 | 164.193 | 0.256 |
| 5 | ln2_kernel | K28 | 384.289 | 387.681 | 3.392 | 0.255 |
| 6 | fc_gelu_kernel | K29 | 387.969 | 552.034 | 164.065 | 0.288 |
| 7 | proj_gemm_kernel | K30 | 552.450 | 1176.899 | 624.449 | 0.416 |

## Hottest GPU kernels (legacy aggregate)

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_proj_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 34.403 | 55 | 52.8 |
| kernel_cutlass_out_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 9.054 | 55 | 13.9 |
| kernel_cutlass_fc_gelu_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmemal… | 9.026 | 55 | 13.8 |
| kernel_cutlass_qkv_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 8.743 | 55 | 13.4 |
| kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 3.103 | 55 | 4.8 |
| kernel_cutlass_ln2_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo7681_tensorptrf32gmemo… | 0.186 | 55 | 0.3 |
| kernel_cutlass_ln1_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo7681_tenso… | 0.176 | 55 | 0.3 |
| void sgemm_largek_lds64<true, false, 6, 3, 4, 5, 2, 66>(float*, float const*, float con… | 0.060 | 1 | 0.1 |
| cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 0.049 | 4 | 0.1 |
| void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 0.034 | 17 | 0.1 |

## Kernel legend

| id | source hint | kernel | calls | total us | launch |
| --- | --- | --- | ---: | ---: | --- |
| K1 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 1 | 2.400 | grid=384x1x1, block=256x1x1, smem=0, regs=56 |
| K2 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 6 | 11.936 | grid=3x1x1, block=256x1x1, smem=0, regs=56 |
| K3 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 6 | 10.369 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K4 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::CUDAFunctorOnSelf_add<flo… | 2 | 3.552 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K5 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 1 | 2.144 | grid=9x1x1, block=256x1x1, smem=0, regs=56 |
| K6 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 2 | 3.264 | grid=3x1x1, block=128x1x1, smem=0, regs=32 |
| K7 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 1 | 1.792 | grid=12x1x1, block=256x1x1, smem=0, regs=56 |
| K8 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 4 | 22.528 | grid=1184x1x1, block=256x1x1, smem=0, regs=56 |
| K9 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 7 | 11.551 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K10 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 4 | 7.456 | grid=256x1x1, block=128x1x1, smem=0, regs=20 |
| K11 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 1 | 2.656 | grid=1728x1x1, block=128x1x1, smem=0, regs=32 |
| K12 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 2 | 8.544 | grid=4608x1x1, block=128x1x1, smem=0, regs=20 |
| K13 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 1 | 2.016 | grid=576x1x1, block=128x1x1, smem=0, regs=32 |
| K14 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 2.560 | grid=1536x1x1, block=128x1x1, smem=0, regs=20 |
| K15 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 6.784 | grid=2304x1x1, block=128x1x1, smem=0, regs=32 |
| K16 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 5.025 | grid=6144x1x1, block=128x1x1, smem=0, regs=20 |
| K17 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::… | 3 | 3.807 | grid=96x1x1, block=128x1x1, smem=0, regs=16 |
| K18 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::… | 1 | 1.632 | grid=288x1x1, block=128x1x1, smem=0, regs=16 |
| K19 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 3.584 | grid=288x1x1, block=128x1x1, smem=0, regs=32 |
| K20 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 2.048 | grid=640x1x1, block=128x1x1, smem=0, regs=20 |
| K21 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::… | 1 | 1.632 | grid=384x1x1, block=128x1x1, smem=0, regs=16 |
| K22 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 3.551 | grid=384x1x1, block=128x1x1, smem=0, regs=32 |
| K23 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 2.048 | grid=768x1x1, block=128x1x1, smem=0, regs=20 |
| K24 | candidate:ln1_kernel | kernel_cutlass_ln1_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo7681_tenso… | 55 | 175.744 | grid=128x1x1, block=128x1x1, smem=1024, regs=32 |
| K25 | candidate:qkv_gemm_kernel | kernel_cutlass_qkv_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 55 | 8743.443 | grid=18x1x1, block=128x1x1, smem=65536, regs=255 |
| K26 | candidate:attention_kernel | kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 55 | 3102.952 | grid=12x128x1, block=128x1x1, smem=1024, regs=40 |
| K27 | candidate:out_gemm_kernel | kernel_cutlass_out_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 55 | 9054.426 | grid=6x1x1, block=128x1x1, smem=65536, regs=255 |
| K28 | candidate:ln2_kernel | kernel_cutlass_ln2_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo7681_tensorptrf32gmemo… | 55 | 186.085 | grid=128x1x1, block=128x1x1, smem=1024, regs=32 |
| K29 | candidate:fc_gelu_kernel | kernel_cutlass_fc_gelu_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmemal… | 55 | 9025.589 | grid=24x1x1, block=128x1x1, smem=65536, regs=255 |
| K30 | candidate:proj_gemm_kernel | kernel_cutlass_proj_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 55 | 34403.094 | grid=6x1x1, block=128x1x1, smem=65536, regs=255 |
| K31 | framework/validation | void at::native::unrolled_elementwise_kernel<at::native::direct_copy_kernel_cuda(at::Te… | 1 | 3.776 | grid=192x1x1, block=128x1x1, smem=0, regs=30 |
| K32 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 1 | 1.695 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K33 | framework/validation | void at::native::(anonymous namespace)::vectorized_layer_norm_kernel<float, float, fals… | 4 | 16.545 | grid=128x1x1, block=32x4x1, smem=24, regs=40 |
| K34 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::float8_copy_kernel_cuda(a… | 3 | 6.112 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K35 | framework/validation | nvjet_sm103_qqsss_64x32_128x16_2x1_2cta_v_bz_TNT | 1 | 3.200 | grid=144x1x1, block=256x1x1, smem=172552, regs=255 |
| K36 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 4.992 | grid=1152x1x1, block=128x1x1, smem=0, regs=20 |
| K37 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::float8_copy_kernel_cuda(a… | 1 | 1.824 | grid=288x1x1, block=128x1x1, smem=0, regs=32 |
| K38 | framework/validation | void at::native::unrolled_elementwise_kernel<at::native::direct_copy_kernel_cuda(at::Te… | 1 | 3.552 | grid=576x1x1, block=128x1x1, smem=0, regs=30 |
| K39 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 1 | 1.856 | grid=288x1x1, block=128x1x1, smem=0, regs=32 |
| K40 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 2 | 8.576 | grid=4x4x12, block=64x1x1, smem=13056, regs=72 |
| K41 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 3.520 | grid=192x1x1, block=128x1x1, smem=0, regs=32 |
| K42 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<bool>, std::a… | 1 | 1.600 | grid=8x1x1, block=128x1x1, smem=0, regs=16 |
| K43 | framework/validation | void at::native::triu_tril_kernel<bool, int, true, 8, false>(at::cuda::detail::TensorIn… | 1 | 2.304 | grid=16x1x1, block=128x1x1, smem=0, regs=30 |
| K44 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 4.608 | grid=768x1x1, block=128x1x1, smem=0, regs=20 |
| K45 | framework/validation | void (anonymous namespace)::softmax_warp_forward<float, float, float, 7, false, false>(… | 2 | 6.369 | grid=192x1x1, block=32x4x1, smem=0, regs=32 |
| K46 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_nnn_align1_bias_f32_relu | 2 | 10.336 | grid=2x4x12, block=64x1x1, smem=12672, regs=84 |
| K47 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 4.831 | grid=384x1x1, block=128x1x1, smem=0, regs=20 |
| K48 | framework/validation | nvjet_sm103_qqsss_64x16_128x16_2x4_2cta_h_bz_TNT | 2 | 7.134 | grid=96x1x1, block=256x1x1, smem=156168, regs=255 |
| K49 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 4 | 9.216 | grid=384x1x1, block=128x1x1, smem=0, regs=20 |
| K50 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::CUDAFunctor_add<float>, s… | 5 | 8.863 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K51 | framework/validation | nvjet_sm103_qqsss_48x64_128x16_2x2_2cta_h_bz_TNN | 1 | 3.488 | grid=128x1x1, block=256x1x1, smem=188944, regs=255 |
| K52 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 5.120 | grid=1536x1x1, block=128x1x1, smem=0, regs=20 |
| K53 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::GeluCUDAKernelImpl(at::Te… | 2 | 4.128 | grid=384x1x1, block=128x1x1, smem=0, regs=32 |
| K54 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::float8_copy_kernel_cuda(a… | 1 | 1.824 | grid=384x1x1, block=128x1x1, smem=0, regs=32 |
| K55 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 1 | 21.344 | grid=72x4x1, block=64x1x1, smem=13056, regs=72 |
| K56 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 1 | 19.457 | grid=24x4x1, block=64x1x1, smem=13056, regs=72 |
| K57 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_64x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 1 | 23.904 | grid=48x4x1, block=64x1x1, smem=19200, regs=146 |
| K58 | framework/validation | void scal_kernel<float, float, 1, true, 6, 5, 5, 3>(cublasTransposeParams<float>, float… | 1 | 1.664 | grid=12x4x1, block=256x1x1, smem=0, regs=24 |
| K59 | framework/validation | void sgemm_largek_lds64<true, false, 6, 3, 4, 5, 2, 66>(float*, float const*, float con… | 1 | 59.648 | grid=12x16x4, block=32x4x1, smem=4868, regs=32 |
| K60 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AbsFunctor<float>, std::a… | 2 | 3.552 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K61 | framework/validation | void at::native::reduce_kernel<512, 1, at::native::ReduceOp<float, at::native::func_wra… | 1 | 13.217 | grid=1x1x1, block=512x1x1, smem=2064, regs=30 |
| K62 | framework/validation | void at::native::(anonymous namespace)::indexSelectSmallIndex<float, long, unsigned int… | 2 | 9.120 | grid=6x1x1, block=128x1x1, smem=0, regs=28 |
| K63 | framework/validation | void at::native::(anonymous namespace)::indexSelectSmallIndex<float, long, unsigned int… | 2 | 8.288 | grid=1x1x1, block=7x1x1, smem=0, regs=28 |
| K64 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::CUDAFunctor_add<float>, s… | 1 | 1.792 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K65 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AbsFunctor<float>, std::a… | 1 | 1.792 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K66 | framework/validation | void at::native::reduce_kernel<512, 1, at::native::ReduceOp<float, at::native::func_wra… | 1 | 2.784 | grid=1x1x1, block=32x1x1, smem=16, regs=30 |
| K67 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 1 | 1.792 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K68 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BinaryFunctor<float, floa… | 1 | 1.855 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K69 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BinaryFunctor<bool, bool,… | 1 | 1.472 | grid=96x1x1, block=128x1x1, smem=0, regs=30 |
| K70 | framework/validation | void at::native::reduce_kernel<512, 1, at::native::ReduceOp<bool, at::native::func_wrap… | 1 | 12.544 | grid=1x1x1, block=512x1x1, smem=528, regs=28 |

## Ordered GPU activities

`gap before` is device-wide idle time since all earlier GPU activity ended; zero means overlap or no measurable hole.

| # | start ms | gap before us | duration us | lane | activity |
| ---: | ---: | ---: | ---: | --- | --- |
| 1 | 0.000 | 0.000 | 2.400 | d0/s7 | K1 |
| 2 | 0.078 | 75.616 | 1.792 | d0/s7 | K2 |
| 3 | 0.123 | 43.680 | 1.569 | d0/s7 | K3 |
| 4 | 0.159 | 34.240 | 1.952 | d0/s7 | K4 |
| 5 | 0.179 | 17.280 | 2.176 | d0/s7 | K2 |
| 6 | 0.191 | 9.824 | 1.984 | d0/s7 | K3 |
| 7 | 0.207 | 14.304 | 2.176 | d0/s7 | K2 |
| 8 | 0.218 | 8.672 | 1.600 | d0/s7 | K3 |
| 9 | 0.236 | 16.480 | 1.600 | d0/s7 | K4 |
| 10 | 0.251 | 13.855 | 1.824 | d0/s7 | K2 |
| 11 | 0.263 | 9.664 | 1.600 | d0/s7 | K3 |
| 12 | 0.278 | 13.600 | 2.144 | d0/s7 | K5 |
| 13 | 0.292 | 11.904 | 1.792 | d0/s7 | K6 |
| 14 | 0.308 | 13.856 | 2.144 | d0/s7 | K2 |
| 15 | 0.317 | 7.744 | 2.016 | d0/s7 | K3 |
| 16 | 0.333 | 13.408 | 1.792 | d0/s7 | K7 |
| 17 | 0.344 | 9.088 | 1.472 | d0/s7 | K6 |
| 18 | 0.358 | 13.184 | 1.824 | d0/s7 | K2 |
| 19 | 0.369 | 8.479 | 1.600 | d0/s7 | K3 |
| 20 | 0.388 | 17.696 | 5.920 | d0/s7 | K8 |
| 21 | 0.404 | 10.432 | 4.384 | d0/s7 | K8 |
| 22 | 0.420 | 11.200 | 6.080 | d0/s7 | K8 |
| 23 | 0.440 | 13.472 | 6.144 | d0/s7 | K8 |
| 24 | 0.480 | 34.785 | 1.663 | d0/s7 | K9 |
| 25 | 32.048 | 31565.839 | 1.952 | d0/s7 | K10 |
| 26 | 32.253 | 203.201 | 2.656 | d0/s7 | K11 |
| 27 | 57.710 | 25454.015 | 4.192 | d0/s7 | K12 |
| 28 | 57.903 | 188.672 | 2.016 | d0/s7 | K13 |
| 29 | 84.269 | 26363.874 | 2.560 | d0/s7 | K14 |
| 30 | 84.450 | 178.849 | 3.392 | d0/s7 | K15 |
| 31 | 109.554 | 25100.990 | 5.025 | d0/s7 | K16 |
| 32 | 109.712 | 152.448 | 3.392 | d0/s7 | K15 |
| 33 | 134.256 | 24540.476 | 4.352 | d0/s7 | K12 |
| 34 | 134.450 | 189.601 | 1.312 | d0/s7 | K17 |
| 35 | 134.509 | 58.112 | 1.408 | d0/s7 | K9 |
| 36 | 158.617 | 24107.003 | 1.888 | d0/s7 | K10 |
| 37 | 158.777 | 157.633 | 1.632 | d0/s7 | K18 |
| 38 | 158.852 | 73.408 | 1.792 | d0/s7 | K19 |
| 39 | 183.386 | 24531.901 | 2.048 | d0/s7 | K20 |
| 40 | 183.538 | 150.688 | 1.248 | d0/s7 | K17 |
| 41 | 183.599 | 59.168 | 1.408 | d0/s7 | K9 |
| 42 | 207.932 | 24331.613 | 1.728 | d0/s7 | K10 |
| 43 | 208.085 | 151.425 | 1.247 | d0/s7 | K17 |
| 44 | 208.144 | 57.569 | 1.760 | d0/s7 | K9 |
| 45 | 232.271 | 24125.021 | 1.888 | d0/s7 | K10 |
| 46 | 232.422 | 149.312 | 1.632 | d0/s7 | K21 |
| 47 | 232.481 | 57.089 | 1.855 | d0/s7 | K22 |
| 48 | 257.154 | 24671.550 | 2.048 | d0/s7 | K23 |
| 49 | 20269.090 | 20011933.562 | 5.087 | d0/s7 | K24 |
| 50 | 20269.106 | 11.201 | 171.456 | d0/s7 | K25 |
| 51 | 20269.278 | 0.256 | 56.128 | d0/s7 | K26 |
| 52 | 20269.334 | 0.256 | 178.497 | d0/s7 | K27 |
| 53 | 20269.513 | 0.256 | 4.512 | d0/s7 | K28 |
| 54 | 20269.517 | 0.256 | 183.456 | d0/s7 | K29 |
| 55 | 20269.701 | 0.384 | 676.482 | d0/s7 | K30 |
| 56 | 20270.378 | 0.256 | 3.104 | d0/s7 | K24 |
| 57 | 20270.381 | 0.256 | 158.784 | d0/s7 | K25 |
| 58 | 20270.540 | 0.256 | 56.385 | d0/s7 | K26 |
| 59 | 20270.597 | 0.255 | 164.289 | d0/s7 | K27 |
| 60 | 20270.762 | 0.256 | 3.392 | d0/s7 | K28 |
| 61 | 20270.765 | 0.256 | 163.872 | d0/s7 | K29 |
| 62 | 20270.930 | 0.416 | 624.546 | d0/s7 | K30 |
| 63 | 20271.554 | 0.256 | 3.232 | d0/s7 | K24 |
| 64 | 20271.558 | 0.256 | 158.688 | d0/s7 | K25 |
| 65 | 20271.717 | 0.256 | 56.416 | d0/s7 | K26 |
| 66 | 20271.773 | 0.257 | 164.576 | d0/s7 | K27 |
| 67 | 20271.938 | 0.288 | 3.328 | d0/s7 | K28 |
| 68 | 20271.942 | 0.256 | 163.936 | d0/s7 | K29 |
| 69 | 20272.106 | 0.416 | 624.546 | d0/s7 | K30 |
| 70 | 20272.731 | 0.256 | 3.200 | d0/s7 | K24 |
| 71 | 20272.735 | 0.256 | 158.784 | d0/s7 | K25 |
| 72 | 20272.894 | 0.256 | 56.544 | d0/s7 | K26 |
| 73 | 20272.950 | 0.257 | 164.128 | d0/s7 | K27 |
| 74 | 20273.115 | 0.256 | 3.360 | d0/s7 | K28 |
| 75 | 20273.118 | 0.256 | 163.584 | d0/s7 | K29 |
| 76 | 20273.282 | 0.416 | 624.802 | d0/s7 | K30 |
| 77 | 20273.907 | 0.256 | 3.200 | d0/s7 | K24 |
| 78 | 20273.911 | 0.256 | 158.720 | d0/s7 | K25 |
| 79 | 20274.070 | 0.256 | 56.480 | d0/s7 | K26 |
| 80 | 20274.127 | 0.256 | 164.353 | d0/s7 | K27 |
| 81 | 20274.291 | 0.256 | 3.360 | d0/s7 | K28 |
| 82 | 20274.295 | 0.256 | 163.808 | d0/s7 | K29 |
| 83 | 20274.459 | 0.416 | 624.130 | d0/s7 | K30 |
| 84 | 20275.227 | 144.320 | 3.200 | d0/s7 | K24 |
| 85 | 20275.232 | 1.760 | 158.816 | d0/s7 | K25 |
| 86 | 20275.392 | 0.257 | 56.480 | d0/s7 | K26 |
| 87 | 20275.448 | 0.256 | 164.576 | d0/s7 | K27 |
| 88 | 20275.613 | 0.255 | 3.328 | d0/s7 | K28 |
| 89 | 20275.617 | 0.256 | 163.648 | d0/s7 | K29 |
| 90 | 20275.781 | 0.417 | 624.225 | d0/s7 | K30 |
| 91 | 20276.470 | 65.280 | 3.105 | d0/s7 | K24 |
| 92 | 20276.474 | 0.415 | 158.785 | d0/s7 | K25 |
| 93 | 20276.633 | 0.256 | 56.448 | d0/s7 | K26 |
| 94 | 20276.690 | 0.288 | 164.225 | d0/s7 | K27 |
| 95 | 20276.854 | 0.255 | 3.425 | d0/s7 | K28 |
| 96 | 20276.858 | 0.255 | 163.521 | d0/s7 | K29 |
| 97 | 20277.022 | 0.416 | 624.513 | d0/s7 | K30 |
| 98 | 20277.692 | 46.081 | 3.103 | d0/s7 | K24 |
| 99 | 20277.696 | 0.897 | 158.688 | d0/s7 | K25 |
| 100 | 20277.855 | 0.256 | 56.288 | d0/s7 | K26 |
| 101 | 20277.912 | 0.288 | 164.257 | d0/s7 | K27 |
| 102 | 20278.076 | 0.255 | 3.393 | d0/s7 | K28 |
| 103 | 20278.080 | 0.287 | 163.873 | d0/s7 | K29 |
| 104 | 20278.244 | 0.448 | 624.513 | d0/s7 | K30 |
| 105 | 20278.913 | 44.257 | 3.103 | d0/s7 | K24 |
| 106 | 20278.917 | 1.280 | 159.105 | d0/s7 | K25 |
| 107 | 20279.077 | 0.256 | 56.288 | d0/s7 | K26 |
| 108 | 20279.133 | 0.288 | 164.417 | d0/s7 | K27 |
| 109 | 20279.298 | 0.255 | 3.393 | d0/s7 | K28 |
| 110 | 20279.302 | 0.287 | 163.809 | d0/s7 | K29 |
| 111 | 20279.466 | 0.416 | 625.314 | d0/s7 | K30 |
| 112 | 20280.136 | 45.216 | 3.104 | d0/s7 | K24 |
| 113 | 20280.140 | 0.768 | 158.656 | d0/s7 | K25 |
| 114 | 20280.299 | 0.256 | 56.384 | d0/s7 | K26 |
| 115 | 20280.356 | 0.288 | 164.193 | d0/s7 | K27 |
| 116 | 20280.520 | 0.256 | 3.392 | d0/s7 | K28 |
| 117 | 20280.524 | 0.256 | 163.872 | d0/s7 | K29 |
| 118 | 20280.688 | 0.416 | 624.386 | d0/s7 | K30 |
| 119 | 20281.357 | 44.160 | 3.200 | d0/s7 | K24 |
| 120 | 20281.362 | 1.472 | 158.720 | d0/s7 | K25 |
| 121 | 20281.521 | 0.256 | 56.448 | d0/s7 | K26 |
| 122 | 20281.577 | 0.257 | 164.320 | d0/s7 | K27 |
| 123 | 20281.742 | 0.256 | 3.328 | d0/s7 | K28 |
| 124 | 20281.745 | 0.288 | 163.840 | d0/s7 | K29 |
| 125 | 20281.910 | 0.448 | 624.834 | d0/s7 | K30 |
| 126 | 20282.579 | 44.288 | 3.200 | d0/s7 | K24 |
| 127 | 20282.583 | 0.896 | 158.720 | d0/s7 | K25 |
| 128 | 20282.742 | 0.256 | 56.320 | d0/s7 | K26 |
| 129 | 20282.798 | 0.289 | 164.224 | d0/s7 | K27 |
| 130 | 20282.963 | 0.256 | 3.328 | d0/s7 | K28 |
| 131 | 20282.967 | 0.256 | 163.520 | d0/s7 | K29 |
| 132 | 20283.130 | 0.416 | 624.354 | d0/s7 | K30 |
| 133 | 20283.801 | 46.464 | 3.168 | d0/s7 | K24 |
| 134 | 20283.806 | 1.440 | 158.528 | d0/s7 | K25 |
| 135 | 20283.965 | 0.257 | 56.447 | d0/s7 | K26 |
| 136 | 20284.021 | 0.257 | 164.128 | d0/s7 | K27 |
| 137 | 20284.186 | 0.256 | 3.360 | d0/s7 | K28 |
| 138 | 20284.189 | 0.256 | 163.968 | d0/s7 | K29 |
| 139 | 20284.354 | 0.417 | 624.098 | d0/s7 | K30 |
| 140 | 20285.023 | 45.216 | 3.200 | d0/s7 | K24 |
| 141 | 20285.028 | 1.248 | 158.753 | d0/s7 | K25 |
| 142 | 20285.187 | 0.255 | 56.513 | d0/s7 | K26 |
| 143 | 20285.243 | 0.256 | 164.640 | d0/s7 | K27 |
| 144 | 20285.408 | 0.256 | 3.328 | d0/s7 | K28 |
| 145 | 20285.412 | 0.256 | 163.873 | d0/s7 | K29 |
| 146 | 20285.576 | 0.448 | 624.705 | d0/s7 | K30 |
| 147 | 20286.245 | 43.712 | 3.136 | d0/s7 | K24 |
| 148 | 20286.249 | 0.864 | 158.784 | d0/s7 | K25 |
| 149 | 20286.408 | 0.289 | 56.512 | d0/s7 | K26 |
| 150 | 20286.464 | 0.288 | 164.512 | d0/s7 | K27 |
| 151 | 20286.629 | 0.288 | 3.392 | d0/s7 | K28 |
| 152 | 20286.633 | 0.256 | 163.617 | d0/s7 | K29 |
| 153 | 20286.797 | 0.416 | 624.033 | d0/s7 | K30 |
| 154 | 20287.466 | 44.864 | 3.136 | d0/s7 | K24 |
| 155 | 20287.470 | 1.152 | 158.753 | d0/s7 | K25 |
| 156 | 20287.629 | 0.256 | 56.480 | d0/s7 | K26 |
| 157 | 20287.686 | 0.256 | 164.320 | d0/s7 | K27 |
| 158 | 20287.850 | 0.288 | 3.392 | d0/s7 | K28 |
| 159 | 20287.854 | 0.256 | 163.809 | d0/s7 | K29 |
| 160 | 20288.018 | 0.416 | 624.769 | d0/s7 | K30 |
| 161 | 20288.689 | 45.728 | 3.104 | d0/s7 | K24 |
| 162 | 20288.693 | 1.153 | 158.688 | d0/s7 | K25 |
| 163 | 20288.852 | 0.256 | 56.288 | d0/s7 | K26 |
| 164 | 20288.909 | 0.256 | 164.544 | d0/s7 | K27 |
| 165 | 20289.073 | 0.257 | 3.360 | d0/s7 | K28 |
| 166 | 20289.077 | 0.255 | 163.745 | d0/s7 | K29 |
| 167 | 20289.241 | 0.416 | 624.449 | d0/s7 | K30 |
| 168 | 20289.909 | 43.489 | 3.104 | d0/s7 | K24 |
| 169 | 20289.914 | 1.631 | 158.689 | d0/s7 | K25 |
| 170 | 20290.073 | 0.256 | 56.224 | d0/s7 | K26 |
| 171 | 20290.129 | 0.288 | 164.352 | d0/s7 | K27 |
| 172 | 20290.294 | 0.256 | 3.392 | d0/s7 | K28 |
| 173 | 20290.298 | 0.257 | 163.872 | d0/s7 | K29 |
| 174 | 20290.462 | 0.416 | 624.641 | d0/s7 | K30 |
| 175 | 20291.131 | 44.577 | 3.232 | d0/s7 | K24 |
| 176 | 20291.136 | 1.600 | 158.720 | d0/s7 | K25 |
| 177 | 20291.295 | 0.256 | 56.448 | d0/s7 | K26 |
| 178 | 20291.352 | 0.256 | 164.385 | d0/s7 | K27 |
| 179 | 20291.516 | 0.256 | 3.360 | d0/s7 | K28 |
| 180 | 20291.520 | 0.256 | 163.840 | d0/s7 | K29 |
| 181 | 20291.684 | 0.448 | 624.322 | d0/s7 | K30 |
| 182 | 20292.351 | 42.240 | 3.200 | d0/s7 | K24 |
| 183 | 20292.355 | 0.992 | 158.720 | d0/s7 | K25 |
| 184 | 20292.514 | 0.256 | 56.416 | d0/s7 | K26 |
| 185 | 20292.570 | 0.256 | 164.417 | d0/s7 | K27 |
| 186 | 20292.735 | 0.256 | 3.360 | d0/s7 | K28 |
| 187 | 20292.739 | 0.256 | 163.712 | d0/s7 | K29 |
| 188 | 20292.903 | 0.416 | 624.674 | d0/s7 | K30 |
| 189 | 20293.570 | 42.816 | 3.200 | d0/s7 | K24 |
| 190 | 20293.575 | 1.184 | 158.560 | d0/s7 | K25 |
| 191 | 20293.734 | 0.256 | 56.416 | d0/s7 | K26 |
| 192 | 20293.790 | 0.256 | 164.193 | d0/s7 | K27 |
| 193 | 20293.955 | 0.256 | 3.328 | d0/s7 | K28 |
| 194 | 20293.958 | 0.256 | 163.776 | d0/s7 | K29 |
| 195 | 20294.122 | 0.416 | 624.802 | d0/s7 | K30 |
| 196 | 20294.794 | 46.656 | 3.200 | d0/s7 | K24 |
| 197 | 20294.799 | 1.472 | 158.720 | d0/s7 | K25 |
| 198 | 20294.958 | 0.255 | 56.481 | d0/s7 | K26 |
| 199 | 20295.014 | 0.255 | 164.353 | d0/s7 | K27 |
| 200 | 20295.179 | 0.256 | 3.328 | d0/s7 | K28 |
| 201 | 20295.183 | 0.256 | 163.456 | d0/s7 | K29 |
| 202 | 20295.346 | 0.416 | 624.706 | d0/s7 | K30 |
| 203 | 20296.015 | 44.224 | 3.104 | d0/s7 | K24 |
| 204 | 20296.020 | 1.664 | 158.784 | d0/s7 | K25 |
| 205 | 20296.179 | 0.257 | 56.672 | d0/s7 | K26 |
| 206 | 20296.236 | 0.255 | 164.705 | d0/s7 | K27 |
| 207 | 20296.401 | 0.256 | 3.392 | d0/s7 | K28 |
| 208 | 20296.405 | 0.288 | 163.616 | d0/s7 | K29 |
| 209 | 20296.569 | 0.416 | 624.226 | d0/s7 | K30 |
| 210 | 20297.237 | 43.776 | 3.136 | d0/s7 | K24 |
| 211 | 20297.241 | 1.312 | 158.848 | d0/s7 | K25 |
| 212 | 20297.400 | 0.257 | 56.416 | d0/s7 | K26 |
| 213 | 20297.457 | 0.256 | 164.448 | d0/s7 | K27 |
| 214 | 20297.622 | 0.288 | 3.392 | d0/s7 | K28 |
| 215 | 20297.625 | 0.256 | 163.681 | d0/s7 | K29 |
| 216 | 20297.789 | 0.416 | 624.353 | d0/s7 | K30 |
| 217 | 20298.457 | 43.264 | 3.104 | d0/s7 | K24 |
| 218 | 20298.462 | 1.504 | 158.753 | d0/s7 | K25 |
| 219 | 20298.621 | 0.255 | 56.289 | d0/s7 | K26 |
| 220 | 20298.677 | 0.256 | 164.288 | d0/s7 | K27 |
| 221 | 20298.842 | 0.256 | 3.392 | d0/s7 | K28 |
| 222 | 20298.845 | 0.256 | 163.745 | d0/s7 | K29 |
| 223 | 20299.010 | 0.415 | 624.258 | d0/s7 | K30 |
| 224 | 20299.678 | 44.257 | 3.103 | d0/s7 | K24 |
| 225 | 20299.682 | 1.217 | 158.720 | d0/s7 | K25 |
| 226 | 20299.841 | 0.256 | 56.448 | d0/s7 | K26 |
| 227 | 20299.898 | 0.256 | 164.320 | d0/s7 | K27 |
| 228 | 20300.063 | 0.288 | 3.392 | d0/s7 | K28 |
| 229 | 20300.066 | 0.256 | 163.713 | d0/s7 | K29 |
| 230 | 20300.230 | 0.416 | 625.249 | d0/s7 | K30 |
| 231 | 20300.986 | 130.273 | 3.232 | d0/s7 | K24 |
| 232 | 20300.991 | 1.600 | 158.784 | d0/s7 | K25 |
| 233 | 20301.150 | 0.256 | 56.448 | d0/s7 | K26 |
| 234 | 20301.207 | 0.256 | 164.384 | d0/s7 | K27 |
| 235 | 20301.371 | 0.257 | 3.328 | d0/s7 | K28 |
| 236 | 20301.375 | 0.255 | 163.905 | d0/s7 | K29 |
| 237 | 20301.539 | 0.416 | 624.353 | d0/s7 | K30 |
| 238 | 20302.209 | 45.473 | 3.200 | d0/s7 | K24 |
| 239 | 20302.213 | 0.512 | 158.656 | d0/s7 | K25 |
| 240 | 20302.372 | 0.256 | 56.352 | d0/s7 | K26 |
| 241 | 20302.428 | 0.288 | 164.417 | d0/s7 | K27 |
| 242 | 20302.593 | 0.256 | 3.328 | d0/s7 | K28 |
| 243 | 20302.596 | 0.256 | 163.456 | d0/s7 | K29 |
| 244 | 20302.760 | 0.416 | 624.930 | d0/s7 | K30 |
| 245 | 20303.430 | 45.120 | 3.200 | d0/s7 | K24 |
| 246 | 20303.434 | 0.704 | 158.624 | d0/s7 | K25 |
| 247 | 20303.593 | 0.256 | 56.416 | d0/s7 | K26 |
| 248 | 20303.650 | 0.257 | 164.128 | d0/s7 | K27 |
| 249 | 20303.814 | 0.256 | 3.360 | d0/s7 | K28 |
| 250 | 20303.818 | 0.256 | 163.808 | d0/s7 | K29 |
| 251 | 20303.982 | 0.416 | 624.738 | d0/s7 | K30 |
| 252 | 20304.650 | 43.520 | 3.200 | d0/s7 | K24 |
| 253 | 20304.655 | 1.152 | 158.976 | d0/s7 | K25 |
| 254 | 20304.814 | 0.256 | 56.480 | d0/s7 | K26 |
| 255 | 20304.871 | 0.257 | 164.544 | d0/s7 | K27 |
| 256 | 20305.035 | 0.288 | 3.328 | d0/s7 | K28 |
| 257 | 20305.039 | 0.256 | 163.872 | d0/s7 | K29 |
| 258 | 20305.203 | 0.416 | 624.226 | d0/s7 | K30 |
| 259 | 20305.870 | 42.048 | 3.136 | d0/s7 | K24 |
| 260 | 20305.874 | 0.928 | 158.752 | d0/s7 | K25 |
| 261 | 20306.033 | 0.257 | 56.544 | d0/s7 | K26 |
| 262 | 20306.089 | 0.256 | 164.352 | d0/s7 | K27 |
| 263 | 20306.254 | 0.256 | 3.392 | d0/s7 | K28 |
| 264 | 20306.258 | 0.288 | 163.360 | d0/s7 | K29 |
| 265 | 20306.422 | 0.417 | 624.577 | d0/s7 | K30 |
| 266 | 20307.089 | 43.167 | 3.072 | d0/s7 | K24 |
| 267 | 20307.093 | 0.641 | 158.657 | d0/s7 | K25 |
| 268 | 20307.252 | 0.254 | 56.513 | d0/s7 | K26 |
| 269 | 20307.309 | 0.256 | 164.576 | d0/s7 | K27 |
| 270 | 20307.474 | 0.256 | 3.424 | d0/s7 | K28 |
| 271 | 20307.477 | 0.256 | 163.873 | d0/s7 | K29 |
| 272 | 20307.642 | 0.415 | 624.834 | d0/s7 | K30 |
| 273 | 20308.310 | 43.648 | 3.104 | d0/s7 | K24 |
| 274 | 20308.314 | 1.120 | 158.689 | d0/s7 | K25 |
| 275 | 20308.473 | 0.256 | 56.096 | d0/s7 | K26 |
| 276 | 20308.530 | 0.256 | 164.352 | d0/s7 | K27 |
| 277 | 20308.694 | 0.256 | 3.392 | d0/s7 | K28 |
| 278 | 20308.698 | 0.256 | 163.744 | d0/s7 | K29 |
| 279 | 20308.862 | 0.417 | 624.833 | d0/s7 | K30 |
| 280 | 20309.531 | 44.288 | 3.104 | d0/s7 | K24 |
| 281 | 20309.535 | 1.280 | 158.721 | d0/s7 | K25 |
| 282 | 20309.694 | 0.256 | 56.224 | d0/s7 | K26 |
| 283 | 20309.751 | 0.256 | 164.193 | d0/s7 | K27 |
| 284 | 20309.915 | 0.255 | 3.392 | d0/s7 | K28 |
| 285 | 20309.919 | 0.288 | 164.065 | d0/s7 | K29 |
| 286 | 20310.083 | 0.416 | 624.449 | d0/s7 | K30 |
| 287 | 20310.751 | 43.553 | 3.231 | d0/s7 | K24 |
| 288 | 20310.756 | 1.664 | 159.105 | d0/s7 | K25 |
| 289 | 20310.916 | 0.256 | 56.320 | d0/s7 | K26 |
| 290 | 20310.972 | 0.256 | 164.384 | d0/s7 | K27 |
| 291 | 20311.137 | 0.290 | 3.327 | d0/s7 | K28 |
| 292 | 20311.141 | 0.256 | 163.905 | d0/s7 | K29 |
| 293 | 20311.305 | 0.416 | 624.705 | d0/s7 | K30 |
| 294 | 20311.974 | 44.192 | 3.233 | d0/s7 | K24 |
| 295 | 20311.978 | 0.895 | 158.593 | d0/s7 | K25 |
| 296 | 20312.137 | 0.256 | 56.416 | d0/s7 | K26 |
| 297 | 20312.193 | 0.256 | 164.128 | d0/s7 | K27 |
| 298 | 20312.358 | 0.288 | 3.329 | d0/s7 | K28 |
| 299 | 20312.361 | 0.256 | 163.584 | d0/s7 | K29 |
| 300 | 20312.525 | 0.416 | 624.994 | d0/s7 | K30 |
| 301 | 20313.193 | 42.816 | 3.200 | d0/s7 | K24 |
| 302 | 20313.197 | 0.960 | 158.592 | d0/s7 | K25 |
| 303 | 20313.356 | 0.256 | 56.544 | d0/s7 | K26 |
| 304 | 20313.413 | 0.288 | 164.097 | d0/s7 | K27 |
| 305 | 20313.577 | 0.256 | 3.328 | d0/s7 | K28 |
| 306 | 20313.581 | 0.288 | 163.744 | d0/s7 | K29 |
| 307 | 20313.745 | 0.416 | 624.482 | d0/s7 | K30 |
| 308 | 20314.413 | 43.456 | 3.200 | d0/s7 | K24 |
| 309 | 20314.417 | 1.023 | 158.656 | d0/s7 | K25 |
| 310 | 20314.576 | 0.289 | 56.384 | d0/s7 | K26 |
| 311 | 20314.633 | 0.256 | 164.481 | d0/s7 | K27 |
| 312 | 20314.798 | 0.256 | 3.328 | d0/s7 | K28 |
| 313 | 20314.801 | 0.288 | 163.680 | d0/s7 | K29 |
| 314 | 20314.965 | 0.416 | 624.482 | d0/s7 | K30 |
| 315 | 20315.635 | 44.896 | 3.136 | d0/s7 | K24 |
| 316 | 20315.639 | 1.056 | 159.104 | d0/s7 | K25 |
| 317 | 20315.798 | 0.256 | 56.448 | d0/s7 | K26 |
| 318 | 20315.855 | 0.255 | 164.385 | d0/s7 | K27 |
| 319 | 20316.020 | 0.289 | 3.392 | d0/s7 | K28 |
| 320 | 20316.023 | 0.256 | 163.712 | d0/s7 | K29 |
| 321 | 20316.188 | 0.416 | 624.514 | d0/s7 | K30 |
| 322 | 20316.858 | 45.856 | 3.104 | d0/s7 | K24 |
| 323 | 20316.861 | 0.256 | 158.720 | d0/s7 | K25 |
| 324 | 20317.020 | 0.256 | 56.448 | d0/s7 | K26 |
| 325 | 20317.077 | 0.257 | 164.448 | d0/s7 | K27 |
| 326 | 20317.242 | 0.256 | 3.424 | d0/s7 | K28 |
| 327 | 20317.245 | 0.256 | 163.841 | d0/s7 | K29 |
| 328 | 20317.410 | 0.415 | 624.290 | d0/s7 | K30 |
| 329 | 20318.077 | 43.392 | 3.104 | d0/s7 | K24 |
| 330 | 20318.081 | 0.672 | 158.913 | d0/s7 | K25 |
| 331 | 20318.240 | 0.288 | 56.192 | d0/s7 | K26 |
| 332 | 20318.297 | 0.255 | 164.513 | d0/s7 | K27 |
| 333 | 20318.461 | 0.255 | 3.392 | d0/s7 | K28 |
| 334 | 20318.465 | 0.288 | 163.744 | d0/s7 | K29 |
| 335 | 20318.629 | 0.417 | 624.961 | d0/s7 | K30 |
| 336 | 20319.297 | 43.232 | 3.104 | d0/s7 | K24 |
| 337 | 20319.302 | 1.120 | 158.656 | d0/s7 | K25 |
| 338 | 20319.461 | 0.257 | 56.416 | d0/s7 | K26 |
| 339 | 20319.517 | 0.256 | 164.480 | d0/s7 | K27 |
| 340 | 20319.682 | 0.256 | 3.360 | d0/s7 | K28 |
| 341 | 20319.686 | 0.256 | 163.904 | d0/s7 | K29 |
| 342 | 20319.850 | 0.417 | 624.577 | d0/s7 | K30 |
| 343 | 20320.517 | 42.464 | 3.232 | d0/s7 | K24 |
| 344 | 20320.521 | 1.120 | 158.881 | d0/s7 | K25 |
| 345 | 20320.680 | 0.255 | 56.417 | d0/s7 | K26 |
| 346 | 20320.737 | 0.256 | 164.192 | d0/s7 | K27 |
| 347 | 20320.902 | 0.256 | 3.328 | d0/s7 | K28 |
| 348 | 20320.905 | 0.256 | 163.937 | d0/s7 | K29 |
| 349 | 20321.070 | 0.448 | 624.609 | d0/s7 | K30 |
| 350 | 20321.743 | 48.896 | 3.232 | d0/s7 | K24 |
| 351 | 20321.747 | 1.088 | 158.689 | d0/s7 | K25 |
| 352 | 20321.906 | 0.256 | 56.480 | d0/s7 | K26 |
| 353 | 20321.963 | 0.256 | 164.224 | d0/s7 | K27 |
| 354 | 20322.128 | 0.256 | 3.360 | d0/s7 | K28 |
| 355 | 20322.131 | 0.256 | 163.617 | d0/s7 | K29 |
| 356 | 20322.295 | 0.416 | 624.770 | d0/s7 | K30 |
| 357 | 20322.963 | 43.455 | 3.200 | d0/s7 | K24 |
| 358 | 20322.968 | 1.440 | 158.497 | d0/s7 | K25 |
| 359 | 20323.127 | 0.256 | 56.416 | d0/s7 | K26 |
| 360 | 20323.184 | 0.288 | 164.225 | d0/s7 | K27 |
| 361 | 20323.348 | 0.255 | 3.360 | d0/s7 | K28 |
| 362 | 20323.352 | 0.257 | 163.680 | d0/s7 | K29 |
| 363 | 20323.516 | 0.448 | 624.609 | d0/s7 | K30 |
| 364 | 20324.183 | 43.072 | 3.233 | d0/s7 | K24 |
| 365 | 20324.188 | 1.216 | 158.752 | d0/s7 | K25 |
| 366 | 20324.347 | 0.256 | 56.416 | d0/s7 | K26 |
| 367 | 20324.404 | 0.256 | 164.577 | d0/s7 | K27 |
| 368 | 20324.568 | 0.288 | 3.328 | d0/s7 | K28 |
| 369 | 20324.572 | 0.255 | 163.553 | d0/s7 | K29 |
| 370 | 20324.736 | 0.416 | 624.225 | d0/s7 | K30 |
| 371 | 20325.406 | 45.792 | 3.105 | d0/s7 | K24 |
| 372 | 20325.410 | 0.928 | 158.720 | d0/s7 | K25 |
| 373 | 20325.569 | 0.256 | 56.576 | d0/s7 | K26 |
| 374 | 20325.626 | 0.256 | 164.481 | d0/s7 | K27 |
| 375 | 20325.791 | 0.255 | 3.393 | d0/s7 | K28 |
| 376 | 20325.794 | 0.256 | 163.488 | d0/s7 | K29 |
| 377 | 20325.958 | 0.417 | 624.450 | d0/s7 | K30 |
| 378 | 20326.625 | 42.271 | 3.104 | d0/s7 | K24 |
| 379 | 20326.629 | 0.800 | 158.656 | d0/s7 | K25 |
| 380 | 20326.788 | 0.256 | 56.640 | d0/s7 | K26 |
| 381 | 20326.845 | 0.256 | 164.577 | d0/s7 | K27 |
| 382 | 20327.009 | 0.288 | 3.360 | d0/s7 | K28 |
| 383 | 20327.013 | 0.256 | 163.776 | d0/s7 | K29 |
| 384 | 20327.177 | 0.448 | 624.034 | d0/s7 | K30 |
| 385 | 20327.844 | 43.008 | 3.072 | d0/s7 | K24 |
| 386 | 20327.848 | 0.896 | 158.784 | d0/s7 | K25 |
| 387 | 20328.007 | 0.256 | 56.385 | d0/s7 | K26 |
| 388 | 20328.064 | 0.255 | 164.353 | d0/s7 | K27 |
| 389 | 20328.229 | 0.256 | 3.392 | d0/s7 | K28 |
| 390 | 20328.232 | 0.288 | 163.680 | d0/s7 | K29 |
| 391 | 20328.396 | 0.448 | 625.026 | d0/s7 | K30 |
| 392 | 20329.065 | 43.457 | 3.136 | d0/s7 | K24 |
| 393 | 20329.069 | 0.928 | 158.721 | d0/s7 | K25 |
| 394 | 20329.228 | 0.255 | 56.352 | d0/s7 | K26 |
| 395 | 20329.285 | 0.288 | 164.225 | d0/s7 | K27 |
| 396 | 20329.449 | 0.256 | 3.392 | d0/s7 | K28 |
| 397 | 20329.453 | 0.256 | 163.840 | d0/s7 | K29 |
| 398 | 20329.617 | 0.384 | 624.674 | d0/s7 | K30 |
| 399 | 20330.285 | 43.840 | 3.200 | d0/s7 | K24 |
| 400 | 20330.290 | 1.088 | 158.785 | d0/s7 | K25 |
| 401 | 20330.449 | 0.255 | 56.545 | d0/s7 | K26 |
| 402 | 20330.506 | 0.255 | 164.289 | d0/s7 | K27 |
| 403 | 20330.670 | 0.256 | 3.328 | d0/s7 | K28 |
| 404 | 20330.674 | 0.256 | 164.096 | d0/s7 | K29 |
| 405 | 20330.838 | 0.385 | 624.865 | d0/s7 | K30 |
| 406 | 20331.506 | 42.848 | 3.200 | d0/s7 | K24 |
| 407 | 20331.510 | 1.056 | 158.625 | d0/s7 | K25 |
| 408 | 20331.669 | 0.287 | 56.353 | d0/s7 | K26 |
| 409 | 20331.726 | 0.256 | 164.288 | d0/s7 | K27 |
| 410 | 20331.890 | 0.288 | 3.328 | d0/s7 | K28 |
| 411 | 20331.894 | 0.256 | 163.681 | d0/s7 | K29 |
| 412 | 20332.058 | 0.415 | 624.514 | d0/s7 | K30 |
| 413 | 20332.725 | 42.336 | 3.168 | d0/s7 | K24 |
| 414 | 20332.729 | 1.024 | 158.625 | d0/s7 | K25 |
| 415 | 20332.888 | 0.256 | 56.480 | d0/s7 | K26 |
| 416 | 20332.945 | 0.256 | 164.320 | d0/s7 | K27 |
| 417 | 20333.109 | 0.256 | 3.328 | d0/s7 | K28 |
| 418 | 20333.113 | 0.288 | 163.809 | d0/s7 | K29 |
| 419 | 20333.277 | 0.416 | 623.905 | d0/s7 | K30 |
| 420 | 20333.945 | 44.256 | 3.200 | d0/s7 | K24 |
| 421 | 20333.950 | 1.313 | 158.880 | d0/s7 | K25 |
| 422 | 20334.109 | 0.256 | 56.544 | d0/s7 | K26 |
| 423 | 20334.166 | 0.256 | 164.641 | d0/s7 | K27 |
| 424 | 20334.330 | 0.255 | 3.328 | d0/s7 | K28 |
| 425 | 20334.334 | 0.257 | 163.520 | d0/s7 | K29 |
| 426 | 20334.498 | 0.416 | 624.993 | d0/s7 | K30 |
| 427 | 20335.169 | 46.432 | 3.137 | d0/s7 | K24 |
| 428 | 20335.174 | 1.568 | 158.688 | d0/s7 | K25 |
| 429 | 20335.333 | 0.256 | 56.448 | d0/s7 | K26 |
| 430 | 20335.390 | 0.255 | 164.512 | d0/s7 | K27 |
| 431 | 20335.555 | 0.288 | 3.329 | d0/s7 | K28 |
| 432 | 20335.558 | 0.255 | 163.553 | d0/s7 | K29 |
| 433 | 20335.722 | 0.416 | 624.545 | d0/s7 | K30 |
| 434 | 20336.651 | 303.873 | 3.776 | d0/s7 | K31 |
| 435 | 20336.739 | 84.673 | 1.695 | d0/s7 | K32 |
| 436 | 20336.855 | 114.241 | 4.064 | d0/s7 | K33 |
| 437 | 20336.916 | 57.024 | 1.760 | d0/s7 | K9 |
| 438 | 20336.956 | 38.400 | 2.016 | d0/s7 | K34 |
| 439 | 20337.037 | 78.592 | 1.568 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 440 | 20337.084 | 45.920 | 0.704 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 441 | 20337.302 | 216.961 | 3.200 | d0/s7 | K35 |
| 442 | 20337.363 | 57.888 | 2.560 | d0/s7 | K36 |
| 443 | 20337.383 | 17.408 | 1.792 | d0/s7 | K19 |
| 444 | 20337.402 | 17.152 | 1.824 | d0/s7 | K37 |
| 445 | 20337.419 | 14.848 | 3.552 | d0/s7 | K38 |
| 446 | 20337.434 | 11.904 | 1.856 | d0/s7 | K39 |
| 447 | 20337.697 | 260.641 | 4.544 | d0/s7 | K40 |
| 448 | 20337.734 | 32.544 | 1.888 | d0/s7 | K41 |
| 449 | 20337.805 | 69.919 | 1.600 | d0/s7 | K42 |
| 450 | 20337.853 | 46.368 | 2.304 | d0/s7 | K43 |
| 451 | 20337.921 | 65.025 | 1.728 | d0/s7 | Memcpy DtoD (Device -> Device) (786432 B) |
| 452 | 20337.958 | 35.327 | 2.400 | d0/s7 | K44 |
| 453 | 20337.993 | 32.480 | 3.105 | d0/s7 | K45 |
| 454 | 20338.075 | 79.520 | 5.216 | d0/s7 | K46 |
| 455 | 20338.111 | 30.081 | 2.464 | d0/s7 | K47 |
| 456 | 20338.135 | 22.048 | 1.792 | d0/s7 | K9 |
| 457 | 20338.154 | 16.960 | 2.048 | d0/s7 | K34 |
| 458 | 20338.185 | 29.056 | 1.760 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 459 | 20338.222 | 34.784 | 1.952 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 460 | 20338.315 | 91.905 | 2.943 | d0/s7 | K48 |
| 461 | 20338.338 | 20.032 | 2.337 | d0/s7 | K49 |
| 462 | 20338.360 | 19.808 | 1.696 | d0/s7 | K50 |
| 463 | 20338.399 | 37.249 | 4.064 | d0/s7 | K33 |
| 464 | 20338.418 | 14.912 | 1.760 | d0/s7 | K9 |
| 465 | 20338.434 | 14.145 | 2.048 | d0/s7 | K34 |
| 466 | 20338.453 | 16.576 | 1.568 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 467 | 20338.482 | 27.392 | 1.568 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 468 | 20338.543 | 59.264 | 3.488 | d0/s7 | K51 |
| 469 | 20338.557 | 11.072 | 2.560 | d0/s7 | K52 |
| 470 | 20338.593 | 33.024 | 2.016 | d0/s7 | K53 |
| 471 | 20338.607 | 11.808 | 1.696 | d0/s7 | K22 |
| 472 | 20338.621 | 12.928 | 1.824 | d0/s7 | K54 |
| 473 | 20338.639 | 16.256 | 1.728 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 474 | 20338.668 | 27.137 | 1.760 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 475 | 20338.715 | 45.472 | 4.191 | d0/s7 | K48 |
| 476 | 20338.730 | 10.017 | 2.335 | d0/s7 | K49 |
| 477 | 20338.742 | 10.177 | 1.823 | d0/s7 | K50 |
| 478 | 20338.765 | 20.832 | 4.417 | d0/s7 | K33 |
| 479 | 20338.838 | 68.480 | 21.344 | d0/s7 | K55 |
| 480 | 20338.859 | 0.256 | 2.432 | d0/s7 | K36 |
| 481 | 20338.942 | 79.968 | 4.032 | d0/s7 | K40 |
| 482 | 20338.967 | 21.504 | 1.632 | d0/s7 | K41 |
| 483 | 20339.003 | 34.112 | 1.728 | d0/s7 | Memcpy DtoD (Device -> Device) (786432 B) |
| 484 | 20339.021 | 16.416 | 2.208 | d0/s7 | K44 |
| 485 | 20339.042 | 18.656 | 3.264 | d0/s7 | K45 |
| 486 | 20339.091 | 45.536 | 5.120 | d0/s7 | K46 |
| 487 | 20339.115 | 18.625 | 2.367 | d0/s7 | K47 |
| 488 | 20339.151 | 33.600 | 19.457 | d0/s7 | K56 |
| 489 | 20339.170 | 0.256 | 1.664 | d0/s7 | K50 |
| 490 | 20339.178 | 5.568 | 2.272 | d0/s7 | K49 |
| 491 | 20339.201 | 21.408 | 4.000 | d0/s7 | K33 |
| 492 | 20339.239 | 33.568 | 23.904 | d0/s7 | K57 |
| 493 | 20339.263 | 0.256 | 2.560 | d0/s7 | K52 |
| 494 | 20339.266 | 0.704 | 2.112 | d0/s7 | K53 |
| 495 | 20339.313 | 44.384 | 0.928 | d0/s7 | Memset (Device) (1536 B) |
| 496 | 20339.326 | 12.384 | 1.664 | d0/s7 | K58 |
| 497 | 20339.338 | 9.952 | 59.648 | d0/s7 | K59 |
| 498 | 20339.398 | 0.256 | 1.728 | d0/s7 | K50 |
| 499 | 20339.399 | 0.224 | 2.272 | d0/s7 | K49 |
| 500 | 20339.402 | 0.224 | 1.952 | d0/s7 | K50 |
| 501 | 20339.433 | 28.768 | 1.792 | d0/s7 | K60 |
| 502 | 20339.470 | 35.648 | 13.217 | d0/s7 | K61 |
| 503 | 20339.516 | 32.992 | 4.672 | d0/s7 | Memcpy DtoH (Device -> Pinned) (4 B) |
| 504 | 20339.570 | 48.895 | 1.600 | d0/s7 | Memcpy HtoD (Pageable -> Device) (56 B) |
| 505 | 20339.604 | 32.417 | 0.704 | d0/s7 | Memcpy HtoD (Pageable -> Device) (48 B) |
| 506 | 20339.659 | 54.496 | 4.576 | d0/s7 | K62 |
| 507 | 20339.677 | 13.408 | 4.448 | d0/s7 | K63 |
| 508 | 20339.693 | 10.976 | 4.544 | d0/s7 | K62 |
| 509 | 20339.706 | 8.896 | 3.840 | d0/s7 | K63 |
| 510 | 20339.719 | 8.800 | 1.792 | d0/s7 | K64 |
| 511 | 20339.733 | 12.704 | 1.792 | d0/s7 | K65 |
| 512 | 20339.750 | 15.424 | 2.784 | d0/s7 | K66 |
| 513 | 20339.762 | 8.992 | 3.840 | d0/s7 | Memcpy DtoH (Device -> Pinned) (4 B) |
| 514 | 20339.811 | 44.736 | 1.760 | d0/s7 | K60 |
| 515 | 20339.841 | 29.024 | 1.792 | d0/s7 | K67 |
| 516 | 20339.865 | 21.473 | 1.855 | d0/s7 | K68 |
| 517 | 20339.886 | 19.585 | 1.472 | d0/s7 | K69 |
| 518 | 20339.941 | 53.760 | 12.544 | d0/s7 | K70 |
| 519 | 20339.958 | 3.968 | 2.848 | d0/s7 | Memcpy DtoH (Device -> Pinned) (1 B) |
