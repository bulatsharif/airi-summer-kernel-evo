# B300 complete GPU timeline of your last candidate

- complete GPU-side trace: 629 activities; CPU/Python profiler records are intentionally omitted
- whole capture: span 1094.723 ms; active union 197.089 ms; idle holes 897.634 ms (82.0%); largest hole 555.894 ms
- that idle figure covers input generation, JIT compilation and the reference as well as your block, so it is not a measure of your kernels; the per-iteration section below is
- summed activity time: 197.089 ms; this may exceed active union when streams overlap
- source labels are hints: `candidate:<symbol>` is matched against this candidate's `@cute.kernel` definitions; other labels describe likely harness/runtime work
- candidate `@cute.kernel` symbols: `attention_context_kernel`, `attention_projection_kernel`, `attention_score_kernel`, `causal_softmax_kernel`, `layer_norm_fp32_kernel`, `layer_norm_fp8_kernel`, `mlp_fc_gelu_kernel`, `mlp_projection_kernel`, `qkv_projection_kernel`
- observed candidate symbols: `attention_context_kernel`, `attention_projection_kernel`, `attention_score_kernel`, `causal_softmax_kernel`, `layer_norm_fp32_kernel`, `layer_norm_fp8_kernel`, `mlp_fc_gelu_kernel`, `mlp_projection_kernel`, `qkv_projection_kernel`
- candidate symbols not observed in this trace: none

## One iteration of your block, launch by launch

Median of 55 timed iterations, 9 launches each. Microseconds from the start of the iteration.

- wall span 3577.097; kernels busy 3574.570; idle between your kernels 2.527 (0.1% of the span)
- largest single gap 0.768 immediately before `qkv_projection_kernel`
- 59.872 elapses between one iteration and the next; that is host-side dispatch outside your block, excluded from the idle figure above, and fusing cannot remove it

| # | kernel | id | start | end | dur | idle before |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 1 | layer_norm_fp8_kernel | K24 | 0.000 | 6.464 | 6.464 | — |
| 2 | qkv_projection_kernel | K25 | 7.232 | 837.250 | 830.018 | 0.768 |
| 3 | attention_score_kernel | K26 | 837.506 | 877.186 | 39.680 | 0.256 |
| 4 | causal_softmax_kernel | K27 | 877.442 | 904.707 | 27.265 | 0.256 |
| 5 | attention_context_kernel | K28 | 904.962 | 913.955 | 8.993 | 0.255 |
| 6 | attention_projection_kernel | K29 | 914.179 | 1228.259 | 314.080 | 0.224 |
| 7 | layer_norm_fp32_kernel | K30 | 1228.515 | 1234.755 | 6.240 | 0.256 |
| 8 | mlp_fc_gelu_kernel | K31 | 1235.011 | 2323.622 | 1088.611 | 0.256 |
| 9 | mlp_projection_kernel | K32 | 2323.878 | 3577.097 | 1253.219 | 0.256 |

## Hottest GPU kernels (legacy aggregate)

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_mlp_projection_kernel_tensorptrf32gmemoi641_tensorptrf8E4M3FNgmemalign16… | 68.938 | 55 | 35.0 |
| kernel_cutlass_mlp_fc_gelu_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgm… | 59.874 | 55 | 30.4 |
| kernel_cutlass_qkv_projection_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3F… | 45.666 | 55 | 23.2 |
| kernel_cutlass_attention_projection_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf… | 17.278 | 55 | 8.8 |
| kernel_cutlass_attention_score_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gme… | 2.186 | 55 | 1.1 |
| kernel_cutlass_causal_softmax_kernel_tensorptrf32gmemoi641_tensorptrf32gmemoi641_3 | 1.487 | 55 | 0.8 |
| kernel_cutlass_attention_context_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32g… | 0.477 | 55 | 0.2 |
| kernel_cutlass_layer_norm_fp8_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmem… | 0.365 | 55 | 0.2 |
| kernel_cutlass_layer_norm_fp32_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo7681_tenso… | 0.354 | 55 | 0.2 |
| void sgemm_largek_lds64<true, false, 6, 3, 4, 5, 2, 66>(float*, float const*, float con… | 0.061 | 1 | 0.0 |

## Kernel legend

| id | source hint | kernel | calls | total us | launch |
| --- | --- | --- | ---: | ---: | --- |
| K1 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 1 | 2.528 | grid=384x1x1, block=256x1x1, smem=0, regs=56 |
| K2 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 6 | 11.777 | grid=3x1x1, block=256x1x1, smem=0, regs=56 |
| K3 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 6 | 11.199 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K4 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::CUDAFunctorOnSelf_add<flo… | 2 | 3.585 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K5 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 1 | 1.792 | grid=9x1x1, block=256x1x1, smem=0, regs=56 |
| K6 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 2 | 3.392 | grid=3x1x1, block=128x1x1, smem=0, regs=32 |
| K7 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 1 | 2.144 | grid=12x1x1, block=256x1x1, smem=0, regs=56 |
| K8 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 4 | 21.792 | grid=1184x1x1, block=256x1x1, smem=0, regs=56 |
| K9 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 7 | 11.999 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K10 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 4 | 7.296 | grid=256x1x1, block=128x1x1, smem=0, regs=20 |
| K11 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 1 | 2.625 | grid=1728x1x1, block=128x1x1, smem=0, regs=32 |
| K12 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 2 | 8.607 | grid=4608x1x1, block=128x1x1, smem=0, regs=20 |
| K13 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 1 | 1.824 | grid=576x1x1, block=128x1x1, smem=0, regs=32 |
| K14 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 2.464 | grid=1536x1x1, block=128x1x1, smem=0, regs=20 |
| K15 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 6.496 | grid=2304x1x1, block=128x1x1, smem=0, regs=32 |
| K16 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 5.087 | grid=6144x1x1, block=128x1x1, smem=0, regs=20 |
| K17 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::… | 3 | 4.832 | grid=96x1x1, block=128x1x1, smem=0, regs=16 |
| K18 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::… | 1 | 1.408 | grid=288x1x1, block=128x1x1, smem=0, regs=16 |
| K19 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 3.264 | grid=288x1x1, block=128x1x1, smem=0, regs=32 |
| K20 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 1.953 | grid=640x1x1, block=128x1x1, smem=0, regs=20 |
| K21 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::… | 1 | 1.376 | grid=384x1x1, block=128x1x1, smem=0, regs=16 |
| K22 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 3.200 | grid=384x1x1, block=128x1x1, smem=0, regs=32 |
| K23 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 2.144 | grid=768x1x1, block=128x1x1, smem=0, regs=20 |
| K24 | candidate:layer_norm_fp8_kernel | kernel_cutlass_layer_norm_fp8_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmem… | 55 | 364.579 | grid=128x1x1, block=32x1x1, smem=0, regs=36 |
| K25 | candidate:qkv_projection_kernel | kernel_cutlass_qkv_projection_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3F… | 55 | 45665.744 | grid=2304x1x1, block=128x1x1, smem=0, regs=34 |
| K26 | candidate:attention_score_kernel | kernel_cutlass_attention_score_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gme… | 55 | 2186.498 | grid=1536x1x1, block=128x1x1, smem=0, regs=32 |
| K27 | candidate:causal_softmax_kernel | kernel_cutlass_causal_softmax_kernel_tensorptrf32gmemoi641_tensorptrf32gmemoi641_3 | 55 | 1487.076 | grid=1536x1x1, block=1x1x1, smem=0, regs=45 |
| K28 | candidate:attention_context_kernel | kernel_cutlass_attention_context_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32g… | 55 | 477.251 | grid=768x1x1, block=128x1x1, smem=0, regs=28 |
| K29 | candidate:attention_projection_kernel | kernel_cutlass_attention_projection_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf… | 55 | 17278.348 | grid=768x1x1, block=128x1x1, smem=0, regs=34 |
| K30 | candidate:layer_norm_fp32_kernel | kernel_cutlass_layer_norm_fp32_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo7681_tenso… | 55 | 354.464 | grid=128x1x1, block=32x1x1, smem=0, regs=44 |
| K31 | candidate:mlp_fc_gelu_kernel | kernel_cutlass_mlp_fc_gelu_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgm… | 55 | 59873.716 | grid=3072x1x1, block=128x1x1, smem=0, regs=34 |
| K32 | candidate:mlp_projection_kernel | kernel_cutlass_mlp_projection_kernel_tensorptrf32gmemoi641_tensorptrf8E4M3FNgmemalign16… | 55 | 68937.546 | grid=768x1x1, block=128x1x1, smem=0, regs=34 |
| K33 | framework/validation | void at::native::unrolled_elementwise_kernel<at::native::direct_copy_kernel_cuda(at::Te… | 1 | 3.840 | grid=192x1x1, block=128x1x1, smem=0, regs=30 |
| K34 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 1 | 1.824 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K35 | framework/validation | void at::native::(anonymous namespace)::vectorized_layer_norm_kernel<float, float, fals… | 4 | 16.928 | grid=128x1x1, block=32x4x1, smem=24, regs=40 |
| K36 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::float8_copy_kernel_cuda(a… | 3 | 5.601 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K37 | framework/validation | nvjet_sm103_qqsss_64x32_128x16_2x1_2cta_v_bz_TNT | 1 | 3.136 | grid=144x1x1, block=256x1x1, smem=172552, regs=255 |
| K38 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 4.895 | grid=1152x1x1, block=128x1x1, smem=0, regs=20 |
| K39 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::float8_copy_kernel_cuda(a… | 1 | 2.048 | grid=288x1x1, block=128x1x1, smem=0, regs=32 |
| K40 | framework/validation | void at::native::unrolled_elementwise_kernel<at::native::direct_copy_kernel_cuda(at::Te… | 1 | 3.648 | grid=576x1x1, block=128x1x1, smem=0, regs=30 |
| K41 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 1 | 1.888 | grid=288x1x1, block=128x1x1, smem=0, regs=32 |
| K42 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 2 | 8.480 | grid=4x4x12, block=64x1x1, smem=13056, regs=72 |
| K43 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 3.456 | grid=192x1x1, block=128x1x1, smem=0, regs=32 |
| K44 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<bool>, std::a… | 1 | 1.185 | grid=8x1x1, block=128x1x1, smem=0, regs=16 |
| K45 | framework/validation | void at::native::triu_tril_kernel<bool, int, true, 8, false>(at::cuda::detail::TensorIn… | 1 | 2.303 | grid=16x1x1, block=128x1x1, smem=0, regs=30 |
| K46 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 4.640 | grid=768x1x1, block=128x1x1, smem=0, regs=20 |
| K47 | framework/validation | void (anonymous namespace)::softmax_warp_forward<float, float, float, 7, false, false>(… | 2 | 6.560 | grid=192x1x1, block=32x4x1, smem=0, regs=32 |
| K48 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_nnn_align1_bias_f32_relu | 2 | 10.272 | grid=2x4x12, block=64x1x1, smem=12672, regs=84 |
| K49 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 4.704 | grid=384x1x1, block=128x1x1, smem=0, regs=20 |
| K50 | framework/validation | nvjet_sm103_qqsss_64x16_128x16_2x4_2cta_h_bz_TNT | 2 | 7.008 | grid=96x1x1, block=256x1x1, smem=156168, regs=255 |
| K51 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 4 | 9.281 | grid=384x1x1, block=128x1x1, smem=0, regs=20 |
| K52 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::CUDAFunctor_add<float>, s… | 5 | 8.832 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K53 | framework/validation | nvjet_sm103_qqsss_48x64_128x16_2x2_2cta_h_bz_TNN | 1 | 3.393 | grid=128x1x1, block=256x1x1, smem=188944, regs=255 |
| K54 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 5.216 | grid=1536x1x1, block=128x1x1, smem=0, regs=20 |
| K55 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::GeluCUDAKernelImpl(at::Te… | 2 | 4.000 | grid=384x1x1, block=128x1x1, smem=0, regs=32 |
| K56 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::float8_copy_kernel_cuda(a… | 1 | 2.080 | grid=384x1x1, block=128x1x1, smem=0, regs=32 |
| K57 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 1 | 22.240 | grid=72x4x1, block=64x1x1, smem=13056, regs=72 |
| K58 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 1 | 19.681 | grid=24x4x1, block=64x1x1, smem=13056, regs=72 |
| K59 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_64x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 1 | 24.704 | grid=48x4x1, block=64x1x1, smem=19200, regs=146 |
| K60 | framework/validation | void scal_kernel<float, float, 1, true, 6, 5, 5, 3>(cublasTransposeParams<float>, float… | 1 | 1.312 | grid=12x4x1, block=256x1x1, smem=0, regs=24 |
| K61 | framework/validation | void sgemm_largek_lds64<true, false, 6, 3, 4, 5, 2, 66>(float*, float const*, float con… | 1 | 61.280 | grid=12x16x4, block=32x4x1, smem=4868, regs=32 |
| K62 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AbsFunctor<float>, std::a… | 2 | 3.552 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K63 | framework/validation | void at::native::reduce_kernel<512, 1, at::native::ReduceOp<float, at::native::func_wra… | 1 | 13.472 | grid=1x1x1, block=512x1x1, smem=2064, regs=30 |
| K64 | framework/validation | void at::native::(anonymous namespace)::indexSelectSmallIndex<float, long, unsigned int… | 2 | 8.672 | grid=6x1x1, block=128x1x1, smem=0, regs=28 |
| K65 | framework/validation | void at::native::(anonymous namespace)::indexSelectSmallIndex<float, long, unsigned int… | 2 | 7.648 | grid=1x1x1, block=7x1x1, smem=0, regs=28 |
| K66 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::CUDAFunctor_add<float>, s… | 1 | 1.600 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K67 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AbsFunctor<float>, std::a… | 1 | 1.568 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K68 | framework/validation | void at::native::reduce_kernel<512, 1, at::native::ReduceOp<float, at::native::func_wra… | 1 | 2.496 | grid=1x1x1, block=32x1x1, smem=16, regs=30 |
| K69 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 1 | 1.504 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K70 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BinaryFunctor<float, floa… | 1 | 1.504 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K71 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BinaryFunctor<bool, bool,… | 1 | 1.472 | grid=96x1x1, block=128x1x1, smem=0, regs=30 |
| K72 | framework/validation | void at::native::reduce_kernel<512, 1, at::native::ReduceOp<bool, at::native::func_wrap… | 1 | 12.545 | grid=1x1x1, block=512x1x1, smem=528, regs=28 |

## Ordered GPU activities

`gap before` is device-wide idle time since all earlier GPU activity ended; zero means overlap or no measurable hole.

| # | start ms | gap before us | duration us | lane | activity |
| ---: | ---: | ---: | ---: | --- | --- |
| 1 | 0.000 | 0.000 | 2.528 | d0/s7 | K1 |
| 2 | 0.082 | 79.136 | 2.208 | d0/s7 | K2 |
| 3 | 0.158 | 73.856 | 2.016 | d0/s7 | K3 |
| 4 | 0.203 | 42.976 | 1.600 | d0/s7 | K4 |
| 5 | 0.225 | 20.992 | 1.760 | d0/s7 | K2 |
| 6 | 0.241 | 14.273 | 1.567 | d0/s7 | K3 |
| 7 | 0.262 | 18.880 | 1.793 | d0/s7 | K2 |
| 8 | 0.275 | 11.840 | 1.984 | d0/s7 | K3 |
| 9 | 0.287 | 9.663 | 1.985 | d0/s7 | K4 |
| 10 | 0.305 | 15.648 | 2.112 | d0/s7 | K2 |
| 11 | 0.316 | 9.568 | 2.016 | d0/s7 | K3 |
| 12 | 0.334 | 15.360 | 1.792 | d0/s7 | K5 |
| 13 | 0.347 | 11.328 | 1.632 | d0/s7 | K6 |
| 14 | 0.362 | 13.984 | 1.760 | d0/s7 | K2 |
| 15 | 0.376 | 11.520 | 1.600 | d0/s7 | K3 |
| 16 | 0.392 | 14.400 | 2.144 | d0/s7 | K7 |
| 17 | 0.403 | 9.536 | 1.760 | d0/s7 | K6 |
| 18 | 0.419 | 14.080 | 2.144 | d0/s7 | K2 |
| 19 | 0.431 | 9.504 | 2.016 | d0/s7 | K3 |
| 20 | 0.460 | 27.520 | 5.728 | d0/s7 | K8 |
| 21 | 0.478 | 11.648 | 4.224 | d0/s7 | K8 |
| 22 | 0.496 | 14.336 | 5.920 | d0/s7 | K8 |
| 23 | 0.513 | 11.008 | 5.920 | d0/s7 | K8 |
| 24 | 0.576 | 57.088 | 1.792 | d0/s7 | K9 |
| 25 | 106.925 | 106346.466 | 1.920 | d0/s7 | K10 |
| 26 | 107.160 | 233.504 | 2.625 | d0/s7 | K11 |
| 27 | 132.579 | 25416.381 | 4.255 | d0/s7 | K12 |
| 28 | 132.778 | 194.209 | 1.824 | d0/s7 | K13 |
| 29 | 157.816 | 25036.893 | 2.464 | d0/s7 | K14 |
| 30 | 157.998 | 179.104 | 3.200 | d0/s7 | K15 |
| 31 | 183.327 | 25326.270 | 5.087 | d0/s7 | K16 |
| 32 | 183.524 | 191.841 | 3.296 | d0/s7 | K15 |
| 33 | 208.662 | 25134.749 | 4.352 | d0/s7 | K12 |
| 34 | 208.938 | 271.553 | 1.600 | d0/s7 | K17 |
| 35 | 209.009 | 69.567 | 1.825 | d0/s7 | K9 |
| 36 | 234.106 | 25094.492 | 1.728 | d0/s7 | K10 |
| 37 | 234.295 | 187.521 | 1.408 | d0/s7 | K18 |
| 38 | 234.359 | 62.432 | 1.504 | d0/s7 | K19 |
| 39 | 259.837 | 25476.413 | 1.953 | d0/s7 | K20 |
| 40 | 260.008 | 169.472 | 1.600 | d0/s7 | K17 |
| 41 | 260.069 | 59.488 | 1.760 | d0/s7 | K9 |
| 42 | 284.942 | 24870.844 | 1.856 | d0/s7 | K10 |
| 43 | 285.108 | 164.800 | 1.632 | d0/s7 | K17 |
| 44 | 285.173 | 63.457 | 1.407 | d0/s7 | K9 |
| 45 | 310.448 | 25273.086 | 1.792 | d0/s7 | K10 |
| 46 | 310.614 | 163.744 | 1.376 | d0/s7 | K21 |
| 47 | 310.681 | 65.792 | 1.568 | d0/s7 | K22 |
| 48 | 335.628 | 24945.341 | 2.144 | d0/s7 | K23 |
| 49 | 891.524 | 555894.240 | 12.864 | d0/s7 | K24 |
| 50 | 891.537 | 0.256 | 830.370 | d0/s7 | K25 |
| 51 | 892.368 | 0.256 | 39.904 | d0/s7 | K26 |
| 52 | 892.408 | 0.256 | 26.944 | d0/s7 | K27 |
| 53 | 892.435 | 0.256 | 8.544 | d0/s7 | K28 |
| 54 | 892.444 | 0.256 | 313.921 | d0/s7 | K29 |
| 55 | 892.758 | 0.256 | 11.968 | d0/s7 | K30 |
| 56 | 892.770 | 0.256 | 1088.259 | d0/s7 | K31 |
| 57 | 893.859 | 0.223 | 1253.315 | d0/s7 | K32 |
| 58 | 895.112 | 0.257 | 6.592 | d0/s7 | K24 |
| 59 | 895.119 | 0.256 | 830.210 | d0/s7 | K25 |
| 60 | 895.950 | 0.256 | 39.776 | d0/s7 | K26 |
| 61 | 895.990 | 0.256 | 26.880 | d0/s7 | K27 |
| 62 | 896.017 | 0.256 | 8.608 | d0/s7 | K28 |
| 63 | 896.026 | 0.256 | 314.177 | d0/s7 | K29 |
| 64 | 896.340 | 0.255 | 6.433 | d0/s7 | K30 |
| 65 | 896.347 | 0.256 | 1088.130 | d0/s7 | K31 |
| 66 | 897.435 | 0.224 | 1253.763 | d0/s7 | K32 |
| 67 | 898.689 | 0.256 | 6.592 | d0/s7 | K24 |
| 68 | 898.696 | 0.256 | 830.050 | d0/s7 | K25 |
| 69 | 899.526 | 0.256 | 39.776 | d0/s7 | K26 |
| 70 | 899.566 | 0.257 | 26.943 | d0/s7 | K27 |
| 71 | 899.594 | 0.257 | 8.672 | d0/s7 | K28 |
| 72 | 899.602 | 0.223 | 313.825 | d0/s7 | K29 |
| 73 | 899.917 | 0.256 | 6.400 | d0/s7 | K30 |
| 74 | 899.923 | 0.256 | 1088.355 | d0/s7 | K31 |
| 75 | 901.012 | 0.256 | 1253.027 | d0/s7 | K32 |
| 76 | 902.265 | 0.256 | 6.464 | d0/s7 | K24 |
| 77 | 902.272 | 0.256 | 829.858 | d0/s7 | K25 |
| 78 | 903.102 | 0.256 | 39.616 | d0/s7 | K26 |
| 79 | 903.142 | 0.224 | 27.008 | d0/s7 | K27 |
| 80 | 903.169 | 0.288 | 8.640 | d0/s7 | K28 |
| 81 | 903.178 | 0.256 | 314.657 | d0/s7 | K29 |
| 82 | 903.493 | 0.256 | 6.400 | d0/s7 | K30 |
| 83 | 903.500 | 0.256 | 1088.419 | d0/s7 | K31 |
| 84 | 904.588 | 0.224 | 1253.027 | d0/s7 | K32 |
| 85 | 905.841 | 0.256 | 6.464 | d0/s7 | K24 |
| 86 | 905.848 | 0.256 | 831.138 | d0/s7 | K25 |
| 87 | 906.680 | 0.255 | 39.745 | d0/s7 | K26 |
| 88 | 906.720 | 0.256 | 27.040 | d0/s7 | K27 |
| 89 | 906.747 | 0.256 | 9.120 | d0/s7 | K28 |
| 90 | 906.756 | 0.224 | 314.144 | d0/s7 | K29 |
| 91 | 907.071 | 0.257 | 6.432 | d0/s7 | K30 |
| 92 | 907.077 | 0.223 | 1088.419 | d0/s7 | K31 |
| 93 | 908.166 | 0.256 | 1252.291 | d0/s7 | K32 |
| 94 | 909.515 | 97.120 | 6.432 | d0/s7 | K24 |
| 95 | 909.523 | 0.832 | 830.626 | d0/s7 | K25 |
| 96 | 910.353 | 0.257 | 39.903 | d0/s7 | K26 |
| 97 | 910.394 | 0.257 | 27.040 | d0/s7 | K27 |
| 98 | 910.421 | 0.255 | 8.833 | d0/s7 | K28 |
| 99 | 910.430 | 0.256 | 314.144 | d0/s7 | K29 |
| 100 | 910.744 | 0.257 | 6.303 | d0/s7 | K30 |
| 101 | 910.751 | 0.257 | 1089.506 | d0/s7 | K31 |
| 102 | 911.841 | 0.256 | 1253.027 | d0/s7 | K32 |
| 103 | 913.154 | 59.872 | 6.464 | d0/s7 | K24 |
| 104 | 913.161 | 0.768 | 830.018 | d0/s7 | K25 |
| 105 | 913.991 | 0.256 | 39.680 | d0/s7 | K26 |
| 106 | 914.031 | 0.256 | 27.265 | d0/s7 | K27 |
| 107 | 914.059 | 0.255 | 8.993 | d0/s7 | K28 |
| 108 | 914.068 | 0.224 | 314.080 | d0/s7 | K29 |
| 109 | 914.382 | 0.256 | 6.240 | d0/s7 | K30 |
| 110 | 914.389 | 0.255 | 1088.611 | d0/s7 | K31 |
| 111 | 915.478 | 0.256 | 1253.219 | d0/s7 | K32 |
| 112 | 916.779 | 48.256 | 6.560 | d0/s7 | K24 |
| 113 | 916.786 | 0.288 | 829.890 | d0/s7 | K25 |
| 114 | 917.616 | 0.256 | 39.968 | d0/s7 | K26 |
| 115 | 917.656 | 0.256 | 27.232 | d0/s7 | K27 |
| 116 | 917.684 | 0.224 | 8.448 | d0/s7 | K28 |
| 117 | 917.692 | 0.256 | 314.529 | d0/s7 | K29 |
| 118 | 918.007 | 0.256 | 6.240 | d0/s7 | K30 |
| 119 | 918.014 | 0.255 | 1088.067 | d0/s7 | K31 |
| 120 | 919.102 | 0.256 | 1252.611 | d0/s7 | K32 |
| 121 | 920.403 | 48.320 | 6.560 | d0/s7 | K24 |
| 122 | 920.410 | 0.256 | 830.402 | d0/s7 | K25 |
| 123 | 921.240 | 0.256 | 39.840 | d0/s7 | K26 |
| 124 | 921.280 | 0.224 | 26.880 | d0/s7 | K27 |
| 125 | 921.308 | 0.256 | 8.544 | d0/s7 | K28 |
| 126 | 921.316 | 0.256 | 314.433 | d0/s7 | K29 |
| 127 | 921.631 | 0.256 | 6.336 | d0/s7 | K30 |
| 128 | 921.638 | 0.224 | 1088.674 | d0/s7 | K31 |
| 129 | 922.727 | 0.257 | 1252.387 | d0/s7 | K32 |
| 130 | 924.024 | 44.672 | 6.592 | d0/s7 | K24 |
| 131 | 924.032 | 1.728 | 830.114 | d0/s7 | K25 |
| 132 | 924.862 | 0.256 | 39.840 | d0/s7 | K26 |
| 133 | 924.902 | 0.256 | 27.072 | d0/s7 | K27 |
| 134 | 924.930 | 0.256 | 8.672 | d0/s7 | K28 |
| 135 | 924.939 | 0.256 | 314.465 | d0/s7 | K29 |
| 136 | 925.253 | 0.224 | 6.432 | d0/s7 | K30 |
| 137 | 925.260 | 0.255 | 1088.867 | d0/s7 | K31 |
| 138 | 926.349 | 0.256 | 1252.547 | d0/s7 | K32 |
| 139 | 927.647 | 45.120 | 6.593 | d0/s7 | K24 |
| 140 | 927.656 | 2.143 | 830.243 | d0/s7 | K25 |
| 141 | 928.486 | 0.255 | 39.680 | d0/s7 | K26 |
| 142 | 928.526 | 0.257 | 26.944 | d0/s7 | K27 |
| 143 | 928.553 | 0.256 | 8.384 | d0/s7 | K28 |
| 144 | 928.562 | 0.223 | 314.145 | d0/s7 | K29 |
| 145 | 928.876 | 0.256 | 6.400 | d0/s7 | K30 |
| 146 | 928.883 | 0.256 | 1089.027 | d0/s7 | K31 |
| 147 | 929.972 | 0.256 | 1253.219 | d0/s7 | K32 |
| 148 | 931.274 | 48.960 | 6.432 | d0/s7 | K24 |
| 149 | 931.281 | 0.256 | 830.626 | d0/s7 | K25 |
| 150 | 932.112 | 0.256 | 39.584 | d0/s7 | K26 |
| 151 | 932.152 | 0.256 | 26.880 | d0/s7 | K27 |
| 152 | 932.179 | 0.257 | 8.800 | d0/s7 | K28 |
| 153 | 932.188 | 0.223 | 314.081 | d0/s7 | K29 |
| 154 | 932.502 | 0.256 | 6.400 | d0/s7 | K30 |
| 155 | 932.509 | 0.256 | 1088.451 | d0/s7 | K31 |
| 156 | 933.598 | 0.256 | 1252.835 | d0/s7 | K32 |
| 157 | 934.897 | 47.040 | 6.464 | d0/s7 | K24 |
| 158 | 934.904 | 0.256 | 830.178 | d0/s7 | K25 |
| 159 | 935.735 | 0.256 | 39.680 | d0/s7 | K26 |
| 160 | 935.775 | 0.256 | 27.040 | d0/s7 | K27 |
| 161 | 935.802 | 0.288 | 8.896 | d0/s7 | K28 |
| 162 | 935.811 | 0.256 | 313.985 | d0/s7 | K29 |
| 163 | 936.125 | 0.224 | 6.464 | d0/s7 | K30 |
| 164 | 936.132 | 0.224 | 1089.155 | d0/s7 | K31 |
| 165 | 937.221 | 0.224 | 1255.203 | d0/s7 | K32 |
| 166 | 938.521 | 44.672 | 6.432 | d0/s7 | K24 |
| 167 | 938.529 | 0.960 | 830.274 | d0/s7 | K25 |
| 168 | 939.359 | 0.256 | 39.744 | d0/s7 | K26 |
| 169 | 939.399 | 0.256 | 27.136 | d0/s7 | K27 |
| 170 | 939.427 | 0.255 | 8.576 | d0/s7 | K28 |
| 171 | 939.435 | 0.256 | 314.017 | d0/s7 | K29 |
| 172 | 939.750 | 0.256 | 6.304 | d0/s7 | K30 |
| 173 | 939.756 | 0.256 | 1089.602 | d0/s7 | K31 |
| 174 | 940.846 | 0.256 | 1253.635 | d0/s7 | K32 |
| 175 | 942.146 | 45.890 | 6.432 | d0/s7 | K24 |
| 176 | 942.152 | 0.255 | 830.339 | d0/s7 | K25 |
| 177 | 942.983 | 0.255 | 39.681 | d0/s7 | K26 |
| 178 | 943.023 | 0.256 | 27.136 | d0/s7 | K27 |
| 179 | 943.050 | 0.256 | 8.928 | d0/s7 | K28 |
| 180 | 943.059 | 0.224 | 313.760 | d0/s7 | K29 |
| 181 | 943.373 | 0.256 | 6.240 | d0/s7 | K30 |
| 182 | 943.380 | 0.257 | 1088.802 | d0/s7 | K31 |
| 183 | 944.469 | 0.224 | 1253.411 | d0/s7 | K32 |
| 184 | 945.770 | 48.192 | 6.560 | d0/s7 | K24 |
| 185 | 945.777 | 0.256 | 830.338 | d0/s7 | K25 |
| 186 | 946.608 | 0.256 | 39.712 | d0/s7 | K26 |
| 187 | 946.648 | 0.256 | 27.009 | d0/s7 | K27 |
| 188 | 946.675 | 0.255 | 8.640 | d0/s7 | K28 |
| 189 | 946.684 | 0.257 | 313.856 | d0/s7 | K29 |
| 190 | 946.998 | 0.224 | 6.240 | d0/s7 | K30 |
| 191 | 947.005 | 0.255 | 1088.579 | d0/s7 | K31 |
| 192 | 948.093 | 0.256 | 1253.091 | d0/s7 | K32 |
| 193 | 949.391 | 44.736 | 6.592 | d0/s7 | K24 |
| 194 | 949.399 | 0.992 | 830.402 | d0/s7 | K25 |
| 195 | 950.229 | 0.256 | 39.904 | d0/s7 | K26 |
| 196 | 950.270 | 0.256 | 26.976 | d0/s7 | K27 |
| 197 | 950.297 | 0.256 | 8.512 | d0/s7 | K28 |
| 198 | 950.306 | 0.256 | 314.081 | d0/s7 | K29 |
| 199 | 950.620 | 0.256 | 6.336 | d0/s7 | K30 |
| 200 | 950.627 | 0.224 | 1088.355 | d0/s7 | K31 |
| 201 | 951.715 | 0.224 | 1253.539 | d0/s7 | K32 |
| 202 | 953.013 | 44.448 | 6.592 | d0/s7 | K24 |
| 203 | 953.021 | 1.248 | 830.274 | d0/s7 | K25 |
| 204 | 953.851 | 0.256 | 39.648 | d0/s7 | K26 |
| 205 | 953.891 | 0.256 | 26.976 | d0/s7 | K27 |
| 206 | 953.919 | 0.256 | 8.384 | d0/s7 | K28 |
| 207 | 953.927 | 0.256 | 314.049 | d0/s7 | K29 |
| 208 | 954.242 | 0.288 | 6.400 | d0/s7 | K30 |
| 209 | 954.248 | 0.256 | 1088.258 | d0/s7 | K31 |
| 210 | 955.337 | 0.256 | 1252.739 | d0/s7 | K32 |
| 211 | 956.635 | 45.505 | 6.592 | d0/s7 | K24 |
| 212 | 956.642 | 0.543 | 831.426 | d0/s7 | K25 |
| 213 | 957.474 | 0.226 | 39.647 | d0/s7 | K26 |
| 214 | 957.514 | 0.257 | 26.976 | d0/s7 | K27 |
| 215 | 957.541 | 0.288 | 8.928 | d0/s7 | K28 |
| 216 | 957.550 | 0.224 | 314.241 | d0/s7 | K29 |
| 217 | 957.865 | 0.256 | 6.240 | d0/s7 | K30 |
| 218 | 957.871 | 0.255 | 1087.779 | d0/s7 | K31 |
| 219 | 958.959 | 0.256 | 1252.899 | d0/s7 | K32 |
| 220 | 960.257 | 45.440 | 6.464 | d0/s7 | K24 |
| 221 | 960.264 | 0.256 | 829.986 | d0/s7 | K25 |
| 222 | 961.094 | 0.256 | 39.456 | d0/s7 | K26 |
| 223 | 961.134 | 0.256 | 26.880 | d0/s7 | K27 |
| 224 | 961.161 | 0.288 | 8.768 | d0/s7 | K28 |
| 225 | 961.170 | 0.256 | 313.697 | d0/s7 | K29 |
| 226 | 961.484 | 0.256 | 6.400 | d0/s7 | K30 |
| 227 | 961.491 | 0.256 | 1088.546 | d0/s7 | K31 |
| 228 | 962.580 | 0.257 | 1254.371 | d0/s7 | K32 |
| 229 | 963.879 | 45.024 | 6.464 | d0/s7 | K24 |
| 230 | 963.888 | 2.016 | 830.082 | d0/s7 | K25 |
| 231 | 964.718 | 0.256 | 39.744 | d0/s7 | K26 |
| 232 | 964.758 | 0.256 | 27.136 | d0/s7 | K27 |
| 233 | 964.785 | 0.288 | 8.608 | d0/s7 | K28 |
| 234 | 964.794 | 0.256 | 313.889 | d0/s7 | K29 |
| 235 | 965.108 | 0.256 | 6.432 | d0/s7 | K30 |
| 236 | 965.115 | 0.256 | 1088.546 | d0/s7 | K31 |
| 237 | 966.204 | 0.256 | 1252.451 | d0/s7 | K32 |
| 238 | 967.501 | 44.801 | 6.431 | d0/s7 | K24 |
| 239 | 967.508 | 0.480 | 829.923 | d0/s7 | K25 |
| 240 | 968.338 | 0.255 | 39.872 | d0/s7 | K26 |
| 241 | 968.378 | 0.257 | 27.264 | d0/s7 | K27 |
| 242 | 968.406 | 0.224 | 8.927 | d0/s7 | K28 |
| 243 | 968.415 | 0.257 | 314.433 | d0/s7 | K29 |
| 244 | 968.730 | 0.255 | 6.272 | d0/s7 | K30 |
| 245 | 968.736 | 0.288 | 1088.483 | d0/s7 | K31 |
| 246 | 969.825 | 0.256 | 1253.251 | d0/s7 | K32 |
| 247 | 971.127 | 49.088 | 6.464 | d0/s7 | K24 |
| 248 | 971.134 | 0.288 | 830.082 | d0/s7 | K25 |
| 249 | 971.964 | 0.256 | 39.904 | d0/s7 | K26 |
| 250 | 972.005 | 0.224 | 27.200 | d0/s7 | K27 |
| 251 | 972.032 | 0.257 | 8.640 | d0/s7 | K28 |
| 252 | 972.041 | 0.255 | 313.889 | d0/s7 | K29 |
| 253 | 972.355 | 0.256 | 6.240 | d0/s7 | K30 |
| 254 | 972.362 | 0.256 | 1088.611 | d0/s7 | K31 |
| 255 | 973.450 | 0.224 | 1256.419 | d0/s7 | K32 |
| 256 | 974.754 | 46.688 | 6.592 | d0/s7 | K24 |
| 257 | 974.760 | 0.256 | 830.114 | d0/s7 | K25 |
| 258 | 975.591 | 0.224 | 39.904 | d0/s7 | K26 |
| 259 | 975.631 | 0.256 | 27.136 | d0/s7 | K27 |
| 260 | 975.658 | 0.256 | 8.256 | d0/s7 | K28 |
| 261 | 975.667 | 0.256 | 313.729 | d0/s7 | K29 |
| 262 | 975.981 | 0.256 | 6.240 | d0/s7 | K30 |
| 263 | 975.987 | 0.224 | 1088.323 | d0/s7 | K31 |
| 264 | 977.076 | 0.254 | 1254.084 | d0/s7 | K32 |
| 265 | 978.374 | 43.776 | 6.560 | d0/s7 | K24 |
| 266 | 978.382 | 1.664 | 830.338 | d0/s7 | K25 |
| 267 | 979.212 | 0.256 | 39.840 | d0/s7 | K26 |
| 268 | 979.253 | 0.256 | 26.944 | d0/s7 | K27 |
| 269 | 979.280 | 0.256 | 8.640 | d0/s7 | K28 |
| 270 | 979.289 | 0.256 | 313.761 | d0/s7 | K29 |
| 271 | 979.603 | 0.288 | 6.272 | d0/s7 | K30 |
| 272 | 979.609 | 0.256 | 1088.066 | d0/s7 | K31 |
| 273 | 980.698 | 0.256 | 1252.867 | d0/s7 | K32 |
| 274 | 981.997 | 46.752 | 6.560 | d0/s7 | K24 |
| 275 | 982.004 | 0.257 | 830.210 | d0/s7 | K25 |
| 276 | 982.834 | 0.256 | 39.584 | d0/s7 | K26 |
| 277 | 982.874 | 0.256 | 26.880 | d0/s7 | K27 |
| 278 | 982.901 | 0.256 | 8.448 | d0/s7 | K28 |
| 279 | 982.910 | 0.255 | 314.337 | d0/s7 | K29 |
| 280 | 983.225 | 0.255 | 6.432 | d0/s7 | K30 |
| 281 | 983.231 | 0.257 | 1089.346 | d0/s7 | K31 |
| 282 | 984.321 | 0.256 | 1253.027 | d0/s7 | K32 |
| 283 | 985.620 | 46.368 | 6.592 | d0/s7 | K24 |
| 284 | 985.627 | 0.256 | 830.082 | d0/s7 | K25 |
| 285 | 986.458 | 0.256 | 39.776 | d0/s7 | K26 |
| 286 | 986.498 | 0.288 | 26.817 | d0/s7 | K27 |
| 287 | 986.525 | 0.255 | 8.705 | d0/s7 | K28 |
| 288 | 986.534 | 0.223 | 314.017 | d0/s7 | K29 |
| 289 | 986.848 | 0.256 | 6.432 | d0/s7 | K30 |
| 290 | 986.855 | 0.256 | 1088.899 | d0/s7 | K31 |
| 291 | 987.944 | 0.256 | 1252.035 | d0/s7 | K32 |
| 292 | 989.242 | 46.176 | 6.432 | d0/s7 | K24 |
| 293 | 989.249 | 0.864 | 830.210 | d0/s7 | K25 |
| 294 | 990.080 | 0.256 | 39.552 | d0/s7 | K26 |
| 295 | 990.120 | 0.256 | 26.912 | d0/s7 | K27 |
| 296 | 990.147 | 0.256 | 8.544 | d0/s7 | K28 |
| 297 | 990.156 | 0.224 | 313.953 | d0/s7 | K29 |
| 298 | 990.470 | 0.256 | 6.432 | d0/s7 | K30 |
| 299 | 990.476 | 0.256 | 1089.027 | d0/s7 | K31 |
| 300 | 991.566 | 0.256 | 1253.859 | d0/s7 | K32 |
| 301 | 992.864 | 44.544 | 6.464 | d0/s7 | K24 |
| 302 | 992.872 | 1.824 | 830.114 | d0/s7 | K25 |
| 303 | 993.703 | 0.256 | 39.744 | d0/s7 | K26 |
| 304 | 993.743 | 0.256 | 27.008 | d0/s7 | K27 |
| 305 | 993.770 | 0.288 | 8.864 | d0/s7 | K28 |
| 306 | 993.779 | 0.256 | 314.081 | d0/s7 | K29 |
| 307 | 994.094 | 0.256 | 6.400 | d0/s7 | K30 |
| 308 | 994.100 | 0.256 | 1088.802 | d0/s7 | K31 |
| 309 | 995.189 | 0.225 | 1252.995 | d0/s7 | K32 |
| 310 | 996.491 | 49.024 | 6.432 | d0/s7 | K24 |
| 311 | 996.498 | 0.256 | 830.242 | d0/s7 | K25 |
| 312 | 997.328 | 0.256 | 39.776 | d0/s7 | K26 |
| 313 | 997.368 | 0.256 | 27.296 | d0/s7 | K27 |
| 314 | 997.396 | 0.288 | 8.992 | d0/s7 | K28 |
| 315 | 997.405 | 0.255 | 314.753 | d0/s7 | K29 |
| 316 | 997.720 | 0.255 | 6.305 | d0/s7 | K30 |
| 317 | 997.727 | 0.255 | 1089.187 | d0/s7 | K31 |
| 318 | 998.816 | 0.256 | 1253.539 | d0/s7 | K32 |
| 319 | 1000.118 | 47.968 | 6.465 | d0/s7 | K24 |
| 320 | 1000.124 | 0.255 | 829.699 | d0/s7 | K25 |
| 321 | 1000.954 | 0.223 | 40.161 | d0/s7 | K26 |
| 322 | 1000.995 | 0.255 | 27.137 | d0/s7 | K27 |
| 323 | 1001.022 | 0.256 | 8.800 | d0/s7 | K28 |
| 324 | 1001.031 | 0.224 | 314.400 | d0/s7 | K29 |
| 325 | 1001.346 | 0.256 | 6.240 | d0/s7 | K30 |
| 326 | 1001.352 | 0.256 | 1088.066 | d0/s7 | K31 |
| 327 | 1002.441 | 0.256 | 1253.091 | d0/s7 | K32 |
| 328 | 1003.744 | 49.760 | 6.592 | d0/s7 | K24 |
| 329 | 1003.752 | 2.144 | 829.762 | d0/s7 | K25 |
| 330 | 1004.582 | 0.256 | 39.840 | d0/s7 | K26 |
| 331 | 1004.622 | 0.256 | 27.264 | d0/s7 | K27 |
| 332 | 1004.650 | 0.256 | 8.640 | d0/s7 | K28 |
| 333 | 1004.659 | 0.256 | 314.529 | d0/s7 | K29 |
| 334 | 1004.974 | 0.288 | 6.208 | d0/s7 | K30 |
| 335 | 1004.980 | 0.256 | 1088.899 | d0/s7 | K31 |
| 336 | 1006.069 | 0.256 | 1254.851 | d0/s7 | K32 |
| 337 | 1007.367 | 42.432 | 6.592 | d0/s7 | K24 |
| 338 | 1007.373 | 0.224 | 830.242 | d0/s7 | K25 |
| 339 | 1008.204 | 0.256 | 39.840 | d0/s7 | K26 |
| 340 | 1008.244 | 0.256 | 26.880 | d0/s7 | K27 |
| 341 | 1008.271 | 0.224 | 8.640 | d0/s7 | K28 |
| 342 | 1008.280 | 0.256 | 314.209 | d0/s7 | K29 |
| 343 | 1008.594 | 0.256 | 6.304 | d0/s7 | K30 |
| 344 | 1008.601 | 0.256 | 1088.579 | d0/s7 | K31 |
| 345 | 1009.690 | 0.223 | 1254.820 | d0/s7 | K32 |
| 346 | 1010.991 | 46.720 | 6.592 | d0/s7 | K24 |
| 347 | 1010.998 | 0.256 | 830.082 | d0/s7 | K25 |
| 348 | 1011.828 | 0.224 | 39.680 | d0/s7 | K26 |
| 349 | 1011.868 | 0.256 | 26.912 | d0/s7 | K27 |
| 350 | 1011.896 | 0.256 | 8.480 | d0/s7 | K28 |
| 351 | 1011.904 | 0.256 | 314.145 | d0/s7 | K29 |
| 352 | 1012.219 | 0.256 | 6.432 | d0/s7 | K30 |
| 353 | 1012.225 | 0.256 | 1088.258 | d0/s7 | K31 |
| 354 | 1013.314 | 0.256 | 1253.059 | d0/s7 | K32 |
| 355 | 1014.612 | 44.992 | 6.593 | d0/s7 | K24 |
| 356 | 1014.620 | 1.248 | 830.306 | d0/s7 | K25 |
| 357 | 1015.450 | 0.257 | 39.744 | d0/s7 | K26 |
| 358 | 1015.490 | 0.256 | 26.944 | d0/s7 | K27 |
| 359 | 1015.518 | 0.256 | 8.608 | d0/s7 | K28 |
| 360 | 1015.526 | 0.256 | 313.856 | d0/s7 | K29 |
| 361 | 1015.841 | 0.257 | 6.400 | d0/s7 | K30 |
| 362 | 1015.847 | 0.255 | 1088.035 | d0/s7 | K31 |
| 363 | 1016.936 | 0.256 | 1252.739 | d0/s7 | K32 |
| 364 | 1018.234 | 45.824 | 6.432 | d0/s7 | K24 |
| 365 | 1018.242 | 1.696 | 830.338 | d0/s7 | K25 |
| 366 | 1019.073 | 0.256 | 39.585 | d0/s7 | K26 |
| 367 | 1019.113 | 0.255 | 27.008 | d0/s7 | K27 |
| 368 | 1019.140 | 0.257 | 9.023 | d0/s7 | K28 |
| 369 | 1019.149 | 0.257 | 314.592 | d0/s7 | K29 |
| 370 | 1019.464 | 0.224 | 6.400 | d0/s7 | K30 |
| 371 | 1019.471 | 0.256 | 1088.419 | d0/s7 | K31 |
| 372 | 1020.559 | 0.256 | 1254.211 | d0/s7 | K32 |
| 373 | 1021.862 | 48.480 | 6.464 | d0/s7 | K24 |
| 374 | 1021.869 | 0.256 | 830.146 | d0/s7 | K25 |
| 375 | 1022.699 | 0.224 | 39.552 | d0/s7 | K26 |
| 376 | 1022.739 | 0.289 | 27.200 | d0/s7 | K27 |
| 377 | 1022.766 | 0.256 | 8.800 | d0/s7 | K28 |
| 378 | 1022.775 | 0.256 | 313.985 | d0/s7 | K29 |
| 379 | 1023.090 | 0.256 | 6.432 | d0/s7 | K30 |
| 380 | 1023.096 | 0.224 | 1088.419 | d0/s7 | K31 |
| 381 | 1024.185 | 0.256 | 1254.051 | d0/s7 | K32 |
| 382 | 1025.486 | 46.464 | 6.432 | d0/s7 | K24 |
| 383 | 1025.492 | 0.224 | 830.530 | d0/s7 | K25 |
| 384 | 1026.323 | 0.224 | 40.064 | d0/s7 | K26 |
| 385 | 1026.363 | 0.256 | 27.136 | d0/s7 | K27 |
| 386 | 1026.391 | 0.255 | 8.640 | d0/s7 | K28 |
| 387 | 1026.400 | 0.224 | 313.761 | d0/s7 | K29 |
| 388 | 1026.714 | 0.256 | 6.304 | d0/s7 | K30 |
| 389 | 1026.720 | 0.255 | 1088.323 | d0/s7 | K31 |
| 390 | 1027.809 | 0.223 | 1254.276 | d0/s7 | K32 |
| 391 | 1029.109 | 46.400 | 6.432 | d0/s7 | K24 |
| 392 | 1029.117 | 1.120 | 830.562 | d0/s7 | K25 |
| 393 | 1029.948 | 0.256 | 39.840 | d0/s7 | K26 |
| 394 | 1029.988 | 0.256 | 27.136 | d0/s7 | K27 |
| 395 | 1030.015 | 0.255 | 8.768 | d0/s7 | K28 |
| 396 | 1030.024 | 0.256 | 314.881 | d0/s7 | K29 |
| 397 | 1030.339 | 0.255 | 6.240 | d0/s7 | K30 |
| 398 | 1030.346 | 0.257 | 1088.642 | d0/s7 | K31 |
| 399 | 1031.435 | 0.256 | 1252.707 | d0/s7 | K32 |
| 400 | 1032.731 | 43.104 | 6.592 | d0/s7 | K24 |
| 401 | 1032.737 | 0.256 | 829.762 | d0/s7 | K25 |
| 402 | 1033.567 | 0.225 | 39.647 | d0/s7 | K26 |
| 403 | 1033.607 | 0.288 | 27.105 | d0/s7 | K27 |
| 404 | 1033.635 | 0.255 | 8.385 | d0/s7 | K28 |
| 405 | 1033.643 | 0.255 | 314.242 | d0/s7 | K29 |
| 406 | 1033.958 | 0.255 | 6.240 | d0/s7 | K30 |
| 407 | 1033.964 | 0.256 | 1088.355 | d0/s7 | K31 |
| 408 | 1035.053 | 0.256 | 1252.963 | d0/s7 | K32 |
| 409 | 1036.351 | 44.864 | 6.560 | d0/s7 | K24 |
| 410 | 1036.358 | 0.256 | 830.434 | d0/s7 | K25 |
| 411 | 1037.188 | 0.224 | 40.032 | d0/s7 | K26 |
| 412 | 1037.229 | 0.256 | 27.040 | d0/s7 | K27 |
| 413 | 1037.256 | 0.256 | 8.576 | d0/s7 | K28 |
| 414 | 1037.265 | 0.224 | 314.241 | d0/s7 | K29 |
| 415 | 1037.579 | 0.256 | 6.336 | d0/s7 | K30 |
| 416 | 1037.586 | 0.256 | 1088.515 | d0/s7 | K31 |
| 417 | 1038.674 | 0.256 | 1253.059 | d0/s7 | K32 |
| 418 | 1039.973 | 45.696 | 6.560 | d0/s7 | K24 |
| 419 | 1039.982 | 2.272 | 831.298 | d0/s7 | K25 |
| 420 | 1040.814 | 0.224 | 39.648 | d0/s7 | K26 |
| 421 | 1040.853 | 0.256 | 26.912 | d0/s7 | K27 |
| 422 | 1040.881 | 0.256 | 8.544 | d0/s7 | K28 |
| 423 | 1040.889 | 0.256 | 314.241 | d0/s7 | K29 |
| 424 | 1041.204 | 0.256 | 6.432 | d0/s7 | K30 |
| 425 | 1041.211 | 0.256 | 1088.515 | d0/s7 | K31 |
| 426 | 1042.299 | 0.255 | 1253.252 | d0/s7 | K32 |
| 427 | 1043.596 | 43.135 | 6.593 | d0/s7 | K24 |
| 428 | 1043.604 | 1.600 | 830.178 | d0/s7 | K25 |
| 429 | 1044.434 | 0.256 | 39.744 | d0/s7 | K26 |
| 430 | 1044.474 | 0.256 | 26.976 | d0/s7 | K27 |
| 431 | 1044.502 | 0.256 | 8.864 | d0/s7 | K28 |
| 432 | 1044.511 | 0.256 | 313.985 | d0/s7 | K29 |
| 433 | 1044.825 | 0.256 | 6.400 | d0/s7 | K30 |
| 434 | 1044.832 | 0.255 | 1090.435 | d0/s7 | K31 |
| 435 | 1045.922 | 0.256 | 1254.467 | d0/s7 | K32 |
| 436 | 1047.222 | 45.025 | 6.431 | d0/s7 | K24 |
| 437 | 1047.229 | 0.257 | 830.113 | d0/s7 | K25 |
| 438 | 1048.059 | 0.226 | 39.712 | d0/s7 | K26 |
| 439 | 1048.099 | 0.255 | 26.945 | d0/s7 | K27 |
| 440 | 1048.126 | 0.255 | 8.737 | d0/s7 | K28 |
| 441 | 1048.135 | 0.223 | 314.433 | d0/s7 | K29 |
| 442 | 1048.450 | 0.257 | 6.367 | d0/s7 | K30 |
| 443 | 1048.456 | 0.288 | 1088.387 | d0/s7 | K31 |
| 444 | 1049.545 | 0.256 | 1253.891 | d0/s7 | K32 |
| 445 | 1050.846 | 46.656 | 6.464 | d0/s7 | K24 |
| 446 | 1050.852 | 0.417 | 829.890 | d0/s7 | K25 |
| 447 | 1051.683 | 0.256 | 39.648 | d0/s7 | K26 |
| 448 | 1051.722 | 0.257 | 27.295 | d0/s7 | K27 |
| 449 | 1051.750 | 0.257 | 8.800 | d0/s7 | K28 |
| 450 | 1051.759 | 0.255 | 313.921 | d0/s7 | K29 |
| 451 | 1052.073 | 0.256 | 6.400 | d0/s7 | K30 |
| 452 | 1052.080 | 0.256 | 1088.803 | d0/s7 | K31 |
| 453 | 1053.169 | 0.256 | 1252.931 | d0/s7 | K32 |
| 454 | 1054.469 | 46.688 | 6.496 | d0/s7 | K24 |
| 455 | 1054.477 | 1.600 | 830.562 | d0/s7 | K25 |
| 456 | 1055.308 | 0.256 | 39.872 | d0/s7 | K26 |
| 457 | 1055.348 | 0.256 | 27.072 | d0/s7 | K27 |
| 458 | 1055.375 | 0.256 | 9.024 | d0/s7 | K28 |
| 459 | 1055.384 | 0.256 | 313.953 | d0/s7 | K29 |
| 460 | 1055.698 | 0.256 | 6.304 | d0/s7 | K30 |
| 461 | 1055.705 | 0.256 | 1088.322 | d0/s7 | K31 |
| 462 | 1056.794 | 0.257 | 1253.187 | d0/s7 | K32 |
| 463 | 1058.093 | 45.760 | 6.432 | d0/s7 | K24 |
| 464 | 1058.099 | 0.256 | 830.658 | d0/s7 | K25 |
| 465 | 1058.930 | 0.224 | 39.520 | d0/s7 | K26 |
| 466 | 1058.970 | 0.256 | 27.040 | d0/s7 | K27 |
| 467 | 1058.997 | 0.256 | 8.640 | d0/s7 | K28 |
| 468 | 1059.006 | 0.224 | 314.081 | d0/s7 | K29 |
| 469 | 1059.320 | 0.256 | 6.240 | d0/s7 | K30 |
| 470 | 1059.327 | 0.288 | 1088.451 | d0/s7 | K31 |
| 471 | 1060.416 | 0.255 | 1253.540 | d0/s7 | K32 |
| 472 | 1061.715 | 45.824 | 6.560 | d0/s7 | K24 |
| 473 | 1061.722 | 0.255 | 831.074 | d0/s7 | K25 |
| 474 | 1062.553 | 0.225 | 39.808 | d0/s7 | K26 |
| 475 | 1062.593 | 0.256 | 27.104 | d0/s7 | K27 |
| 476 | 1062.621 | 0.256 | 8.512 | d0/s7 | K28 |
| 477 | 1062.629 | 0.256 | 313.984 | d0/s7 | K29 |
| 478 | 1062.943 | 0.225 | 6.240 | d0/s7 | K30 |
| 479 | 1062.950 | 0.255 | 1088.835 | d0/s7 | K31 |
| 480 | 1064.039 | 0.256 | 1253.635 | d0/s7 | K32 |
| 481 | 1065.336 | 43.168 | 6.592 | d0/s7 | K24 |
| 482 | 1065.343 | 0.992 | 830.242 | d0/s7 | K25 |
| 483 | 1066.174 | 0.224 | 39.648 | d0/s7 | K26 |
| 484 | 1066.214 | 0.224 | 27.040 | d0/s7 | K27 |
| 485 | 1066.241 | 0.256 | 8.512 | d0/s7 | K28 |
| 486 | 1066.250 | 0.257 | 314.048 | d0/s7 | K29 |
| 487 | 1066.564 | 0.256 | 6.336 | d0/s7 | K30 |
| 488 | 1066.571 | 0.256 | 1088.355 | d0/s7 | K31 |
| 489 | 1067.659 | 0.256 | 1254.531 | d0/s7 | K32 |
| 490 | 1068.958 | 43.873 | 6.592 | d0/s7 | K24 |
| 491 | 1068.966 | 1.280 | 830.978 | d0/s7 | K25 |
| 492 | 1069.797 | 0.256 | 39.680 | d0/s7 | K26 |
| 493 | 1069.837 | 0.256 | 26.912 | d0/s7 | K27 |
| 494 | 1069.864 | 0.256 | 8.544 | d0/s7 | K28 |
| 495 | 1069.873 | 0.224 | 314.465 | d0/s7 | K29 |
| 496 | 1070.187 | 0.256 | 6.400 | d0/s7 | K30 |
| 497 | 1070.194 | 0.256 | 1087.875 | d0/s7 | K31 |
| 498 | 1071.282 | 0.256 | 1252.995 | d0/s7 | K32 |
| 499 | 1072.583 | 48.160 | 6.592 | d0/s7 | K24 |
| 500 | 1072.590 | 0.256 | 830.146 | d0/s7 | K25 |
| 501 | 1073.421 | 0.256 | 39.680 | d0/s7 | K26 |
| 502 | 1073.461 | 0.256 | 26.944 | d0/s7 | K27 |
| 503 | 1073.488 | 0.256 | 8.416 | d0/s7 | K28 |
| 504 | 1073.496 | 0.256 | 314.017 | d0/s7 | K29 |
| 505 | 1073.811 | 0.256 | 6.432 | d0/s7 | K30 |
| 506 | 1073.817 | 0.256 | 1088.483 | d0/s7 | K31 |
| 507 | 1074.906 | 0.255 | 1254.115 | d0/s7 | K32 |
| 508 | 1076.207 | 46.241 | 6.464 | d0/s7 | K24 |
| 509 | 1076.213 | 0.256 | 830.050 | d0/s7 | K25 |
| 510 | 1077.044 | 0.225 | 39.808 | d0/s7 | K26 |
| 511 | 1077.084 | 0.256 | 26.912 | d0/s7 | K27 |
| 512 | 1077.111 | 0.256 | 8.736 | d0/s7 | K28 |
| 513 | 1077.120 | 0.256 | 314.528 | d0/s7 | K29 |
| 514 | 1077.435 | 0.257 | 6.400 | d0/s7 | K30 |
| 515 | 1077.441 | 0.256 | 1088.674 | d0/s7 | K31 |
| 516 | 1078.530 | 0.256 | 1252.835 | d0/s7 | K32 |
| 517 | 1079.828 | 45.280 | 6.433 | d0/s7 | K24 |
| 518 | 1079.837 | 2.080 | 830.273 | d0/s7 | K25 |
| 519 | 1080.667 | 0.256 | 39.713 | d0/s7 | K26 |
| 520 | 1080.707 | 0.256 | 27.072 | d0/s7 | K27 |
| 521 | 1080.735 | 0.255 | 8.640 | d0/s7 | K28 |
| 522 | 1080.743 | 0.257 | 314.016 | d0/s7 | K29 |
| 523 | 1081.058 | 0.257 | 6.400 | d0/s7 | K30 |
| 524 | 1081.064 | 0.255 | 1088.643 | d0/s7 | K31 |
| 525 | 1082.153 | 0.224 | 1252.355 | d0/s7 | K32 |
| 526 | 1083.454 | 48.544 | 6.432 | d0/s7 | K24 |
| 527 | 1083.461 | 0.288 | 830.210 | d0/s7 | K25 |
| 528 | 1084.291 | 0.256 | 39.808 | d0/s7 | K26 |
| 529 | 1084.331 | 0.224 | 27.072 | d0/s7 | K27 |
| 530 | 1084.359 | 0.256 | 8.832 | d0/s7 | K28 |
| 531 | 1084.368 | 0.256 | 314.785 | d0/s7 | K29 |
| 532 | 1084.683 | 0.256 | 6.272 | d0/s7 | K30 |
| 533 | 1084.689 | 0.256 | 1089.123 | d0/s7 | K31 |
| 534 | 1085.779 | 0.256 | 1253.379 | d0/s7 | K32 |
| 535 | 1087.078 | 45.728 | 6.464 | d0/s7 | K24 |
| 536 | 1087.085 | 0.256 | 830.050 | d0/s7 | K25 |
| 537 | 1087.915 | 0.256 | 39.744 | d0/s7 | K26 |
| 538 | 1087.955 | 0.256 | 27.168 | d0/s7 | K27 |
| 539 | 1087.982 | 0.256 | 8.576 | d0/s7 | K28 |
| 540 | 1087.991 | 0.224 | 313.921 | d0/s7 | K29 |
| 541 | 1088.305 | 0.256 | 6.240 | d0/s7 | K30 |
| 542 | 1088.312 | 0.224 | 1089.154 | d0/s7 | K31 |
| 543 | 1089.401 | 0.257 | 1253.923 | d0/s7 | K32 |
| 544 | 1090.868 | 213.088 | 3.840 | d0/s7 | K33 |
| 545 | 1090.931 | 59.104 | 1.824 | d0/s7 | K34 |
| 546 | 1091.057 | 124.192 | 4.192 | d0/s7 | K35 |
| 547 | 1091.102 | 40.640 | 1.824 | d0/s7 | K9 |
| 548 | 1091.141 | 37.152 | 1.888 | d0/s7 | K36 |
| 549 | 1091.211 | 67.744 | 1.344 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 550 | 1091.263 | 51.007 | 0.864 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 551 | 1091.649 | 384.737 | 3.136 | d0/s7 | K37 |
| 552 | 1091.697 | 45.664 | 2.464 | d0/s7 | K38 |
| 553 | 1091.718 | 17.856 | 1.760 | d0/s7 | K19 |
| 554 | 1091.739 | 20.032 | 2.048 | d0/s7 | K39 |
| 555 | 1091.760 | 18.752 | 3.648 | d0/s7 | K40 |
| 556 | 1091.781 | 17.152 | 1.888 | d0/s7 | K41 |
| 557 | 1092.149 | 366.433 | 4.448 | d0/s7 | K42 |
| 558 | 1092.185 | 30.816 | 1.664 | d0/s7 | K43 |
| 559 | 1092.243 | 57.184 | 1.185 | d0/s7 | K44 |
| 560 | 1092.299 | 54.464 | 2.303 | d0/s7 | K45 |
| 561 | 1092.390 | 88.673 | 1.728 | d0/s7 | Memcpy DtoD (Device -> Device) (786432 B) |
| 562 | 1092.448 | 55.840 | 2.464 | d0/s7 | K46 |
| 563 | 1092.510 | 59.712 | 3.264 | d0/s7 | K47 |
| 564 | 1092.593 | 80.256 | 5.184 | d0/s7 | K48 |
| 565 | 1092.630 | 31.840 | 2.432 | d0/s7 | K49 |
| 566 | 1092.667 | 33.729 | 1.600 | d0/s7 | K9 |
| 567 | 1092.690 | 21.983 | 1.697 | d0/s7 | K36 |
| 568 | 1092.729 | 37.344 | 1.856 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 569 | 1092.773 | 41.568 | 1.888 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 570 | 1092.893 | 118.656 | 2.880 | d0/s7 | K50 |
| 571 | 1092.922 | 25.920 | 2.240 | d0/s7 | K51 |
| 572 | 1092.942 | 17.888 | 1.824 | d0/s7 | K52 |
| 573 | 1092.993 | 49.056 | 4.064 | d0/s7 | K35 |
| 574 | 1093.014 | 17.281 | 1.791 | d0/s7 | K9 |
| 575 | 1093.033 | 16.448 | 2.016 | d0/s7 | K36 |
| 576 | 1093.053 | 18.337 | 0.831 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 577 | 1093.083 | 29.472 | 1.952 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 578 | 1093.143 | 57.952 | 3.393 | d0/s7 | K53 |
| 579 | 1093.161 | 14.720 | 2.624 | d0/s7 | K54 |
| 580 | 1093.216 | 51.872 | 2.016 | d0/s7 | K55 |
| 581 | 1093.233 | 15.520 | 1.632 | d0/s7 | K22 |
| 582 | 1093.249 | 14.400 | 2.080 | d0/s7 | K56 |
| 583 | 1093.268 | 17.088 | 1.952 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 584 | 1093.298 | 27.648 | 1.888 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 585 | 1093.349 | 48.832 | 4.128 | d0/s7 | K50 |
| 586 | 1093.364 | 10.720 | 2.304 | d0/s7 | K51 |
| 587 | 1093.377 | 11.328 | 1.824 | d0/s7 | K52 |
| 588 | 1093.400 | 21.152 | 4.608 | d0/s7 | K35 |
| 589 | 1093.479 | 73.761 | 22.240 | d0/s7 | K57 |
| 590 | 1093.501 | 0.224 | 2.431 | d0/s7 | K38 |
| 591 | 1093.591 | 87.233 | 4.032 | d0/s7 | K42 |
| 592 | 1093.615 | 20.640 | 1.792 | d0/s7 | K43 |
| 593 | 1093.660 | 42.336 | 1.824 | d0/s7 | Memcpy DtoD (Device -> Device) (786432 B) |
| 594 | 1093.679 | 18.048 | 2.176 | d0/s7 | K46 |
| 595 | 1093.708 | 26.400 | 3.296 | d0/s7 | K47 |
| 596 | 1093.761 | 49.696 | 5.088 | d0/s7 | K48 |
| 597 | 1093.786 | 20.320 | 2.272 | d0/s7 | K49 |
| 598 | 1093.837 | 48.160 | 19.681 | d0/s7 | K58 |
| 599 | 1093.857 | 0.255 | 1.696 | d0/s7 | K52 |
| 600 | 1093.866 | 7.936 | 2.433 | d0/s7 | K51 |
| 601 | 1093.893 | 24.383 | 4.064 | d0/s7 | K35 |
| 602 | 1093.929 | 31.745 | 24.704 | d0/s7 | K59 |
| 603 | 1093.954 | 0.256 | 2.592 | d0/s7 | K54 |
| 604 | 1093.963 | 6.496 | 1.984 | d0/s7 | K55 |
| 605 | 1094.025 | 60.000 | 2.016 | d0/s7 | Memset (Device) (1536 B) |
| 606 | 1094.045 | 17.824 | 1.312 | d0/s7 | K60 |
| 607 | 1094.057 | 10.400 | 61.280 | d0/s7 | K61 |
| 608 | 1094.118 | 0.256 | 1.696 | d0/s7 | K52 |
| 609 | 1094.120 | 0.256 | 2.304 | d0/s7 | K51 |
| 610 | 1094.123 | 0.255 | 1.792 | d0/s7 | K52 |
| 611 | 1094.151 | 26.144 | 1.792 | d0/s7 | K62 |
| 612 | 1094.191 | 38.720 | 13.472 | d0/s7 | K63 |
| 613 | 1094.248 | 43.008 | 4.225 | d0/s7 | Memcpy DtoH (Device -> Pinned) (4 B) |
| 614 | 1094.311 | 59.135 | 0.864 | d0/s7 | Memcpy HtoD (Pageable -> Device) (56 B) |
| 615 | 1094.344 | 32.320 | 1.697 | d0/s7 | Memcpy HtoD (Pageable -> Device) (48 B) |
| 616 | 1094.411 | 65.664 | 4.160 | d0/s7 | K64 |
| 617 | 1094.439 | 23.168 | 3.808 | d0/s7 | K65 |
| 618 | 1094.454 | 11.872 | 4.512 | d0/s7 | K64 |
| 619 | 1094.469 | 9.888 | 3.840 | d0/s7 | K65 |
| 620 | 1094.483 | 10.752 | 1.600 | d0/s7 | K66 |
| 621 | 1094.502 | 16.640 | 1.568 | d0/s7 | K67 |
| 622 | 1094.521 | 17.536 | 2.496 | d0/s7 | K68 |
| 623 | 1094.536 | 12.672 | 3.456 | d0/s7 | Memcpy DtoH (Device -> Pinned) (4 B) |
| 624 | 1094.570 | 31.008 | 1.760 | d0/s7 | K62 |
| 625 | 1094.607 | 34.464 | 1.504 | d0/s7 | K69 |
| 626 | 1094.632 | 23.872 | 1.504 | d0/s7 | K70 |
| 627 | 1094.656 | 22.080 | 1.472 | d0/s7 | K71 |
| 628 | 1094.702 | 45.344 | 12.545 | d0/s7 | K72 |
| 629 | 1094.721 | 5.600 | 2.271 | d0/s7 | Memcpy DtoH (Device -> Pinned) (1 B) |
