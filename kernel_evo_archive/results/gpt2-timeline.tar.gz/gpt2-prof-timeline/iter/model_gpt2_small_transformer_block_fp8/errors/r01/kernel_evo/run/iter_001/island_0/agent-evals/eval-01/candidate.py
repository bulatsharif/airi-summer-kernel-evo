import cutlass
import cutlass.cute as cute


TOKENS = 128
HIDDEN_SIZE = 768
NUM_HEADS = 12
HEAD_DIM = 64
MLP_SIZE = 3072
QKV_SIZE = 3 * HIDDEN_SIZE
THREADS = 128
EPSILON = 1.0e-5

INPUT_SCALE = 1.0 / 448.0
NORM_SCALE = 1.0 / 64.0
QKV_SCALE = 1.0 / 64.0
CONTEXT_SCALE = 1.0 / 64.0
MLP_SCALE = 1.0 / 64.0
WEIGHT_H_SCALE = HIDDEN_SIZE ** -0.5 / 448.0
WEIGHT_MLP_SCALE = MLP_SIZE ** -0.5 / 448.0

# Per-GEMM combined scale = input_scale * weight_scale.
S_QKV = NORM_SCALE * WEIGHT_H_SCALE
S_OUT = CONTEXT_SCALE * WEIGHT_H_SCALE
S_FC = NORM_SCALE * WEIGHT_H_SCALE
S_PROJ = MLP_SCALE * WEIGHT_MLP_SCALE
# attention scores: q@k.T / sqrt(head_dim) with both operands scaled by QKV_SCALE.
SCORE_SCALE = QKV_SCALE * QKV_SCALE / 8.0
# context requant: P @ v_q  * QKV_SCALE / CONTEXT_SCALE  == 1.0
CONTEXT_RATIO = QKV_SCALE / CONTEXT_SCALE

FP8_DTYPE = cutlass.Float8E4M3FN


@cute.jit
def gelu_new(x):
    c = cutlass.Float32(0.7978845608028654)  # sqrt(2/pi)
    t = x + cutlass.Float32(0.044715) * x * x * x
    return cutlass.Float32(0.5) * x * (cutlass.Float32(1.0) + cute.tanh(c * t))


@cute.kernel
def layer_norm_fp8_kernel(
    hidden: cute.Tensor,
    weight: cute.Tensor,
    bias: cute.Tensor,
    output: cute.Tensor,
    in_scale,
    out_scale,
):
    tid, _, _ = cute.arch.thread_idx()
    token, _, _ = cute.arch.block_idx()
    smem = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, 2 * THREADS, 4),
        cute.make_layout(2 * THREADS),
    )
    s = cutlass.Float32(0.0)
    ss = cutlass.Float32(0.0)
    for t in cutlass.range_constexpr(HIDDEN_SIZE // THREADS):
        f = t * THREADS + tid
        x = hidden[token, f].to(cutlass.Float32) * cutlass.Float32(in_scale)
        s = s + x
        ss = ss + x * x
    smem[tid] = s
    smem[THREADS + tid] = ss
    cute.arch.sync_threads()
    total = cutlass.Float32(0.0)
    for j in cutlass.range_constexpr(THREADS):
        total = total + smem[j]
    total_ss = cutlass.Float32(0.0)
    for j in cutlass.range_constexpr(THREADS):
        total_ss = total_ss + smem[THREADS + j]
    mean = total / cutlass.Float32(HIDDEN_SIZE)
    var = total_ss / cutlass.Float32(HIDDEN_SIZE) - mean * mean
    rstd = cute.rsqrt(var + cutlass.Float32(EPSILON))
    for t in cutlass.range_constexpr(HIDDEN_SIZE // THREADS):
        f = t * THREADS + tid
        x = hidden[token, f].to(cutlass.Float32) * cutlass.Float32(in_scale)
        norm = (x - mean) * rstd * weight[f] + bias[f]
        output[token, f] = norm / cutlass.Float32(out_scale)


@cute.kernel
def linear_fp8_kernel(
    a: cute.Tensor,
    w: cute.Tensor,
    bias: cute.Tensor,
    aux: cute.Tensor,
    out: cute.Tensor,
    kind,
    M,
    N,
    K,
    acc_scale,
    out_scale,
):
    tid, _, _ = cute.arch.thread_idx()
    bx, by, _ = cute.arch.block_idx()
    n0 = bx * THREADS + tid
    m = by
    if n0 < N:
        acc = cutlass.Float32(0.0)
        for k in cutlass.range(K):
            acc = acc + a[m, k].to(cutlass.Float32) * w[n0, k].to(cutlass.Float32)
        bv = bias[n0].to(cutlass.Float32)
        if cutlass.const_expr(kind == 0):
            # qkv projection -> FP8 workspace
            out[m, n0] = (acc * cutlass.Float32(acc_scale) + bv) / cutlass.Float32(out_scale)
        elif cutlass.const_expr(kind == 1):
            # attention output projection + first residual (hidden)
            rv = (
                aux[m, n0].to(cutlass.Float32) * cutlass.Float32(INPUT_SCALE)
                + acc * cutlass.Float32(acc_scale)
                + bv
            )
            out[m, n0] = rv
        elif cutlass.const_expr(kind == 2):
            # MLP fc + GELU -> FP8 workspace
            g = gelu_new(acc * cutlass.Float32(acc_scale) + bv)
            out[m, n0] = g / cutlass.Float32(out_scale)
        else:
            # MLP projection + second residual add
            out[m, n0] = (
                aux[m, n0].to(cutlass.Float32) + acc * cutlass.Float32(acc_scale) + bv
            )


@cute.kernel
def attention_score_kernel(qkv: cute.Tensor, scores: cute.Tensor):
    h, i, _ = cute.arch.block_idx()
    j = cute.arch.thread_idx()[0]
    acc = cutlass.Float32(0.0)
    for d in cutlass.range_constexpr(HEAD_DIM):
        acc = acc + qkv[i, h * HEAD_DIM + d].to(cutlass.Float32) * qkv[
            j, HIDDEN_SIZE + h * HEAD_DIM + d
        ].to(cutlass.Float32)
    scores[h, i, j] = acc * cutlass.Float32(SCORE_SCALE)


@cute.kernel
def causal_softmax_kernel(scores: cute.Tensor, probabilities: cute.Tensor):
    h, i, _ = cute.arch.block_idx()
    j = cute.arch.thread_idx()[0]
    smem = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, THREADS, 4),
        cute.make_layout(THREADS),
    )
    val = scores[h, i, j].to(cutlass.Float32)
    causal = val if (j <= i) else cutlass.Float32(-3.0e38)
    smem[j] = causal
    cute.arch.sync_threads()
    mx = cutlass.Float32(-3.0e38)
    for jj in cutlass.range_constexpr(THREADS):
        vv = smem[jj]
        mx = vv if (vv > mx) else mx
    e = cute.exp(causal - mx)
    smem[j] = e
    cute.arch.sync_threads()
    total = cutlass.Float32(0.0)
    for jj in cutlass.range_constexpr(THREADS):
        total = total + smem[jj]
    probabilities[h, i, j] = e / total


@cute.kernel
def attention_context_kernel(
    probabilities: cute.Tensor,
    qkv: cute.Tensor,
    context: cute.Tensor,
):
    h, i, _ = cute.arch.block_idx()
    d = cute.arch.thread_idx()[0]
    acc = cutlass.Float32(0.0)
    for j in cutlass.range_constexpr(TOKENS):
        acc = acc + probabilities[h, i, j].to(cutlass.Float32) * qkv[
            j, 2 * HIDDEN_SIZE + h * HEAD_DIM + d
        ].to(cutlass.Float32)
    context[i, h * HEAD_DIM + d] = acc * cutlass.Float32(CONTEXT_RATIO)


@cute.jit
def gpt2_transformer_block(
    hidden: cute.Tensor,
    ln1_weight: cute.Tensor,
    ln1_bias: cute.Tensor,
    qkv_weight: cute.Tensor,
    qkv_bias: cute.Tensor,
    out_weight: cute.Tensor,
    out_bias: cute.Tensor,
    ln2_weight: cute.Tensor,
    ln2_bias: cute.Tensor,
    fc_weight: cute.Tensor,
    fc_bias: cute.Tensor,
    proj_weight: cute.Tensor,
    proj_bias: cute.Tensor,
    norm1_workspace: cute.Tensor,
    qkv_workspace: cute.Tensor,
    score_workspace: cute.Tensor,
    probability_workspace: cute.Tensor,
    context_workspace: cute.Tensor,
    residual_workspace: cute.Tensor,
    norm2_workspace: cute.Tensor,
    mlp_workspace: cute.Tensor,
    output: cute.Tensor,
):
    # n1 = layer_norm(hidden, ln1) -> FP8
    layer_norm_fp8_kernel(
        hidden, ln1_weight, ln1_bias, norm1_workspace, INPUT_SCALE, NORM_SCALE
    ).launch(grid=(TOKENS, 1, 1), block=(THREADS, 1, 1))

    # q, k, v = split(linear_fp8(n1, qkv)) -> FP8 qkv workspace
    linear_fp8_kernel(
        norm1_workspace,
        qkv_weight,
        qkv_bias,
        hidden,
        qkv_workspace,
        0,
        TOKENS,
        QKV_SIZE,
        HIDDEN_SIZE,
        S_QKV,
        QKV_SCALE,
    ).launch(grid=(QKV_SIZE // THREADS, TOKENS, 1), block=(THREADS, 1, 1))

    # scores = q @ k.T / sqrt(64)
    attention_score_kernel(qkv_workspace, score_workspace).launch(
        grid=(NUM_HEADS, TOKENS, 1), block=(THREADS, 1, 1)
    )
    # causal softmax
    causal_softmax_kernel(score_workspace, probability_workspace).launch(
        grid=(NUM_HEADS, TOKENS, 1), block=(THREADS, 1, 1)
    )
    # context = softmax @ v -> FP8
    attention_context_kernel(
        probability_workspace, qkv_workspace, context_workspace
    ).launch(grid=(NUM_HEADS, TOKENS, 1), block=(HEAD_DIM, 1, 1))

    # residual = hidden + linear_fp8(context, out)
    linear_fp8_kernel(
        context_workspace,
        out_weight,
        out_bias,
        hidden,
        residual_workspace,
        1,
        TOKENS,
        HIDDEN_SIZE,
        HIDDEN_SIZE,
        S_OUT,
        1.0,
    ).launch(grid=(HIDDEN_SIZE // THREADS, TOKENS, 1), block=(THREADS, 1, 1))

    # n2 = layer_norm(residual, ln2) -> FP8
    layer_norm_fp8_kernel(
        residual_workspace, ln2_weight, ln2_bias, norm2_workspace, 1.0, NORM_SCALE
    ).launch(grid=(TOKENS, 1, 1), block=(THREADS, 1, 1))

    # mlp = linear_fp8(gelu_new(linear_fp8(n2, fc)), proj)  (fc+gelu fused -> FP8)
    linear_fp8_kernel(
        norm2_workspace,
        fc_weight,
        fc_bias,
        residual_workspace,
        mlp_workspace,
        2,
        TOKENS,
        MLP_SIZE,
        HIDDEN_SIZE,
        S_FC,
        MLP_SCALE,
    ).launch(grid=(MLP_SIZE // THREADS, TOKENS, 1), block=(THREADS, 1, 1))

    # output = residual + mlp_proj
    linear_fp8_kernel(
        mlp_workspace,
        proj_weight,
        proj_bias,
        residual_workspace,
        output,
        3,
        TOKENS,
        HIDDEN_SIZE,
        MLP_SIZE,
        S_PROJ,
        1.0,
    ).launch(grid=(HIDDEN_SIZE // THREADS, TOKENS, 1), block=(THREADS, 1, 1))


class ModelNew:
    forward = staticmethod(gpt2_transformer_block)
