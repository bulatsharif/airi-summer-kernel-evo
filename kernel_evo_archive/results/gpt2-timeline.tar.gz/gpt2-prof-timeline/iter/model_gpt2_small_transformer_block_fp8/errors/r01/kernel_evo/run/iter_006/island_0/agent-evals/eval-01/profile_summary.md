# B300 device profile of your last candidate

- device: NVIDIA B300 SXM6 AC, 148 SMs, 232448 B opt-in shared memory/block
- GPU busy: 41.583 ms total; kernels 41.552 ms over 503 launches of 40 distinct names
- memcpy: 0.030 ms over 15 calls; memset: 0.002 ms over 1 calls

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_proj_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 19.109 | 55 | 46.0 |
| kernel_cutlass_fc_gelu_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmemal… | 8.841 | 55 | 21.3 |
| kernel_cutlass_qkv_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 4.876 | 55 | 11.7 |
| kernel_cutlass_out_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 4.858 | 55 | 11.7 |
| kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 3.090 | 55 | 7.4 |
| kernel_cutlass_ln2_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo7681_tensorptrf32gmemo… | 0.184 | 55 | 0.4 |
| kernel_cutlass_ln1_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo7681_tenso… | 0.173 | 55 | 0.4 |
| void sgemm_largek_lds64<true, false, 6, 3, 4, 5, 2, 66>(float*, float const*, float con… | 0.061 | 1 | 0.1 |
| cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 0.041 | 4 | 0.1 |
| void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 0.033 | 17 | 0.1 |
