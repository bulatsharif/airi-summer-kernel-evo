# B300 complete GPU timeline of your last candidate

- complete GPU-side trace: 519 activities; CPU/Python profiler records are intentionally omitted
- whole capture: span 2362.626 ms; active union 221.262 ms; idle holes 2141.365 ms (90.6%); largest hole 1871.121 ms
- that idle figure covers input generation, JIT compilation and the reference as well as your block, so it is not a measure of your kernels; the per-iteration section below is
- summed activity time: 221.262 ms; this may exceed active union when streams overlap
- source labels are hints: `candidate:<symbol>` is matched against this candidate's `@cute.kernel` definitions; other labels describe likely harness/runtime work
- candidate `@cute.kernel` symbols: `attention_output_kernel`, `fused_attention_kernel`, `layer_norm_fp8_kernel`, `mlp_fc_gelu_kernel`, `mlp_projection_kernel`, `qkv_projection_kernel`
- observed candidate symbols: `attention_output_kernel`, `fused_attention_kernel`, `layer_norm_fp8_kernel`, `mlp_fc_gelu_kernel`, `mlp_projection_kernel`, `qkv_projection_kernel`
- candidate symbols not observed in this trace: none

## One iteration of your block, launch by launch

Median of 55 timed iterations, 7 launches each. Microseconds from the start of the iteration.

- wall span 4017.962; kernels busy 4012.969; idle between your kernels 4.993 (0.1% of the span)
- largest single gap 3.776 immediately before `qkv_projection_kernel`
- 61.504 elapses between one iteration and the next; that is host-side dispatch outside your block, excluded from the idle figure above, and fusing cannot remove it

| # | kernel | id | start | end | dur | idle before |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 1 | layer_norm_fp8_kernel | K24 | 0.000 | 3.456 | 3.456 | — |
| 2 | qkv_projection_kernel | K25 | 7.232 | 837.954 | 830.722 | 3.776 |
| 3 | fused_attention_kernel | K26 | 838.178 | 1355.011 | 516.833 | 0.224 |
| 4 | attention_output_kernel | K27 | 1355.268 | 1669.572 | 314.304 | 0.257 |
| 5 | layer_norm_fp8_kernel | K28 | 1669.828 | 1673.252 | 3.424 | 0.256 |
| 6 | mlp_fc_gelu_kernel | K29 | 1673.508 | 2763.015 | 1089.507 | 0.256 |
| 7 | mlp_projection_kernel | K30 | 2763.239 | 4017.962 | 1254.723 | 0.224 |

## Hottest GPU kernels (legacy aggregate)

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_mlp_projection_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3F… | 69.068 | 55 | 31.2 |
| kernel_cutlass_mlp_fc_gelu_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgm… | 59.941 | 55 | 27.1 |
| kernel_cutlass_qkv_projection_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3F… | 45.685 | 55 | 20.6 |
| kernel_cutlass_fused_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3… | 28.431 | 55 | 12.8 |
| kernel_cutlass_attention_output_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M… | 17.310 | 55 | 7.8 |
| kernel_cutlass_layer_norm_fp8_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo7681_tensor… | 0.191 | 55 | 0.1 |
| kernel_cutlass_layer_norm_fp8_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmem… | 0.185 | 55 | 0.1 |
| void sgemm_largek_lds64<true, false, 6, 3, 4, 5, 2, 66>(float*, float const*, float con… | 0.062 | 1 | 0.0 |
| cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 0.041 | 4 | 0.0 |
| void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 0.033 | 17 | 0.0 |

## Kernel legend

| id | source hint | kernel | calls | total us | launch |
| --- | --- | --- | ---: | ---: | --- |
| K1 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 1 | 2.528 | grid=384x1x1, block=256x1x1, smem=0, regs=56 |
| K2 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 6 | 11.711 | grid=3x1x1, block=256x1x1, smem=0, regs=56 |
| K3 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 6 | 11.136 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K4 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::CUDAFunctorOnSelf_add<flo… | 2 | 3.552 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K5 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 1 | 1.792 | grid=9x1x1, block=256x1x1, smem=0, regs=56 |
| K6 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 2 | 3.392 | grid=3x1x1, block=128x1x1, smem=0, regs=32 |
| K7 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 1 | 2.144 | grid=12x1x1, block=256x1x1, smem=0, regs=56 |
| K8 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 4 | 21.792 | grid=1184x1x1, block=256x1x1, smem=0, regs=56 |
| K9 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 7 | 11.616 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K10 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 4 | 7.329 | grid=256x1x1, block=128x1x1, smem=0, regs=20 |
| K11 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 1 | 2.752 | grid=1728x1x1, block=128x1x1, smem=0, regs=32 |
| K12 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 2 | 8.544 | grid=4608x1x1, block=128x1x1, smem=0, regs=20 |
| K13 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 1 | 1.920 | grid=576x1x1, block=128x1x1, smem=0, regs=32 |
| K14 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 2.432 | grid=1536x1x1, block=128x1x1, smem=0, regs=20 |
| K15 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 6.591 | grid=2304x1x1, block=128x1x1, smem=0, regs=32 |
| K16 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 5.056 | grid=6144x1x1, block=128x1x1, smem=0, regs=20 |
| K17 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::… | 3 | 4.832 | grid=96x1x1, block=128x1x1, smem=0, regs=16 |
| K18 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::… | 1 | 1.408 | grid=288x1x1, block=128x1x1, smem=0, regs=16 |
| K19 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 3.328 | grid=288x1x1, block=128x1x1, smem=0, regs=32 |
| K20 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 1.952 | grid=640x1x1, block=128x1x1, smem=0, regs=20 |
| K21 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::… | 1 | 1.376 | grid=384x1x1, block=128x1x1, smem=0, regs=16 |
| K22 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 3.520 | grid=384x1x1, block=128x1x1, smem=0, regs=32 |
| K23 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 2.143 | grid=768x1x1, block=128x1x1, smem=0, regs=20 |
| K24 | candidate:layer_norm_fp8_kernel | kernel_cutlass_layer_norm_fp8_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmem… | 55 | 185.021 | grid=128x1x1, block=128x1x1, smem=1024, regs=32 |
| K25 | candidate:qkv_projection_kernel | kernel_cutlass_qkv_projection_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3F… | 55 | 45684.679 | grid=18x128x1, block=128x1x1, smem=0, regs=30 |
| K26 | candidate:fused_attention_kernel | kernel_cutlass_fused_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3… | 55 | 28431.104 | grid=12x128x1, block=64x1x1, smem=0, regs=255 |
| K27 | candidate:attention_output_kernel | kernel_cutlass_attention_output_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M… | 55 | 17310.057 | grid=6x128x1, block=128x1x1, smem=0, regs=30 |
| K28 | candidate:layer_norm_fp8_kernel | kernel_cutlass_layer_norm_fp8_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo7681_tensor… | 55 | 190.943 | grid=128x1x1, block=128x1x1, smem=1024, regs=32 |
| K29 | candidate:mlp_fc_gelu_kernel | kernel_cutlass_mlp_fc_gelu_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgm… | 55 | 59941.171 | grid=24x128x1, block=128x1x1, smem=0, regs=30 |
| K30 | candidate:mlp_projection_kernel | kernel_cutlass_mlp_projection_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3F… | 55 | 69067.882 | grid=6x128x1, block=128x1x1, smem=0, regs=30 |
| K31 | framework/validation | void at::native::unrolled_elementwise_kernel<at::native::direct_copy_kernel_cuda(at::Te… | 1 | 3.935 | grid=192x1x1, block=128x1x1, smem=0, regs=30 |
| K32 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 1 | 1.824 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K33 | framework/validation | void at::native::(anonymous namespace)::vectorized_layer_norm_kernel<float, float, fals… | 4 | 15.969 | grid=128x1x1, block=32x4x1, smem=24, regs=40 |
| K34 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::float8_copy_kernel_cuda(a… | 3 | 5.184 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K35 | framework/validation | nvjet_sm103_qqsss_64x32_128x16_2x1_2cta_v_bz_TNT | 1 | 3.104 | grid=144x1x1, block=256x1x1, smem=172552, regs=255 |
| K36 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 5.024 | grid=1152x1x1, block=128x1x1, smem=0, regs=20 |
| K37 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::float8_copy_kernel_cuda(a… | 1 | 2.048 | grid=288x1x1, block=128x1x1, smem=0, regs=32 |
| K38 | framework/validation | void at::native::unrolled_elementwise_kernel<at::native::direct_copy_kernel_cuda(at::Te… | 1 | 3.584 | grid=576x1x1, block=128x1x1, smem=0, regs=30 |
| K39 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 1 | 1.760 | grid=288x1x1, block=128x1x1, smem=0, regs=32 |
| K40 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 2 | 8.512 | grid=4x4x12, block=64x1x1, smem=13056, regs=72 |
| K41 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 3.456 | grid=192x1x1, block=128x1x1, smem=0, regs=32 |
| K42 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<bool>, std::a… | 1 | 1.216 | grid=8x1x1, block=128x1x1, smem=0, regs=16 |
| K43 | framework/validation | void at::native::triu_tril_kernel<bool, int, true, 8, false>(at::cuda::detail::TensorIn… | 1 | 2.272 | grid=16x1x1, block=128x1x1, smem=0, regs=30 |
| K44 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 4.577 | grid=768x1x1, block=128x1x1, smem=0, regs=20 |
| K45 | framework/validation | void (anonymous namespace)::softmax_warp_forward<float, float, float, 7, false, false>(… | 2 | 6.465 | grid=192x1x1, block=32x4x1, smem=0, regs=32 |
| K46 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_nnn_align1_bias_f32_relu | 2 | 10.080 | grid=2x4x12, block=64x1x1, smem=12672, regs=84 |
| K47 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 4.576 | grid=384x1x1, block=128x1x1, smem=0, regs=20 |
| K48 | framework/validation | nvjet_sm103_qqsss_64x16_128x16_2x4_2cta_h_bz_TNT | 2 | 7.008 | grid=96x1x1, block=256x1x1, smem=156168, regs=255 |
| K49 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 4 | 9.281 | grid=384x1x1, block=128x1x1, smem=0, regs=20 |
| K50 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::CUDAFunctor_add<float>, s… | 5 | 8.927 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K51 | framework/validation | nvjet_sm103_qqsss_48x64_128x16_2x2_2cta_h_bz_TNN | 1 | 3.360 | grid=128x1x1, block=256x1x1, smem=188944, regs=255 |
| K52 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 5.216 | grid=1536x1x1, block=128x1x1, smem=0, regs=20 |
| K53 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::GeluCUDAKernelImpl(at::Te… | 2 | 4.064 | grid=384x1x1, block=128x1x1, smem=0, regs=32 |
| K54 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::float8_copy_kernel_cuda(a… | 1 | 2.048 | grid=384x1x1, block=128x1x1, smem=0, regs=32 |
| K55 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 1 | 16.896 | grid=72x4x1, block=64x1x1, smem=13056, regs=72 |
| K56 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 1 | 15.264 | grid=24x4x1, block=64x1x1, smem=13056, regs=72 |
| K57 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_64x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 1 | 22.304 | grid=48x4x1, block=64x1x1, smem=19200, regs=146 |
| K58 | framework/validation | void scal_kernel<float, float, 1, true, 6, 5, 5, 3>(cublasTransposeParams<float>, float… | 1 | 1.312 | grid=12x4x1, block=256x1x1, smem=0, regs=24 |
| K59 | framework/validation | void sgemm_largek_lds64<true, false, 6, 3, 4, 5, 2, 66>(float*, float const*, float con… | 1 | 62.464 | grid=12x16x4, block=32x4x1, smem=4868, regs=32 |
| K60 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AbsFunctor<float>, std::a… | 2 | 2.848 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K61 | framework/validation | void at::native::reduce_kernel<512, 1, at::native::ReduceOp<float, at::native::func_wra… | 1 | 12.928 | grid=1x1x1, block=512x1x1, smem=2064, regs=30 |
| K62 | framework/validation | void at::native::(anonymous namespace)::indexSelectSmallIndex<float, long, unsigned int… | 2 | 8.864 | grid=6x1x1, block=128x1x1, smem=0, regs=28 |
| K63 | framework/validation | void at::native::(anonymous namespace)::indexSelectSmallIndex<float, long, unsigned int… | 2 | 8.064 | grid=1x1x1, block=7x1x1, smem=0, regs=28 |
| K64 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::CUDAFunctor_add<float>, s… | 1 | 1.760 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K65 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AbsFunctor<float>, std::a… | 1 | 1.792 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K66 | framework/validation | void at::native::reduce_kernel<512, 1, at::native::ReduceOp<float, at::native::func_wra… | 1 | 2.048 | grid=1x1x1, block=32x1x1, smem=16, regs=30 |
| K67 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 1 | 1.504 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K68 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BinaryFunctor<float, floa… | 1 | 1.504 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K69 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BinaryFunctor<bool, bool,… | 1 | 1.792 | grid=96x1x1, block=128x1x1, smem=0, regs=30 |
| K70 | framework/validation | void at::native::reduce_kernel<512, 1, at::native::ReduceOp<bool, at::native::func_wrap… | 1 | 12.832 | grid=1x1x1, block=512x1x1, smem=528, regs=28 |

## Ordered GPU activities

`gap before` is device-wide idle time since all earlier GPU activity ended; zero means overlap or no measurable hole.

| # | start ms | gap before us | duration us | lane | activity |
| ---: | ---: | ---: | ---: | --- | --- |
| 1 | 0.000 | 0.000 | 2.528 | d0/s7 | K1 |
| 2 | 0.053 | 50.945 | 2.143 | d0/s7 | K2 |
| 3 | 0.095 | 39.233 | 2.016 | d0/s7 | K3 |
| 4 | 0.130 | 33.504 | 1.600 | d0/s7 | K4 |
| 5 | 0.150 | 17.888 | 1.792 | d0/s7 | K2 |
| 6 | 0.162 | 10.432 | 1.568 | d0/s7 | K3 |
| 7 | 0.179 | 15.392 | 1.792 | d0/s7 | K2 |
| 8 | 0.191 | 10.080 | 1.952 | d0/s7 | K3 |
| 9 | 0.202 | 9.632 | 1.952 | d0/s7 | K4 |
| 10 | 0.219 | 14.688 | 2.112 | d0/s7 | K2 |
| 11 | 0.230 | 8.800 | 2.016 | d0/s7 | K3 |
| 12 | 0.247 | 15.424 | 1.792 | d0/s7 | K5 |
| 13 | 0.261 | 11.936 | 1.632 | d0/s7 | K6 |
| 14 | 0.278 | 14.784 | 1.760 | d0/s7 | K2 |
| 15 | 0.289 | 9.344 | 1.600 | d0/s7 | K3 |
| 16 | 0.304 | 13.856 | 2.144 | d0/s7 | K7 |
| 17 | 0.316 | 9.248 | 1.760 | d0/s7 | K6 |
| 18 | 0.332 | 14.944 | 2.112 | d0/s7 | K2 |
| 19 | 0.345 | 10.145 | 1.984 | d0/s7 | K3 |
| 20 | 0.365 | 18.656 | 5.728 | d0/s7 | K8 |
| 21 | 0.382 | 11.584 | 4.224 | d0/s7 | K8 |
| 22 | 0.400 | 13.024 | 5.920 | d0/s7 | K8 |
| 23 | 0.418 | 12.064 | 5.920 | d0/s7 | K8 |
| 24 | 0.453 | 28.928 | 1.792 | d0/s7 | K9 |
| 25 | 33.555 | 33100.331 | 1.920 | d0/s7 | K10 |
| 26 | 33.758 | 201.664 | 2.752 | d0/s7 | K11 |
| 27 | 58.108 | 24347.127 | 4.224 | d0/s7 | K12 |
| 28 | 58.287 | 174.209 | 1.920 | d0/s7 | K13 |
| 29 | 83.074 | 24785.627 | 2.432 | d0/s7 | K14 |
| 30 | 83.252 | 175.585 | 3.263 | d0/s7 | K15 |
| 31 | 107.372 | 24116.443 | 5.056 | d0/s7 | K16 |
| 32 | 107.550 | 173.536 | 3.328 | d0/s7 | K15 |
| 33 | 132.934 | 25380.189 | 4.320 | d0/s7 | K12 |
| 34 | 133.107 | 168.928 | 1.600 | d0/s7 | K17 |
| 35 | 133.169 | 60.577 | 1.792 | d0/s7 | K9 |
| 36 | 157.258 | 24087.034 | 1.760 | d0/s7 | K10 |
| 37 | 157.408 | 148.160 | 1.408 | d0/s7 | K18 |
| 38 | 157.466 | 56.256 | 1.504 | d0/s7 | K19 |
| 39 | 182.102 | 24634.940 | 1.952 | d0/s7 | K20 |
| 40 | 182.274 | 169.536 | 1.600 | d0/s7 | K17 |
| 41 | 182.333 | 57.536 | 1.760 | d0/s7 | K9 |
| 42 | 211.231 | 28896.645 | 1.857 | d0/s7 | K10 |
| 43 | 211.771 | 537.953 | 1.632 | d0/s7 | K17 |
| 44 | 211.938 | 165.568 | 1.376 | d0/s7 | K9 |
| 45 | 238.479 | 26538.848 | 1.792 | d0/s7 | K10 |
| 46 | 238.654 | 173.537 | 1.376 | d0/s7 | K21 |
| 47 | 238.725 | 70.048 | 1.600 | d0/s7 | K22 |
| 48 | 264.354 | 25626.718 | 2.143 | d0/s7 | K23 |
| 49 | 2135.477 | 1871121.210 | 3.968 | d0/s7 | K24 |
| 50 | 2135.488 | 7.137 | 830.338 | d0/s7 | K25 |
| 51 | 2136.319 | 0.255 | 515.554 | d0/s7 | K26 |
| 52 | 2136.834 | 0.256 | 314.496 | d0/s7 | K27 |
| 53 | 2137.149 | 0.225 | 3.680 | d0/s7 | K28 |
| 54 | 2137.153 | 0.254 | 1089.571 | d0/s7 | K29 |
| 55 | 2138.243 | 0.225 | 1255.939 | d0/s7 | K30 |
| 56 | 2139.499 | 0.256 | 3.424 | d0/s7 | K24 |
| 57 | 2139.503 | 0.256 | 830.626 | d0/s7 | K25 |
| 58 | 2140.334 | 0.256 | 519.393 | d0/s7 | K26 |
| 59 | 2140.853 | 0.256 | 314.657 | d0/s7 | K27 |
| 60 | 2141.168 | 0.256 | 3.392 | d0/s7 | K28 |
| 61 | 2141.172 | 0.256 | 1089.571 | d0/s7 | K29 |
| 62 | 2142.262 | 0.256 | 1256.995 | d0/s7 | K30 |
| 63 | 2143.519 | 0.256 | 3.264 | d0/s7 | K24 |
| 64 | 2143.522 | 0.256 | 831.106 | d0/s7 | K25 |
| 65 | 2144.354 | 0.256 | 513.953 | d0/s7 | K26 |
| 66 | 2144.868 | 0.256 | 314.881 | d0/s7 | K27 |
| 67 | 2145.183 | 0.256 | 3.520 | d0/s7 | K28 |
| 68 | 2145.187 | 0.256 | 1090.307 | d0/s7 | K29 |
| 69 | 2146.277 | 0.223 | 1256.292 | d0/s7 | K30 |
| 70 | 2147.534 | 0.256 | 3.264 | d0/s7 | K24 |
| 71 | 2147.538 | 0.256 | 830.882 | d0/s7 | K25 |
| 72 | 2148.369 | 0.256 | 521.537 | d0/s7 | K26 |
| 73 | 2148.890 | 0.256 | 315.168 | d0/s7 | K27 |
| 74 | 2149.206 | 0.257 | 3.488 | d0/s7 | K28 |
| 75 | 2149.210 | 0.255 | 1089.379 | d0/s7 | K29 |
| 76 | 2150.299 | 0.256 | 1255.939 | d0/s7 | K30 |
| 77 | 2151.555 | 0.256 | 3.296 | d0/s7 | K24 |
| 78 | 2151.559 | 0.256 | 831.106 | d0/s7 | K25 |
| 79 | 2152.390 | 0.224 | 516.065 | d0/s7 | K26 |
| 80 | 2152.907 | 0.256 | 314.945 | d0/s7 | K27 |
| 81 | 2153.222 | 0.256 | 3.488 | d0/s7 | K28 |
| 82 | 2153.226 | 0.256 | 1089.987 | d0/s7 | K29 |
| 83 | 2154.316 | 0.256 | 1256.355 | d0/s7 | K30 |
| 84 | 2155.755 | 182.752 | 3.264 | d0/s7 | K24 |
| 85 | 2155.763 | 4.288 | 830.818 | d0/s7 | K25 |
| 86 | 2156.594 | 0.256 | 515.714 | d0/s7 | K26 |
| 87 | 2157.110 | 0.256 | 314.624 | d0/s7 | K27 |
| 88 | 2157.424 | 0.256 | 3.520 | d0/s7 | K28 |
| 89 | 2157.428 | 0.257 | 1090.114 | d0/s7 | K29 |
| 90 | 2158.519 | 0.224 | 1255.075 | d0/s7 | K30 |
| 91 | 2159.835 | 61.504 | 3.456 | d0/s7 | K24 |
| 92 | 2159.842 | 3.776 | 830.722 | d0/s7 | K25 |
| 93 | 2160.673 | 0.224 | 516.833 | d0/s7 | K26 |
| 94 | 2161.190 | 0.257 | 314.304 | d0/s7 | K27 |
| 95 | 2161.505 | 0.256 | 3.424 | d0/s7 | K28 |
| 96 | 2161.509 | 0.256 | 1089.507 | d0/s7 | K29 |
| 97 | 2162.598 | 0.224 | 1254.723 | d0/s7 | K30 |
| 98 | 2163.901 | 47.488 | 3.424 | d0/s7 | K24 |
| 99 | 2163.907 | 3.040 | 830.402 | d0/s7 | K25 |
| 100 | 2164.738 | 0.256 | 515.553 | d0/s7 | K26 |
| 101 | 2165.254 | 0.256 | 314.433 | d0/s7 | K27 |
| 102 | 2165.568 | 0.256 | 3.424 | d0/s7 | K28 |
| 103 | 2165.572 | 0.256 | 1089.283 | d0/s7 | K29 |
| 104 | 2166.661 | 0.256 | 1256.547 | d0/s7 | K30 |
| 105 | 2167.964 | 45.760 | 3.424 | d0/s7 | K24 |
| 106 | 2167.971 | 3.584 | 830.658 | d0/s7 | K25 |
| 107 | 2168.802 | 0.256 | 514.529 | d0/s7 | K26 |
| 108 | 2169.316 | 0.224 | 314.369 | d0/s7 | K27 |
| 109 | 2169.631 | 0.256 | 3.424 | d0/s7 | K28 |
| 110 | 2169.635 | 0.256 | 1089.506 | d0/s7 | K29 |
| 111 | 2170.724 | 0.256 | 1256.803 | d0/s7 | K30 |
| 112 | 2172.027 | 45.216 | 3.391 | d0/s7 | K24 |
| 113 | 2172.033 | 3.104 | 830.499 | d0/s7 | K25 |
| 114 | 2172.864 | 0.255 | 514.242 | d0/s7 | K26 |
| 115 | 2173.378 | 0.256 | 314.945 | d0/s7 | K27 |
| 116 | 2173.693 | 0.255 | 3.392 | d0/s7 | K28 |
| 117 | 2173.697 | 0.288 | 1089.507 | d0/s7 | K29 |
| 118 | 2174.787 | 0.256 | 1255.299 | d0/s7 | K30 |
| 119 | 2176.090 | 48.192 | 3.296 | d0/s7 | K24 |
| 120 | 2176.097 | 3.104 | 830.210 | d0/s7 | K25 |
| 121 | 2176.927 | 0.256 | 515.745 | d0/s7 | K26 |
| 122 | 2177.443 | 0.257 | 314.816 | d0/s7 | K27 |
| 123 | 2177.758 | 0.224 | 3.520 | d0/s7 | K28 |
| 124 | 2177.762 | 0.256 | 1089.347 | d0/s7 | K29 |
| 125 | 2178.852 | 0.256 | 1256.483 | d0/s7 | K30 |
| 126 | 2180.157 | 48.416 | 3.296 | d0/s7 | K24 |
| 127 | 2180.163 | 3.360 | 830.434 | d0/s7 | K25 |
| 128 | 2180.994 | 0.256 | 513.985 | d0/s7 | K26 |
| 129 | 2181.508 | 0.224 | 314.529 | d0/s7 | K27 |
| 130 | 2181.823 | 0.256 | 3.520 | d0/s7 | K28 |
| 131 | 2181.827 | 0.256 | 1089.859 | d0/s7 | K29 |
| 132 | 2182.917 | 0.256 | 1256.067 | d0/s7 | K30 |
| 133 | 2184.218 | 44.992 | 3.264 | d0/s7 | K24 |
| 134 | 2184.224 | 2.720 | 830.434 | d0/s7 | K25 |
| 135 | 2185.055 | 0.288 | 521.217 | d0/s7 | K26 |
| 136 | 2185.576 | 0.256 | 315.233 | d0/s7 | K27 |
| 137 | 2185.892 | 0.256 | 3.488 | d0/s7 | K28 |
| 138 | 2185.895 | 0.288 | 1089.891 | d0/s7 | K29 |
| 139 | 2186.985 | 0.256 | 1254.722 | d0/s7 | K30 |
| 140 | 2188.285 | 45.089 | 3.296 | d0/s7 | K24 |
| 141 | 2188.292 | 3.104 | 830.786 | d0/s7 | K25 |
| 142 | 2189.123 | 0.256 | 512.545 | d0/s7 | K26 |
| 143 | 2189.636 | 0.256 | 314.721 | d0/s7 | K27 |
| 144 | 2189.950 | 0.255 | 3.520 | d0/s7 | K28 |
| 145 | 2189.954 | 0.255 | 1089.315 | d0/s7 | K29 |
| 146 | 2191.044 | 0.256 | 1254.691 | d0/s7 | K30 |
| 147 | 2192.344 | 45.568 | 3.424 | d0/s7 | K24 |
| 148 | 2192.351 | 3.649 | 830.018 | d0/s7 | K25 |
| 149 | 2193.181 | 0.223 | 513.954 | d0/s7 | K26 |
| 150 | 2193.696 | 0.256 | 314.336 | d0/s7 | K27 |
| 151 | 2194.010 | 0.288 | 3.424 | d0/s7 | K28 |
| 152 | 2194.014 | 0.256 | 1090.627 | d0/s7 | K29 |
| 153 | 2195.105 | 0.224 | 1254.883 | d0/s7 | K30 |
| 154 | 2196.408 | 48.224 | 3.424 | d0/s7 | K24 |
| 155 | 2196.414 | 2.720 | 830.818 | d0/s7 | K25 |
| 156 | 2197.245 | 0.256 | 514.081 | d0/s7 | K26 |
| 157 | 2197.759 | 0.257 | 314.400 | d0/s7 | K27 |
| 158 | 2198.074 | 0.256 | 3.424 | d0/s7 | K28 |
| 159 | 2198.078 | 0.256 | 1089.283 | d0/s7 | K29 |
| 160 | 2199.167 | 0.256 | 1256.291 | d0/s7 | K30 |
| 161 | 2200.471 | 47.264 | 3.424 | d0/s7 | K24 |
| 162 | 2200.477 | 3.136 | 830.594 | d0/s7 | K25 |
| 163 | 2201.308 | 0.256 | 513.569 | d0/s7 | K26 |
| 164 | 2201.822 | 0.256 | 314.625 | d0/s7 | K27 |
| 165 | 2202.137 | 0.256 | 3.424 | d0/s7 | K28 |
| 166 | 2202.141 | 0.256 | 1090.627 | d0/s7 | K29 |
| 167 | 2203.232 | 0.224 | 1256.003 | d0/s7 | K30 |
| 168 | 2204.532 | 44.160 | 3.424 | d0/s7 | K24 |
| 169 | 2204.538 | 3.008 | 830.210 | d0/s7 | K25 |
| 170 | 2205.369 | 0.256 | 521.281 | d0/s7 | K26 |
| 171 | 2205.890 | 0.288 | 314.657 | d0/s7 | K27 |
| 172 | 2206.205 | 0.256 | 3.424 | d0/s7 | K28 |
| 173 | 2206.209 | 0.256 | 1090.306 | d0/s7 | K29 |
| 174 | 2207.299 | 0.256 | 1256.004 | d0/s7 | K30 |
| 175 | 2208.599 | 43.935 | 3.297 | d0/s7 | K24 |
| 176 | 2208.606 | 3.072 | 830.498 | d0/s7 | K25 |
| 177 | 2209.436 | 0.224 | 512.353 | d0/s7 | K26 |
| 178 | 2209.949 | 0.256 | 314.881 | d0/s7 | K27 |
| 179 | 2210.264 | 0.223 | 3.520 | d0/s7 | K28 |
| 180 | 2210.268 | 0.257 | 1090.338 | d0/s7 | K29 |
| 181 | 2211.358 | 0.256 | 1255.203 | d0/s7 | K30 |
| 182 | 2212.661 | 47.424 | 3.328 | d0/s7 | K24 |
| 183 | 2212.668 | 3.937 | 832.577 | d0/s7 | K25 |
| 184 | 2213.501 | 0.256 | 513.794 | d0/s7 | K26 |
| 185 | 2214.015 | 0.255 | 314.882 | d0/s7 | K27 |
| 186 | 2214.330 | 0.223 | 3.520 | d0/s7 | K28 |
| 187 | 2214.334 | 0.257 | 1091.106 | d0/s7 | K29 |
| 188 | 2215.425 | 0.256 | 1256.355 | d0/s7 | K30 |
| 189 | 2216.732 | 49.856 | 3.296 | d0/s7 | K24 |
| 190 | 2216.738 | 2.944 | 830.754 | d0/s7 | K25 |
| 191 | 2217.569 | 0.256 | 516.353 | d0/s7 | K26 |
| 192 | 2218.085 | 0.224 | 315.201 | d0/s7 | K27 |
| 193 | 2218.401 | 0.256 | 3.488 | d0/s7 | K28 |
| 194 | 2218.405 | 0.256 | 1089.379 | d0/s7 | K29 |
| 195 | 2219.494 | 0.256 | 1255.331 | d0/s7 | K30 |
| 196 | 2220.795 | 45.248 | 3.296 | d0/s7 | K24 |
| 197 | 2220.801 | 2.656 | 830.498 | d0/s7 | K25 |
| 198 | 2221.632 | 0.256 | 515.745 | d0/s7 | K26 |
| 199 | 2222.148 | 0.256 | 314.593 | d0/s7 | K27 |
| 200 | 2222.462 | 0.256 | 3.520 | d0/s7 | K28 |
| 201 | 2222.466 | 0.256 | 1090.339 | d0/s7 | K29 |
| 202 | 2223.557 | 0.288 | 1256.675 | d0/s7 | K30 |
| 203 | 2224.858 | 44.417 | 3.456 | d0/s7 | K24 |
| 204 | 2224.865 | 3.232 | 830.402 | d0/s7 | K25 |
| 205 | 2225.695 | 0.224 | 518.561 | d0/s7 | K26 |
| 206 | 2226.214 | 0.256 | 314.849 | d0/s7 | K27 |
| 207 | 2226.529 | 0.256 | 3.424 | d0/s7 | K28 |
| 208 | 2226.533 | 0.256 | 1090.722 | d0/s7 | K29 |
| 209 | 2227.624 | 0.256 | 1255.523 | d0/s7 | K30 |
| 210 | 2228.924 | 44.513 | 3.455 | d0/s7 | K24 |
| 211 | 2228.930 | 2.753 | 831.201 | d0/s7 | K25 |
| 212 | 2229.762 | 0.257 | 514.337 | d0/s7 | K26 |
| 213 | 2230.276 | 0.288 | 314.529 | d0/s7 | K27 |
| 214 | 2230.591 | 0.225 | 3.423 | d0/s7 | K28 |
| 215 | 2230.595 | 0.288 | 1089.475 | d0/s7 | K29 |
| 216 | 2231.684 | 0.224 | 1255.075 | d0/s7 | K30 |
| 217 | 2232.988 | 48.160 | 3.424 | d0/s7 | K24 |
| 218 | 2232.993 | 2.464 | 831.010 | d0/s7 | K25 |
| 219 | 2233.825 | 0.256 | 522.786 | d0/s7 | K26 |
| 220 | 2234.348 | 0.256 | 315.040 | d0/s7 | K27 |
| 221 | 2234.663 | 0.256 | 3.424 | d0/s7 | K28 |
| 222 | 2234.667 | 0.256 | 1089.795 | d0/s7 | K29 |
| 223 | 2235.757 | 0.256 | 1256.867 | d0/s7 | K30 |
| 224 | 2237.059 | 44.928 | 3.424 | d0/s7 | K24 |
| 225 | 2237.065 | 3.424 | 830.722 | d0/s7 | K25 |
| 226 | 2237.896 | 0.256 | 520.193 | d0/s7 | K26 |
| 227 | 2238.417 | 0.288 | 314.561 | d0/s7 | K27 |
| 228 | 2238.732 | 0.256 | 3.424 | d0/s7 | K28 |
| 229 | 2238.735 | 0.256 | 1089.283 | d0/s7 | K29 |
| 230 | 2239.825 | 0.256 | 1257.827 | d0/s7 | K30 |
| 231 | 2241.129 | 46.272 | 3.264 | d0/s7 | K24 |
| 232 | 2241.136 | 3.647 | 832.290 | d0/s7 | K25 |
| 233 | 2241.968 | 0.256 | 518.209 | d0/s7 | K26 |
| 234 | 2242.487 | 0.256 | 314.497 | d0/s7 | K27 |
| 235 | 2242.802 | 0.256 | 3.520 | d0/s7 | K28 |
| 236 | 2242.805 | 0.256 | 1089.731 | d0/s7 | K29 |
| 237 | 2243.895 | 0.223 | 1256.100 | d0/s7 | K30 |
| 238 | 2245.199 | 47.872 | 3.296 | d0/s7 | K24 |
| 239 | 2245.205 | 2.752 | 830.114 | d0/s7 | K25 |
| 240 | 2246.036 | 0.256 | 522.849 | d0/s7 | K26 |
| 241 | 2246.559 | 0.224 | 314.817 | d0/s7 | K27 |
| 242 | 2246.874 | 0.256 | 3.520 | d0/s7 | K28 |
| 243 | 2246.878 | 0.256 | 1089.986 | d0/s7 | K29 |
| 244 | 2247.968 | 0.257 | 1254.658 | d0/s7 | K30 |
| 245 | 2249.269 | 46.208 | 3.263 | d0/s7 | K24 |
| 246 | 2249.275 | 3.105 | 829.985 | d0/s7 | K25 |
| 247 | 2250.105 | 0.256 | 519.362 | d0/s7 | K26 |
| 248 | 2250.625 | 0.256 | 314.657 | d0/s7 | K27 |
| 249 | 2250.940 | 0.255 | 3.520 | d0/s7 | K28 |
| 250 | 2250.944 | 0.257 | 1089.826 | d0/s7 | K29 |
| 251 | 2252.034 | 0.224 | 1256.035 | d0/s7 | K30 |
| 252 | 2253.333 | 43.167 | 3.296 | d0/s7 | K24 |
| 253 | 2253.339 | 2.656 | 830.690 | d0/s7 | K25 |
| 254 | 2254.170 | 0.256 | 518.145 | d0/s7 | K26 |
| 255 | 2254.688 | 0.257 | 314.432 | d0/s7 | K27 |
| 256 | 2255.003 | 0.256 | 3.520 | d0/s7 | K28 |
| 257 | 2255.007 | 0.256 | 1090.211 | d0/s7 | K29 |
| 258 | 2256.097 | 0.224 | 1254.499 | d0/s7 | K30 |
| 259 | 2257.398 | 46.400 | 3.456 | d0/s7 | K24 |
| 260 | 2257.405 | 3.424 | 831.234 | d0/s7 | K25 |
| 261 | 2258.236 | 0.256 | 524.129 | d0/s7 | K26 |
| 262 | 2258.761 | 0.256 | 314.593 | d0/s7 | K27 |
| 263 | 2259.076 | 0.256 | 3.424 | d0/s7 | K28 |
| 264 | 2259.079 | 0.256 | 1089.603 | d0/s7 | K29 |
| 265 | 2260.169 | 0.256 | 1256.867 | d0/s7 | K30 |
| 266 | 2261.471 | 44.800 | 3.424 | d0/s7 | K24 |
| 267 | 2261.477 | 2.880 | 830.722 | d0/s7 | K25 |
| 268 | 2262.308 | 0.224 | 514.177 | d0/s7 | K26 |
| 269 | 2262.823 | 0.256 | 314.913 | d0/s7 | K27 |
| 270 | 2263.138 | 0.256 | 3.456 | d0/s7 | K28 |
| 271 | 2263.141 | 0.224 | 1089.954 | d0/s7 | K29 |
| 272 | 2264.232 | 0.224 | 1255.363 | d0/s7 | K30 |
| 273 | 2265.530 | 42.977 | 3.424 | d0/s7 | K24 |
| 274 | 2265.536 | 2.688 | 830.369 | d0/s7 | K25 |
| 275 | 2266.367 | 0.257 | 517.633 | d0/s7 | K26 |
| 276 | 2266.885 | 0.256 | 314.465 | d0/s7 | K27 |
| 277 | 2267.199 | 0.256 | 3.424 | d0/s7 | K28 |
| 278 | 2267.203 | 0.256 | 1089.346 | d0/s7 | K29 |
| 279 | 2268.293 | 0.256 | 1255.203 | d0/s7 | K30 |
| 280 | 2269.592 | 44.449 | 3.391 | d0/s7 | K24 |
| 281 | 2269.599 | 2.977 | 830.209 | d0/s7 | K25 |
| 282 | 2270.429 | 0.257 | 514.689 | d0/s7 | K26 |
| 283 | 2270.944 | 0.256 | 315.456 | d0/s7 | K27 |
| 284 | 2271.260 | 0.288 | 3.392 | d0/s7 | K28 |
| 285 | 2271.263 | 0.257 | 1089.314 | d0/s7 | K29 |
| 286 | 2272.353 | 0.224 | 1255.651 | d0/s7 | K30 |
| 287 | 2273.656 | 47.264 | 3.264 | d0/s7 | K24 |
| 288 | 2273.662 | 3.168 | 830.434 | d0/s7 | K25 |
| 289 | 2274.493 | 0.256 | 519.265 | d0/s7 | K26 |
| 290 | 2275.013 | 0.257 | 315.104 | d0/s7 | K27 |
| 291 | 2275.328 | 0.256 | 3.520 | d0/s7 | K28 |
| 292 | 2275.332 | 0.256 | 1089.667 | d0/s7 | K29 |
| 293 | 2276.422 | 0.224 | 1255.011 | d0/s7 | K30 |
| 294 | 2277.738 | 60.960 | 3.296 | d0/s7 | K24 |
| 295 | 2277.743 | 2.336 | 830.050 | d0/s7 | K25 |
| 296 | 2278.573 | 0.256 | 521.345 | d0/s7 | K26 |
| 297 | 2279.095 | 0.224 | 315.073 | d0/s7 | K27 |
| 298 | 2279.410 | 0.256 | 3.488 | d0/s7 | K28 |
| 299 | 2279.414 | 0.256 | 1089.443 | d0/s7 | K29 |
| 300 | 2280.504 | 0.256 | 1255.203 | d0/s7 | K30 |
| 301 | 2281.805 | 46.432 | 3.264 | d0/s7 | K24 |
| 302 | 2281.811 | 2.208 | 830.242 | d0/s7 | K25 |
| 303 | 2282.641 | 0.256 | 516.449 | d0/s7 | K26 |
| 304 | 2283.158 | 0.256 | 314.721 | d0/s7 | K27 |
| 305 | 2283.473 | 0.256 | 3.488 | d0/s7 | K28 |
| 306 | 2283.477 | 0.288 | 1089.474 | d0/s7 | K29 |
| 307 | 2284.567 | 0.257 | 1259.683 | d0/s7 | K30 |
| 308 | 2285.871 | 44.896 | 3.263 | d0/s7 | K24 |
| 309 | 2285.877 | 2.273 | 832.513 | d0/s7 | K25 |
| 310 | 2286.709 | 0.257 | 514.753 | d0/s7 | K26 |
| 311 | 2287.224 | 0.256 | 314.785 | d0/s7 | K27 |
| 312 | 2287.540 | 0.255 | 3.520 | d0/s7 | K28 |
| 313 | 2287.543 | 0.257 | 1089.378 | d0/s7 | K29 |
| 314 | 2288.633 | 0.256 | 1255.619 | d0/s7 | K30 |
| 315 | 2289.934 | 45.280 | 3.456 | d0/s7 | K24 |
| 316 | 2289.940 | 3.200 | 830.210 | d0/s7 | K25 |
| 317 | 2290.771 | 0.256 | 515.234 | d0/s7 | K26 |
| 318 | 2291.286 | 0.256 | 314.496 | d0/s7 | K27 |
| 319 | 2291.601 | 0.256 | 3.424 | d0/s7 | K28 |
| 320 | 2291.605 | 0.256 | 1089.731 | d0/s7 | K29 |
| 321 | 2292.695 | 0.256 | 1256.899 | d0/s7 | K30 |
| 322 | 2293.997 | 45.312 | 3.424 | d0/s7 | K24 |
| 323 | 2294.004 | 3.296 | 830.530 | d0/s7 | K25 |
| 324 | 2294.835 | 0.256 | 515.169 | d0/s7 | K26 |
| 325 | 2295.350 | 0.256 | 314.337 | d0/s7 | K27 |
| 326 | 2295.665 | 0.256 | 3.424 | d0/s7 | K28 |
| 327 | 2295.668 | 0.288 | 1089.603 | d0/s7 | K29 |
| 328 | 2296.758 | 0.256 | 1255.907 | d0/s7 | K30 |
| 329 | 2298.061 | 46.656 | 3.424 | d0/s7 | K24 |
| 330 | 2298.067 | 2.944 | 830.658 | d0/s7 | K25 |
| 331 | 2298.898 | 0.256 | 514.337 | d0/s7 | K26 |
| 332 | 2299.413 | 0.256 | 314.817 | d0/s7 | K27 |
| 333 | 2299.728 | 0.256 | 3.456 | d0/s7 | K28 |
| 334 | 2299.731 | 0.256 | 1089.443 | d0/s7 | K29 |
| 335 | 2300.821 | 0.255 | 1255.364 | d0/s7 | K30 |
| 336 | 2302.124 | 47.104 | 3.456 | d0/s7 | K24 |
| 337 | 2302.130 | 2.720 | 830.722 | d0/s7 | K25 |
| 338 | 2302.961 | 0.256 | 518.945 | d0/s7 | K26 |
| 339 | 2303.480 | 0.256 | 314.657 | d0/s7 | K27 |
| 340 | 2303.795 | 0.256 | 3.456 | d0/s7 | K28 |
| 341 | 2303.799 | 0.256 | 1090.178 | d0/s7 | K29 |
| 342 | 2304.889 | 0.256 | 1255.140 | d0/s7 | K30 |
| 343 | 2306.187 | 42.400 | 3.263 | d0/s7 | K24 |
| 344 | 2306.193 | 3.040 | 830.370 | d0/s7 | K25 |
| 345 | 2307.023 | 0.257 | 515.009 | d0/s7 | K26 |
| 346 | 2307.539 | 0.256 | 314.977 | d0/s7 | K27 |
| 347 | 2307.854 | 0.224 | 3.520 | d0/s7 | K28 |
| 348 | 2307.858 | 0.256 | 1089.442 | d0/s7 | K29 |
| 349 | 2308.947 | 0.256 | 1255.139 | d0/s7 | K30 |
| 350 | 2310.248 | 45.472 | 3.296 | d0/s7 | K24 |
| 351 | 2310.253 | 1.888 | 830.498 | d0/s7 | K25 |
| 352 | 2311.084 | 0.256 | 523.458 | d0/s7 | K26 |
| 353 | 2311.608 | 0.255 | 314.785 | d0/s7 | K27 |
| 354 | 2311.923 | 0.257 | 3.520 | d0/s7 | K28 |
| 355 | 2311.926 | 0.255 | 1089.891 | d0/s7 | K29 |
| 356 | 2313.017 | 0.256 | 1254.819 | d0/s7 | K30 |
| 357 | 2314.315 | 44.064 | 3.264 | d0/s7 | K24 |
| 358 | 2314.322 | 2.848 | 830.338 | d0/s7 | K25 |
| 359 | 2315.152 | 0.256 | 519.905 | d0/s7 | K26 |
| 360 | 2315.672 | 0.256 | 314.817 | d0/s7 | K27 |
| 361 | 2315.987 | 0.256 | 3.488 | d0/s7 | K28 |
| 362 | 2315.991 | 0.256 | 1090.307 | d0/s7 | K29 |
| 363 | 2317.082 | 0.256 | 1255.011 | d0/s7 | K30 |
| 364 | 2318.382 | 45.344 | 3.264 | d0/s7 | K24 |
| 365 | 2318.388 | 3.008 | 830.210 | d0/s7 | K25 |
| 366 | 2319.219 | 0.256 | 513.665 | d0/s7 | K26 |
| 367 | 2319.733 | 0.256 | 314.369 | d0/s7 | K27 |
| 368 | 2320.047 | 0.256 | 3.520 | d0/s7 | K28 |
| 369 | 2320.051 | 0.256 | 1090.147 | d0/s7 | K29 |
| 370 | 2321.142 | 0.255 | 1255.876 | d0/s7 | K30 |
| 371 | 2322.443 | 45.216 | 3.424 | d0/s7 | K24 |
| 372 | 2322.450 | 3.936 | 830.562 | d0/s7 | K25 |
| 373 | 2323.281 | 0.256 | 524.385 | d0/s7 | K26 |
| 374 | 2323.805 | 0.256 | 314.593 | d0/s7 | K27 |
| 375 | 2324.120 | 0.256 | 3.424 | d0/s7 | K28 |
| 376 | 2324.124 | 0.256 | 1089.986 | d0/s7 | K29 |
| 377 | 2325.214 | 0.256 | 1256.035 | d0/s7 | K30 |
| 378 | 2326.514 | 44.224 | 3.425 | d0/s7 | K24 |
| 379 | 2326.520 | 2.368 | 830.273 | d0/s7 | K25 |
| 380 | 2327.351 | 0.225 | 515.969 | d0/s7 | K26 |
| 381 | 2327.867 | 0.256 | 314.433 | d0/s7 | K27 |
| 382 | 2328.182 | 0.288 | 3.423 | d0/s7 | K28 |
| 383 | 2328.185 | 0.257 | 1089.986 | d0/s7 | K29 |
| 384 | 2329.276 | 0.256 | 1255.587 | d0/s7 | K30 |
| 385 | 2330.575 | 44.000 | 3.424 | d0/s7 | K24 |
| 386 | 2330.581 | 2.400 | 830.434 | d0/s7 | K25 |
| 387 | 2331.412 | 0.256 | 518.817 | d0/s7 | K26 |
| 388 | 2331.931 | 0.257 | 314.656 | d0/s7 | K27 |
| 389 | 2332.246 | 0.256 | 3.424 | d0/s7 | K28 |
| 390 | 2332.249 | 0.288 | 1089.603 | d0/s7 | K29 |
| 391 | 2333.339 | 0.256 | 1255.683 | d0/s7 | K30 |
| 392 | 2334.639 | 44.416 | 3.424 | d0/s7 | K24 |
| 393 | 2334.646 | 2.848 | 830.082 | d0/s7 | K25 |
| 394 | 2335.476 | 0.224 | 521.889 | d0/s7 | K26 |
| 395 | 2335.998 | 0.288 | 314.817 | d0/s7 | K27 |
| 396 | 2336.313 | 0.256 | 3.392 | d0/s7 | K28 |
| 397 | 2336.317 | 0.256 | 1089.955 | d0/s7 | K29 |
| 398 | 2337.407 | 0.256 | 1256.547 | d0/s7 | K30 |
| 399 | 2338.715 | 51.296 | 3.296 | d0/s7 | K24 |
| 400 | 2338.721 | 2.368 | 830.434 | d0/s7 | K25 |
| 401 | 2339.551 | 0.256 | 512.097 | d0/s7 | K26 |
| 402 | 2340.064 | 0.256 | 315.041 | d0/s7 | K27 |
| 403 | 2340.379 | 0.256 | 3.520 | d0/s7 | K28 |
| 404 | 2340.383 | 0.256 | 1090.147 | d0/s7 | K29 |
| 405 | 2341.473 | 0.255 | 1254.820 | d0/s7 | K30 |
| 406 | 2342.774 | 46.367 | 3.297 | d0/s7 | K24 |
| 407 | 2342.780 | 2.816 | 830.594 | d0/s7 | K25 |
| 408 | 2343.611 | 0.256 | 513.857 | d0/s7 | K26 |
| 409 | 2344.125 | 0.256 | 314.848 | d0/s7 | K27 |
| 410 | 2344.440 | 0.257 | 3.520 | d0/s7 | K28 |
| 411 | 2344.444 | 0.256 | 1090.146 | d0/s7 | K29 |
| 412 | 2345.535 | 0.256 | 1254.531 | d0/s7 | K30 |
| 413 | 2346.839 | 49.344 | 3.264 | d0/s7 | K24 |
| 414 | 2346.844 | 2.529 | 830.369 | d0/s7 | K25 |
| 415 | 2347.675 | 0.257 | 514.049 | d0/s7 | K26 |
| 416 | 2348.189 | 0.224 | 314.560 | d0/s7 | K27 |
| 417 | 2348.504 | 0.256 | 3.489 | d0/s7 | K28 |
| 418 | 2348.508 | 0.255 | 1089.923 | d0/s7 | K29 |
| 419 | 2349.598 | 0.256 | 1256.355 | d0/s7 | K30 |
| 420 | 2350.901 | 46.176 | 3.264 | d0/s7 | K24 |
| 421 | 2350.912 | 7.968 | 830.818 | d0/s7 | K25 |
| 422 | 2351.743 | 0.256 | 516.129 | d0/s7 | K26 |
| 423 | 2352.259 | 0.256 | 315.009 | d0/s7 | K27 |
| 424 | 2352.574 | 0.288 | 3.488 | d0/s7 | K28 |
| 425 | 2352.578 | 0.256 | 1089.955 | d0/s7 | K29 |
| 426 | 2353.668 | 0.256 | 1255.395 | d0/s7 | K30 |
| 427 | 2354.969 | 44.736 | 3.456 | d0/s7 | K24 |
| 428 | 2354.975 | 3.456 | 830.402 | d0/s7 | K25 |
| 429 | 2355.806 | 0.256 | 513.313 | d0/s7 | K26 |
| 430 | 2356.320 | 0.256 | 314.657 | d0/s7 | K27 |
| 431 | 2356.635 | 0.255 | 3.424 | d0/s7 | K28 |
| 432 | 2356.638 | 0.256 | 1090.371 | d0/s7 | K29 |
| 433 | 2357.729 | 0.256 | 1254.915 | d0/s7 | K30 |
| 434 | 2359.352 | 368.545 | 3.935 | d0/s7 | K31 |
| 435 | 2359.438 | 81.473 | 1.824 | d0/s7 | K32 |
| 436 | 2359.555 | 115.840 | 3.968 | d0/s7 | K33 |
| 437 | 2359.601 | 41.792 | 1.664 | d0/s7 | K9 |
| 438 | 2359.646 | 42.880 | 1.728 | d0/s7 | K34 |
| 439 | 2359.731 | 83.648 | 1.760 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 440 | 2359.783 | 49.792 | 1.697 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 441 | 2359.980 | 195.392 | 3.104 | d0/s7 | K35 |
| 442 | 2360.024 | 41.504 | 2.528 | d0/s7 | K36 |
| 443 | 2360.046 | 18.880 | 1.824 | d0/s7 | K19 |
| 444 | 2360.068 | 20.288 | 2.048 | d0/s7 | K37 |
| 445 | 2360.087 | 16.672 | 3.584 | d0/s7 | K38 |
| 446 | 2360.106 | 15.744 | 1.760 | d0/s7 | K39 |
| 447 | 2360.363 | 254.977 | 4.352 | d0/s7 | K40 |
| 448 | 2360.400 | 33.056 | 1.664 | d0/s7 | K41 |
| 449 | 2360.453 | 51.136 | 1.216 | d0/s7 | K42 |
| 450 | 2360.491 | 36.512 | 2.272 | d0/s7 | K43 |
| 451 | 2360.553 | 60.256 | 1.825 | d0/s7 | Memcpy DtoD (Device -> Device) (786432 B) |
| 452 | 2360.579 | 24.511 | 2.369 | d0/s7 | K44 |
| 453 | 2360.611 | 28.735 | 3.297 | d0/s7 | K45 |
| 454 | 2360.676 | 62.400 | 5.024 | d0/s7 | K46 |
| 455 | 2360.723 | 41.280 | 2.336 | d0/s7 | K47 |
| 456 | 2360.744 | 18.880 | 1.632 | d0/s7 | K9 |
| 457 | 2360.766 | 20.416 | 1.728 | d0/s7 | K34 |
| 458 | 2360.799 | 31.456 | 1.056 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 459 | 2360.837 | 36.736 | 1.920 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 460 | 2360.925 | 85.889 | 2.847 | d0/s7 | K48 |
| 461 | 2360.950 | 22.465 | 2.368 | d0/s7 | K49 |
| 462 | 2360.969 | 16.479 | 1.792 | d0/s7 | K50 |
| 463 | 2361.009 | 38.080 | 4.064 | d0/s7 | K33 |
| 464 | 2361.028 | 15.296 | 1.600 | d0/s7 | K9 |
| 465 | 2361.044 | 14.592 | 1.728 | d0/s7 | K34 |
| 466 | 2361.065 | 18.784 | 1.952 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 467 | 2361.095 | 28.512 | 1.728 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 468 | 2361.149 | 52.352 | 3.360 | d0/s7 | K51 |
| 469 | 2361.165 | 11.968 | 2.624 | d0/s7 | K52 |
| 470 | 2361.201 | 34.240 | 2.080 | d0/s7 | K53 |
| 471 | 2361.215 | 11.744 | 1.920 | d0/s7 | K22 |
| 472 | 2361.231 | 13.760 | 2.048 | d0/s7 | K54 |
| 473 | 2361.262 | 28.672 | 1.952 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 474 | 2361.294 | 30.720 | 1.856 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 475 | 2361.343 | 46.464 | 4.161 | d0/s7 | K48 |
| 476 | 2361.358 | 10.943 | 2.177 | d0/s7 | K49 |
| 477 | 2361.371 | 10.720 | 1.695 | d0/s7 | K50 |
| 478 | 2361.394 | 21.568 | 3.840 | d0/s7 | K33 |
| 479 | 2361.452 | 54.081 | 16.896 | d0/s7 | K55 |
| 480 | 2361.469 | 0.256 | 2.496 | d0/s7 | K36 |
| 481 | 2361.554 | 82.176 | 4.160 | d0/s7 | K40 |
| 482 | 2361.579 | 20.992 | 1.792 | d0/s7 | K41 |
| 483 | 2361.620 | 38.976 | 1.824 | d0/s7 | Memcpy DtoD (Device -> Device) (786432 B) |
| 484 | 2361.638 | 16.800 | 2.208 | d0/s7 | K44 |
| 485 | 2361.660 | 20.000 | 3.168 | d0/s7 | K45 |
| 486 | 2361.723 | 59.296 | 5.056 | d0/s7 | K46 |
| 487 | 2361.750 | 22.400 | 2.240 | d0/s7 | K47 |
| 488 | 2361.782 | 29.375 | 15.264 | d0/s7 | K56 |
| 489 | 2361.798 | 0.832 | 1.792 | d0/s7 | K50 |
| 490 | 2361.811 | 11.008 | 2.432 | d0/s7 | K49 |
| 491 | 2361.837 | 24.032 | 4.097 | d0/s7 | K33 |
| 492 | 2361.870 | 28.800 | 22.304 | d0/s7 | K57 |
| 493 | 2361.893 | 0.255 | 2.592 | d0/s7 | K52 |
| 494 | 2361.903 | 7.296 | 1.984 | d0/s7 | K53 |
| 495 | 2361.946 | 41.600 | 1.056 | d0/s7 | Memset (Device) (1536 B) |
| 496 | 2361.961 | 14.016 | 1.312 | d0/s7 | K58 |
| 497 | 2361.972 | 9.184 | 62.464 | d0/s7 | K59 |
| 498 | 2362.035 | 0.256 | 1.824 | d0/s7 | K50 |
| 499 | 2362.037 | 0.224 | 2.304 | d0/s7 | K49 |
| 500 | 2362.039 | 0.256 | 1.824 | d0/s7 | K50 |
| 501 | 2362.086 | 45.120 | 1.472 | d0/s7 | K60 |
| 502 | 2362.124 | 36.576 | 12.928 | d0/s7 | K61 |
| 503 | 2362.167 | 30.176 | 3.329 | d0/s7 | Memcpy DtoH (Device -> Pinned) (4 B) |
| 504 | 2362.228 | 57.567 | 1.728 | d0/s7 | Memcpy HtoD (Pageable -> Device) (56 B) |
| 505 | 2362.270 | 40.097 | 0.864 | d0/s7 | Memcpy HtoD (Pageable -> Device) (48 B) |
| 506 | 2362.329 | 57.760 | 4.160 | d0/s7 | K62 |
| 507 | 2362.346 | 13.152 | 3.840 | d0/s7 | K63 |
| 508 | 2362.361 | 10.784 | 4.704 | d0/s7 | K62 |
| 509 | 2362.375 | 9.472 | 4.224 | d0/s7 | K63 |
| 510 | 2362.389 | 9.856 | 1.760 | d0/s7 | K64 |
| 511 | 2362.405 | 14.560 | 1.792 | d0/s7 | K65 |
| 512 | 2362.425 | 18.080 | 2.048 | d0/s7 | K66 |
| 513 | 2362.438 | 11.296 | 3.456 | d0/s7 | Memcpy DtoH (Device -> Pinned) (4 B) |
| 514 | 2362.488 | 46.624 | 1.376 | d0/s7 | K60 |
| 515 | 2362.515 | 25.312 | 1.504 | d0/s7 | K67 |
| 516 | 2362.537 | 20.544 | 1.504 | d0/s7 | K68 |
| 517 | 2362.561 | 22.272 | 1.792 | d0/s7 | K69 |
| 518 | 2362.608 | 44.801 | 12.832 | d0/s7 | K70 |
| 519 | 2362.624 | 3.743 | 2.272 | d0/s7 | Memcpy DtoH (Device -> Pinned) (1 B) |
