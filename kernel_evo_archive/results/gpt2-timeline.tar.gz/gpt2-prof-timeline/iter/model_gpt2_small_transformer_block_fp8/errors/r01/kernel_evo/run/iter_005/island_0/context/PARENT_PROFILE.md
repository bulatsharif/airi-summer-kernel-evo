# Parent profile and optimization guidance

# B300 complete GPU timeline of your last candidate

- complete GPU-side trace: 519 activities; CPU/Python profiler records are intentionally omitted
- whole capture: span 20617.928 ms; active union 65.078 ms; idle holes 20552.850 ms (99.7%); largest hole 20287.962 ms
- that idle figure covers input generation, JIT compilation and the reference as well as your block, so it is not a measure of your kernels; the per-iteration section below is
- summed activity time: 65.078 ms; this may exceed active union when streams overlap
- source labels are hints: `candidate:<symbol>` is matched against this candidate's `@cute.kernel` definitions; other labels describe likely harness/runtime work
- candidate `@cute.kernel` symbols: `attention_kernel`, `fc_gelu_kernel`, `ln1_kernel`, `ln2_kernel`, `out_gemm_kernel`, `proj_gemm_kernel`, `qkv_gemm_kernel`
- observed candidate symbols: `attention_kernel`, `fc_gelu_kernel`, `ln1_kernel`, `ln2_kernel`, `out_gemm_kernel`, `proj_gemm_kernel`, `qkv_gemm_kernel`
- candidate symbols not observed in this trace: none

## One iteration of your block, launch by launch

Median of 55 timed iterations, 7 launches each. Microseconds from the start of the iteration.

- wall span 1176.932; kernels busy 1174.404; idle between your kernels 2.528 (0.2% of the span)
- largest single gap 1.088 immediately before `qkv_gemm_kernel`
- 44.992 elapses between one iteration and the next; that is host-side dispatch outside your block, excluded from the idle figure above, and fusing cannot remove it

| # | kernel | id | start | end | dur | idle before |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 1 | ln1_kernel | K24 | 0.000 | 3.137 | 3.137 | — |
| 2 | qkv_gemm_kernel | K25 | 4.225 | 163.009 | 158.784 | 1.088 |
| 3 | attention_kernel | K26 | 163.265 | 219.617 | 56.352 | 0.256 |
| 4 | out_gemm_kernel | K27 | 219.873 | 384.130 | 164.257 | 0.256 |
| 5 | ln2_kernel | K28 | 384.386 | 387.810 | 3.424 | 0.256 |
| 6 | fc_gelu_kernel | K29 | 388.066 | 552.002 | 163.936 | 0.256 |
| 7 | proj_gemm_kernel | K30 | 552.418 | 1176.932 | 624.514 | 0.416 |

## Hottest GPU kernels (legacy aggregate)

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_proj_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 34.365 | 55 | 52.8 |
| kernel_cutlass_out_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 9.046 | 55 | 13.9 |
| kernel_cutlass_fc_gelu_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmemal… | 9.016 | 55 | 13.8 |
| kernel_cutlass_qkv_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 8.733 | 55 | 13.4 |
| kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 3.102 | 55 | 4.8 |
| kernel_cutlass_ln2_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo7681_tensorptrf32gmemo… | 0.186 | 55 | 0.3 |
| kernel_cutlass_ln1_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo7681_tenso… | 0.174 | 55 | 0.3 |
| void sgemm_largek_lds64<true, false, 6, 3, 4, 5, 2, 66>(float*, float const*, float con… | 0.060 | 1 | 0.1 |
| cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 0.047 | 4 | 0.1 |
| void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 0.033 | 17 | 0.1 |

## Kernel legend

| id | source hint | kernel | calls | total us | launch |
| --- | --- | --- | ---: | ---: | --- |
| K1 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 1 | 2.528 | grid=384x1x1, block=256x1x1, smem=0, regs=56 |
| K2 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 6 | 11.649 | grid=3x1x1, block=256x1x1, smem=0, regs=56 |
| K3 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 6 | 11.200 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K4 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::CUDAFunctorOnSelf_add<flo… | 2 | 3.616 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K5 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 1 | 1.824 | grid=9x1x1, block=256x1x1, smem=0, regs=56 |
| K6 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 2 | 3.200 | grid=3x1x1, block=128x1x1, smem=0, regs=32 |
| K7 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 1 | 2.144 | grid=12x1x1, block=256x1x1, smem=0, regs=56 |
| K8 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 4 | 21.857 | grid=1184x1x1, block=256x1x1, smem=0, regs=56 |
| K9 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 7 | 11.712 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K10 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 4 | 7.360 | grid=256x1x1, block=128x1x1, smem=0, regs=20 |
| K11 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 1 | 2.688 | grid=1728x1x1, block=128x1x1, smem=0, regs=32 |
| K12 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 2 | 8.640 | grid=4608x1x1, block=128x1x1, smem=0, regs=20 |
| K13 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 1 | 1.888 | grid=576x1x1, block=128x1x1, smem=0, regs=32 |
| K14 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 2.464 | grid=1536x1x1, block=128x1x1, smem=0, regs=20 |
| K15 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 6.464 | grid=2304x1x1, block=128x1x1, smem=0, regs=32 |
| K16 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 5.024 | grid=6144x1x1, block=128x1x1, smem=0, regs=20 |
| K17 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::… | 3 | 4.832 | grid=96x1x1, block=128x1x1, smem=0, regs=16 |
| K18 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::… | 1 | 1.408 | grid=288x1x1, block=128x1x1, smem=0, regs=16 |
| K19 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 3.328 | grid=288x1x1, block=128x1x1, smem=0, regs=32 |
| K20 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 1.984 | grid=640x1x1, block=128x1x1, smem=0, regs=20 |
| K21 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::… | 1 | 1.376 | grid=384x1x1, block=128x1x1, smem=0, regs=16 |
| K22 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 3.455 | grid=384x1x1, block=128x1x1, smem=0, regs=32 |
| K23 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 2.112 | grid=768x1x1, block=128x1x1, smem=0, regs=20 |
| K24 | candidate:ln1_kernel | kernel_cutlass_ln1_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo7681_tenso… | 55 | 174.437 | grid=128x1x1, block=128x1x1, smem=1024, regs=32 |
| K25 | candidate:qkv_gemm_kernel | kernel_cutlass_qkv_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 55 | 8733.084 | grid=18x1x1, block=128x1x1, smem=65536, regs=255 |
| K26 | candidate:attention_kernel | kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 55 | 3102.090 | grid=12x128x1, block=128x1x1, smem=1024, regs=40 |
| K27 | candidate:out_gemm_kernel | kernel_cutlass_out_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 55 | 9045.538 | grid=6x1x1, block=128x1x1, smem=65536, regs=255 |
| K28 | candidate:ln2_kernel | kernel_cutlass_ln2_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo7681_tensorptrf32gmemo… | 55 | 185.927 | grid=128x1x1, block=128x1x1, smem=1024, regs=32 |
| K29 | candidate:fc_gelu_kernel | kernel_cutlass_fc_gelu_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmemal… | 55 | 9016.222 | grid=24x1x1, block=128x1x1, smem=65536, regs=255 |
| K30 | candidate:proj_gemm_kernel | kernel_cutlass_proj_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 55 | 34364.877 | grid=6x1x1, block=128x1x1, smem=65536, regs=255 |
| K31 | framework/validation | void at::native::unrolled_elementwise_kernel<at::native::direct_copy_kernel_cuda(at::Te… | 1 | 3.680 | grid=192x1x1, block=128x1x1, smem=0, regs=30 |
| K32 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 1 | 1.824 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K33 | framework/validation | void at::native::(anonymous namespace)::vectorized_layer_norm_kernel<float, float, fals… | 4 | 16.031 | grid=128x1x1, block=32x4x1, smem=24, regs=40 |
| K34 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::float8_copy_kernel_cuda(a… | 3 | 5.152 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K35 | framework/validation | nvjet_sm103_qqsss_64x32_128x16_2x1_2cta_v_bz_TNT | 1 | 3.104 | grid=144x1x1, block=256x1x1, smem=172552, regs=255 |
| K36 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 5.088 | grid=1152x1x1, block=128x1x1, smem=0, regs=20 |
| K37 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::float8_copy_kernel_cuda(a… | 1 | 2.048 | grid=288x1x1, block=128x1x1, smem=0, regs=32 |
| K38 | framework/validation | void at::native::unrolled_elementwise_kernel<at::native::direct_copy_kernel_cuda(at::Te… | 1 | 3.649 | grid=576x1x1, block=128x1x1, smem=0, regs=30 |
| K39 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 1 | 1.792 | grid=288x1x1, block=128x1x1, smem=0, regs=32 |
| K40 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 2 | 8.512 | grid=4x4x12, block=64x1x1, smem=13056, regs=72 |
| K41 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 3.520 | grid=192x1x1, block=128x1x1, smem=0, regs=32 |
| K42 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<bool>, std::a… | 1 | 1.216 | grid=8x1x1, block=128x1x1, smem=0, regs=16 |
| K43 | framework/validation | void at::native::triu_tril_kernel<bool, int, true, 8, false>(at::cuda::detail::TensorIn… | 1 | 2.304 | grid=16x1x1, block=128x1x1, smem=0, regs=30 |
| K44 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 4.608 | grid=768x1x1, block=128x1x1, smem=0, regs=20 |
| K45 | framework/validation | void (anonymous namespace)::softmax_warp_forward<float, float, float, 7, false, false>(… | 2 | 6.368 | grid=192x1x1, block=32x4x1, smem=0, regs=32 |
| K46 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_nnn_align1_bias_f32_relu | 2 | 10.080 | grid=2x4x12, block=64x1x1, smem=12672, regs=84 |
| K47 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 4.512 | grid=384x1x1, block=128x1x1, smem=0, regs=20 |
| K48 | framework/validation | nvjet_sm103_qqsss_64x16_128x16_2x4_2cta_h_bz_TNT | 2 | 7.072 | grid=96x1x1, block=256x1x1, smem=156168, regs=255 |
| K49 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 4 | 9.408 | grid=384x1x1, block=128x1x1, smem=0, regs=20 |
| K50 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::CUDAFunctor_add<float>, s… | 5 | 9.152 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K51 | framework/validation | nvjet_sm103_qqsss_48x64_128x16_2x2_2cta_h_bz_TNN | 1 | 3.392 | grid=128x1x1, block=256x1x1, smem=188944, regs=255 |
| K52 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 5.247 | grid=1536x1x1, block=128x1x1, smem=0, regs=20 |
| K53 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::GeluCUDAKernelImpl(at::Te… | 2 | 4.031 | grid=384x1x1, block=128x1x1, smem=0, regs=32 |
| K54 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::float8_copy_kernel_cuda(a… | 1 | 2.047 | grid=384x1x1, block=128x1x1, smem=0, regs=32 |
| K55 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 1 | 19.936 | grid=72x4x1, block=64x1x1, smem=13056, regs=72 |
| K56 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 1 | 18.816 | grid=24x4x1, block=64x1x1, smem=13056, regs=72 |
| K57 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_64x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 1 | 22.432 | grid=48x4x1, block=64x1x1, smem=19200, regs=146 |
| K58 | framework/validation | void scal_kernel<float, float, 1, true, 6, 5, 5, 3>(cublasTransposeParams<float>, float… | 1 | 1.312 | grid=12x4x1, block=256x1x1, smem=0, regs=24 |
| K59 | framework/validation | void sgemm_largek_lds64<true, false, 6, 3, 4, 5, 2, 66>(float*, float const*, float con… | 1 | 60.448 | grid=12x16x4, block=32x4x1, smem=4868, regs=32 |
| K60 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AbsFunctor<float>, std::a… | 2 | 2.880 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K61 | framework/validation | void at::native::reduce_kernel<512, 1, at::native::ReduceOp<float, at::native::func_wra… | 1 | 12.864 | grid=1x1x1, block=512x1x1, smem=2064, regs=30 |
| K62 | framework/validation | void at::native::(anonymous namespace)::indexSelectSmallIndex<float, long, unsigned int… | 2 | 9.120 | grid=6x1x1, block=128x1x1, smem=0, regs=28 |
| K63 | framework/validation | void at::native::(anonymous namespace)::indexSelectSmallIndex<float, long, unsigned int… | 2 | 8.256 | grid=1x1x1, block=7x1x1, smem=0, regs=28 |
| K64 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::CUDAFunctor_add<float>, s… | 1 | 1.984 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K65 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AbsFunctor<float>, std::a… | 1 | 1.824 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K66 | framework/validation | void at::native::reduce_kernel<512, 1, at::native::ReduceOp<float, at::native::func_wra… | 1 | 2.272 | grid=1x1x1, block=32x1x1, smem=16, regs=30 |
| K67 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 1 | 1.504 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K68 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BinaryFunctor<float, floa… | 1 | 1.535 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K69 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BinaryFunctor<bool, bool,… | 1 | 1.793 | grid=96x1x1, block=128x1x1, smem=0, regs=30 |
| K70 | framework/validation | void at::native::reduce_kernel<512, 1, at::native::ReduceOp<bool, at::native::func_wrap… | 1 | 12.960 | grid=1x1x1, block=512x1x1, smem=528, regs=28 |

## Ordered GPU activities

`gap before` is device-wide idle time since all earlier GPU activity ended; zero means overlap or no measurable hole.

| # | start ms | gap before us | duration us | lane | activity |
| ---: | ---: | ---: | ---: | --- | --- |
| 1 | 0.000 | 0.000 | 2.528 | d0/s7 | K1 |
| 2 | 0.118 | 115.328 | 1.953 | d0/s7 | K2 |
| 3 | 0.163 | 43.040 | 1.984 | d0/s7 | K3 |
| 4 | 0.208 | 43.136 | 1.600 | d0/s7 | K4 |
| 5 | 0.229 | 19.040 | 1.792 | d0/s7 | K2 |
| 6 | 0.241 | 10.624 | 1.600 | d0/s7 | K3 |
| 7 | 0.257 | 14.592 | 1.792 | d0/s7 | K2 |
| 8 | 0.269 | 9.824 | 1.984 | d0/s7 | K3 |
| 9 | 0.280 | 9.024 | 2.016 | d0/s7 | K4 |
| 10 | 0.295 | 13.312 | 2.144 | d0/s7 | K2 |
| 11 | 0.307 | 9.440 | 2.016 | d0/s7 | K3 |
| 12 | 0.323 | 14.496 | 1.824 | d0/s7 | K5 |
| 13 | 0.335 | 10.016 | 1.440 | d0/s7 | K6 |
| 14 | 0.351 | 14.016 | 1.824 | d0/s7 | K2 |
| 15 | 0.361 | 8.352 | 1.600 | d0/s7 | K3 |
| 16 | 0.377 | 14.240 | 2.144 | d0/s7 | K7 |
| 17 | 0.388 | 9.632 | 1.760 | d0/s7 | K6 |
| 18 | 0.404 | 13.824 | 2.144 | d0/s7 | K2 |
| 19 | 0.414 | 8.256 | 2.016 | d0/s7 | K3 |
| 20 | 0.441 | 24.384 | 5.760 | d0/s7 | K8 |
| 21 | 0.458 | 11.073 | 4.224 | d0/s7 | K8 |
| 22 | 0.473 | 10.943 | 5.953 | d0/s7 | K8 |
| 23 | 0.492 | 12.927 | 5.920 | d0/s7 | K8 |
| 24 | 0.536 | 38.337 | 1.792 | d0/s7 | K9 |
| 25 | 31.497 | 30958.976 | 1.920 | d0/s7 | K10 |
| 26 | 31.687 | 188.929 | 2.688 | d0/s7 | K11 |
| 27 | 57.832 | 26142.289 | 4.256 | d0/s7 | K12 |
| 28 | 58.023 | 186.625 | 1.888 | d0/s7 | K13 |
| 29 | 84.173 | 26148.049 | 2.464 | d0/s7 | K14 |
| 30 | 84.370 | 194.241 | 3.200 | d0/s7 | K15 |
| 31 | 109.877 | 25504.239 | 5.024 | d0/s7 | K16 |
| 32 | 110.057 | 174.081 | 3.264 | d0/s7 | K15 |
| 33 | 135.015 | 24955.181 | 4.384 | d0/s7 | K12 |
| 34 | 135.216 | 196.769 | 1.632 | d0/s7 | K17 |
| 35 | 135.276 | 58.432 | 1.824 | d0/s7 | K9 |
| 36 | 159.718 | 24440.012 | 1.760 | d0/s7 | K10 |
| 37 | 159.874 | 153.857 | 1.408 | d0/s7 | K18 |
| 38 | 159.933 | 57.728 | 1.504 | d0/s7 | K19 |
| 39 | 184.638 | 24703.533 | 1.984 | d0/s7 | K20 |
| 40 | 184.792 | 152.128 | 1.568 | d0/s7 | K17 |
| 41 | 184.852 | 58.112 | 1.792 | d0/s7 | K9 |
| 42 | 209.385 | 24531.468 | 1.888 | d0/s7 | K10 |
| 43 | 209.539 | 152.577 | 1.632 | d0/s7 | K17 |
| 44 | 209.601 | 59.776 | 1.408 | d0/s7 | K9 |
| 45 | 234.095 | 24492.556 | 1.792 | d0/s7 | K10 |
| 46 | 234.263 | 166.465 | 1.376 | d0/s7 | K21 |
| 47 | 234.329 | 64.256 | 1.568 | d0/s7 | K22 |
| 48 | 259.142 | 24811.469 | 2.112 | d0/s7 | K23 |
| 49 | 20547.106 | 20287962.453 | 3.777 | d0/s7 | K24 |
| 50 | 20547.121 | 11.296 | 162.816 | d0/s7 | K25 |
| 51 | 20547.284 | 0.256 | 56.672 | d0/s7 | K26 |
| 52 | 20547.341 | 0.256 | 168.609 | d0/s7 | K27 |
| 53 | 20547.510 | 0.256 | 4.000 | d0/s7 | K28 |
| 54 | 20547.514 | 0.256 | 174.496 | d0/s7 | K29 |
| 55 | 20547.689 | 0.416 | 640.002 | d0/s7 | K30 |
| 56 | 20548.330 | 0.256 | 3.200 | d0/s7 | K24 |
| 57 | 20548.333 | 0.288 | 158.561 | d0/s7 | K25 |
| 58 | 20548.492 | 0.256 | 56.416 | d0/s7 | K26 |
| 59 | 20548.549 | 0.256 | 164.545 | d0/s7 | K27 |
| 60 | 20548.713 | 0.255 | 3.328 | d0/s7 | K28 |
| 61 | 20548.717 | 0.289 | 163.584 | d0/s7 | K29 |
| 62 | 20548.881 | 0.416 | 624.386 | d0/s7 | K30 |
| 63 | 20549.506 | 0.256 | 3.104 | d0/s7 | K24 |
| 64 | 20549.509 | 0.288 | 158.784 | d0/s7 | K25 |
| 65 | 20549.668 | 0.257 | 56.735 | d0/s7 | K26 |
| 66 | 20549.725 | 0.257 | 164.224 | d0/s7 | K27 |
| 67 | 20549.890 | 0.288 | 3.392 | d0/s7 | K28 |
| 68 | 20549.893 | 0.256 | 163.681 | d0/s7 | K29 |
| 69 | 20550.057 | 0.448 | 624.130 | d0/s7 | K30 |
| 70 | 20550.682 | 0.288 | 3.103 | d0/s7 | K24 |
| 71 | 20550.685 | 0.257 | 158.720 | d0/s7 | K25 |
| 72 | 20550.844 | 0.256 | 56.320 | d0/s7 | K26 |
| 73 | 20550.901 | 0.289 | 164.481 | d0/s7 | K27 |
| 74 | 20551.065 | 0.256 | 3.392 | d0/s7 | K28 |
| 75 | 20551.069 | 0.288 | 163.809 | d0/s7 | K29 |
| 76 | 20551.233 | 0.415 | 624.546 | d0/s7 | K30 |
| 77 | 20551.858 | 0.256 | 3.104 | d0/s7 | K24 |
| 78 | 20551.861 | 0.256 | 158.913 | d0/s7 | K25 |
| 79 | 20552.021 | 0.256 | 56.096 | d0/s7 | K26 |
| 80 | 20552.077 | 0.256 | 164.449 | d0/s7 | K27 |
| 81 | 20552.242 | 0.287 | 3.360 | d0/s7 | K28 |
| 82 | 20552.245 | 0.288 | 163.585 | d0/s7 | K29 |
| 83 | 20552.409 | 0.448 | 624.834 | d0/s7 | K30 |
| 84 | 20553.163 | 128.545 | 3.071 | d0/s7 | K24 |
| 85 | 20553.168 | 1.729 | 158.816 | d0/s7 | K25 |
| 86 | 20553.327 | 0.256 | 56.480 | d0/s7 | K26 |
| 87 | 20553.383 | 0.288 | 164.033 | d0/s7 | K27 |
| 88 | 20553.548 | 0.255 | 3.425 | d0/s7 | K28 |
| 89 | 20553.551 | 0.255 | 163.905 | d0/s7 | K29 |
| 90 | 20553.716 | 0.448 | 624.674 | d0/s7 | K30 |
| 91 | 20554.403 | 62.625 | 3.232 | d0/s7 | K24 |
| 92 | 20554.408 | 1.344 | 158.977 | d0/s7 | K25 |
| 93 | 20554.567 | 0.256 | 56.288 | d0/s7 | K26 |
| 94 | 20554.623 | 0.256 | 164.224 | d0/s7 | K27 |
| 95 | 20554.788 | 0.288 | 3.297 | d0/s7 | K28 |
| 96 | 20554.792 | 0.287 | 163.777 | d0/s7 | K29 |
| 97 | 20554.956 | 0.448 | 624.770 | d0/s7 | K30 |
| 98 | 20555.631 | 50.880 | 3.200 | d0/s7 | K24 |
| 99 | 20555.637 | 2.176 | 158.465 | d0/s7 | K25 |
| 100 | 20555.796 | 0.288 | 56.416 | d0/s7 | K26 |
| 101 | 20555.852 | 0.256 | 164.288 | d0/s7 | K27 |
| 102 | 20556.017 | 0.256 | 3.328 | d0/s7 | K28 |
| 103 | 20556.020 | 0.288 | 163.713 | d0/s7 | K29 |
| 104 | 20556.184 | 0.417 | 624.674 | d0/s7 | K30 |
| 105 | 20556.853 | 43.616 | 3.168 | d0/s7 | K24 |
| 106 | 20556.857 | 1.120 | 158.785 | d0/s7 | K25 |
| 107 | 20557.016 | 0.255 | 56.512 | d0/s7 | K26 |
| 108 | 20557.073 | 0.257 | 164.224 | d0/s7 | K27 |
| 109 | 20557.237 | 0.288 | 3.328 | d0/s7 | K28 |
| 110 | 20557.241 | 0.256 | 163.585 | d0/s7 | K29 |
| 111 | 20557.405 | 0.448 | 624.354 | d0/s7 | K30 |
| 112 | 20558.073 | 43.296 | 3.232 | d0/s7 | K24 |
| 113 | 20558.077 | 0.768 | 158.656 | d0/s7 | K25 |
| 114 | 20558.236 | 0.256 | 56.512 | d0/s7 | K26 |
| 115 | 20558.292 | 0.256 | 164.449 | d0/s7 | K27 |
| 116 | 20558.457 | 0.256 | 3.328 | d0/s7 | K28 |
| 117 | 20558.461 | 0.256 | 163.616 | d0/s7 | K29 |
| 118 | 20558.625 | 0.448 | 624.226 | d0/s7 | K30 |
| 119 | 20559.293 | 44.385 | 3.104 | d0/s7 | K24 |
| 120 | 20559.297 | 0.896 | 158.720 | d0/s7 | K25 |
| 121 | 20559.456 | 0.256 | 56.448 | d0/s7 | K26 |
| 122 | 20559.513 | 0.256 | 164.257 | d0/s7 | K27 |
| 123 | 20559.677 | 0.256 | 3.424 | d0/s7 | K28 |
| 124 | 20559.681 | 0.256 | 163.680 | d0/s7 | K29 |
| 125 | 20559.845 | 0.416 | 624.450 | d0/s7 | K30 |
| 126 | 20560.514 | 43.872 | 3.072 | d0/s7 | K24 |
| 127 | 20560.518 | 1.186 | 158.816 | d0/s7 | K25 |
| 128 | 20560.677 | 0.256 | 56.544 | d0/s7 | K26 |
| 129 | 20560.734 | 0.256 | 164.673 | d0/s7 | K27 |
| 130 | 20560.899 | 0.288 | 3.392 | d0/s7 | K28 |
| 131 | 20560.902 | 0.256 | 164.064 | d0/s7 | K29 |
| 132 | 20561.067 | 0.448 | 624.674 | d0/s7 | K30 |
| 133 | 20561.734 | 42.625 | 3.136 | d0/s7 | K24 |
| 134 | 20561.738 | 0.704 | 159.265 | d0/s7 | K25 |
| 135 | 20561.897 | 0.256 | 56.192 | d0/s7 | K26 |
| 136 | 20561.954 | 0.256 | 164.481 | d0/s7 | K27 |
| 137 | 20562.119 | 0.255 | 3.392 | d0/s7 | K28 |
| 138 | 20562.122 | 0.256 | 163.585 | d0/s7 | K29 |
| 139 | 20562.286 | 0.448 | 624.674 | d0/s7 | K30 |
| 140 | 20562.954 | 43.200 | 3.104 | d0/s7 | K24 |
| 141 | 20562.959 | 1.472 | 158.753 | d0/s7 | K25 |
| 142 | 20563.118 | 0.255 | 56.545 | d0/s7 | K26 |
| 143 | 20563.175 | 0.255 | 164.417 | d0/s7 | K27 |
| 144 | 20563.339 | 0.256 | 3.392 | d0/s7 | K28 |
| 145 | 20563.343 | 0.256 | 163.841 | d0/s7 | K29 |
| 146 | 20563.507 | 0.448 | 624.098 | d0/s7 | K30 |
| 147 | 20564.176 | 45.056 | 3.232 | d0/s7 | K24 |
| 148 | 20564.189 | 9.632 | 158.593 | d0/s7 | K25 |
| 149 | 20564.348 | 0.255 | 56.352 | d0/s7 | K26 |
| 150 | 20564.405 | 0.257 | 164.672 | d0/s7 | K27 |
| 151 | 20564.570 | 0.256 | 3.328 | d0/s7 | K28 |
| 152 | 20564.573 | 0.256 | 163.937 | d0/s7 | K29 |
| 153 | 20564.738 | 0.447 | 624.259 | d0/s7 | K30 |
| 154 | 20565.405 | 43.135 | 3.200 | d0/s7 | K24 |
| 155 | 20565.409 | 1.025 | 158.592 | d0/s7 | K25 |
| 156 | 20565.568 | 0.256 | 56.288 | d0/s7 | K26 |
| 157 | 20565.625 | 0.256 | 164.257 | d0/s7 | K27 |
| 158 | 20565.789 | 0.256 | 3.328 | d0/s7 | K28 |
| 159 | 20565.793 | 0.256 | 163.680 | d0/s7 | K29 |
| 160 | 20565.957 | 0.416 | 624.418 | d0/s7 | K30 |
| 161 | 20566.624 | 42.912 | 3.200 | d0/s7 | K24 |
| 162 | 20566.629 | 1.536 | 158.465 | d0/s7 | K25 |
| 163 | 20566.788 | 0.256 | 56.448 | d0/s7 | K26 |
| 164 | 20566.844 | 0.288 | 164.193 | d0/s7 | K27 |
| 165 | 20567.009 | 0.255 | 3.361 | d0/s7 | K28 |
| 166 | 20567.012 | 0.256 | 163.776 | d0/s7 | K29 |
| 167 | 20567.177 | 0.448 | 625.218 | d0/s7 | K30 |
| 168 | 20567.845 | 43.680 | 3.200 | d0/s7 | K24 |
| 169 | 20567.850 | 1.024 | 158.561 | d0/s7 | K25 |
| 170 | 20568.009 | 0.256 | 56.512 | d0/s7 | K26 |
| 171 | 20568.065 | 0.256 | 164.640 | d0/s7 | K27 |
| 172 | 20568.230 | 0.257 | 3.328 | d0/s7 | K28 |
| 173 | 20568.234 | 0.255 | 163.617 | d0/s7 | K29 |
| 174 | 20568.398 | 0.448 | 624.194 | d0/s7 | K30 |
| 175 | 20569.065 | 42.976 | 3.104 | d0/s7 | K24 |
| 176 | 20569.069 | 1.056 | 158.817 | d0/s7 | K25 |
| 177 | 20569.228 | 0.255 | 56.705 | d0/s7 | K26 |
| 178 | 20569.285 | 0.256 | 164.256 | d0/s7 | K27 |
| 179 | 20569.450 | 0.256 | 3.424 | d0/s7 | K28 |
| 180 | 20569.453 | 0.256 | 163.681 | d0/s7 | K29 |
| 181 | 20569.618 | 0.448 | 624.418 | d0/s7 | K30 |
| 182 | 20570.286 | 43.584 | 3.104 | d0/s7 | K24 |
| 183 | 20570.290 | 0.960 | 158.752 | d0/s7 | K25 |
| 184 | 20570.449 | 0.256 | 56.417 | d0/s7 | K26 |
| 185 | 20570.505 | 0.255 | 164.449 | d0/s7 | K27 |
| 186 | 20570.670 | 0.255 | 3.424 | d0/s7 | K28 |
| 187 | 20570.674 | 0.256 | 163.808 | d0/s7 | K29 |
| 188 | 20570.838 | 0.417 | 625.122 | d0/s7 | K30 |
| 189 | 20571.507 | 43.648 | 3.104 | d0/s7 | K24 |
| 190 | 20571.511 | 0.960 | 159.008 | d0/s7 | K25 |
| 191 | 20571.670 | 0.256 | 56.257 | d0/s7 | K26 |
| 192 | 20571.727 | 0.255 | 164.481 | d0/s7 | K27 |
| 193 | 20571.891 | 0.288 | 3.360 | d0/s7 | K28 |
| 194 | 20571.895 | 0.256 | 163.744 | d0/s7 | K29 |
| 195 | 20572.059 | 0.417 | 624.449 | d0/s7 | K30 |
| 196 | 20572.728 | 44.992 | 3.137 | d0/s7 | K24 |
| 197 | 20572.733 | 1.088 | 158.784 | d0/s7 | K25 |
| 198 | 20572.892 | 0.256 | 56.352 | d0/s7 | K26 |
| 199 | 20572.948 | 0.256 | 164.257 | d0/s7 | K27 |
| 200 | 20573.113 | 0.256 | 3.424 | d0/s7 | K28 |
| 201 | 20573.117 | 0.256 | 163.936 | d0/s7 | K29 |
| 202 | 20573.281 | 0.416 | 624.514 | d0/s7 | K30 |
| 203 | 20573.949 | 44.032 | 3.232 | d0/s7 | K24 |
| 204 | 20573.954 | 1.632 | 158.593 | d0/s7 | K25 |
| 205 | 20574.113 | 0.256 | 56.160 | d0/s7 | K26 |
| 206 | 20574.170 | 0.288 | 164.384 | d0/s7 | K27 |
| 207 | 20574.334 | 0.257 | 3.328 | d0/s7 | K28 |
| 208 | 20574.338 | 0.255 | 163.873 | d0/s7 | K29 |
| 209 | 20574.502 | 0.448 | 624.162 | d0/s7 | K30 |
| 210 | 20575.172 | 45.312 | 3.232 | d0/s7 | K24 |
| 211 | 20575.176 | 0.832 | 158.529 | d0/s7 | K25 |
| 212 | 20575.334 | 0.256 | 56.160 | d0/s7 | K26 |
| 213 | 20575.391 | 0.256 | 164.256 | d0/s7 | K27 |
| 214 | 20575.555 | 0.256 | 3.360 | d0/s7 | K28 |
| 215 | 20575.559 | 0.256 | 163.617 | d0/s7 | K29 |
| 216 | 20575.723 | 0.416 | 625.058 | d0/s7 | K30 |
| 217 | 20576.390 | 42.208 | 3.200 | d0/s7 | K24 |
| 218 | 20576.395 | 1.408 | 158.497 | d0/s7 | K25 |
| 219 | 20576.554 | 0.255 | 56.449 | d0/s7 | K26 |
| 220 | 20576.610 | 0.288 | 164.128 | d0/s7 | K27 |
| 221 | 20576.775 | 0.256 | 3.328 | d0/s7 | K28 |
| 222 | 20576.778 | 0.256 | 163.617 | d0/s7 | K29 |
| 223 | 20576.942 | 0.448 | 624.546 | d0/s7 | K30 |
| 224 | 20577.609 | 42.240 | 3.232 | d0/s7 | K24 |
| 225 | 20577.614 | 1.184 | 158.560 | d0/s7 | K25 |
| 226 | 20577.772 | 0.256 | 56.385 | d0/s7 | K26 |
| 227 | 20577.829 | 0.255 | 164.321 | d0/s7 | K27 |
| 228 | 20577.994 | 0.256 | 3.328 | d0/s7 | K28 |
| 229 | 20577.997 | 0.256 | 163.552 | d0/s7 | K29 |
| 230 | 20578.161 | 0.417 | 624.289 | d0/s7 | K30 |
| 231 | 20578.828 | 42.848 | 3.137 | d0/s7 | K24 |
| 232 | 20578.833 | 1.120 | 158.688 | d0/s7 | K25 |
| 233 | 20578.992 | 0.288 | 56.736 | d0/s7 | K26 |
| 234 | 20579.049 | 0.289 | 164.385 | d0/s7 | K27 |
| 235 | 20579.213 | 0.256 | 3.424 | d0/s7 | K28 |
| 236 | 20579.217 | 0.256 | 163.712 | d0/s7 | K29 |
| 237 | 20579.381 | 0.416 | 624.610 | d0/s7 | K30 |
| 238 | 20580.050 | 43.872 | 3.137 | d0/s7 | K24 |
| 239 | 20580.054 | 0.895 | 158.753 | d0/s7 | K25 |
| 240 | 20580.213 | 0.256 | 56.512 | d0/s7 | K26 |
| 241 | 20580.269 | 0.288 | 164.449 | d0/s7 | K27 |
| 242 | 20580.434 | 0.254 | 3.393 | d0/s7 | K28 |
| 243 | 20580.438 | 0.256 | 163.904 | d0/s7 | K29 |
| 244 | 20580.602 | 0.448 | 624.674 | d0/s7 | K30 |
| 245 | 20581.270 | 43.329 | 3.104 | d0/s7 | K24 |
| 246 | 20581.275 | 1.760 | 158.753 | d0/s7 | K25 |
| 247 | 20581.434 | 0.256 | 56.416 | d0/s7 | K26 |
| 248 | 20581.491 | 0.256 | 164.225 | d0/s7 | K27 |
| 249 | 20581.655 | 0.255 | 3.393 | d0/s7 | K28 |
| 250 | 20581.659 | 0.255 | 163.777 | d0/s7 | K29 |
| 251 | 20581.823 | 0.448 | 624.546 | d0/s7 | K30 |
| 252 | 20582.492 | 44.416 | 3.104 | d0/s7 | K24 |
| 253 | 20582.497 | 1.504 | 158.784 | d0/s7 | K25 |
| 254 | 20582.656 | 0.288 | 56.417 | d0/s7 | K26 |
| 255 | 20582.712 | 0.256 | 164.224 | d0/s7 | K27 |
| 256 | 20582.877 | 0.256 | 3.424 | d0/s7 | K28 |
| 257 | 20582.880 | 0.256 | 163.969 | d0/s7 | K29 |
| 258 | 20583.045 | 0.448 | 624.066 | d0/s7 | K30 |
| 259 | 20583.712 | 42.784 | 3.232 | d0/s7 | K24 |
| 260 | 20583.716 | 1.504 | 158.592 | d0/s7 | K25 |
| 261 | 20583.875 | 0.257 | 56.320 | d0/s7 | K26 |
| 262 | 20583.932 | 0.255 | 164.161 | d0/s7 | K27 |
| 263 | 20584.096 | 0.256 | 3.328 | d0/s7 | K28 |
| 264 | 20584.100 | 0.288 | 163.713 | d0/s7 | K29 |
| 265 | 20584.264 | 0.447 | 624.739 | d0/s7 | K30 |
| 266 | 20584.933 | 44.608 | 3.200 | d0/s7 | K24 |
| 267 | 20584.938 | 0.896 | 158.688 | d0/s7 | K25 |
| 268 | 20585.096 | 0.256 | 56.256 | d0/s7 | K26 |
| 269 | 20585.153 | 0.257 | 164.320 | d0/s7 | K27 |
| 270 | 20585.318 | 0.256 | 3.328 | d0/s7 | K28 |
| 271 | 20585.321 | 0.256 | 163.553 | d0/s7 | K29 |
| 272 | 20585.485 | 0.447 | 624.738 | d0/s7 | K30 |
| 273 | 20586.154 | 44.129 | 3.200 | d0/s7 | K24 |
| 274 | 20586.158 | 0.672 | 158.560 | d0/s7 | K25 |
| 275 | 20586.317 | 0.256 | 56.352 | d0/s7 | K26 |
| 276 | 20586.373 | 0.256 | 164.321 | d0/s7 | K27 |
| 277 | 20586.538 | 0.256 | 3.328 | d0/s7 | K28 |
| 278 | 20586.541 | 0.256 | 163.616 | d0/s7 | K29 |
| 279 | 20586.706 | 0.448 | 624.834 | d0/s7 | K30 |
| 280 | 20587.375 | 44.160 | 3.200 | d0/s7 | K24 |
| 281 | 20587.379 | 0.800 | 158.465 | d0/s7 | K25 |
| 282 | 20587.537 | 0.256 | 56.320 | d0/s7 | K26 |
| 283 | 20587.594 | 0.256 | 164.416 | d0/s7 | K27 |
| 284 | 20587.759 | 0.256 | 3.329 | d0/s7 | K28 |
| 285 | 20587.762 | 0.288 | 163.648 | d0/s7 | K29 |
| 286 | 20587.926 | 0.448 | 624.578 | d0/s7 | K30 |
| 287 | 20588.597 | 46.112 | 3.136 | d0/s7 | K24 |
| 288 | 20588.601 | 1.120 | 158.753 | d0/s7 | K25 |
| 289 | 20588.760 | 0.256 | 56.672 | d0/s7 | K26 |
| 290 | 20588.817 | 0.256 | 164.289 | d0/s7 | K27 |
| 291 | 20588.982 | 0.255 | 3.425 | d0/s7 | K28 |
| 292 | 20588.985 | 0.255 | 163.617 | d0/s7 | K29 |
| 293 | 20589.149 | 0.448 | 624.066 | d0/s7 | K30 |
| 294 | 20589.818 | 44.032 | 3.232 | d0/s7 | K24 |
| 295 | 20589.822 | 0.992 | 158.688 | d0/s7 | K25 |
| 296 | 20589.981 | 0.257 | 56.416 | d0/s7 | K26 |
| 297 | 20590.037 | 0.288 | 164.544 | d0/s7 | K27 |
| 298 | 20590.202 | 0.288 | 3.328 | d0/s7 | K28 |
| 299 | 20590.206 | 0.288 | 164.065 | d0/s7 | K29 |
| 300 | 20590.370 | 0.448 | 624.449 | d0/s7 | K30 |
| 301 | 20591.039 | 43.937 | 3.104 | d0/s7 | K24 |
| 302 | 20591.043 | 1.408 | 158.880 | d0/s7 | K25 |
| 303 | 20591.202 | 0.256 | 56.288 | d0/s7 | K26 |
| 304 | 20591.259 | 0.256 | 164.545 | d0/s7 | K27 |
| 305 | 20591.424 | 0.256 | 3.392 | d0/s7 | K28 |
| 306 | 20591.427 | 0.256 | 163.649 | d0/s7 | K29 |
| 307 | 20591.591 | 0.416 | 624.739 | d0/s7 | K30 |
| 308 | 20592.259 | 42.495 | 3.105 | d0/s7 | K24 |
| 309 | 20592.263 | 1.344 | 158.688 | d0/s7 | K25 |
| 310 | 20592.422 | 0.256 | 56.512 | d0/s7 | K26 |
| 311 | 20592.479 | 0.256 | 164.257 | d0/s7 | K27 |
| 312 | 20592.643 | 0.256 | 3.424 | d0/s7 | K28 |
| 313 | 20592.647 | 0.256 | 163.904 | d0/s7 | K29 |
| 314 | 20592.811 | 0.416 | 624.674 | d0/s7 | K30 |
| 315 | 20593.480 | 43.840 | 3.232 | d0/s7 | K24 |
| 316 | 20593.485 | 1.728 | 158.657 | d0/s7 | K25 |
| 317 | 20593.644 | 0.256 | 56.128 | d0/s7 | K26 |
| 318 | 20593.700 | 0.256 | 164.321 | d0/s7 | K27 |
| 319 | 20593.865 | 0.256 | 3.360 | d0/s7 | K28 |
| 320 | 20593.868 | 0.256 | 163.744 | d0/s7 | K29 |
| 321 | 20594.032 | 0.416 | 624.706 | d0/s7 | K30 |
| 322 | 20594.700 | 43.200 | 3.200 | d0/s7 | K24 |
| 323 | 20594.704 | 0.896 | 158.529 | d0/s7 | K25 |
| 324 | 20594.863 | 0.256 | 56.192 | d0/s7 | K26 |
| 325 | 20594.920 | 0.256 | 164.288 | d0/s7 | K27 |
| 326 | 20595.084 | 0.288 | 3.328 | d0/s7 | K28 |
| 327 | 20595.088 | 0.256 | 163.713 | d0/s7 | K29 |
| 328 | 20595.252 | 0.448 | 624.706 | d0/s7 | K30 |
| 329 | 20595.920 | 43.264 | 3.200 | d0/s7 | K24 |
| 330 | 20595.924 | 0.992 | 158.497 | d0/s7 | K25 |
| 331 | 20596.083 | 0.255 | 56.641 | d0/s7 | K26 |
| 332 | 20596.140 | 0.256 | 164.352 | d0/s7 | K27 |
| 333 | 20596.304 | 0.256 | 3.328 | d0/s7 | K28 |
| 334 | 20596.308 | 0.288 | 163.681 | d0/s7 | K29 |
| 335 | 20596.472 | 0.416 | 624.034 | d0/s7 | K30 |
| 336 | 20597.140 | 43.744 | 3.232 | d0/s7 | K24 |
| 337 | 20597.144 | 0.928 | 158.720 | d0/s7 | K25 |
| 338 | 20597.303 | 0.257 | 56.480 | d0/s7 | K26 |
| 339 | 20597.360 | 0.255 | 164.801 | d0/s7 | K27 |
| 340 | 20597.525 | 0.256 | 3.328 | d0/s7 | K28 |
| 341 | 20597.528 | 0.288 | 163.457 | d0/s7 | K29 |
| 342 | 20597.692 | 0.448 | 624.289 | d0/s7 | K30 |
| 343 | 20598.361 | 44.769 | 3.136 | d0/s7 | K24 |
| 344 | 20598.366 | 1.056 | 158.688 | d0/s7 | K25 |
| 345 | 20598.525 | 0.256 | 56.480 | d0/s7 | K26 |
| 346 | 20598.581 | 0.256 | 164.321 | d0/s7 | K27 |
| 347 | 20598.746 | 0.256 | 3.424 | d0/s7 | K28 |
| 348 | 20598.750 | 0.256 | 163.552 | d0/s7 | K29 |
| 349 | 20598.914 | 0.416 | 624.418 | d0/s7 | K30 |
| 350 | 20599.581 | 42.976 | 3.105 | d0/s7 | K24 |
| 351 | 20599.585 | 1.055 | 158.785 | d0/s7 | K25 |
| 352 | 20599.744 | 0.256 | 56.736 | d0/s7 | K26 |
| 353 | 20599.801 | 0.256 | 164.609 | d0/s7 | K27 |
| 354 | 20599.966 | 0.256 | 3.424 | d0/s7 | K28 |
| 355 | 20599.970 | 0.256 | 163.904 | d0/s7 | K29 |
| 356 | 20600.134 | 0.416 | 624.322 | d0/s7 | K30 |
| 357 | 20600.801 | 43.168 | 3.104 | d0/s7 | K24 |
| 358 | 20600.805 | 0.608 | 158.945 | d0/s7 | K25 |
| 359 | 20600.964 | 0.288 | 56.416 | d0/s7 | K26 |
| 360 | 20601.021 | 0.288 | 164.449 | d0/s7 | K27 |
| 361 | 20601.186 | 0.255 | 3.425 | d0/s7 | K28 |
| 362 | 20601.190 | 0.255 | 163.681 | d0/s7 | K29 |
| 363 | 20601.354 | 0.448 | 624.482 | d0/s7 | K30 |
| 364 | 20602.022 | 43.840 | 3.104 | d0/s7 | K24 |
| 365 | 20602.026 | 1.280 | 158.785 | d0/s7 | K25 |
| 366 | 20602.185 | 0.256 | 56.320 | d0/s7 | K26 |
| 367 | 20602.242 | 0.256 | 164.512 | d0/s7 | K27 |
| 368 | 20602.407 | 0.256 | 3.392 | d0/s7 | K28 |
| 369 | 20602.410 | 0.256 | 163.969 | d0/s7 | K29 |
| 370 | 20602.575 | 0.448 | 624.450 | d0/s7 | K30 |
| 371 | 20603.244 | 44.928 | 3.200 | d0/s7 | K24 |
| 372 | 20603.249 | 1.280 | 158.688 | d0/s7 | K25 |
| 373 | 20603.408 | 0.256 | 56.128 | d0/s7 | K26 |
| 374 | 20603.464 | 0.257 | 164.384 | d0/s7 | K27 |
| 375 | 20603.629 | 0.256 | 3.360 | d0/s7 | K28 |
| 376 | 20603.632 | 0.256 | 164.129 | d0/s7 | K29 |
| 377 | 20603.797 | 0.448 | 624.546 | d0/s7 | K30 |
| 378 | 20604.464 | 42.336 | 3.200 | d0/s7 | K24 |
| 379 | 20604.468 | 1.056 | 158.528 | d0/s7 | K25 |
| 380 | 20604.627 | 0.256 | 56.001 | d0/s7 | K26 |
| 381 | 20604.683 | 0.287 | 164.225 | d0/s7 | K27 |
| 382 | 20604.848 | 0.256 | 3.328 | d0/s7 | K28 |
| 383 | 20604.851 | 0.288 | 163.584 | d0/s7 | K29 |
| 384 | 20605.015 | 0.448 | 624.738 | d0/s7 | K30 |
| 385 | 20605.682 | 42.528 | 3.169 | d0/s7 | K24 |
| 386 | 20605.687 | 1.216 | 158.464 | d0/s7 | K25 |
| 387 | 20605.846 | 0.256 | 56.448 | d0/s7 | K26 |
| 388 | 20605.902 | 0.256 | 164.513 | d0/s7 | K27 |
| 389 | 20606.067 | 0.256 | 3.328 | d0/s7 | K28 |
| 390 | 20606.071 | 0.288 | 163.648 | d0/s7 | K29 |
| 391 | 20606.235 | 0.448 | 624.866 | d0/s7 | K30 |
| 392 | 20606.903 | 43.360 | 3.200 | d0/s7 | K24 |
| 393 | 20606.907 | 1.248 | 158.689 | d0/s7 | K25 |
| 394 | 20607.066 | 0.256 | 56.512 | d0/s7 | K26 |
| 395 | 20607.123 | 0.255 | 164.641 | d0/s7 | K27 |
| 396 | 20607.288 | 0.288 | 3.327 | d0/s7 | K28 |
| 397 | 20607.292 | 0.257 | 163.584 | d0/s7 | K29 |
| 398 | 20607.456 | 0.448 | 624.290 | d0/s7 | K30 |
| 399 | 20608.125 | 44.640 | 3.136 | d0/s7 | K24 |
| 400 | 20608.129 | 1.568 | 159.073 | d0/s7 | K25 |
| 401 | 20608.289 | 0.256 | 56.544 | d0/s7 | K26 |
| 402 | 20608.345 | 0.288 | 164.160 | d0/s7 | K27 |
| 403 | 20608.510 | 0.256 | 3.424 | d0/s7 | K28 |
| 404 | 20608.514 | 0.256 | 163.649 | d0/s7 | K29 |
| 405 | 20608.678 | 0.448 | 624.450 | d0/s7 | K30 |
| 406 | 20609.346 | 44.160 | 3.104 | d0/s7 | K24 |
| 407 | 20609.350 | 0.704 | 158.625 | d0/s7 | K25 |
| 408 | 20609.509 | 0.255 | 56.449 | d0/s7 | K26 |
| 409 | 20609.566 | 0.256 | 164.576 | d0/s7 | K27 |
| 410 | 20609.730 | 0.256 | 3.392 | d0/s7 | K28 |
| 411 | 20609.734 | 0.288 | 163.776 | d0/s7 | K29 |
| 412 | 20609.898 | 0.449 | 624.738 | d0/s7 | K30 |
| 413 | 20610.567 | 44.320 | 3.104 | d0/s7 | K24 |
| 414 | 20610.572 | 1.024 | 158.880 | d0/s7 | K25 |
| 415 | 20610.731 | 0.256 | 56.289 | d0/s7 | K26 |
| 416 | 20610.787 | 0.255 | 164.449 | d0/s7 | K27 |
| 417 | 20610.952 | 0.256 | 3.392 | d0/s7 | K28 |
| 418 | 20610.956 | 0.288 | 163.648 | d0/s7 | K29 |
| 419 | 20611.120 | 0.448 | 624.738 | d0/s7 | K30 |
| 420 | 20611.787 | 42.753 | 3.104 | d0/s7 | K24 |
| 421 | 20611.791 | 0.960 | 158.816 | d0/s7 | K25 |
| 422 | 20611.950 | 0.256 | 56.384 | d0/s7 | K26 |
| 423 | 20612.007 | 0.289 | 164.609 | d0/s7 | K27 |
| 424 | 20612.172 | 0.256 | 3.424 | d0/s7 | K28 |
| 425 | 20612.176 | 0.256 | 163.808 | d0/s7 | K29 |
| 426 | 20612.340 | 0.416 | 624.866 | d0/s7 | K30 |
| 427 | 20613.007 | 42.080 | 3.232 | d0/s7 | K24 |
| 428 | 20613.012 | 1.824 | 158.625 | d0/s7 | K25 |
| 429 | 20613.171 | 0.288 | 56.064 | d0/s7 | K26 |
| 430 | 20613.227 | 0.256 | 164.544 | d0/s7 | K27 |
| 431 | 20613.392 | 0.257 | 3.328 | d0/s7 | K28 |
| 432 | 20613.395 | 0.255 | 163.809 | d0/s7 | K29 |
| 433 | 20613.560 | 0.448 | 624.386 | d0/s7 | K30 |
| 434 | 20614.455 | 270.880 | 3.680 | d0/s7 | K31 |
| 435 | 20614.545 | 86.208 | 1.824 | d0/s7 | K32 |
| 436 | 20614.662 | 114.912 | 4.032 | d0/s7 | K33 |
| 437 | 20614.728 | 62.721 | 1.632 | d0/s7 | K9 |
| 438 | 20614.765 | 35.296 | 1.728 | d0/s7 | K34 |
| 439 | 20614.853 | 86.048 | 1.568 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 440 | 20614.901 | 46.656 | 0.704 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 441 | 20615.145 | 243.041 | 3.104 | d0/s7 | K35 |
| 442 | 20615.213 | 64.736 | 2.560 | d0/s7 | K36 |
| 443 | 20615.234 | 18.784 | 1.824 | d0/s7 | K19 |
| 444 | 20615.253 | 16.959 | 2.048 | d0/s7 | K37 |
| 445 | 20615.274 | 19.232 | 3.649 | d0/s7 | K38 |
| 446 | 20615.292 | 14.496 | 1.792 | d0/s7 | K39 |
| 447 | 20615.600 | 305.984 | 4.352 | d0/s7 | K40 |
| 448 | 20615.649 | 44.897 | 1.664 | d0/s7 | K41 |
| 449 | 20615.720 | 68.576 | 1.216 | d0/s7 | K42 |
| 450 | 20615.766 | 44.672 | 2.304 | d0/s7 | K43 |
| 451 | 20615.840 | 71.680 | 1.824 | d0/s7 | Memcpy DtoD (Device -> Device) (786432 B) |
| 452 | 20615.879 | 37.440 | 2.400 | d0/s7 | K44 |
| 453 | 20615.918 | 36.832 | 3.296 | d0/s7 | K45 |
| 454 | 20615.997 | 75.361 | 5.024 | d0/s7 | K46 |
| 455 | 20616.033 | 31.744 | 2.272 | d0/s7 | K47 |
| 456 | 20616.059 | 23.488 | 1.664 | d0/s7 | K9 |
| 457 | 20616.078 | 17.344 | 1.696 | d0/s7 | K34 |
| 458 | 20616.108 | 27.808 | 1.760 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 459 | 20616.143 | 33.312 | 1.760 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 460 | 20616.259 | 114.465 | 2.880 | d0/s7 | K48 |
| 461 | 20616.284 | 22.016 | 2.368 | d0/s7 | K49 |
| 462 | 20616.306 | 19.808 | 1.824 | d0/s7 | K50 |
| 463 | 20616.347 | 39.072 | 4.096 | d0/s7 | K33 |
| 464 | 20616.367 | 15.680 | 1.600 | d0/s7 | K9 |
| 465 | 20616.384 | 15.776 | 1.728 | d0/s7 | K34 |
| 466 | 20616.402 | 16.512 | 0.736 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 467 | 20616.430 | 26.976 | 0.736 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 468 | 20616.491 | 60.480 | 3.392 | d0/s7 | K51 |
| 469 | 20616.508 | 13.375 | 2.624 | d0/s7 | K52 |
| 470 | 20616.542 | 30.880 | 2.048 | d0/s7 | K53 |
| 471 | 20616.555 | 11.585 | 1.887 | d0/s7 | K22 |
| 472 | 20616.570 | 13.153 | 2.047 | d0/s7 | K54 |
| 473 | 20616.588 | 16.065 | 0.895 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 474 | 20616.615 | 25.601 | 0.896 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 475 | 20616.661 | 44.928 | 4.192 | d0/s7 | K48 |
| 476 | 20616.675 | 10.336 | 2.272 | d0/s7 | K49 |
| 477 | 20616.687 | 9.984 | 1.696 | d0/s7 | K50 |
| 478 | 20616.709 | 20.160 | 3.808 | d0/s7 | K33 |
| 479 | 20616.778 | 64.768 | 19.936 | d0/s7 | K55 |
| 480 | 20616.798 | 0.256 | 2.528 | d0/s7 | K36 |
| 481 | 20616.891 | 90.017 | 4.160 | d0/s7 | K40 |
| 482 | 20616.916 | 20.832 | 1.856 | d0/s7 | K41 |
| 483 | 20616.951 | 34.016 | 1.856 | d0/s7 | Memcpy DtoD (Device -> Device) (786432 B) |
| 484 | 20616.971 | 17.536 | 2.208 | d0/s7 | K44 |
| 485 | 20616.992 | 18.912 | 3.072 | d0/s7 | K45 |
| 486 | 20617.040 | 44.641 | 5.056 | d0/s7 | K46 |
| 487 | 20617.067 | 21.888 | 2.240 | d0/s7 | K47 |
| 488 | 20617.099 | 30.048 | 18.816 | d0/s7 | K56 |
| 489 | 20617.118 | 0.256 | 1.792 | d0/s7 | K50 |
| 490 | 20617.126 | 6.464 | 2.400 | d0/s7 | K49 |
| 491 | 20617.152 | 23.042 | 4.095 | d0/s7 | K33 |
| 492 | 20617.202 | 45.728 | 22.432 | d0/s7 | K57 |
| 493 | 20617.224 | 0.257 | 2.623 | d0/s7 | K52 |
| 494 | 20617.232 | 4.897 | 1.983 | d0/s7 | K53 |
| 495 | 20617.279 | 45.409 | 1.760 | d0/s7 | Memset (Device) (1536 B) |
| 496 | 20617.293 | 12.064 | 1.312 | d0/s7 | K58 |
| 497 | 20617.304 | 9.888 | 60.448 | d0/s7 | K59 |
| 498 | 20617.365 | 0.288 | 1.824 | d0/s7 | K50 |
| 499 | 20617.367 | 0.224 | 2.368 | d0/s7 | K49 |
| 500 | 20617.370 | 0.256 | 2.016 | d0/s7 | K50 |
| 501 | 20617.392 | 19.968 | 1.472 | d0/s7 | K60 |
| 502 | 20617.432 | 39.456 | 12.864 | d0/s7 | K61 |
| 503 | 20617.478 | 32.384 | 3.904 | d0/s7 | Memcpy DtoH (Device -> Pinned) (4 B) |
| 504 | 20617.534 | 52.256 | 1.569 | d0/s7 | Memcpy HtoD (Pageable -> Device) (56 B) |
| 505 | 20617.570 | 34.816 | 1.536 | d0/s7 | Memcpy HtoD (Pageable -> Device) (48 B) |
| 506 | 20617.630 | 58.048 | 4.384 | d0/s7 | K62 |
| 507 | 20617.648 | 13.440 | 4.032 | d0/s7 | K63 |
| 508 | 20617.661 | 9.792 | 4.736 | d0/s7 | K62 |
| 509 | 20617.675 | 9.184 | 4.224 | d0/s7 | K63 |
| 510 | 20617.687 | 7.712 | 1.984 | d0/s7 | K64 |
| 511 | 20617.703 | 13.184 | 1.824 | d0/s7 | K65 |
| 512 | 20617.720 | 15.552 | 2.272 | d0/s7 | K66 |
| 513 | 20617.732 | 9.856 | 3.776 | d0/s7 | Memcpy DtoH (Device -> Pinned) (4 B) |
| 514 | 20617.768 | 32.672 | 1.408 | d0/s7 | K60 |
| 515 | 20617.802 | 32.000 | 1.504 | d0/s7 | K67 |
| 516 | 20617.828 | 24.225 | 1.535 | d0/s7 | K68 |
| 517 | 20617.849 | 19.680 | 1.793 | d0/s7 | K69 |
| 518 | 20617.907 | 56.384 | 12.960 | d0/s7 | K70 |
| 519 | 20617.924 | 3.744 | 3.904 | d0/s7 | Memcpy DtoH (Device -> Pinned) (1 B) |
