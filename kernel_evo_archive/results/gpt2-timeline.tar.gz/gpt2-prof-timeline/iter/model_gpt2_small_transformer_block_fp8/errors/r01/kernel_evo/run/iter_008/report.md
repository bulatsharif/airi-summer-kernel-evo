# KernelEvo iteration 8

Run: `run`  
Barrier status: **evaluated**  
Valid: 1 · Promoted: 1

| Island | Result | Progress | Runtime | Speedup | Promoted | Idea |
|---:|---|---:|---:|---:|:---:|---|
| 0 | valid | — | 347.168 µs | 10.356x | yes | Implement the task's CuTe DSL FP8 kernel so it compiles and produces numerically correct output on… |

Global best: `iter-008-island-0` at **10.356x** speedup.

## Compact profile objectives

- Island 0 (b300_trace): inner device — µs, — kernels, — memcpys; eager layer — µs, dispatch gaps — µs; graph no, replay — µs.

Compact profile review required for island(s): 0. Use `kernel-evo iter review-profiles`, then `kernel-evo island review-submit`.
