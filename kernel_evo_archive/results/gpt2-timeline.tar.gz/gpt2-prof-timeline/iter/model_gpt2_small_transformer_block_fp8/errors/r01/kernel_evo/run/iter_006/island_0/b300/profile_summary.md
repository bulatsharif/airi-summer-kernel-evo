# B300 complete GPU timeline of your last candidate

- complete GPU-side trace: 519 activities; CPU/Python profiler records are intentionally omitted
- whole capture: span 5307.665 ms; active union 18.678 ms; idle holes 5288.987 ms (99.7%); largest hole 5031.867 ms
- that idle figure covers input generation, JIT compilation and the reference as well as your block, so it is not a measure of your kernels; the per-iteration section below is
- summed activity time: 18.678 ms; this may exceed active union when streams overlap
- source labels are hints: `candidate:<symbol>` is matched against this candidate's `@cute.kernel` definitions; other labels describe likely harness/runtime work
- candidate `@cute.kernel` symbols: `attention_kernel`, `fc_gelu_kernel`, `ln1_kernel`, `ln2_kernel`, `out_gemm_kernel`, `proj_gemm_kernel`, `qkv_gemm_kernel`
- observed candidate symbols: `attention_kernel`, `fc_gelu_kernel`, `ln1_kernel`, `ln2_kernel`, `out_gemm_kernel`, `proj_gemm_kernel`, `qkv_gemm_kernel`
- candidate symbols not observed in this trace: none

## One iteration of your block, launch by launch

Median of 55 timed iterations, 7 launches each. Microseconds from the start of the iteration.

- wall span 331.745; kernels busy 329.633; idle between your kernels 2.112 (0.6% of the span)
- largest single gap 0.704 immediately before `qkv_gemm_kernel`
- 47.104 elapses between one iteration and the next; that is host-side dispatch outside your block, excluded from the idle figure above, and fusing cannot remove it

| # | kernel | id | start | end | dur | idle before |
| ---: | --- | --- | ---: | ---: | ---: | ---: |
| 1 | ln1_kernel | K24 | 0.000 | 3.264 | 3.264 | — |
| 2 | qkv_gemm_kernel | K25 | 3.968 | 50.176 | 46.208 | 0.704 |
| 3 | attention_kernel | K26 | 50.432 | 106.784 | 56.352 | 0.256 |
| 4 | out_gemm_kernel | K27 | 107.169 | 140.897 | 33.728 | 0.385 |
| 5 | ln2_kernel | K28 | 141.152 | 144.481 | 3.329 | 0.255 |
| 6 | fc_gelu_kernel | K29 | 144.737 | 202.017 | 57.280 | 0.256 |
| 7 | proj_gemm_kernel | K30 | 202.273 | 331.745 | 129.472 | 0.256 |

## Hottest GPU kernels (legacy aggregate)

| kernel | ms | calls | % GPU |
| --- | ---: | ---: | ---: |
| kernel_cutlass_proj_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 7.179 | 55 | 38.4 |
| kernel_cutlass_fc_gelu_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmemal… | 3.150 | 55 | 16.9 |
| kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 3.097 | 55 | 16.6 |
| kernel_cutlass_qkv_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 2.548 | 55 | 13.6 |
| kernel_cutlass_out_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 1.872 | 55 | 10.0 |
| kernel_cutlass_ln2_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo7681_tensorptrf32gmemo… | 0.185 | 55 | 1.0 |
| kernel_cutlass_ln1_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo7681_tenso… | 0.178 | 55 | 0.9 |
| void sgemm_largek_lds64<true, false, 6, 3, 4, 5, 2, 66>(float*, float const*, float con… | 0.062 | 1 | 0.3 |
| cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 0.051 | 4 | 0.3 |
| void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 0.033 | 17 | 0.2 |

## Kernel legend

| id | source hint | kernel | calls | total us | launch |
| --- | --- | --- | ---: | ---: | --- |
| K1 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 1 | 2.624 | grid=384x1x1, block=256x1x1, smem=0, regs=56 |
| K2 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 6 | 12.063 | grid=3x1x1, block=256x1x1, smem=0, regs=56 |
| K3 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 6 | 10.783 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K4 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::CUDAFunctorOnSelf_add<flo… | 2 | 3.583 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K5 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 1 | 2.144 | grid=9x1x1, block=256x1x1, smem=0, regs=56 |
| K6 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 2 | 3.232 | grid=3x1x1, block=128x1x1, smem=0, regs=32 |
| K7 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 1 | 1.824 | grid=12x1x1, block=256x1x1, smem=0, regs=56 |
| K8 | framework/validation | void at::native::(anonymous namespace)::distribution_elementwise_grid_stride_kernel<flo… | 4 | 22.146 | grid=1184x1x1, block=256x1x1, smem=0, regs=56 |
| K9 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 7 | 11.778 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K10 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 4 | 7.456 | grid=256x1x1, block=128x1x1, smem=0, regs=20 |
| K11 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 1 | 2.880 | grid=1728x1x1, block=128x1x1, smem=0, regs=32 |
| K12 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 2 | 8.576 | grid=4608x1x1, block=128x1x1, smem=0, regs=20 |
| K13 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 1 | 1.985 | grid=576x1x1, block=128x1x1, smem=0, regs=32 |
| K14 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 2.528 | grid=1536x1x1, block=128x1x1, smem=0, regs=20 |
| K15 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 6.592 | grid=2304x1x1, block=128x1x1, smem=0, regs=32 |
| K16 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 5.087 | grid=6144x1x1, block=128x1x1, smem=0, regs=20 |
| K17 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::… | 3 | 4.448 | grid=96x1x1, block=128x1x1, smem=0, regs=16 |
| K18 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::… | 1 | 1.632 | grid=288x1x1, block=128x1x1, smem=0, regs=16 |
| K19 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 3.265 | grid=288x1x1, block=128x1x1, smem=0, regs=32 |
| K20 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 1.984 | grid=640x1x1, block=128x1x1, smem=0, regs=20 |
| K21 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<float>, std::… | 1 | 1.408 | grid=384x1x1, block=128x1x1, smem=0, regs=16 |
| K22 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 3.202 | grid=384x1x1, block=128x1x1, smem=0, regs=32 |
| K23 | CuTe helper/setup | kernel_cutlass__convert_kernel_tensorptrf32gmemo151201i64512_tensorptrf8E4M3FNgmemalign… | 1 | 2.080 | grid=768x1x1, block=128x1x1, smem=0, regs=20 |
| K24 | candidate:ln1_kernel | kernel_cutlass_ln1_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf32gmemo7681_tenso… | 55 | 177.793 | grid=128x1x1, block=128x1x1, smem=1024, regs=32 |
| K25 | candidate:qkv_gemm_kernel | kernel_cutlass_qkv_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 55 | 2548.357 | grid=36x8x1, block=128x1x1, smem=20480, regs=128 |
| K26 | candidate:attention_kernel | kernel_cutlass_attention_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 55 | 3096.517 | grid=12x128x1, block=128x1x1, smem=1024, regs=40 |
| K27 | candidate:out_gemm_kernel | kernel_cutlass_out_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmema… | 55 | 1872.421 | grid=12x8x1, block=128x1x1, smem=20480, regs=128 |
| K28 | candidate:ln2_kernel | kernel_cutlass_ln2_kernel_tensorptrf32gmemoi641_tensorptrf32gmemo7681_tensorptrf32gmemo… | 55 | 185.054 | grid=128x1x1, block=128x1x1, smem=1024, regs=32 |
| K29 | candidate:fc_gelu_kernel | kernel_cutlass_fc_gelu_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmemal… | 55 | 3150.312 | grid=48x8x1, block=128x1x1, smem=20480, regs=128 |
| K30 | candidate:proj_gemm_kernel | kernel_cutlass_proj_gemm_kernel_tensorptrf8E4M3FNgmemalign16oi641_tensorptrf8E4M3FNgmem… | 55 | 7179.089 | grid=12x8x1, block=128x1x1, smem=20480, regs=128 |
| K31 | framework/validation | void at::native::unrolled_elementwise_kernel<at::native::direct_copy_kernel_cuda(at::Te… | 1 | 3.968 | grid=192x1x1, block=128x1x1, smem=0, regs=30 |
| K32 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 1 | 1.792 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K33 | framework/validation | void at::native::(anonymous namespace)::vectorized_layer_norm_kernel<float, float, fals… | 4 | 16.672 | grid=128x1x1, block=32x4x1, smem=24, regs=40 |
| K34 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::float8_copy_kernel_cuda(a… | 3 | 5.440 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K35 | framework/validation | nvjet_sm103_qqsss_64x32_128x16_2x1_2cta_v_bz_TNT | 1 | 3.200 | grid=144x1x1, block=256x1x1, smem=172552, regs=255 |
| K36 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 4.896 | grid=1152x1x1, block=128x1x1, smem=0, regs=20 |
| K37 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::float8_copy_kernel_cuda(a… | 1 | 2.048 | grid=288x1x1, block=128x1x1, smem=0, regs=32 |
| K38 | framework/validation | void at::native::unrolled_elementwise_kernel<at::native::direct_copy_kernel_cuda(at::Te… | 1 | 3.648 | grid=576x1x1, block=128x1x1, smem=0, regs=30 |
| K39 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 1 | 1.888 | grid=288x1x1, block=128x1x1, smem=0, regs=32 |
| K40 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 2 | 8.609 | grid=4x4x12, block=64x1x1, smem=13056, regs=72 |
| K41 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BUnaryFunctor<float, floa… | 2 | 3.457 | grid=192x1x1, block=128x1x1, smem=0, regs=32 |
| K42 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::FillFunctor<bool>, std::a… | 1 | 1.248 | grid=8x1x1, block=128x1x1, smem=0, regs=16 |
| K43 | framework/validation | void at::native::triu_tril_kernel<bool, int, true, 8, false>(at::cuda::detail::TensorIn… | 1 | 2.336 | grid=16x1x1, block=128x1x1, smem=0, regs=30 |
| K44 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 4.640 | grid=768x1x1, block=128x1x1, smem=0, regs=20 |
| K45 | framework/validation | void (anonymous namespace)::softmax_warp_forward<float, float, float, 7, false, false>(… | 2 | 6.495 | grid=192x1x1, block=32x4x1, smem=0, regs=32 |
| K46 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_nnn_align1_bias_f32_relu | 2 | 10.208 | grid=2x4x12, block=64x1x1, smem=12672, regs=84 |
| K47 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 4.736 | grid=384x1x1, block=128x1x1, smem=0, regs=20 |
| K48 | framework/validation | nvjet_sm103_qqsss_64x16_128x16_2x4_2cta_h_bz_TNT | 2 | 7.008 | grid=96x1x1, block=256x1x1, smem=156168, regs=255 |
| K49 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 4 | 9.409 | grid=384x1x1, block=128x1x1, smem=0, regs=20 |
| K50 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::CUDAFunctor_add<float>, s… | 5 | 8.928 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K51 | framework/validation | nvjet_sm103_qqsss_48x64_128x16_2x2_2cta_h_bz_TNN | 1 | 3.456 | grid=128x1x1, block=256x1x1, smem=188944, regs=255 |
| K52 | framework/validation | void at::native::elementwise_kernel<128, 2, at::native::gpu_kernel_impl_nocast<at::nati… | 2 | 5.184 | grid=1536x1x1, block=128x1x1, smem=0, regs=20 |
| K53 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::GeluCUDAKernelImpl(at::Te… | 2 | 4.160 | grid=384x1x1, block=128x1x1, smem=0, regs=32 |
| K54 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::float8_copy_kernel_cuda(a… | 1 | 2.112 | grid=384x1x1, block=128x1x1, smem=0, regs=32 |
| K55 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 1 | 22.112 | grid=72x4x1, block=64x1x1, smem=13056, regs=72 |
| K56 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_32x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 1 | 20.064 | grid=24x4x1, block=64x1x1, smem=13056, regs=72 |
| K57 | framework/validation | cutlass3x_sm100_simt_sgemm_f32_f32_f32_f32_f32_64x32x16_1x1x1_3_tnn_align1_bias_f32_relu | 1 | 24.608 | grid=48x4x1, block=64x1x1, smem=19200, regs=146 |
| K58 | framework/validation | void scal_kernel<float, float, 1, true, 6, 5, 5, 3>(cublasTransposeParams<float>, float… | 1 | 1.313 | grid=12x4x1, block=256x1x1, smem=0, regs=24 |
| K59 | framework/validation | void sgemm_largek_lds64<true, false, 6, 3, 4, 5, 2, 66>(float*, float const*, float con… | 1 | 61.760 | grid=12x16x4, block=32x4x1, smem=4868, regs=32 |
| K60 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AbsFunctor<float>, std::a… | 2 | 3.552 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K61 | framework/validation | void at::native::reduce_kernel<512, 1, at::native::ReduceOp<float, at::native::func_wra… | 1 | 13.632 | grid=1x1x1, block=512x1x1, smem=2064, regs=30 |
| K62 | framework/validation | void at::native::(anonymous namespace)::indexSelectSmallIndex<float, long, unsigned int… | 2 | 8.223 | grid=6x1x1, block=128x1x1, smem=0, regs=28 |
| K63 | framework/validation | void at::native::(anonymous namespace)::indexSelectSmallIndex<float, long, unsigned int… | 2 | 7.841 | grid=1x1x1, block=7x1x1, smem=0, regs=28 |
| K64 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::CUDAFunctor_add<float>, s… | 1 | 1.951 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K65 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AbsFunctor<float>, std::a… | 1 | 1.920 | grid=1x1x1, block=128x1x1, smem=0, regs=32 |
| K66 | framework/validation | void at::native::reduce_kernel<512, 1, at::native::ReduceOp<float, at::native::func_wra… | 1 | 2.816 | grid=1x1x1, block=32x1x1, smem=16, regs=30 |
| K67 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::AUnaryFunctor<float, floa… | 1 | 1.504 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K68 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BinaryFunctor<float, floa… | 1 | 1.536 | grid=96x1x1, block=128x1x1, smem=0, regs=32 |
| K69 | framework/validation | void at::native::vectorized_elementwise_kernel<4, at::native::BinaryFunctor<bool, bool,… | 1 | 1.472 | grid=96x1x1, block=128x1x1, smem=0, regs=30 |
| K70 | framework/validation | void at::native::reduce_kernel<512, 1, at::native::ReduceOp<bool, at::native::func_wrap… | 1 | 12.576 | grid=1x1x1, block=512x1x1, smem=528, regs=28 |

## Ordered GPU activities

`gap before` is device-wide idle time since all earlier GPU activity ended; zero means overlap or no measurable hole.

| # | start ms | gap before us | duration us | lane | activity |
| ---: | ---: | ---: | ---: | --- | --- |
| 1 | 0.000 | 0.000 | 2.624 | d0/s7 | K1 |
| 2 | 0.076 | 72.993 | 2.015 | d0/s7 | K2 |
| 3 | 0.141 | 63.809 | 1.983 | d0/s7 | K3 |
| 4 | 0.184 | 40.257 | 1.983 | d0/s7 | K4 |
| 5 | 0.203 | 16.961 | 2.144 | d0/s7 | K2 |
| 6 | 0.217 | 11.776 | 1.600 | d0/s7 | K3 |
| 7 | 0.233 | 14.464 | 1.824 | d0/s7 | K2 |
| 8 | 0.243 | 8.352 | 1.600 | d0/s7 | K3 |
| 9 | 0.253 | 8.992 | 1.600 | d0/s7 | K4 |
| 10 | 0.269 | 13.536 | 2.144 | d0/s7 | K2 |
| 11 | 0.280 | 8.896 | 1.984 | d0/s7 | K3 |
| 12 | 0.296 | 14.496 | 2.144 | d0/s7 | K5 |
| 13 | 0.306 | 7.616 | 1.760 | d0/s7 | K6 |
| 14 | 0.328 | 20.384 | 1.792 | d0/s7 | K2 |
| 15 | 0.338 | 8.160 | 1.632 | d0/s7 | K3 |
| 16 | 0.359 | 19.168 | 1.824 | d0/s7 | K7 |
| 17 | 0.368 | 7.680 | 1.472 | d0/s7 | K6 |
| 18 | 0.384 | 14.048 | 2.144 | d0/s7 | K2 |
| 19 | 0.394 | 8.256 | 1.984 | d0/s7 | K3 |
| 20 | 0.419 | 22.688 | 5.920 | d0/s7 | K8 |
| 21 | 0.435 | 10.625 | 4.353 | d0/s7 | K8 |
| 22 | 0.452 | 12.415 | 5.920 | d0/s7 | K8 |
| 23 | 0.468 | 9.632 | 5.953 | d0/s7 | K8 |
| 24 | 0.521 | 47.007 | 1.665 | d0/s7 | K9 |
| 25 | 26.138 | 25615.812 | 1.824 | d0/s7 | K10 |
| 26 | 26.346 | 206.497 | 2.880 | d0/s7 | K11 |
| 27 | 50.715 | 24365.921 | 4.224 | d0/s7 | K12 |
| 28 | 50.896 | 176.160 | 1.985 | d0/s7 | K13 |
| 29 | 75.730 | 24832.194 | 2.528 | d0/s7 | K14 |
| 30 | 75.906 | 173.760 | 3.168 | d0/s7 | K15 |
| 31 | 102.098 | 26188.583 | 5.087 | d0/s7 | K16 |
| 32 | 102.276 | 173.281 | 3.424 | d0/s7 | K15 |
| 33 | 126.907 | 24627.074 | 4.352 | d0/s7 | K12 |
| 34 | 127.109 | 198.145 | 1.600 | d0/s7 | K17 |
| 35 | 127.172 | 61.536 | 1.760 | d0/s7 | K9 |
| 36 | 151.926 | 24751.522 | 1.856 | d0/s7 | K10 |
| 37 | 152.085 | 157.344 | 1.632 | d0/s7 | K18 |
| 38 | 152.147 | 60.320 | 1.505 | d0/s7 | K19 |
| 39 | 176.581 | 24432.737 | 1.984 | d0/s7 | K20 |
| 40 | 176.734 | 151.360 | 1.248 | d0/s7 | K17 |
| 41 | 176.802 | 66.208 | 1.408 | d0/s7 | K9 |
| 42 | 201.639 | 24836.002 | 1.888 | d0/s7 | K10 |
| 43 | 201.788 | 146.560 | 1.600 | d0/s7 | K17 |
| 44 | 201.845 | 55.552 | 1.761 | d0/s7 | K9 |
| 45 | 226.300 | 24453.697 | 1.888 | d0/s7 | K10 |
| 46 | 226.463 | 160.960 | 1.408 | d0/s7 | K21 |
| 47 | 226.528 | 63.072 | 1.569 | d0/s7 | K22 |
| 48 | 251.411 | 24881.442 | 2.080 | d0/s7 | K23 |
| 49 | 5283.279 | 5031866.604 | 4.896 | d0/s7 | K24 |
| 50 | 5283.291 | 6.336 | 59.200 | d0/s7 | K25 |
| 51 | 5283.350 | 0.256 | 56.320 | d0/s7 | K26 |
| 52 | 5283.407 | 0.288 | 47.840 | d0/s7 | K27 |
| 53 | 5283.455 | 0.257 | 4.320 | d0/s7 | K28 |
| 54 | 5283.459 | 0.287 | 65.825 | d0/s7 | K29 |
| 55 | 5283.525 | 0.256 | 192.416 | d0/s7 | K30 |
| 56 | 5283.718 | 0.256 | 3.136 | d0/s7 | K24 |
| 57 | 5283.721 | 0.288 | 45.664 | d0/s7 | K25 |
| 58 | 5283.767 | 0.257 | 56.095 | d0/s7 | K26 |
| 59 | 5283.824 | 0.449 | 33.792 | d0/s7 | K27 |
| 60 | 5283.858 | 0.256 | 3.392 | d0/s7 | K28 |
| 61 | 5283.862 | 0.256 | 57.184 | d0/s7 | K29 |
| 62 | 5283.919 | 0.224 | 129.216 | d0/s7 | K30 |
| 63 | 5284.048 | 0.256 | 3.168 | d0/s7 | K24 |
| 64 | 5284.052 | 0.256 | 46.208 | d0/s7 | K25 |
| 65 | 5284.098 | 0.256 | 56.320 | d0/s7 | K26 |
| 66 | 5284.155 | 0.449 | 33.695 | d0/s7 | K27 |
| 67 | 5284.189 | 0.257 | 3.360 | d0/s7 | K28 |
| 68 | 5284.193 | 0.288 | 57.216 | d0/s7 | K29 |
| 69 | 5284.250 | 0.256 | 129.344 | d0/s7 | K30 |
| 70 | 5284.380 | 0.224 | 3.136 | d0/s7 | K24 |
| 71 | 5284.383 | 0.288 | 45.856 | d0/s7 | K25 |
| 72 | 5284.429 | 0.256 | 56.192 | d0/s7 | K26 |
| 73 | 5284.486 | 0.384 | 33.760 | d0/s7 | K27 |
| 74 | 5284.520 | 0.256 | 3.392 | d0/s7 | K28 |
| 75 | 5284.524 | 0.256 | 57.153 | d0/s7 | K29 |
| 76 | 5284.581 | 0.256 | 129.248 | d0/s7 | K30 |
| 77 | 5284.710 | 0.256 | 3.232 | d0/s7 | K24 |
| 78 | 5284.714 | 0.256 | 45.824 | d0/s7 | K25 |
| 79 | 5284.760 | 0.256 | 56.288 | d0/s7 | K26 |
| 80 | 5284.817 | 0.416 | 33.952 | d0/s7 | K27 |
| 81 | 5284.851 | 0.256 | 3.296 | d0/s7 | K28 |
| 82 | 5284.855 | 0.256 | 56.992 | d0/s7 | K29 |
| 83 | 5284.912 | 0.257 | 129.504 | d0/s7 | K30 |
| 84 | 5285.137 | 95.264 | 3.232 | d0/s7 | K24 |
| 85 | 5285.142 | 1.856 | 46.272 | d0/s7 | K25 |
| 86 | 5285.188 | 0.256 | 56.001 | d0/s7 | K26 |
| 87 | 5285.245 | 0.415 | 33.728 | d0/s7 | K27 |
| 88 | 5285.279 | 0.257 | 3.327 | d0/s7 | K28 |
| 89 | 5285.282 | 0.257 | 57.120 | d0/s7 | K29 |
| 90 | 5285.340 | 0.256 | 129.376 | d0/s7 | K30 |
| 91 | 5285.529 | 60.000 | 3.264 | d0/s7 | K24 |
| 92 | 5285.535 | 2.688 | 46.304 | d0/s7 | K25 |
| 93 | 5285.581 | 0.256 | 56.192 | d0/s7 | K26 |
| 94 | 5285.638 | 0.417 | 33.792 | d0/s7 | K27 |
| 95 | 5285.672 | 0.255 | 3.328 | d0/s7 | K28 |
| 96 | 5285.676 | 0.257 | 57.216 | d0/s7 | K29 |
| 97 | 5285.733 | 0.256 | 129.280 | d0/s7 | K30 |
| 98 | 5285.909 | 47.104 | 3.264 | d0/s7 | K24 |
| 99 | 5285.913 | 0.704 | 46.208 | d0/s7 | K25 |
| 100 | 5285.960 | 0.256 | 56.352 | d0/s7 | K26 |
| 101 | 5286.017 | 0.385 | 33.728 | d0/s7 | K27 |
| 102 | 5286.051 | 0.255 | 3.329 | d0/s7 | K28 |
| 103 | 5286.054 | 0.256 | 57.280 | d0/s7 | K29 |
| 104 | 5286.112 | 0.256 | 129.472 | d0/s7 | K30 |
| 105 | 5286.286 | 45.120 | 3.136 | d0/s7 | K24 |
| 106 | 5286.290 | 0.672 | 46.272 | d0/s7 | K25 |
| 107 | 5286.337 | 0.257 | 56.287 | d0/s7 | K26 |
| 108 | 5286.393 | 0.385 | 33.984 | d0/s7 | K27 |
| 109 | 5286.428 | 0.288 | 3.360 | d0/s7 | K28 |
| 110 | 5286.431 | 0.256 | 57.184 | d0/s7 | K29 |
| 111 | 5286.489 | 0.256 | 129.344 | d0/s7 | K30 |
| 112 | 5286.663 | 45.184 | 3.136 | d0/s7 | K24 |
| 113 | 5286.668 | 1.504 | 46.080 | d0/s7 | K25 |
| 114 | 5286.714 | 0.288 | 56.576 | d0/s7 | K26 |
| 115 | 5286.771 | 0.417 | 33.728 | d0/s7 | K27 |
| 116 | 5286.805 | 0.255 | 3.392 | d0/s7 | K28 |
| 117 | 5286.809 | 0.257 | 57.184 | d0/s7 | K29 |
| 118 | 5286.866 | 0.256 | 129.312 | d0/s7 | K30 |
| 119 | 5287.041 | 45.152 | 3.168 | d0/s7 | K24 |
| 120 | 5287.045 | 1.312 | 46.080 | d0/s7 | K25 |
| 121 | 5287.092 | 0.257 | 56.352 | d0/s7 | K26 |
| 122 | 5287.148 | 0.415 | 33.793 | d0/s7 | K27 |
| 123 | 5287.182 | 0.256 | 3.391 | d0/s7 | K28 |
| 124 | 5287.186 | 0.257 | 57.056 | d0/s7 | K29 |
| 125 | 5287.243 | 0.256 | 129.408 | d0/s7 | K30 |
| 126 | 5287.417 | 44.063 | 3.168 | d0/s7 | K24 |
| 127 | 5287.421 | 0.672 | 46.049 | d0/s7 | K25 |
| 128 | 5287.467 | 0.255 | 56.097 | d0/s7 | K26 |
| 129 | 5287.523 | 0.383 | 33.793 | d0/s7 | K27 |
| 130 | 5287.557 | 0.256 | 3.360 | d0/s7 | K28 |
| 131 | 5287.561 | 0.256 | 57.088 | d0/s7 | K29 |
| 132 | 5287.618 | 0.256 | 129.504 | d0/s7 | K30 |
| 133 | 5287.792 | 44.064 | 3.232 | d0/s7 | K24 |
| 134 | 5287.796 | 0.992 | 46.209 | d0/s7 | K25 |
| 135 | 5287.843 | 0.255 | 56.385 | d0/s7 | K26 |
| 136 | 5287.900 | 0.415 | 33.825 | d0/s7 | K27 |
| 137 | 5287.934 | 0.256 | 3.328 | d0/s7 | K28 |
| 138 | 5287.937 | 0.256 | 57.088 | d0/s7 | K29 |
| 139 | 5287.995 | 0.256 | 129.472 | d0/s7 | K30 |
| 140 | 5288.169 | 44.704 | 3.264 | d0/s7 | K24 |
| 141 | 5288.174 | 1.952 | 46.176 | d0/s7 | K25 |
| 142 | 5288.220 | 0.256 | 56.384 | d0/s7 | K26 |
| 143 | 5288.277 | 0.417 | 33.696 | d0/s7 | K27 |
| 144 | 5288.311 | 0.256 | 3.328 | d0/s7 | K28 |
| 145 | 5288.315 | 0.256 | 56.928 | d0/s7 | K29 |
| 146 | 5288.372 | 0.255 | 129.376 | d0/s7 | K30 |
| 147 | 5288.546 | 44.768 | 3.232 | d0/s7 | K24 |
| 148 | 5288.552 | 2.305 | 46.272 | d0/s7 | K25 |
| 149 | 5288.598 | 0.255 | 56.225 | d0/s7 | K26 |
| 150 | 5288.655 | 0.384 | 33.696 | d0/s7 | K27 |
| 151 | 5288.689 | 0.256 | 3.328 | d0/s7 | K28 |
| 152 | 5288.692 | 0.256 | 56.896 | d0/s7 | K29 |
| 153 | 5288.749 | 0.256 | 129.312 | d0/s7 | K30 |
| 154 | 5288.922 | 43.808 | 3.264 | d0/s7 | K24 |
| 155 | 5288.927 | 1.472 | 45.920 | d0/s7 | K25 |
| 156 | 5288.973 | 0.257 | 56.416 | d0/s7 | K26 |
| 157 | 5289.030 | 0.416 | 33.792 | d0/s7 | K27 |
| 158 | 5289.064 | 0.256 | 3.296 | d0/s7 | K28 |
| 159 | 5289.068 | 0.256 | 57.152 | d0/s7 | K29 |
| 160 | 5289.125 | 0.256 | 129.376 | d0/s7 | K30 |
| 161 | 5289.299 | 44.192 | 3.168 | d0/s7 | K24 |
| 162 | 5289.304 | 2.240 | 46.176 | d0/s7 | K25 |
| 163 | 5289.351 | 0.257 | 56.224 | d0/s7 | K26 |
| 164 | 5289.407 | 0.384 | 33.792 | d0/s7 | K27 |
| 165 | 5289.441 | 0.256 | 3.392 | d0/s7 | K28 |
| 166 | 5289.445 | 0.256 | 57.248 | d0/s7 | K29 |
| 167 | 5289.502 | 0.256 | 129.376 | d0/s7 | K30 |
| 168 | 5289.675 | 43.457 | 3.167 | d0/s7 | K24 |
| 169 | 5289.679 | 0.928 | 46.017 | d0/s7 | K25 |
| 170 | 5289.726 | 0.255 | 56.577 | d0/s7 | K26 |
| 171 | 5289.783 | 0.384 | 33.792 | d0/s7 | K27 |
| 172 | 5289.817 | 0.256 | 3.392 | d0/s7 | K28 |
| 173 | 5289.820 | 0.256 | 57.216 | d0/s7 | K29 |
| 174 | 5289.878 | 0.256 | 129.376 | d0/s7 | K30 |
| 175 | 5290.051 | 44.096 | 3.169 | d0/s7 | K24 |
| 176 | 5290.056 | 1.247 | 46.208 | d0/s7 | K25 |
| 177 | 5290.102 | 0.257 | 56.192 | d0/s7 | K26 |
| 178 | 5290.159 | 0.384 | 33.792 | d0/s7 | K27 |
| 179 | 5290.193 | 0.256 | 3.392 | d0/s7 | K28 |
| 180 | 5290.196 | 0.256 | 57.056 | d0/s7 | K29 |
| 181 | 5290.254 | 0.288 | 129.248 | d0/s7 | K30 |
| 182 | 5290.427 | 44.352 | 3.169 | d0/s7 | K24 |
| 183 | 5290.431 | 0.768 | 46.207 | d0/s7 | K25 |
| 184 | 5290.478 | 0.257 | 56.288 | d0/s7 | K26 |
| 185 | 5290.534 | 0.384 | 33.792 | d0/s7 | K27 |
| 186 | 5290.568 | 0.256 | 3.392 | d0/s7 | K28 |
| 187 | 5290.572 | 0.288 | 57.056 | d0/s7 | K29 |
| 188 | 5290.629 | 0.256 | 129.504 | d0/s7 | K30 |
| 189 | 5290.804 | 44.833 | 3.265 | d0/s7 | K24 |
| 190 | 5290.808 | 0.959 | 46.112 | d0/s7 | K25 |
| 191 | 5290.854 | 0.256 | 56.320 | d0/s7 | K26 |
| 192 | 5290.911 | 0.416 | 33.792 | d0/s7 | K27 |
| 193 | 5290.945 | 0.256 | 3.296 | d0/s7 | K28 |
| 194 | 5290.949 | 0.288 | 57.056 | d0/s7 | K29 |
| 195 | 5291.006 | 0.288 | 129.248 | d0/s7 | K30 |
| 196 | 5291.180 | 44.609 | 3.263 | d0/s7 | K24 |
| 197 | 5291.184 | 0.737 | 46.272 | d0/s7 | K25 |
| 198 | 5291.230 | 0.256 | 56.160 | d0/s7 | K26 |
| 199 | 5291.287 | 0.384 | 33.792 | d0/s7 | K27 |
| 200 | 5291.321 | 0.256 | 3.296 | d0/s7 | K28 |
| 201 | 5291.325 | 0.256 | 57.184 | d0/s7 | K29 |
| 202 | 5291.382 | 0.288 | 129.472 | d0/s7 | K30 |
| 203 | 5291.557 | 45.664 | 3.233 | d0/s7 | K24 |
| 204 | 5291.562 | 1.824 | 46.048 | d0/s7 | K25 |
| 205 | 5291.609 | 0.255 | 56.321 | d0/s7 | K26 |
| 206 | 5291.665 | 0.416 | 33.760 | d0/s7 | K27 |
| 207 | 5291.699 | 0.256 | 3.328 | d0/s7 | K28 |
| 208 | 5291.703 | 0.256 | 57.024 | d0/s7 | K29 |
| 209 | 5291.760 | 0.256 | 129.376 | d0/s7 | K30 |
| 210 | 5291.933 | 43.105 | 3.264 | d0/s7 | K24 |
| 211 | 5291.937 | 0.671 | 46.017 | d0/s7 | K25 |
| 212 | 5291.983 | 0.256 | 56.320 | d0/s7 | K26 |
| 213 | 5292.040 | 0.384 | 33.792 | d0/s7 | K27 |
| 214 | 5292.074 | 0.256 | 3.296 | d0/s7 | K28 |
| 215 | 5292.077 | 0.256 | 57.312 | d0/s7 | K29 |
| 216 | 5292.135 | 0.224 | 129.377 | d0/s7 | K30 |
| 217 | 5292.306 | 42.272 | 3.167 | d0/s7 | K24 |
| 218 | 5292.311 | 1.505 | 46.304 | d0/s7 | K25 |
| 219 | 5292.358 | 0.256 | 56.160 | d0/s7 | K26 |
| 220 | 5292.414 | 0.384 | 33.952 | d0/s7 | K27 |
| 221 | 5292.448 | 0.288 | 3.360 | d0/s7 | K28 |
| 222 | 5292.452 | 0.256 | 57.216 | d0/s7 | K29 |
| 223 | 5292.510 | 0.256 | 129.441 | d0/s7 | K30 |
| 224 | 5292.683 | 43.552 | 3.168 | d0/s7 | K24 |
| 225 | 5292.687 | 1.792 | 45.952 | d0/s7 | K25 |
| 226 | 5292.734 | 0.256 | 56.480 | d0/s7 | K26 |
| 227 | 5292.791 | 0.416 | 33.792 | d0/s7 | K27 |
| 228 | 5292.825 | 0.256 | 3.392 | d0/s7 | K28 |
| 229 | 5292.828 | 0.256 | 57.056 | d0/s7 | K29 |
| 230 | 5292.886 | 0.256 | 129.281 | d0/s7 | K30 |
| 231 | 5293.058 | 42.880 | 3.167 | d0/s7 | K24 |
| 232 | 5293.063 | 2.337 | 46.240 | d0/s7 | K25 |
| 233 | 5293.110 | 0.256 | 56.192 | d0/s7 | K26 |
| 234 | 5293.166 | 0.384 | 33.760 | d0/s7 | K27 |
| 235 | 5293.200 | 0.256 | 3.360 | d0/s7 | K28 |
| 236 | 5293.204 | 0.256 | 56.992 | d0/s7 | K29 |
| 237 | 5293.261 | 0.256 | 129.409 | d0/s7 | K30 |
| 238 | 5293.433 | 42.656 | 3.136 | d0/s7 | K24 |
| 239 | 5293.438 | 1.535 | 45.985 | d0/s7 | K25 |
| 240 | 5293.484 | 0.224 | 56.128 | d0/s7 | K26 |
| 241 | 5293.541 | 0.384 | 33.760 | d0/s7 | K27 |
| 242 | 5293.575 | 0.256 | 3.360 | d0/s7 | K28 |
| 243 | 5293.578 | 0.256 | 57.152 | d0/s7 | K29 |
| 244 | 5293.636 | 0.256 | 129.504 | d0/s7 | K30 |
| 245 | 5293.809 | 43.841 | 3.200 | d0/s7 | K24 |
| 246 | 5293.813 | 0.736 | 46.048 | d0/s7 | K25 |
| 247 | 5293.859 | 0.256 | 56.448 | d0/s7 | K26 |
| 248 | 5293.916 | 0.384 | 33.728 | d0/s7 | K27 |
| 249 | 5293.950 | 0.256 | 3.296 | d0/s7 | K28 |
| 250 | 5293.954 | 0.256 | 57.024 | d0/s7 | K29 |
| 251 | 5294.011 | 0.256 | 129.536 | d0/s7 | K30 |
| 252 | 5294.184 | 43.777 | 3.264 | d0/s7 | K24 |
| 253 | 5294.188 | 0.991 | 46.113 | d0/s7 | K25 |
| 254 | 5294.235 | 0.288 | 56.096 | d0/s7 | K26 |
| 255 | 5294.291 | 0.384 | 33.824 | d0/s7 | K27 |
| 256 | 5294.325 | 0.255 | 3.328 | d0/s7 | K28 |
| 257 | 5294.329 | 0.256 | 57.216 | d0/s7 | K29 |
| 258 | 5294.387 | 0.256 | 129.505 | d0/s7 | K30 |
| 259 | 5294.560 | 44.415 | 3.233 | d0/s7 | K24 |
| 260 | 5294.565 | 0.960 | 46.016 | d0/s7 | K25 |
| 261 | 5294.611 | 0.256 | 56.224 | d0/s7 | K26 |
| 262 | 5294.667 | 0.384 | 33.824 | d0/s7 | K27 |
| 263 | 5294.702 | 0.256 | 3.296 | d0/s7 | K28 |
| 264 | 5294.705 | 0.256 | 57.088 | d0/s7 | K29 |
| 265 | 5294.762 | 0.256 | 129.344 | d0/s7 | K30 |
| 266 | 5294.937 | 44.896 | 3.232 | d0/s7 | K24 |
| 267 | 5294.941 | 0.960 | 46.016 | d0/s7 | K25 |
| 268 | 5294.987 | 0.256 | 56.544 | d0/s7 | K26 |
| 269 | 5295.044 | 0.416 | 33.728 | d0/s7 | K27 |
| 270 | 5295.078 | 0.256 | 3.296 | d0/s7 | K28 |
| 271 | 5295.082 | 0.256 | 57.056 | d0/s7 | K29 |
| 272 | 5295.139 | 0.256 | 129.248 | d0/s7 | K30 |
| 273 | 5295.314 | 46.017 | 3.168 | d0/s7 | K24 |
| 274 | 5295.318 | 0.960 | 46.368 | d0/s7 | K25 |
| 275 | 5295.365 | 0.256 | 56.352 | d0/s7 | K26 |
| 276 | 5295.422 | 0.384 | 33.728 | d0/s7 | K27 |
| 277 | 5295.456 | 0.256 | 3.392 | d0/s7 | K28 |
| 278 | 5295.459 | 0.256 | 56.960 | d0/s7 | K29 |
| 279 | 5295.517 | 0.256 | 129.345 | d0/s7 | K30 |
| 280 | 5295.690 | 43.776 | 3.168 | d0/s7 | K24 |
| 281 | 5295.694 | 0.832 | 46.016 | d0/s7 | K25 |
| 282 | 5295.740 | 0.256 | 56.576 | d0/s7 | K26 |
| 283 | 5295.797 | 0.384 | 33.824 | d0/s7 | K27 |
| 284 | 5295.831 | 0.256 | 3.392 | d0/s7 | K28 |
| 285 | 5295.835 | 0.256 | 57.152 | d0/s7 | K29 |
| 286 | 5295.892 | 0.256 | 129.313 | d0/s7 | K30 |
| 287 | 5296.065 | 44.096 | 3.168 | d0/s7 | K24 |
| 288 | 5296.070 | 1.568 | 46.144 | d0/s7 | K25 |
| 289 | 5296.117 | 0.288 | 56.256 | d0/s7 | K26 |
| 290 | 5296.173 | 0.384 | 33.792 | d0/s7 | K27 |
| 291 | 5296.207 | 0.256 | 3.360 | d0/s7 | K28 |
| 292 | 5296.211 | 0.256 | 57.088 | d0/s7 | K29 |
| 293 | 5296.268 | 0.256 | 129.473 | d0/s7 | K30 |
| 294 | 5296.443 | 44.992 | 3.136 | d0/s7 | K24 |
| 295 | 5296.447 | 1.536 | 45.920 | d0/s7 | K25 |
| 296 | 5296.494 | 0.256 | 56.128 | d0/s7 | K26 |
| 297 | 5296.550 | 0.384 | 33.728 | d0/s7 | K27 |
| 298 | 5296.584 | 0.256 | 3.392 | d0/s7 | K28 |
| 299 | 5296.588 | 0.256 | 56.992 | d0/s7 | K29 |
| 300 | 5296.645 | 0.256 | 129.185 | d0/s7 | K30 |
| 301 | 5296.817 | 42.400 | 3.264 | d0/s7 | K24 |
| 302 | 5296.821 | 1.504 | 46.048 | d0/s7 | K25 |
| 303 | 5296.868 | 0.256 | 56.224 | d0/s7 | K26 |
| 304 | 5296.924 | 0.384 | 33.792 | d0/s7 | K27 |
| 305 | 5296.958 | 0.256 | 3.328 | d0/s7 | K28 |
| 306 | 5296.962 | 0.256 | 57.056 | d0/s7 | K29 |
| 307 | 5297.019 | 0.256 | 129.377 | d0/s7 | K30 |
| 308 | 5297.192 | 43.584 | 3.264 | d0/s7 | K24 |
| 309 | 5297.197 | 1.376 | 46.016 | d0/s7 | K25 |
| 310 | 5297.243 | 0.256 | 56.192 | d0/s7 | K26 |
| 311 | 5297.300 | 0.384 | 33.792 | d0/s7 | K27 |
| 312 | 5297.334 | 0.256 | 3.328 | d0/s7 | K28 |
| 313 | 5297.337 | 0.256 | 57.376 | d0/s7 | K29 |
| 314 | 5297.395 | 0.256 | 129.409 | d0/s7 | K30 |
| 315 | 5297.568 | 43.776 | 3.264 | d0/s7 | K24 |
| 316 | 5297.573 | 1.792 | 46.080 | d0/s7 | K25 |
| 317 | 5297.620 | 0.256 | 56.416 | d0/s7 | K26 |
| 318 | 5297.676 | 0.416 | 33.728 | d0/s7 | K27 |
| 319 | 5297.710 | 0.256 | 3.328 | d0/s7 | K28 |
| 320 | 5297.714 | 0.256 | 57.152 | d0/s7 | K29 |
| 321 | 5297.771 | 0.256 | 129.377 | d0/s7 | K30 |
| 322 | 5297.944 | 43.328 | 3.264 | d0/s7 | K24 |
| 323 | 5297.948 | 0.512 | 46.112 | d0/s7 | K25 |
| 324 | 5297.994 | 0.256 | 56.544 | d0/s7 | K26 |
| 325 | 5298.051 | 0.384 | 33.792 | d0/s7 | K27 |
| 326 | 5298.085 | 0.256 | 3.328 | d0/s7 | K28 |
| 327 | 5298.089 | 0.256 | 57.376 | d0/s7 | K29 |
| 328 | 5298.146 | 0.256 | 129.377 | d0/s7 | K30 |
| 329 | 5298.319 | 42.784 | 3.136 | d0/s7 | K24 |
| 330 | 5298.331 | 9.312 | 45.856 | d0/s7 | K25 |
| 331 | 5298.377 | 0.256 | 56.384 | d0/s7 | K26 |
| 332 | 5298.434 | 0.417 | 33.824 | d0/s7 | K27 |
| 333 | 5298.468 | 0.256 | 3.360 | d0/s7 | K28 |
| 334 | 5298.472 | 0.256 | 57.024 | d0/s7 | K29 |
| 335 | 5298.529 | 0.256 | 129.473 | d0/s7 | K30 |
| 336 | 5298.703 | 44.704 | 3.168 | d0/s7 | K24 |
| 337 | 5298.707 | 0.448 | 45.792 | d0/s7 | K25 |
| 338 | 5298.753 | 0.256 | 56.480 | d0/s7 | K26 |
| 339 | 5298.810 | 0.384 | 33.760 | d0/s7 | K27 |
| 340 | 5298.844 | 0.256 | 3.424 | d0/s7 | K28 |
| 341 | 5298.847 | 0.256 | 57.153 | d0/s7 | K29 |
| 342 | 5298.905 | 0.255 | 129.313 | d0/s7 | K30 |
| 343 | 5299.077 | 42.784 | 3.200 | d0/s7 | K24 |
| 344 | 5299.081 | 0.960 | 45.952 | d0/s7 | K25 |
| 345 | 5299.127 | 0.256 | 56.224 | d0/s7 | K26 |
| 346 | 5299.184 | 0.384 | 33.824 | d0/s7 | K27 |
| 347 | 5299.218 | 0.256 | 3.392 | d0/s7 | K28 |
| 348 | 5299.221 | 0.256 | 57.056 | d0/s7 | K29 |
| 349 | 5299.279 | 0.256 | 129.473 | d0/s7 | K30 |
| 350 | 5299.468 | 60.032 | 3.136 | d0/s7 | K24 |
| 351 | 5299.480 | 8.160 | 46.016 | d0/s7 | K25 |
| 352 | 5299.526 | 0.256 | 56.160 | d0/s7 | K26 |
| 353 | 5299.582 | 0.384 | 33.792 | d0/s7 | K27 |
| 354 | 5299.616 | 0.256 | 3.360 | d0/s7 | K28 |
| 355 | 5299.620 | 0.288 | 57.089 | d0/s7 | K29 |
| 356 | 5299.677 | 0.255 | 129.409 | d0/s7 | K30 |
| 357 | 5299.852 | 44.704 | 3.232 | d0/s7 | K24 |
| 358 | 5299.856 | 0.864 | 46.080 | d0/s7 | K25 |
| 359 | 5299.902 | 0.256 | 56.192 | d0/s7 | K26 |
| 360 | 5299.959 | 0.384 | 33.921 | d0/s7 | K27 |
| 361 | 5299.993 | 0.255 | 3.296 | d0/s7 | K28 |
| 362 | 5299.996 | 0.257 | 57.056 | d0/s7 | K29 |
| 363 | 5300.054 | 0.256 | 129.472 | d0/s7 | K30 |
| 364 | 5300.226 | 43.200 | 3.232 | d0/s7 | K24 |
| 365 | 5300.231 | 1.504 | 46.240 | d0/s7 | K25 |
| 366 | 5300.277 | 0.256 | 56.256 | d0/s7 | K26 |
| 367 | 5300.334 | 0.384 | 33.761 | d0/s7 | K27 |
| 368 | 5300.368 | 0.255 | 3.296 | d0/s7 | K28 |
| 369 | 5300.372 | 0.256 | 57.280 | d0/s7 | K29 |
| 370 | 5300.429 | 0.257 | 129.504 | d0/s7 | K30 |
| 371 | 5300.603 | 43.872 | 3.232 | d0/s7 | K24 |
| 372 | 5300.608 | 2.432 | 46.176 | d0/s7 | K25 |
| 373 | 5300.655 | 0.256 | 56.289 | d0/s7 | K26 |
| 374 | 5300.711 | 0.383 | 33.792 | d0/s7 | K27 |
| 375 | 5300.745 | 0.257 | 3.328 | d0/s7 | K28 |
| 376 | 5300.749 | 0.255 | 57.185 | d0/s7 | K29 |
| 377 | 5300.806 | 0.256 | 129.280 | d0/s7 | K30 |
| 378 | 5300.979 | 43.648 | 3.232 | d0/s7 | K24 |
| 379 | 5300.983 | 0.800 | 46.272 | d0/s7 | K25 |
| 380 | 5301.030 | 0.256 | 56.416 | d0/s7 | K26 |
| 381 | 5301.087 | 0.385 | 33.760 | d0/s7 | K27 |
| 382 | 5301.121 | 0.255 | 3.329 | d0/s7 | K28 |
| 383 | 5301.124 | 0.256 | 57.087 | d0/s7 | K29 |
| 384 | 5301.182 | 0.257 | 129.408 | d0/s7 | K30 |
| 385 | 5301.358 | 46.912 | 3.136 | d0/s7 | K24 |
| 386 | 5301.363 | 1.888 | 46.144 | d0/s7 | K25 |
| 387 | 5301.409 | 0.256 | 56.416 | d0/s7 | K26 |
| 388 | 5301.466 | 0.384 | 33.792 | d0/s7 | K27 |
| 389 | 5301.500 | 0.257 | 3.360 | d0/s7 | K28 |
| 390 | 5301.504 | 0.255 | 56.992 | d0/s7 | K29 |
| 391 | 5301.561 | 0.257 | 129.440 | d0/s7 | K30 |
| 392 | 5301.732 | 41.728 | 3.136 | d0/s7 | K24 |
| 393 | 5301.737 | 1.216 | 46.016 | d0/s7 | K25 |
| 394 | 5301.783 | 0.288 | 56.544 | d0/s7 | K26 |
| 395 | 5301.840 | 0.416 | 33.761 | d0/s7 | K27 |
| 396 | 5301.874 | 0.255 | 3.392 | d0/s7 | K28 |
| 397 | 5301.878 | 0.255 | 57.153 | d0/s7 | K29 |
| 398 | 5301.935 | 0.256 | 129.152 | d0/s7 | K30 |
| 399 | 5302.106 | 41.984 | 3.136 | d0/s7 | K24 |
| 400 | 5302.110 | 0.928 | 46.112 | d0/s7 | K25 |
| 401 | 5302.157 | 0.256 | 56.256 | d0/s7 | K26 |
| 402 | 5302.213 | 0.417 | 33.792 | d0/s7 | K27 |
| 403 | 5302.247 | 0.256 | 3.360 | d0/s7 | K28 |
| 404 | 5302.251 | 0.255 | 57.089 | d0/s7 | K29 |
| 405 | 5302.308 | 0.256 | 129.472 | d0/s7 | K30 |
| 406 | 5302.483 | 44.832 | 3.136 | d0/s7 | K24 |
| 407 | 5302.487 | 0.832 | 46.080 | d0/s7 | K25 |
| 408 | 5302.533 | 0.256 | 56.224 | d0/s7 | K26 |
| 409 | 5302.589 | 0.385 | 33.952 | d0/s7 | K27 |
| 410 | 5302.624 | 0.255 | 3.360 | d0/s7 | K28 |
| 411 | 5302.627 | 0.289 | 57.089 | d0/s7 | K29 |
| 412 | 5302.685 | 0.256 | 129.472 | d0/s7 | K30 |
| 413 | 5302.858 | 43.552 | 3.264 | d0/s7 | K24 |
| 414 | 5302.862 | 0.832 | 46.144 | d0/s7 | K25 |
| 415 | 5302.908 | 0.256 | 56.385 | d0/s7 | K26 |
| 416 | 5302.965 | 0.383 | 33.761 | d0/s7 | K27 |
| 417 | 5302.999 | 0.256 | 3.295 | d0/s7 | K28 |
| 418 | 5303.003 | 0.257 | 56.992 | d0/s7 | K29 |
| 419 | 5303.060 | 0.256 | 129.408 | d0/s7 | K30 |
| 420 | 5303.233 | 44.000 | 3.264 | d0/s7 | K24 |
| 421 | 5303.237 | 0.704 | 46.080 | d0/s7 | K25 |
| 422 | 5303.283 | 0.256 | 56.160 | d0/s7 | K26 |
| 423 | 5303.340 | 0.385 | 33.792 | d0/s7 | K27 |
| 424 | 5303.374 | 0.256 | 3.327 | d0/s7 | K28 |
| 425 | 5303.378 | 0.257 | 57.248 | d0/s7 | K29 |
| 426 | 5303.435 | 0.256 | 129.568 | d0/s7 | K30 |
| 427 | 5303.608 | 43.232 | 3.264 | d0/s7 | K24 |
| 428 | 5303.612 | 0.736 | 46.368 | d0/s7 | K25 |
| 429 | 5303.659 | 0.289 | 56.287 | d0/s7 | K26 |
| 430 | 5303.715 | 0.385 | 33.695 | d0/s7 | K27 |
| 431 | 5303.749 | 0.257 | 3.328 | d0/s7 | K28 |
| 432 | 5303.753 | 0.255 | 57.153 | d0/s7 | K29 |
| 433 | 5303.810 | 0.256 | 129.184 | d0/s7 | K30 |
| 434 | 5304.172 | 232.609 | 3.968 | d0/s7 | K31 |
| 435 | 5304.247 | 71.232 | 1.792 | d0/s7 | K32 |
| 436 | 5304.354 | 105.216 | 4.192 | d0/s7 | K33 |
| 437 | 5304.402 | 43.233 | 1.760 | d0/s7 | K9 |
| 438 | 5304.440 | 36.512 | 1.728 | d0/s7 | K34 |
| 439 | 5304.517 | 75.264 | 1.632 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 440 | 5304.565 | 46.432 | 1.600 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 441 | 5304.834 | 267.361 | 3.200 | d0/s7 | K35 |
| 442 | 5304.892 | 55.040 | 2.464 | d0/s7 | K36 |
| 443 | 5304.913 | 17.856 | 1.760 | d0/s7 | K19 |
| 444 | 5304.931 | 17.056 | 2.048 | d0/s7 | K37 |
| 445 | 5304.947 | 13.312 | 3.648 | d0/s7 | K38 |
| 446 | 5304.963 | 13.088 | 1.888 | d0/s7 | K39 |
| 447 | 5305.309 | 343.297 | 4.512 | d0/s7 | K40 |
| 448 | 5305.356 | 42.880 | 1.632 | d0/s7 | K41 |
| 449 | 5305.417 | 59.328 | 1.248 | d0/s7 | K42 |
| 450 | 5305.465 | 46.496 | 2.336 | d0/s7 | K43 |
| 451 | 5305.549 | 81.824 | 1.729 | d0/s7 | Memcpy DtoD (Device -> Device) (786432 B) |
| 452 | 5305.592 | 40.960 | 2.432 | d0/s7 | K44 |
| 453 | 5305.635 | 40.800 | 3.264 | d0/s7 | K45 |
| 454 | 5305.715 | 77.184 | 5.152 | d0/s7 | K46 |
| 455 | 5305.748 | 27.552 | 2.464 | d0/s7 | K47 |
| 456 | 5305.774 | 23.744 | 1.664 | d0/s7 | K9 |
| 457 | 5305.793 | 16.832 | 1.728 | d0/s7 | K34 |
| 458 | 5305.824 | 29.696 | 1.760 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 459 | 5305.859 | 33.665 | 1.728 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 460 | 5305.955 | 94.113 | 2.880 | d0/s7 | K48 |
| 461 | 5305.982 | 23.360 | 2.240 | d0/s7 | K49 |
| 462 | 5306.005 | 21.567 | 1.792 | d0/s7 | K50 |
| 463 | 5306.045 | 37.888 | 4.064 | d0/s7 | K33 |
| 464 | 5306.064 | 14.400 | 1.760 | d0/s7 | K9 |
| 465 | 5306.080 | 14.784 | 1.984 | d0/s7 | K34 |
| 466 | 5306.100 | 17.984 | 1.536 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 467 | 5306.128 | 26.688 | 0.704 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 468 | 5306.185 | 56.224 | 3.456 | d0/s7 | K51 |
| 469 | 5306.200 | 10.880 | 2.624 | d0/s7 | K52 |
| 470 | 5306.236 | 34.112 | 2.176 | d0/s7 | K53 |
| 471 | 5306.251 | 13.024 | 1.633 | d0/s7 | K22 |
| 472 | 5306.267 | 14.015 | 2.112 | d0/s7 | K54 |
| 473 | 5306.286 | 16.288 | 1.760 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 474 | 5306.313 | 25.312 | 1.953 | d0/s7 | Memcpy HtoD (Pageable -> Device) (4 B) |
| 475 | 5306.372 | 57.856 | 4.128 | d0/s7 | K48 |
| 476 | 5306.386 | 9.024 | 2.368 | d0/s7 | K49 |
| 477 | 5306.398 | 10.112 | 1.824 | d0/s7 | K50 |
| 478 | 5306.420 | 20.160 | 4.384 | d0/s7 | K33 |
| 479 | 5306.494 | 69.888 | 22.112 | d0/s7 | K55 |
| 480 | 5306.517 | 0.256 | 2.432 | d0/s7 | K36 |
| 481 | 5306.602 | 82.464 | 4.097 | d0/s7 | K40 |
| 482 | 5306.624 | 18.367 | 1.825 | d0/s7 | K41 |
| 483 | 5306.662 | 35.775 | 1.825 | d0/s7 | Memcpy DtoD (Device -> Device) (786432 B) |
| 484 | 5306.679 | 15.935 | 2.208 | d0/s7 | K44 |
| 485 | 5306.700 | 18.881 | 3.231 | d0/s7 | K45 |
| 486 | 5306.751 | 47.105 | 5.056 | d0/s7 | K46 |
| 487 | 5306.777 | 20.864 | 2.272 | d0/s7 | K47 |
| 488 | 5306.806 | 27.424 | 20.064 | d0/s7 | K56 |
| 489 | 5306.827 | 0.256 | 1.664 | d0/s7 | K50 |
| 490 | 5306.832 | 3.776 | 2.464 | d0/s7 | K49 |
| 491 | 5306.858 | 23.296 | 4.032 | d0/s7 | K33 |
| 492 | 5306.896 | 34.175 | 24.608 | d0/s7 | K57 |
| 493 | 5306.921 | 0.256 | 2.560 | d0/s7 | K52 |
| 494 | 5306.925 | 1.760 | 1.984 | d0/s7 | K53 |
| 495 | 5306.960 | 32.961 | 1.760 | d0/s7 | Memset (Device) (1536 B) |
| 496 | 5306.976 | 13.887 | 1.313 | d0/s7 | K58 |
| 497 | 5306.989 | 11.680 | 61.760 | d0/s7 | K59 |
| 498 | 5307.051 | 0.256 | 1.696 | d0/s7 | K50 |
| 499 | 5307.053 | 0.255 | 2.337 | d0/s7 | K49 |
| 500 | 5307.055 | 0.256 | 1.952 | d0/s7 | K50 |
| 501 | 5307.078 | 20.608 | 1.792 | d0/s7 | K60 |
| 502 | 5307.127 | 47.072 | 13.632 | d0/s7 | K61 |
| 503 | 5307.169 | 28.192 | 5.184 | d0/s7 | Memcpy DtoH (Device -> Pinned) (4 B) |
| 504 | 5307.225 | 50.848 | 1.600 | d0/s7 | Memcpy HtoD (Pageable -> Device) (56 B) |
| 505 | 5307.261 | 34.528 | 1.600 | d0/s7 | Memcpy HtoD (Pageable -> Device) (48 B) |
| 506 | 5307.344 | 81.856 | 4.288 | d0/s7 | K62 |
| 507 | 5307.363 | 14.112 | 4.033 | d0/s7 | K63 |
| 508 | 5307.377 | 10.240 | 3.935 | d0/s7 | K62 |
| 509 | 5307.397 | 16.192 | 3.808 | d0/s7 | K63 |
| 510 | 5307.410 | 8.769 | 1.951 | d0/s7 | K64 |
| 511 | 5307.426 | 14.752 | 1.920 | d0/s7 | K65 |
| 512 | 5307.444 | 15.617 | 2.816 | d0/s7 | K66 |
| 513 | 5307.456 | 9.280 | 3.840 | d0/s7 | Memcpy DtoH (Device -> Pinned) (4 B) |
| 514 | 5307.493 | 32.864 | 1.760 | d0/s7 | K60 |
| 515 | 5307.529 | 34.368 | 1.504 | d0/s7 | K67 |
| 516 | 5307.561 | 30.592 | 1.536 | d0/s7 | K68 |
| 517 | 5307.590 | 27.328 | 1.472 | d0/s7 | K69 |
| 518 | 5307.645 | 54.048 | 12.576 | d0/s7 | K70 |
| 519 | 5307.662 | 4.192 | 2.848 | d0/s7 | Memcpy DtoH (Device -> Pinned) (1 B) |
