import cutlass
import cutlass.cute as cute


TOKENS = 128
HIDDEN_SIZE = 768
NUM_HEADS = 12
HEAD_DIM = 64
MLP_SIZE = 3072
QKV_SIZE = 3 * HIDDEN_SIZE
THREADS = 128
EPSILON = 1.0e-5

INPUT_SCALE = 1.0 / 448.0
NORM_SCALE = 1.0 / 64.0
QKV_SCALE = 1.0 / 64.0
CONTEXT_SCALE = 1.0 / 64.0
MLP_SCALE = 1.0 / 64.0
WEIGHT_H_SCALE = HIDDEN_SIZE ** -0.5 / 448.0
WEIGHT_MLP_SCALE = MLP_SIZE ** -0.5 / 448.0

# Per-GEMM combined scale = input_scale * weight_scale.
S_QKV = NORM_SCALE * WEIGHT_H_SCALE
S_OUT = CONTEXT_SCALE * WEIGHT_H_SCALE
S_FC = NORM_SCALE * WEIGHT_H_SCALE
S_PROJ = MLP_SCALE * WEIGHT_MLP_SCALE
# attention scores: q@k.T / sqrt(head_dim) with both operands scaled by QKV_SCALE.
SCORE_SCALE = QKV_SCALE * QKV_SCALE / 8.0
# context requant: P @ v_q  * QKV_SCALE / CONTEXT_SCALE  == 1.0
CONTEXT_RATIO = QKV_SCALE / CONTEXT_SCALE

FP8_DTYPE = cutlass.Float8E4M3FN


@cute.jit
def gelu_new(x):
    c = cutlass.Float32(0.7978845608028654)  # sqrt(2/pi)
    t = x + cutlass.Float32(0.044715) * x * x * x
    return cutlass.Float32(0.5) * x * (cutlass.Float32(1.0) + cute.tanh(c * t))


@cute.kernel
def layer_norm_fp8_kernel(
    hidden: cute.Tensor,
    weight: cute.Tensor,
    bias: cute.Tensor,
    output: cute.Tensor,
    in_scale,
    out_scale,
):
    tid, _, _ = cute.arch.thread_idx()
    token, _, _ = cute.arch.block_idx()
    smem = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, 2 * THREADS, 4),
        cute.make_layout(2 * THREADS),
    )
    s = cutlass.Float32(0.0)
    ss = cutlass.Float32(0.0)
    for t in cutlass.range_constexpr(HIDDEN_SIZE // THREADS):
        f = t * THREADS + tid
        x = hidden[token, f].to(cutlass.Float32) * cutlass.Float32(in_scale)
        s = s + x
        ss = ss + x * x
    smem[tid] = s
    smem[THREADS + tid] = ss
    cute.arch.sync_threads()
    total = cutlass.Float32(0.0)
    for j in cutlass.range_constexpr(THREADS):
        total = total + smem[j]
    total_ss = cutlass.Float32(0.0)
    for j in cutlass.range_constexpr(THREADS):
        total_ss = total_ss + smem[THREADS + j]
    mean = total / cutlass.Float32(HIDDEN_SIZE)
    var = total_ss / cutlass.Float32(HIDDEN_SIZE) - mean * mean
    rstd = cute.rsqrt(var + cutlass.Float32(EPSILON))
    for t in cutlass.range_constexpr(HIDDEN_SIZE // THREADS):
        f = t * THREADS + tid
        x = hidden[token, f].to(cutlass.Float32) * cutlass.Float32(in_scale)
        norm = (x - mean) * rstd * weight[f] + bias[f]
        output[token, f] = norm / cutlass.Float32(out_scale)


@cute.kernel
def linear_fp8_kernel(
    a: cute.Tensor,
    w: cute.Tensor,
    bias: cute.Tensor,
    aux: cute.Tensor,
    out: cute.Tensor,
    kind,
    M,
    N,
    K,
    acc_scale,
    out_scale,
):
    tid, _, _ = cute.arch.thread_idx()
    bx, by, _ = cute.arch.block_idx()
    n0 = bx * THREADS + tid
    m = by
    if n0 < N:
        acc = cutlass.Float32(0.0)
        for k in cutlass.range(K):
            acc = acc + a[m, k].to(cutlass.Float32) * w[n0, k].to(cutlass.Float32)
        bv = bias[n0].to(cutlass.Float32)
        if cutlass.const_expr(kind == 0):
            # qkv projection -> FP8 workspace
            out[m, n0] = (acc * cutlass.Float32(acc_scale) + bv) / cutlass.Float32(out_scale)
        elif cutlass.const_expr(kind == 1):
            # attention output projection + first residual (hidden)
            rv = (
                aux[m, n0].to(cutlass.Float32) * cutlass.Float32(INPUT_SCALE)
                + acc * cutlass.Float32(acc_scale)
                + bv
            )
            out[m, n0] = rv
        elif cutlass.const_expr(kind == 2):
            # MLP fc + GELU -> FP8 workspace
            g = gelu_new(acc * cutlass.Float32(acc_scale) + bv)
            out[m, n0] = g / cutlass.Float32(out_scale)
        else:
            # MLP projection + second residual add
            out[m, n0] = (
                aux[m, n0].to(cutlass.Float32) + acc * cutlass.Float32(acc_scale) + bv
            )


@cute.kernel
def attention_score_kernel(qkv: cute.Tensor, scores: cute.Tensor):
    h, i, _ = cute.arch.block_idx()
    j = cute.arch.thread_idx()[0]
    acc = cutlass.Float32(0.0)
    for d in cutlass.range_constexpr(HEAD_DIM):
        acc = acc + qkv[i, h * HEAD_DIM + d].to(cutlass.Float32) * qkv[
            j, HIDDEN_SIZE + h * HEAD_DIM + d
        ].to(cutlass.Float32)
    scores[h, i, j] = acc * cutlass.Float32(SCORE_SCALE)


@cute.kernel
def causal_softmax_kernel(scores: cute.Tensor, probabilities: cute.Tensor):
    h, i, _ = cute.arch.block_idx()
    j = cute.arch.thread_idx()[0]
    smem = cute.make_tensor(
        cute.arch.alloc_smem(cutlass.Float32, THREADS, 4),
        cute.make_layout(THREADS),
    )
    val = scores[h, i, j].to(cutlass.Float32)
    causal = val if (j <= i) else cutlass.Float32(-3.0e38)
    smem[j] = causal
    cute.arch.sync_threads()
    mx = cutlass.Float32(-3.0e38)
    for jj in cutlass.range_constexpr(THREADS):
        vv = smem[jj]
        mx = vv if (vv > mx) else mx
    e = cute.exp(causal - mx)
    smem[j] = e
    cute.arch.sync_threads()
    total = cutlass.Float32(0.0)
    for jj in cutlass.range_constexpr(THREADS):
        total = total + smem[jj]
    probabilities[h, i, j] = e / total


@cute.kernel
def attention_context_kernel(
    probabilities: cute.Tensor,
    qkv: cute.Tensor,
    context: cute.Tensor,
):
    h, i, _ = cute.arch.block_idx()
    d = cute.arch.thread_idx()[0]
    acc = cutlass.Float32(0.0)
    for j in cutlass.range_constexpr(TOKENS):
        acc = acc + probabilities[h, i, j].to(cutlass.Float32) * qkv[
            j, 2 * HIDDEN_SIZE + h * HEAD_DIM + d
        ].to(cutlass.Float32)
    context[i, h * HEAD_DIM + d] = acc * cutlass.Float32(CONTEXT_RATIO)


@cute.jit
def gpt2_transformer_block(
    hidden: cute.Tensor,
    ln1_weight: cute.Tensor,
    ln1_bias: cute.Tensor,
    qkv_weight: cute.Tensor,
    qkv_bias: cute.Tensor,
    out_weight: cute.Tensor,
    out_bias: cute.Tensor,
    ln2_weight: cute.Tensor,
    ln2_bias: cute.Tensor,
    fc_weight: cute.Tensor,
    fc_bias: cute.Tensor,
    proj_weight: cute.Tensor,
    proj_bias: cute.Tensor,
    norm1_workspace: cute.Tensor,
    qkv_workspace: cute.Tensor,
    score_workspace: cute.Tensor,
    probability_workspace: cute.Tensor,
    context_workspace: cute.Tensor,
    residual_workspace: cute.Tensor,
    norm2_workspace: cute.Tensor,
    mlp_workspace: cute.Tensor,
    output: cute.Tensor,
):
    # n1 = layer_norm(hidden, ln1) -> FP8
    layer_norm_fp8_kernel(
        hidden, ln1_weight, ln1_bias, norm1_workspace, INPUT_SCALE, NORM_SCALE
    ).launch(grid=(TOKENS, 1, 1), block=(THREADS, 1, 1))

    # q, k, v = split(linear_fp8(n1, qkv)) -> FP8 qkv workspace
    linear_fp8_kernel(
        norm1_workspace,
        qkv_weight,
        qkv_bias,
        hidden,
        qkv_workspace,
        0,
        TOKENS,
        QKV_SIZE,
        HIDDEN_SIZE,
        S_QKV,
        QKV_SCALE,
    ).launch(grid=(QKV_SIZE // THREADS, TOKENS, 1), block=(THREADS, 1, 1))

    # scores = q @ k.T / sqrt(64)
    attention_score_kernel(qkv_workspace, score_workspace).launch(
        grid=(NUM_HEADS, TOKENS, 1), block=(THREADS, 1, 1)
    )
    # causal softmax
    causal_softmax_kernel(score_workspace, probability_workspace).launch(
        grid=(NUM_HEADS, TOKENS, 1), block=(THREADS, 1, 1)
    )
    # context = softmax @ v -> FP8
    attention_context_kernel(
        probability_workspace, qkv_workspace, context_workspace
    ).launch(grid=(NUM_HEADS, TOKENS, 1), block=(HEAD_DIM, 1, 1))

    # residual = hidden + linear_fp8(context, out)
    linear_fp8_kernel(
        context_workspace,
        out_weight,
        out_bias,
        hidden,
        residual_workspace,
        1,
        TOKENS,
        HIDDEN_SIZE,
        HIDDEN_SIZE,
        S_OUT,
        1.0,
    ).launch(grid=(HIDDEN_SIZE // THREADS, TOKENS, 1), block=(THREADS, 1, 1))

    # n2 = layer_norm(residual, ln2) -> FP8
    layer_norm_fp8_kernel(
        residual_workspace, ln2_weight, ln2_bias, norm2_workspace, 1.0, NORM_SCALE
    ).launch(grid=(TOKENS, 1, 1), block=(THREADS, 1, 1))

    # mlp = linear_fp8(gelu_new(linear_fp8(n2, fc)), proj)  (fc+gelu fused -> FP8)
    linear_fp8_kernel(
        norm2_workspace,
        fc_weight,
        fc_bias,
        residual_workspace,
        mlp_workspace,
        2,
        TOKENS,
        MLP_SIZE,
        HIDDEN_SIZE,
        S_FC,
        MLP_SCALE,
    ).launch(grid=(MLP_SIZE // THREADS, TOKENS, 1), block=(THREADS, 1, 1))

    # output = residual + mlp_proj
    linear_fp8_kernel(
        mlp_workspace,
        proj_weight,
        proj_bias,
        residual_workspace,
        output,
        3,
        TOKENS,
        HIDDEN_SIZE,
        MLP_SIZE,
        S_PROJ,
        1.0,
    ).launch(grid=(HIDDEN_SIZE // THREADS, TOKENS, 1), block=(THREADS, 1, 1))


class ModelNew:
    forward = staticmethod(gpt2_transformer_block)

# === CUTE_HARNESS_EVALUATOR_V1 ===
_CUTE_HARNESS_SEED = 0
_CUTE_HARNESS_WARMUP = 5
_CUTE_HARNESS_REPEATS = 50

import math as _cute_harness_math

import torch as _cute_harness_torch
import torch.nn.functional as _cute_harness_functional

import cutlass as _cute_harness_cutlass
import cutlass.cute as _cute_harness_cute
from cutlass.cute.runtime import from_dlpack as _cute_harness_from_dlpack
from cutlass.utils import (
    create_cute_tensor_for_fp8 as _cute_harness_create_fp8,
)


_CUTE_HARNESS_TOKENS = 128
_CUTE_HARNESS_HIDDEN = 768
_CUTE_HARNESS_HEADS = 12
_CUTE_HARNESS_HEAD_DIM = 64
_CUTE_HARNESS_MLP = 3072
_CUTE_HARNESS_QKV = 2304
_CUTE_HARNESS_EPSILON = 1.0e-5
_CUTE_HARNESS_INPUT_SCALE = 1.0 / 448.0
_CUTE_HARNESS_NORM_SCALE = 1.0 / 64.0
_CUTE_HARNESS_QKV_SCALE = 1.0 / 64.0
_CUTE_HARNESS_CONTEXT_SCALE = 1.0 / 64.0
_CUTE_HARNESS_MLP_SCALE = 1.0 / 64.0
_CUTE_HARNESS_WEIGHT_H_BOUND = _CUTE_HARNESS_HIDDEN ** -0.5
_CUTE_HARNESS_WEIGHT_MLP_BOUND = _CUTE_HARNESS_MLP ** -0.5
_CUTE_HARNESS_WEIGHT_H_SCALE = _CUTE_HARNESS_WEIGHT_H_BOUND / 448.0
_CUTE_HARNESS_WEIGHT_MLP_SCALE = _CUTE_HARNESS_WEIGHT_MLP_BOUND / 448.0
_CUTE_HARNESS_FP8_DTYPE = _cute_harness_cutlass.Float8E4M3FN


def _cute_harness_fp8_tensor(source, scale):
    storage = _cute_harness_torch.empty(
        source.shape,
        device="cuda",
        dtype=_cute_harness_torch.uint8,
    )
    tensor = _cute_harness_create_fp8(
        storage,
        _CUTE_HARNESS_FP8_DTYPE,
        1,
        source / scale,
    )
    return storage, tensor


def _cute_harness_empty_fp8(shape):
    source = _cute_harness_torch.zeros(
        shape,
        device="cuda",
        dtype=_cute_harness_torch.float32,
    )
    return _cute_harness_fp8_tensor(source, 1.0)


def _cute_harness_scaled_linear(
    activation,
    weight,
    activation_scale,
    weight_scale,
    bias,
):
    scale_a = _cute_harness_torch.tensor(
        activation_scale,
        device="cuda",
        dtype=_cute_harness_torch.float32,
    )
    scale_b = _cute_harness_torch.tensor(
        weight_scale,
        device="cuda",
        dtype=_cute_harness_torch.float32,
    )
    return _cute_harness_torch._scaled_mm(
        activation,
        weight.t(),
        scale_a=scale_a,
        scale_b=scale_b,
        out_dtype=_cute_harness_torch.float32,
    ) + bias


def main():
    if not _cute_harness_torch.cuda.is_available():
        raise RuntimeError("A Blackwell CUDA device is required")

    _cute_harness_torch.manual_seed(_CUTE_HARNESS_SEED)
    hidden_source = _cute_harness_torch.empty(
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_HIDDEN),
        device="cuda",
        dtype=_cute_harness_torch.float32,
    ).uniform_(-1.0, 1.0)
    ln1_weight = 1.0 + 0.02 * _cute_harness_torch.randn(
        (_CUTE_HARNESS_HIDDEN,), device="cuda"
    )
    ln1_bias = 0.02 * _cute_harness_torch.randn(
        (_CUTE_HARNESS_HIDDEN,), device="cuda"
    )
    ln2_weight = 1.0 + 0.02 * _cute_harness_torch.randn(
        (_CUTE_HARNESS_HIDDEN,), device="cuda"
    )
    ln2_bias = 0.02 * _cute_harness_torch.randn(
        (_CUTE_HARNESS_HIDDEN,), device="cuda"
    )
    qkv_bias = 0.02 * _cute_harness_torch.randn(
        (_CUTE_HARNESS_QKV,), device="cuda"
    )
    out_bias = 0.02 * _cute_harness_torch.randn(
        (_CUTE_HARNESS_HIDDEN,), device="cuda"
    )
    fc_bias = 0.02 * _cute_harness_torch.randn(
        (_CUTE_HARNESS_MLP,), device="cuda"
    )
    proj_bias = 0.02 * _cute_harness_torch.randn(
        (_CUTE_HARNESS_HIDDEN,), device="cuda"
    )

    qkv_weight_source = _cute_harness_torch.empty(
        (_CUTE_HARNESS_QKV, _CUTE_HARNESS_HIDDEN), device="cuda"
    ).uniform_(
        -_CUTE_HARNESS_WEIGHT_H_BOUND,
        _CUTE_HARNESS_WEIGHT_H_BOUND,
    )
    out_weight_source = _cute_harness_torch.empty(
        (_CUTE_HARNESS_HIDDEN, _CUTE_HARNESS_HIDDEN), device="cuda"
    ).uniform_(
        -_CUTE_HARNESS_WEIGHT_H_BOUND,
        _CUTE_HARNESS_WEIGHT_H_BOUND,
    )
    fc_weight_source = _cute_harness_torch.empty(
        (_CUTE_HARNESS_MLP, _CUTE_HARNESS_HIDDEN), device="cuda"
    ).uniform_(
        -_CUTE_HARNESS_WEIGHT_H_BOUND,
        _CUTE_HARNESS_WEIGHT_H_BOUND,
    )
    proj_weight_source = _cute_harness_torch.empty(
        (_CUTE_HARNESS_HIDDEN, _CUTE_HARNESS_MLP), device="cuda"
    ).uniform_(
        -_CUTE_HARNESS_WEIGHT_MLP_BOUND,
        _CUTE_HARNESS_WEIGHT_MLP_BOUND,
    )

    hidden_storage, hidden = _cute_harness_fp8_tensor(
        hidden_source, _CUTE_HARNESS_INPUT_SCALE
    )
    qkv_weight_storage, qkv_weight = _cute_harness_fp8_tensor(
        qkv_weight_source, _CUTE_HARNESS_WEIGHT_H_SCALE
    )
    out_weight_storage, out_weight = _cute_harness_fp8_tensor(
        out_weight_source, _CUTE_HARNESS_WEIGHT_H_SCALE
    )
    fc_weight_storage, fc_weight = _cute_harness_fp8_tensor(
        fc_weight_source, _CUTE_HARNESS_WEIGHT_H_SCALE
    )
    proj_weight_storage, proj_weight = _cute_harness_fp8_tensor(
        proj_weight_source, _CUTE_HARNESS_WEIGHT_MLP_SCALE
    )

    norm1_workspace_storage, norm1_workspace = _cute_harness_empty_fp8(
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_HIDDEN)
    )
    qkv_workspace_storage, qkv_workspace = _cute_harness_empty_fp8(
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_QKV)
    )
    context_workspace_storage, context_workspace = _cute_harness_empty_fp8(
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_HIDDEN)
    )
    norm2_workspace_storage, norm2_workspace = _cute_harness_empty_fp8(
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_HIDDEN)
    )
    mlp_workspace_storage, mlp_workspace = _cute_harness_empty_fp8(
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_MLP)
    )

    score_workspace_storage = _cute_harness_torch.empty(
        (_CUTE_HARNESS_HEADS * _CUTE_HARNESS_TOKENS, _CUTE_HARNESS_TOKENS),
        device="cuda",
        dtype=_cute_harness_torch.float32,
    )
    probability_workspace_storage = _cute_harness_torch.empty_like(
        score_workspace_storage
    )
    residual_workspace_storage = _cute_harness_torch.empty(
        (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_HIDDEN),
        device="cuda",
        dtype=_cute_harness_torch.float32,
    )
    output_storage = _cute_harness_torch.empty_like(
        residual_workspace_storage
    )
    score_workspace = _cute_harness_from_dlpack(
        score_workspace_storage
    ).mark_layout_dynamic(leading_dim=1)
    probability_workspace = _cute_harness_from_dlpack(
        probability_workspace_storage
    ).mark_layout_dynamic(leading_dim=1)
    residual_workspace = _cute_harness_from_dlpack(
        residual_workspace_storage
    ).mark_layout_dynamic(leading_dim=1)
    output = _cute_harness_from_dlpack(output_storage).mark_layout_dynamic(
        leading_dim=1
    )

    parameter_tensors = (
        _cute_harness_from_dlpack(ln1_weight),
        _cute_harness_from_dlpack(ln1_bias),
        qkv_weight,
        _cute_harness_from_dlpack(qkv_bias),
        out_weight,
        _cute_harness_from_dlpack(out_bias),
        _cute_harness_from_dlpack(ln2_weight),
        _cute_harness_from_dlpack(ln2_bias),
        fc_weight,
        _cute_harness_from_dlpack(fc_bias),
        proj_weight,
        _cute_harness_from_dlpack(proj_bias),
    )
    arguments = (
        hidden,
        *parameter_tensors,
        norm1_workspace,
        qkv_workspace,
        score_workspace,
        probability_workspace,
        context_workspace,
        residual_workspace,
        norm2_workspace,
        mlp_workspace,
        output,
    )
    compiled = _cute_harness_cute.compile(
        gpt2_transformer_block,
        *arguments,
    )
    for _ in range(_CUTE_HARNESS_WARMUP):
        compiled(*arguments)
    _cute_harness_torch.cuda.synchronize()

    timings_ms = []
    for _ in range(_CUTE_HARNESS_REPEATS):
        start = _cute_harness_torch.cuda.Event(enable_timing=True)
        end = _cute_harness_torch.cuda.Event(enable_timing=True)
        start.record()
        compiled(*arguments)
        end.record()
        end.synchronize()
        timings_ms.append(start.elapsed_time(end))
    kernel_time_ms = sorted(timings_ms)[len(timings_ms) // 2]

    hidden_fp8 = hidden_storage.view(_cute_harness_torch.float8_e4m3fn)
    qkv_weight_fp8 = qkv_weight_storage.view(
        _cute_harness_torch.float8_e4m3fn
    )
    out_weight_fp8 = out_weight_storage.view(
        _cute_harness_torch.float8_e4m3fn
    )
    fc_weight_fp8 = fc_weight_storage.view(
        _cute_harness_torch.float8_e4m3fn
    )
    proj_weight_fp8 = proj_weight_storage.view(
        _cute_harness_torch.float8_e4m3fn
    )
    hidden_dequantized = hidden_fp8.float() * _CUTE_HARNESS_INPUT_SCALE
    norm1_reference = _cute_harness_functional.layer_norm(
        hidden_dequantized,
        (_CUTE_HARNESS_HIDDEN,),
        ln1_weight,
        ln1_bias,
        _CUTE_HARNESS_EPSILON,
    )
    norm1_fp8 = (norm1_reference / _CUTE_HARNESS_NORM_SCALE).to(
        _cute_harness_torch.float8_e4m3fn
    )
    qkv_reference = _cute_harness_scaled_linear(
        norm1_fp8,
        qkv_weight_fp8,
        _CUTE_HARNESS_NORM_SCALE,
        _CUTE_HARNESS_WEIGHT_H_SCALE,
        qkv_bias,
    )
    qkv_fp8 = (qkv_reference / _CUTE_HARNESS_QKV_SCALE).to(
        _cute_harness_torch.float8_e4m3fn
    )
    qkv_dequantized = qkv_fp8.float() * _CUTE_HARNESS_QKV_SCALE
    query, key, value = qkv_dequantized.reshape(
        _CUTE_HARNESS_TOKENS,
        3,
        _CUTE_HARNESS_HEADS,
        _CUTE_HARNESS_HEAD_DIM,
    ).unbind(dim=1)
    scores = _cute_harness_torch.einsum(
        "thd,shd->hts", query, key
    ) / _cute_harness_math.sqrt(_CUTE_HARNESS_HEAD_DIM)
    causal_mask = _cute_harness_torch.triu(
        _cute_harness_torch.ones(
            (_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_TOKENS),
            device="cuda",
            dtype=_cute_harness_torch.bool,
        ),
        diagonal=1,
    )
    probabilities = scores.masked_fill(causal_mask, -float("inf")).softmax(
        dim=-1
    )
    context_reference = _cute_harness_torch.einsum(
        "hts,shd->thd", probabilities, value
    ).reshape(_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_HIDDEN)
    context_fp8 = (
        context_reference / _CUTE_HARNESS_CONTEXT_SCALE
    ).to(_cute_harness_torch.float8_e4m3fn)
    residual_reference = hidden_dequantized + _cute_harness_scaled_linear(
        context_fp8,
        out_weight_fp8,
        _CUTE_HARNESS_CONTEXT_SCALE,
        _CUTE_HARNESS_WEIGHT_H_SCALE,
        out_bias,
    )
    norm2_reference = _cute_harness_functional.layer_norm(
        residual_reference,
        (_CUTE_HARNESS_HIDDEN,),
        ln2_weight,
        ln2_bias,
        _CUTE_HARNESS_EPSILON,
    )
    norm2_fp8 = (norm2_reference / _CUTE_HARNESS_NORM_SCALE).to(
        _cute_harness_torch.float8_e4m3fn
    )
    fc_reference = _cute_harness_scaled_linear(
        norm2_fp8,
        fc_weight_fp8,
        _CUTE_HARNESS_NORM_SCALE,
        _CUTE_HARNESS_WEIGHT_H_SCALE,
        fc_bias,
    )
    mlp_fp8 = (
        _cute_harness_functional.gelu(fc_reference, approximate="tanh")
        / _CUTE_HARNESS_MLP_SCALE
    ).to(_cute_harness_torch.float8_e4m3fn)
    quantized_reference = residual_reference + _cute_harness_scaled_linear(
        mlp_fp8,
        proj_weight_fp8,
        _CUTE_HARNESS_MLP_SCALE,
        _CUTE_HARNESS_WEIGHT_MLP_SCALE,
        proj_bias,
    )

    fp32_norm1 = _cute_harness_functional.layer_norm(
        hidden_source,
        (_CUTE_HARNESS_HIDDEN,),
        ln1_weight,
        ln1_bias,
        _CUTE_HARNESS_EPSILON,
    )
    fp32_qkv = fp32_norm1 @ qkv_weight_source.t() + qkv_bias
    fp32_query, fp32_key, fp32_value = fp32_qkv.reshape(
        _CUTE_HARNESS_TOKENS,
        3,
        _CUTE_HARNESS_HEADS,
        _CUTE_HARNESS_HEAD_DIM,
    ).unbind(dim=1)
    fp32_scores = _cute_harness_torch.einsum(
        "thd,shd->hts", fp32_query, fp32_key
    ) / _cute_harness_math.sqrt(_CUTE_HARNESS_HEAD_DIM)
    fp32_probabilities = fp32_scores.masked_fill(
        causal_mask, -float("inf")
    ).softmax(dim=-1)
    fp32_context = _cute_harness_torch.einsum(
        "hts,shd->thd", fp32_probabilities, fp32_value
    ).reshape(_CUTE_HARNESS_TOKENS, _CUTE_HARNESS_HIDDEN)
    fp32_residual = (
        hidden_source + fp32_context @ out_weight_source.t() + out_bias
    )
    fp32_norm2 = _cute_harness_functional.layer_norm(
        fp32_residual,
        (_CUTE_HARNESS_HIDDEN,),
        ln2_weight,
        ln2_bias,
        _CUTE_HARNESS_EPSILON,
    )
    fp32_mlp = _cute_harness_functional.gelu(
        fp32_norm2 @ fc_weight_source.t() + fc_bias,
        approximate="tanh",
    )
    fp32_reference = (
        fp32_residual + fp32_mlp @ proj_weight_source.t() + proj_bias
    )

    quantized_max_abs = (output_storage - quantized_reference).abs().max().item()
    sample_rows = _cute_harness_torch.tensor(
        [0, 1, 31, 63, 64, 95, 127], device="cuda"
    )
    sample_columns = _cute_harness_torch.tensor(
        [0, 63, 64, 255, 511, 767], device="cuda"
    )
    sample_actual = output_storage.index_select(0, sample_rows).index_select(
        1, sample_columns
    )
    sample_reference = fp32_reference.index_select(
        0, sample_rows
    ).index_select(1, sample_columns)
    fp32_sample_max_abs = (sample_actual - sample_reference).abs().max().item()
    if (
        not _cute_harness_torch.isfinite(output_storage).all().item()
        or quantized_max_abs > 0.05
        or fp32_sample_max_abs > 0.5
    ):
        raise RuntimeError(
            f"validation failed: quantized_abs={quantized_max_abs:.6f}, "
            f"fp32_sample_abs={fp32_sample_max_abs:.6f}"
        )

    print(
        "task=model_gpt2_small_transformer_block_fp8 "
        f"quantized_max_abs={quantized_max_abs:.6f} "
        f"fp32_sample_max_abs={fp32_sample_max_abs:.6f} "
        f"kernel_time_ms={kernel_time_ms:.6f} PASS"
    )
    _cute_harness_torch.cuda.synchronize()


main()
